﻿from sqlalchemy import or_


_EDU_ALIASES = {
    "博士": (
        "博士",
        "博士后",
        "phd",
        "ph.d",
        "doctor",
        "doctoral",
        "dba",
        "硕博",
    ),
    "硕士": (
        "硕士",
        "研究生",
        "master",
        "msc",
        "mba",
        "master degree",
    ),
    "本科": (
        "本科",
        "学士",
        "bachelor",
        "b.sc",
        "beng",
    ),
    "大专": (
        "大专",
        "专科",
        "college",
        "associate",
    ),
    "中专": (
        "中专",
        "中技",
        "技校",
        "secondary vocational",
    ),
    "高中": (
        "高中",
        "high school",
    ),
    "不限": (
        "不限",
        "无要求",
        "学历不限",
        "学历无要求",
        "no requirement",
        "not required",
        "any education",
    ),
}

_EDU_MATCH_ORDER = ("博士", "硕士", "本科", "大专", "中专", "高中", "不限")


def normalize_edu_level(edu_text):
    text = str(edu_text or "").strip().lower()
    if not text:
        return "不限"
    for level in _EDU_MATCH_ORDER:
        aliases = _EDU_ALIASES.get(level, ())
        if any(alias.lower() in text for alias in aliases):
            return level
    return "不限"


def _build_edu_aliases(level):
    canonical = normalize_edu_level(level)
    aliases = list(_EDU_ALIASES.get(canonical, ()))
    if canonical and canonical not in aliases:
        aliases.append(canonical)
    seen = set()
    unique = []
    for token in aliases:
        token = str(token or "").strip()
        if not token:
            continue
        key = token.lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(token)
    return canonical, unique


def apply_edu_filter(query, edu_column, edu_value, fallback_columns=None):
    canonical, aliases = _build_edu_aliases(edu_value)
    if not canonical or canonical == "不限":
        return query
    columns = [edu_column]
    for col in (fallback_columns or []):
        if col is not None:
            columns.append(col)
    conditions = []
    for column in columns:
        for token in aliases:
            conditions.append(column.like(f"%{token}%"))
    if not conditions:
        return query
    return query.filter(or_(*conditions))

