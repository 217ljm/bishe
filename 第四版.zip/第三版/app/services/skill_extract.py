import os
import re
from functools import lru_cache


_TAG_SPLIT_RE = re.compile(r"[,，、;/|\\\s]+")
_TOKEN_CLEAN_RE = re.compile(r"[^0-9A-Za-z+#.\-\u4e00-\u9fa5]")
_ASCII_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9+#.\-]{1,30}")

_SKILL_STOPWORDS = {
    "负责", "熟悉", "掌握", "了解", "相关", "经验", "能力", "岗位", "职位", "工作", "要求",
    "优先", "以上", "以下", "不限", "团队", "沟通", "开发", "系统", "平台", "公司",
}


def _default_dict_path() -> str:
    return os.path.join(os.path.dirname(__file__), "dict.txt")


@lru_cache(maxsize=8)
def load_skill_dict(path: str | None = None) -> tuple[str, ...]:
    """
    读取技能词典（带缓存），返回按文件顺序排列的词列表。
    词典每行支持：skill / skill weight pos。
    """
    real_path = path or _default_dict_path()
    if not os.path.exists(real_path):
        return tuple()

    ordered = []
    seen = set()
    with open(real_path, "r", encoding="utf-8", errors="ignore") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            token = line.split()[0].strip()
            if not token:
                continue
            norm = _normalize_skill_token(token)
            if not norm:
                continue
            key = norm.lower()
            if key in seen:
                continue
            seen.add(key)
            ordered.append(norm)
    return tuple(ordered)


def _normalize_skill_token(token: str) -> str:
    s = str(token or "").strip()
    if not s:
        return ""
    s = _TOKEN_CLEAN_RE.sub("", s)
    if not s:
        return ""

    # 英文技能统一小写；中文保持原样
    if _ASCII_TOKEN_RE.fullmatch(s):
        s = s.lower()

    if len(s) < 2 or len(s) > 32:
        return ""
    if s in _SKILL_STOPWORDS:
        return ""
    if s.isdigit():
        return ""
    return s


def _extract_from_tags(tags: str | list | tuple | None) -> list[str]:
    if tags is None:
        return []
    parts = []
    if isinstance(tags, (list, tuple)):
        for item in tags:
            parts.extend(_TAG_SPLIT_RE.split(str(item or "")))
    else:
        parts = _TAG_SPLIT_RE.split(str(tags))

    out = []
    seen = set()
    for p in parts:
        t = _normalize_skill_token(p)
        if not t:
            continue
        key = t.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(t)
    return out


def _extract_from_desc(desc: str | None, dict_terms: tuple[str, ...]) -> list[str]:
    text = str(desc or "")
    if not text or not dict_terms:
        return []
    lower_text = text.lower()
    out = []
    for term in dict_terms:
        # 英文技能大小写不敏感，中文直接包含判断
        if re.search(r"[A-Za-z]", term):
            if term.lower() in lower_text:
                out.append(term)
        else:
            if term in text:
                out.append(term)
    return out


def extract_skills(tags: str | list | None, desc: str | None, dict_path: str | None = None) -> list[str]:
    """
    提取并规范化技能词：
    1) 优先 tags 拆分
    2) desc 按词典匹配补全
    3) 去重并保持稳定顺序（tags 在前，词典命中在后）
    """
    tag_skills = _extract_from_tags(tags)
    desc_hits = _extract_from_desc(desc, load_skill_dict(dict_path))

    out = []
    seen = set()
    for token in [*tag_skills, *desc_hits]:
        norm = _normalize_skill_token(token)
        if not norm:
            continue
        key = norm.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(norm)
    return out

