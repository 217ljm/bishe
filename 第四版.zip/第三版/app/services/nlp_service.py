# -*- coding: utf-8 -*-
import jieba
import os
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class NLPService:
    def __init__(self):
        self.dict_path = os.path.join(os.path.dirname(__file__), 'dict.txt')
        if os.path.exists(self.dict_path):
            jieba.load_userdict(self.dict_path)
            logger.info("已加载自定义词典")
        else:
            logger.warning("未找到自定义词典 dict.txt，将使用默认分词")

        self.stop_words = set(['的', '了', '和', '是', '就', '都', '而', '及', '与', '在', '对', '等', '能', '会', '要', '有', '无', '为', '以', '或', '或者', '熟悉', '精通', '了解', '具备', '具有', '优先', '相关', '经验', '工作', '负责', '参与', '使用', '进行', '完成', '编写', '开发', '维护', '设计', '实现', '优化', '解决', '技术', '业务', '系统', '平台', '项目', '产品', '服务', '应用', '模块', '功能', '代码', '文档', '规范', '流程', '团队', '沟通', '协作', '能力', '精神', '意识', '责任心', '抗压', '学习', '能够', '良好', '强', '以上', '以下', '以及', '包括', '不限', '岗位', '职责', '任职', '要求'])

    def clean_text(self, text):
        """清洗文本，去除符号等"""
        if not text:
            return ""
        # 去除 HTML 标签
        text = re.sub(r'<[^>]+>', '', text)
        # 去除特殊字符，只保留中英文和数字
        text = re.sub(r'[^\w\s\u4e00-\u9fa5]', ' ', text)
        return text.lower().strip()

    def segmented_text(self, text):
        """分词并去停用词"""
        text = self.clean_text(text)
        words = jieba.cut(text)
        return " ".join([w for w in words if w not in self.stop_words and len(w.strip()) > 1])

    def extract_keywords(self, text, top_k=5):
        """提取关键词 (简化版，仅基于词频/词长)"""
        # 注意：单个文本无法做真正的 TF-IDF，这里仅作分词清洗
        if not text:
            return []
        
        seg = self.segmented_text(text)
        words = seg.split()
        
        # 统计词频
        freq = {}
        for w in words:
            # 给予英文单词更高权重 (通常是技术栈)
            weight = 1.5 if re.match(r'[a-zA-Z]+', w) else 1.0
            freq[w] = freq.get(w, 0) + weight
            
        # 排序
        sorted_words = sorted(freq.items(), key=lambda x: x[1], reverse=True)
        return [w[0] for w in sorted_words[:top_k]]
    def _is_noise_gap_token(self, token):
        """过滤不适合作为技能缺口展示的泛词/城市词/噪声词。"""
        t = str(token or '').strip().lower()
        if not t:
            return True
        if len(t) < 2 or len(t) > 24:
            return True
        if t.isdigit():
            return True
        if re.fullmatch(r'\d+[kKwW]?[-~]\d+[kKwW]?', t):
            return True
        if re.fullmatch(r'[a-z]{1,2}', t):
            return True

        noise_terms = {
            '北京', '上海', '深圳', '广州', '杭州', '成都', '西安', '南京', '武汉', '苏州', '全国',
            '公司', '服务', '服务公司', '专业', '学历', '本科', '大专', '硕士', '博士', '应届',
            '岗位', '职位', '工作', '要求', '相关', '方向', '业务', '项目', '平台', '系统', '模块',
            '能力', '经验', '以上', '以下', '优先', '负责', '良好', '沟通', '团队'
        }
        if t in noise_terms:
            return True
        if t.endswith('公司') and len(t) <= 4:
            return True
        if t.endswith('专业') and len(t) <= 6:
            return True
        return False

    def calculate_match_score(self, target_profile, job_list):
        """
        计算匹配度
        :param target_profile: 用户画像字符串 (包含技能、目标岗位等)
        :param job_list: 职位列表，每个元素为 dict {'id': ..., 'text': ...}
        :return: 包含分数的职位列表 (dict 增加 'score' 和 'match_details')
        """
        if not job_list or not target_profile:
            return job_list
        
        # 准备语料
        documents = [self.segmented_text(target_profile)]
        job_texts = [self.segmented_text(j['text']) for j in job_list]
        documents.extend(job_texts)
        
        try:
            # TF-IDF 向量化
            vectorizer = TfidfVectorizer()
            tfidf_matrix = vectorizer.fit_transform(documents)
            
            # 计算余弦相似度 (第一行是用户，其余是职位)
            user_vec = tfidf_matrix[0:1]
            job_vecs = tfidf_matrix[1:]
            
            similarities = cosine_similarity(user_vec, job_vecs).flatten()
            
            # 获取特征词用于分析 (Gap Analysis)
            feature_names = vectorizer.get_feature_names_out()
            user_vector_array = user_vec.toarray()[0]
            
            # 用户的高权重词 (掌握的技能)
            user_top_indices = user_vector_array.argsort()[-20:][::-1]
            user_keywords = set([
                feature_names[i]
                for i in user_top_indices
                if user_vector_array[i] > 0 and not self._is_noise_gap_token(feature_names[i])
            ])
            
            for i, job in enumerate(job_list):
                # 归一化分数 0-100
                sim_score = similarities[i]
                final_score = int(sim_score * 100)
                
                # 限制在合理区间 (避免过低或过高)
                # 基础分 40，最高加成到 95
                final_score = 40 + int(sim_score * 60)
                final_score = min(99, max(40, final_score))
                
                job['nlp_score'] = final_score
                
                # 差异分析
                job_vec_array = job_vecs[i].toarray()[0]
                job_top_indices = job_vec_array.argsort()[-10:][::-1]
                job_keywords = [
                    feature_names[idx]
                    for idx in job_top_indices
                    if job_vec_array[idx] > 0 and not self._is_noise_gap_token(feature_names[idx])
                ]
                
                # 匹配的词
                matched = [w for w in job_keywords if w in user_keywords][:5]
                # 缺失的词 (用户没有，但职位强调)
                missing = [w for w in job_keywords if w not in user_keywords][:3]
                
                job['analysis'] = {
                     'matched': matched,
                     'missing': missing
                }
                
        except Exception as e:
            logger.error(f"NLP 计算失败: {e}")
            for job in job_list:
                job['nlp_score'] = 60 # 默认分
                job['analysis'] = {'matched': [], 'missing': []}
                
        return job_list

    def diagnose_resume(self, resume_text, job_text):
        """
        深度简历诊断
        :param resume_text: 简历/用户画像文本
        :param job_text: JD 文本
        :return: dict {score, missing, optimized_text}
        """
        if not resume_text or not job_text:
            return {'score': 0, 'missing': [], 'advice': '数据不足'}
            
        # 1. 提取关键词
        resume_kws = set(self.extract_keywords(resume_text, top_k=20))
        job_kws = self.extract_keywords(job_text, top_k=15)
        
        # 2. 对比
        missing = [kw for kw in job_kws if kw not in resume_kws]
        matched = [kw for kw in job_kws if kw in resume_kws]
        
        # 3. 评分
        match_rate = len(matched) / len(job_kws) if job_kws else 0
        score = int(match_rate * 100)
        
        # 4. 生成建议
        advice = []
        if missing:
            advice.append(f"您的简历缺失关键技能：{', '.join(missing[:3])}")
            advice.append("建议在项目经历中补充相关实践描述。")
        else:
            advice.append("简历与该岗位核心技能匹配度较高，建议突出具体成果。")
            
        return {
            'score': score,
            'missing': missing,
            'matched': matched,
            'advice': advice
        }

nlp_service = NLPService()
