﻿import re
from sqlalchemy import or_


_CITY_ALIASES = {
    "北京": ("北京", "北京市", "beijing"),
    "上海": ("上海", "上海市", "shanghai"),
    "广州": ("广州", "广州市", "guangzhou"),
    "深圳": ("深圳", "深圳市", "shenzhen"),
    "杭州": ("杭州", "杭州市", "hangzhou"),
    "成都": ("成都", "成都市", "chengdu"),
    "武汉": ("武汉", "武汉市", "wuhan"),
}

_SOURCE_ALIASES = {
    "猎聘": ("猎聘", "猎聘网", "liepin", "lietou"),
    "BOSS直聘": ("BOSS直聘", "Boss直聘", "boss直聘", "boss", "bosszhipin"),
    "前程无忧": ("前程无忧", "51job", "job51", "51"),
    "手动导入": ("手动导入", "manual", "import"),
}

_EXP_ALIASES = {
    "应届": ("应届", "应届生", "在校", "校招", "实习", "intern", "entry"),
    "1年以内": ("1年以内", "1年", "一年", "0-1年", "1年以下"),
    "1-3年": ("1-3年", "1~3年", "1至3年", "1到3年", "1-3"),
    "3-5年": ("3-5年", "3~5年", "3至5年", "3到5年", "3-5"),
    "5-10年": ("5-10年", "5~10年", "5至10年", "5到10年", "5-10"),
    "10年以上": ("10年以上", "10+年", "10年以上经验", "10年及以上"),
    "不限": ("不限", "经验不限", "无经验", "no requirement"),
}


def _clean_text(value):
    return str(value or "").strip()


def _dedupe_tokens(tokens):
    seen = set()
    result = []
    for token in tokens:
        val = _clean_text(token)
        if not val:
            continue
        key = val.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(val)
    return result


def _normalize_common_text(value):
    text = _clean_text(value).lower()
    text = text.replace("（", "(").replace("）", ")")
    text = text.replace(" ", "")
    return text


def normalize_city_value(city_text):
    raw = _clean_text(city_text)
    if not raw:
        return ""
    text = _normalize_common_text(raw)
    if text in ("", "all", "全部", "不限", "全国"):
        return ""

    city_base = raw.replace("特别行政区", "").replace("自治区", "").replace("省", "").strip()
    city_base = city_base[:-1] if city_base.endswith("市") and len(city_base) > 2 else city_base
    norm_base = _normalize_common_text(city_base)
    for canonical, aliases in _CITY_ALIASES.items():
        if norm_base == _normalize_common_text(canonical):
            return canonical
        if any(_normalize_common_text(alias) in text for alias in aliases):
            return canonical
    return city_base


def normalize_source_value(source_text):
    raw = _clean_text(source_text)
    if not raw:
        return ""
    text = _normalize_common_text(raw)
    if text in ("", "all", "全部", "不限"):
        return ""
    for canonical, aliases in _SOURCE_ALIASES.items():
        if any(_normalize_common_text(alias) in text for alias in aliases):
            return canonical
    return raw


def normalize_exp_level(exp_text):
    raw = _clean_text(exp_text)
    if not raw:
        return ""
    text = _normalize_common_text(raw)
    if text in ("", "all", "全部", "不限", "经验不限", "无经验"):
        return ""

    for canonical, aliases in _EXP_ALIASES.items():
        if any(_normalize_common_text(alias) in text for alias in aliases):
            return canonical

    range_match = re.search(r"(\d+)\s*[-~至到]\s*(\d+)", raw)
    if range_match:
        low = int(range_match.group(1))
        high = int(range_match.group(2))
        if high <= 1:
            return "1年以内"
        if low <= 1 and high <= 3:
            return "1-3年"
        if low <= 3 and high <= 5:
            return "3-5年"
        if low <= 5 and high <= 10:
            return "5-10年"
        return "10年以上"

    single_match = re.search(r"(\d+)", raw)
    if single_match:
        val = int(single_match.group(1))
        if "以上" in raw or "及以上" in raw or val >= 10:
            return "10年以上"
        if val <= 1:
            return "1年以内"
        if val <= 3:
            return "1-3年"
        if val <= 5:
            return "3-5年"
        if val <= 10:
            return "5-10年"
        return "10年以上"

    return raw


def _apply_like_filter(query, primary_column, tokens, fallback_columns=None):
    token_list = _dedupe_tokens(tokens)
    if not token_list:
        return query
    columns = [primary_column] + [col for col in (fallback_columns or []) if col is not None]
    conditions = [col.like(f"%{token}%") for col in columns for token in token_list]
    if not conditions:
        return query
    return query.filter(or_(*conditions))


def apply_city_filter(query, city_column, city_value, fallback_columns=None):
    canonical = normalize_city_value(city_value)
    if not canonical:
        return query
    aliases = list(_CITY_ALIASES.get(canonical, ()))
    tokens = [canonical, f"{canonical}市", city_value] + aliases
    return _apply_like_filter(query, city_column, tokens, fallback_columns=fallback_columns)


def apply_source_filter(query, source_column, source_value, fallback_columns=None):
    canonical = normalize_source_value(source_value)
    if not canonical:
        return query
    aliases = list(_SOURCE_ALIASES.get(canonical, ()))
    tokens = [canonical, source_value] + aliases
    return _apply_like_filter(query, source_column, tokens, fallback_columns=fallback_columns)


def apply_exp_filter(query, exp_column, exp_value, fallback_columns=None):
    canonical = normalize_exp_level(exp_value)
    if not canonical:
        return query
    aliases = list(_EXP_ALIASES.get(canonical, ()))
    tokens = [canonical, exp_value] + aliases
    return _apply_like_filter(query, exp_column, tokens, fallback_columns=fallback_columns)

