import logging
import os
import socket
import time
import urllib.request
import urllib.error
import json

from openai import OpenAI


# 本地 Ollama（优先）
OLLAMA_API_KEY = "ollama"
OLLAMA_BASE_URL = "http://localhost:11434/v1"
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:7b")

# 云端兼容 OpenAI（可选兜底）
FALLBACK_API_KEY = os.environ.get("SILICONFLOW_API_KEY", "")
FALLBACK_BASE_URL = "https://api.siliconflow.cn/v1"
FALLBACK_MODEL = os.environ.get("FALLBACK_MODEL", "Qwen/Qwen2.5-7B-Instruct")


class AIService:
    """AI 分析服务：优先本地 Ollama，失败时可选云端兜底。"""

    def __init__(self, mode="ollama"):
        self.mode = mode
        # 本地 7B 模型在 CPU 或冷启动时首包较慢，默认超时不能过短
        self.request_timeout_sec = float(os.environ.get("AI_TIMEOUT_SEC", "60"))
        self.client = OpenAI(
            api_key=OLLAMA_API_KEY,
            base_url=OLLAMA_BASE_URL,
            max_retries=0,
            timeout=self.request_timeout_sec,
        )
        self.default_model = OLLAMA_MODEL
        self.fallback_client = None
        if FALLBACK_API_KEY:
            try:
                self.fallback_client = OpenAI(
                    api_key=FALLBACK_API_KEY,
                    base_url=FALLBACK_BASE_URL,
                    max_retries=0,
                    timeout=self.request_timeout_sec,
                )
            except Exception:
                self.fallback_client = None

        self._last_health_check_ts = 0.0
        self._last_health_ok = None

    def _is_ollama_reachable(self, ttl_sec=20):
        now = time.time()
        if self._last_health_ok is not None and (now - self._last_health_check_ts) < ttl_sec:
            return self._last_health_ok

        try:
            with socket.create_connection(("127.0.0.1", 11434), timeout=0.8):
                self._last_health_ok = True
        except Exception:
            self._last_health_ok = False
        self._last_health_check_ts = now
        return self._last_health_ok

    def _is_model_available(self, model_name, timeout_sec=1.2):
        """快速检查 Ollama 是否已拉取指定模型，避免 chat 接口长时间阻塞。"""
        try:
            req = urllib.request.Request("http://127.0.0.1:11434/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                raw = resp.read().decode("utf-8", errors="ignore")
            return model_name in raw
        except (urllib.error.URLError, TimeoutError, OSError):
            return False
        except Exception:
            return False

    def _call_ollama_native_chat(self, system_prompt, user_message, max_tokens=256, timeout_sec=60):
        """优先使用 Ollama 原生 /api/chat，避免 OpenAI 兼容层在本地环境的额外开销。"""
        payload = {
            "model": self.default_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
            "stream": False,
            "keep_alive": "10m",
            "options": {
                "temperature": 0.3,
                "num_predict": int(max(32, min(max_tokens, 320))),
            },
        }
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            "http://127.0.0.1:11434/api/chat",
            data=data,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            raw = resp.read().decode("utf-8", errors="ignore")
        body = json.loads(raw)
        msg = (body.get("message") or {}).get("content")
        if not msg:
            raise RuntimeError(f"Ollama 原生返回异常: {raw[:200]}")
        return str(msg)

    def generate_analysis(self, system_prompt, user_message, max_tokens=800, timeout_sec=None):
        """
        向大模型发送请求并返回文本结果。
        - 本地不可达时，优先尝试云端兜底
        - 两者都不可用时，返回错误文本（上层可按规则结果降级）
        """
        try:
            client = self.client
            model = self.default_model

            if self.mode == "ollama" and not self._is_ollama_reachable():
                if self.fallback_client:
                    logging.warning("本地 Ollama 不可达，切换云端兼容模型。")
                    client = self.fallback_client
                    model = FALLBACK_MODEL
                else:
                    raise RuntimeError("本地AI服务不可用：Ollama 未运行或未监听 11434 端口")
            if self.mode == "ollama" and client is self.client and not self._is_model_available(model):
                if self.fallback_client:
                    logging.warning("本地模型未就绪，切换云端兼容模型。")
                    client = self.fallback_client
                    model = FALLBACK_MODEL
                else:
                    raise RuntimeError(f"本地模型未就绪：{model}，请先执行 ollama pull/run")

            logging.info(f"调用 AI 模型: {model}")
            effective_timeout = self.request_timeout_sec if timeout_sec is None else max(3.0, float(timeout_sec))
            if self.mode == "ollama" and client is self.client:
                return self._call_ollama_native_chat(
                    system_prompt=system_prompt,
                    user_message=user_message,
                    max_tokens=max_tokens,
                    timeout_sec=effective_timeout,
                )
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ],
                max_tokens=max_tokens,
                temperature=0.3,
                timeout=effective_timeout,
            )
            return response.choices[0].message.content
        except Exception as e:
            error_msg = f"大模型服务请求失败: {type(e).__name__}: {str(e)}"
            logging.error(error_msg)
            return error_msg


ai_service = AIService(mode="ollama")
