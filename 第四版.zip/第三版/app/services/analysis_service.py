﻿from collections import Counter
from datetime import datetime, timedelta
from collections import Counter

import numpy as np
import pandas as pd
from sqlalchemy import or_

from app.models.job import Job
from app.services.data_quality_utils import normalize_date_str
from app.services.edu_utils import apply_edu_filter, normalize_edu_level
from app.services.filter_utils import (
    apply_city_filter,
    apply_exp_filter,
    apply_source_filter,
    normalize_city_value,
    normalize_exp_level,
    normalize_source_value,
)
from app.services.salary_utils import SALARY_MAX_VALID, SALARY_MIN_VALID, sanitize_salary_avg


class AnalysisService:
    def __init__(self, user_id):
        self.user_id = user_id

    @staticmethod
    def _safe_int(v, default=0):
        try:
            if v is None:
                return default
            return int(round(float(v)))
        except Exception:
            return default

    @staticmethod
    def _exp_to_years(text):
        s = str(text or "")
        if "应届" in s or "在校" in s:
            return 0
        if "不限" in s:
            return 1
        if "1-3" in s:
            return 2
        if "3-5" in s:
            return 4
        if "5-10" in s:
            return 7
        if "10" in s:
            return 10
        import re

        m = re.search(r"(\d+)", s)
        return int(m.group(1)) if m else 0

    @staticmethod
    def _resolve_date_range(date_range):
        if not date_range:
            return "", ""
        if isinstance(date_range, dict):
            start = str(date_range.get("start") or "").strip()
            end = str(date_range.get("end") or "").strip()
            return start, end

        text = str(date_range).strip().lower()
        now = datetime.now().date()
        if text in {"7d", "7", "week", "last7d"}:
            return (now - timedelta(days=6)).strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d")
        if text in {"30d", "30", "month", "last30d"}:
            return (now - timedelta(days=29)).strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d")
        if text in {"90d", "90", "quarter", "last90d"}:
            return (now - timedelta(days=89)).strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d")
        return "", ""

    @staticmethod
    def _is_noise_skill_token(token):
        t = str(token or "").strip().lower()
        if not t:
            return True
        if any(k in t for k in ("本科", "大专", "硕士", "博士", "学历", "统招", "应届", "实习", "经验", "不限", "年以上", "年以下")):
            return True
        if any(k in t for k in ("融资", "上市", "集团", "公司", "人以上", "人以下", "人数", "规模")):
            return True
        if t in {"互联网", "电商", "金融", "制造", "医疗", "教育", "物流", "游戏", "saas"}:
            return True
        city_words = {
            "北京", "上海", "深圳", "广州", "杭州", "成都", "武汉", "南京", "苏州", "西安",
            "全国", "city", "beijing", "shanghai", "shenzhen", "guangzhou", "hangzhou",
        }
        generic_words = {
            "岗位", "职位", "工作", "要求", "经验", "学历", "相关", "负责", "能力", "团队", "公司",
            "工程师", "开发", "分析师", "经理", "系统", "平台", "项目",
            "本科", "大专", "硕士", "博士", "中专", "应届", "实习", "不限",
        }
        if t in city_words or t in generic_words:
            return True
        import re
        if re.fullmatch(r"\d+(?:-\d+)?年", t):
            return True
        if re.fullmatch(r"\d+(?:\.\d+)?[kKwW万千元]?", t):
            return True
        if re.fullmatch(r"\d+(?:-\d+)?人(?:以上|以下)?", t):
            return True
        if (t.endswith("市") or t.endswith("区")) and len(t) <= 4:
            return True
        return False

    @staticmethod
    def _tokenize_skills(text):
        import re

        raw = str(text or "").strip()
        if not raw:
            return []
        parts = re.split(r"[^0-9A-Za-z+#.\-\u4e00-\u9fa5]+", raw)
        out = []
        seen = set()
        for p in parts:
            t = p.strip()
            if len(t) < 2 or len(t) > 24:
                continue
            k = t.lower()
            if AnalysisService._is_noise_skill_token(k):
                continue
            if k in seen:
                continue
            seen.add(k)
            out.append(t)
        return out

    def _collect_skills(self, df):
        all_tokens = []
        per_row_tokens = []
        if df.empty:
            return all_tokens, per_row_tokens

        for rec in df.to_dict("records"):
            tokens = []
            tokens.extend(self._tokenize_skills(rec.get("skills")))
            tokens.extend(self._tokenize_skills(rec.get("tags")))
            if len(tokens) < 3:
                tokens.extend(self._tokenize_skills(rec.get("job_name")))
            if len(tokens) < 3:
                tokens.extend(self._tokenize_skills(rec.get("raw_desc")))
            uniq = []
            seen = set()
            for t in tokens:
                k = t.lower()
                if k in seen:
                    continue
                seen.add(k)
                uniq.append(t)
            all_tokens.extend(uniq)
            per_row_tokens.append(uniq)
        return all_tokens, per_row_tokens

    def _get_dataframe(self, filters=None):
        query = Job.query.filter(Job.owner_id == self.user_id)
        f = filters or {}

        if f.get("keyword"):
            kw = str(f.get("keyword") or "").strip()
            query = query.filter(
                or_(
                    Job.job_name.like(f"%{kw}%"),
                    Job.company.like(f"%{kw}%"),
                    Job.tags.like(f"%{kw}%"),
                    Job.skills.like(f"%{kw}%"),
                    Job.raw_desc.like(f"%{kw}%"),
                )
            )
        if f.get("city"):
            query = apply_city_filter(query, Job.city, f.get("city"))
        if f.get("source"):
            query = apply_source_filter(query, Job.source, f.get("source"))
        if f.get("edu"):
            query = apply_edu_filter(query, Job.edu_req, f.get("edu"), fallback_columns=[Job.tags, Job.raw_desc])
        if f.get("exp"):
            query = apply_exp_filter(query, Job.exp_req, f.get("exp"), fallback_columns=[Job.tags, Job.raw_desc])
        if f.get("salary_min") and str(f.get("salary_min")).isdigit():
            query = query.filter(Job.salary_avg >= int(f.get("salary_min")))
        if f.get("salary_max") and str(f.get("salary_max")).isdigit():
            query = query.filter(Job.salary_avg <= int(f.get("salary_max")))

        date_start, date_end = self._resolve_date_range(f.get("date_range"))
        if date_start:
            query = query.filter(Job.pub_date >= date_start)
        if date_end:
            query = query.filter(Job.pub_date <= date_end)

        query = query.filter(Job.salary_avg >= SALARY_MIN_VALID, Job.salary_avg <= SALARY_MAX_VALID)

        rows = query.all()
        if not rows:
            return pd.DataFrame()

        df = pd.DataFrame([r.__dict__ for r in rows])
        if "_sa_instance_state" in df.columns:
            df = df.drop(columns=["_sa_instance_state"])

        if "salary_avg" in df.columns:
            df["salary_avg"] = df["salary_avg"].apply(sanitize_salary_avg)
            df = df[df["salary_avg"] > 0]
            # 二次稳健截断，避免极端值拉高均值与最高薪资显示。
            if not df.empty:
                q10 = float(df["salary_avg"].quantile(0.10))
                q90 = float(df["salary_avg"].quantile(0.90))
                lower = max(SALARY_MIN_VALID, int(round(q10 * 0.5)))
                upper = min(SALARY_MAX_VALID, int(round(q90 * 2.2)))
                if upper > lower:
                    trimmed = df[(df["salary_avg"] >= lower) & (df["salary_avg"] <= upper)]
                    if len(trimmed) >= max(20, int(len(df) * 0.6)):
                        df = trimmed

        if "city" in df.columns:
            df["city"] = df["city"].apply(lambda x: normalize_city_value(x) or "未知")
        if "source" in df.columns:
            df["source"] = df["source"].apply(lambda x: normalize_source_value(x) or "未知来源")
        if "edu_req" in df.columns:
            df["edu_req"] = df["edu_req"].apply(normalize_edu_level)
        if "exp_req" in df.columns:
            df["exp_req"] = df["exp_req"].apply(lambda x: normalize_exp_level(x) or "不限")
        if "pub_date" in df.columns:
            df["pub_date"] = df["pub_date"].apply(lambda x: normalize_date_str(x) or "")

        return df.reset_index(drop=True)

    def get_chart_data_city(self, df):
        if df.empty or "city" not in df.columns:
            return {"labels": [], "avg": [], "count": []}
        grp = df.groupby("city")["salary_avg"].agg(["mean", "count"]).sort_values("count", ascending=False).head(10)
        return {
            "labels": grp.index.tolist(),
            "avg": [self._safe_int(v) for v in grp["mean"].tolist()],
            "count": [self._safe_int(v) for v in grp["count"].tolist()],
        }

    def get_chart_data_cloud(self, df):
        if df.empty:
            return []
        all_tokens, _ = self._collect_skills(df)
        if not all_tokens:
            return []
        cnt = Counter(all_tokens)
        return [{"name": k, "value": int(v)} for k, v in cnt.most_common(60)]

    def get_chart_data_salary(self, df):
        if df.empty:
            return {"range_dist": {"labels": [], "values": []}, "exp_trend": {"labels": [], "values": []}}

        bins = [0, 5000, 10000, 15000, 20000, 30000, 50000, 1000000]
        labels = ["0-5k", "5-10k", "10-15k", "15-20k", "20-30k", "30-50k", "50k+"]
        d = pd.cut(df["salary_avg"], bins=bins, labels=labels)
        dist = d.value_counts().reindex(labels).fillna(0)

        exp_order = ["应届/在校", "1年以内", "1-3年", "3-5年", "5-10年", "10年以上", "不限"]
        exp_grp = df.groupby("exp_req")["salary_avg"].mean()
        exp_labels = [x for x in exp_order if x in exp_grp.index]
        exp_labels += [x for x in exp_grp.index.tolist() if x not in exp_labels]
        exp_values = [self._safe_int(exp_grp.get(x, 0)) for x in exp_labels]

        return {
            "range_dist": {"labels": labels, "values": [self._safe_int(v) for v in dist.tolist()]},
            "exp_trend": {"labels": exp_labels, "values": exp_values},
        }
    def get_chart_data_edu(self, df):
        if df.empty or "edu_req" not in df.columns:
            return {"labels": [], "values": [], "counts": []}
        grp = df.groupby("edu_req")["salary_avg"].agg(["mean", "count"]).sort_values("count", ascending=False)
        return {
            "labels": grp.index.tolist(),
            "values": [self._safe_int(v) for v in grp["mean"].tolist()],
            "counts": [self._safe_int(v) for v in grp["count"].tolist()],
        }

    def get_chart_data_time_trend(self, df):
        if df.empty or "pub_date" not in df.columns:
            return {"labels": [], "job_counts": [], "salary_trend": []}

        dfx = df.copy()
        dfx["pub_date_dt"] = pd.to_datetime(dfx["pub_date"], errors="coerce")
        dfx = dfx[dfx["pub_date_dt"].notna()]
        if dfx.empty:
            return {"labels": [], "job_counts": [], "salary_trend": []}

        daily = (
            dfx.groupby(dfx["pub_date_dt"].dt.strftime("%Y-%m-%d"))["salary_avg"]
            .agg(["count", "mean"])
            .reset_index()
            .sort_values("pub_date_dt")
        )
        if daily.empty:
            return {"labels": [], "job_counts": [], "salary_trend": []}

        daily = daily.tail(14)
        return {
            "labels": daily["pub_date_dt"].tolist(),
            "job_counts": [self._safe_int(v) for v in daily["count"].tolist()],
            "salary_trend": [self._safe_int(v) for v in daily["mean"].tolist()],
        }

    def get_chart_data_heatmap(self, df):
        if df.empty:
            return {"city_edu": {"cities": [], "edus": [], "data": []}}

        dfx = df.copy()
        dfx["city"] = dfx["city"].fillna("未知")
        dfx["edu_req"] = dfx["edu_req"].fillna("不限")
        city_top = (
            dfx.groupby("city")["salary_avg"]
            .count()
            .sort_values(ascending=False)
            .head(10)
            .index.tolist()
        )
        if not city_top:
            return {"city_edu": {"cities": [], "edus": [], "data": []}}

        edu_order = ["不限", "大专", "本科", "硕士", "博士"]
        edu_seen = [x for x in edu_order if x in set(dfx["edu_req"].tolist())]
        if not edu_seen:
            edu_seen = sorted([str(x) for x in dfx["edu_req"].dropna().unique().tolist()])[:6]

        city_index = {name: idx for idx, name in enumerate(city_top)}
        edu_index = {name: idx for idx, name in enumerate(edu_seen)}
        rows = []
        grouped = dfx[dfx["city"].isin(city_top)].groupby(["city", "edu_req"])["salary_avg"].mean().reset_index()
        for _, row in grouped.iterrows():
            city = str(row.get("city") or "")
            edu = str(row.get("edu_req") or "")
            if city not in city_index or edu not in edu_index:
                continue
            rows.append([city_index[city], edu_index[edu], self._safe_int(row.get("salary_avg"))])

        return {"city_edu": {"cities": city_top, "edus": edu_seen, "data": rows}}

    def get_chart_data_company(self, df):
        if df.empty:
            return {"salary_rank": [], "size_dist": [], "size_salary": {"labels": [], "values": []}}

        company_grp = (
            df.groupby("company")["salary_avg"]
            .agg(["mean", "count"])
            .sort_values(["mean", "count"], ascending=[False, False])
        )
        salary_rank = []
        for company, row in company_grp.head(8).iterrows():
            if not company or str(company).strip() == "":
                continue
            salary_rank.append(
                {
                    "name": str(company),
                    "avg": self._safe_int(row.get("mean")),
                    "count": self._safe_int(row.get("count")),
                }
            )

        size_grp = df.groupby("company_size")["salary_avg"].agg(["count", "mean"]).sort_values("count", ascending=False)
        size_dist = []
        size_labels = []
        size_values = []
        for size, row in size_grp.head(6).iterrows():
            name = str(size or "未知规模")
            cnt = self._safe_int(row.get("count"))
            avg = self._safe_int(row.get("mean"))
            if cnt <= 0:
                continue
            size_dist.append({"name": name, "value": cnt})
            size_labels.append(name)
            size_values.append(avg)

        return {
            "salary_rank": salary_rank,
            "size_dist": size_dist,
            "size_salary": {"labels": size_labels, "values": size_values},
        }

    def _salary_depth(self, df):
        if df.empty:
            return {"median": 0, "q25": 0, "q75": 0, "q90": 0, "std": 0, "cv": 0, "ranges": []}

        s = df["salary_avg"]
        mean_v = float(s.mean()) if len(s) else 0.0
        std_v = float(s.std()) if len(s) > 1 else 0.0
        cv = (std_v / mean_v) if mean_v > 0 else 0.0
        return {
            "median": self._safe_int(s.median()),
            "q25": self._safe_int(s.quantile(0.25)),
            "q75": self._safe_int(s.quantile(0.75)),
            "q90": self._safe_int(s.quantile(0.90)),
            "std": self._safe_int(std_v),
            "cv": round(cv, 4),
            "ranges": self.get_chart_data_salary(df).get("range_dist", {}).get("values", []),
        }

    def _skills_insight(self, df):
        if df.empty:
            return {"common": [], "high_value": []}

        all_tokens, per_row_tokens = self._collect_skills(df)
        if not all_tokens:
            return {"common": [], "high_value": []}

        common = [k for k, _ in Counter(all_tokens).most_common(12)]

        base_avg = float(df["salary_avg"].mean()) if len(df) else 0.0
        skill_salary = {}
        skill_count = Counter()
        for idx, tokens in enumerate(per_row_tokens):
            salary = float(df.iloc[idx]["salary_avg"])
            for t in set(tokens):
                skill_count[t] += 1
                skill_salary.setdefault(t, []).append(salary)

        high_value = []
        for skill, arr in skill_salary.items():
            if skill_count[skill] < 3:
                continue
            avg = float(np.mean(arr)) if arr else 0.0
            premium = ((avg - base_avg) / base_avg * 100.0) if base_avg > 0 else 0.0
            high_value.append({
                "name": skill,
                "premium": round(premium, 1),
                "count": int(skill_count[skill]),
                "avg_salary": self._safe_int(avg),
            })
        high_value.sort(key=lambda x: x["premium"], reverse=True)

        return {"common": common, "high_value": high_value[:50]}

    def _demand_index(self, df):
        if df.empty:
            return {"categories": []}

        if "job_category" not in df.columns:
            df = df.copy()
            df["job_category"] = "其他"

        grp = df.groupby("job_category")["salary_avg"].agg(["count", "mean"]).sort_values("count", ascending=False)
        max_cnt = max(float(grp["count"].max()), 1.0)
        max_mean = max(float(grp["mean"].max()), 1.0)

        cats = []
        for name, row in grp.head(12).iterrows():
            heat = int(round((row["count"] / max_cnt) * 70 + (row["mean"] / max_mean) * 30))
            cats.append({
                "name": str(name or "其他"),
                "count": self._safe_int(row["count"]),
                "avg_salary": self._safe_int(row["mean"]),
                "heat_index": heat,
            })
        return {"categories": cats}

    def _market_insight(self, df, salary_depth):
        sample_size = int(len(df))
        cv_ratio = float(salary_depth.get("cv") or 0.0)
        cv_pct = max(0.0, min(100.0, cv_ratio * 100.0))
        sample_score = min(100.0, sample_size / 8.0)
        stability_score = max(0.0, 100.0 - cv_pct)
        score = int(round(sample_score * 0.55 + stability_score * 0.45))
        if score >= 75:
            level = "高热"
        elif score >= 50:
            level = "活跃"
        else:
            level = "平稳"
        return {"level": level, "score": int(max(0, min(100, score)))}
    def _factor_weights(self, df, salary_depth, skills):
        if df.empty:
            return []

        def _spread(series):
            arr = [self._safe_int(x) for x in series if self._safe_int(x) > 0]
            if len(arr) < 2:
                return 0
            return max(arr) - min(arr)

        exp_gap = _spread(df.groupby("exp_req")["salary_avg"].mean().tolist()) if "exp_req" in df.columns else 0
        edu_gap = _spread(df.groupby("edu_req")["salary_avg"].mean().tolist()) if "edu_req" in df.columns else 0
        city_gap = _spread(df.groupby("city")["salary_avg"].mean().head(8).tolist()) if "city" in df.columns else 0
        skill_premium = max([self._safe_int(x.get("premium")) for x in (skills.get("high_value") or [])] + [0])
        volatility = self._safe_int((salary_depth.get("cv") or 0) * 100)

        raw = {
            "经验": max(1, exp_gap),
            "学历": max(1, edu_gap),
            "城市": max(1, city_gap),
            "技能": max(1, skill_premium * 80),
            "市场波动": max(1, volatility * 50),
        }
        total = sum(raw.values()) or 1
        weights = [{"name": k, "value": int(round(v * 100.0 / total))} for k, v in raw.items()]
        diff = 100 - sum(x["value"] for x in weights)
        if weights and diff != 0:
            weights[0]["value"] += diff
        return sorted(weights, key=lambda x: x["value"], reverse=True)
    def _competitiveness(self, stats, skills, pub_date_parse_rate):
        sample_score = min(100, int(round((stats.get("sample_size", 0) / 500.0) * 100)))
        salary_score = min(100, int(round((stats.get("median_salary", 0) / 25000.0) * 100)))
        city_score = min(100, int(round((stats.get("city_count", 0) / 20.0) * 100)))
        skill_score = min(100, int(round((len(skills.get("common") or []) / 12.0) * 100)))
        trend_score = min(100, int(round(pub_date_parse_rate)))
        return {
            "dimensions": ["样本规模", "薪资竞争力", "城市覆盖", "技能覆盖", "趋势可信度"],
            "values": [sample_score, salary_score, city_score, skill_score, trend_score],
        }
    def _conclusions(self, stats, city_chart, edu_chart, salary_depth, skills, time_chart, heatmap_chart, company_chart, demand_index, competitiveness):
        top_city = ""
        top_city_salary = 0
        if city_chart.get("labels") and city_chart.get("avg"):
            top_city = str(city_chart["labels"][0])
            top_city_salary = self._safe_int(city_chart["avg"][0])

        top_skill = ""
        top_skill_premium = 0
        if skills.get("high_value"):
            top_skill = str(skills["high_value"][0].get("name") or "")
            top_skill_premium = self._safe_int(skills["high_value"][0].get("premium"))

        edu_best = ""
        edu_best_salary = 0
        if edu_chart.get("labels") and edu_chart.get("values"):
            idx = int(np.argmax([self._safe_int(v) for v in edu_chart["values"]]))
            edu_best = str(edu_chart["labels"][idx])
            edu_best_salary = self._safe_int(edu_chart["values"][idx])

        trend_text = "暂无时间趋势样本。"
        if time_chart.get("labels") and time_chart.get("job_counts"):
            total_new = sum([self._safe_int(v) for v in time_chart.get("job_counts", [])[-7:]])
            trend_text = f"最近 7 天新增岗位约 {total_new} 条，市场活跃度处于相应水平。"
            
        heatmap_text = "样本数据不足以生成城市与学历的显著热力交叉特征。"
        if heatmap_chart.get("city_edu") and heatmap_chart["city_edu"].get("data"):
            heatmap_text = "热力交叉显示某几个核心城市对特定学历的人才给出了最高平均薪资。"
            
        company_text = "企业规模与薪资之间暂无明显关联。"
        if company_chart.get("size_salary") and company_chart["size_salary"].get("labels"):
            top_size = company_chart["size_salary"]["labels"][0]
            company_text = f"{top_size}的平均薪资在当前样本中表现较好。"
            
        demand_text = "当前市场需求方向较为分散。"
        if demand_index.get("categories") and len(demand_index["categories"]) > 0:
            top_demand = demand_index["categories"][0].get("name", "")
            demand_text = f"「{top_demand}」方向近期需求热度最高，可作为重点投递目标。"
            
        radar_text = "雷达图已根据您的画像对比全网均值得出各项竞争力指标。"
        if competitiveness.get("values") and len(competitiveness["values"]) >= 5:
            radar_text = f"在技能和经验等五个维度上，您的数据呈现多边形分布，评估整体投递匹配力。"

        return {
            "salary": f"样本中位薪资 {self._safe_int(stats.get('median_salary'))} 元，Top20% 门槛约 {self._safe_int(salary_depth.get('q90'))} 元。",
            "cloud": f"高价值技能以 {top_skill or '暂无稳定技能'} 为主，溢价约 {top_skill_premium}%。",
            "city": f"{top_city or '当前样本'} 平均薪资领先，约 {top_city_salary} 元。",
            "edu": f"{edu_best or '学历维度'} 对应平均薪资约 {edu_best_salary} 元。",
            "trend": trend_text,
            "heatmap": heatmap_text,
            "company": company_text,
            "demand": demand_text,
            "radar": radar_text
        }
    def _action_plan(self, stats, skills, demand_index):
        actions = []
        sample_size = self._safe_int(stats.get("sample_size"))
        if sample_size < 500:
            actions.append(
                {
                    "priority": "high",
                    "type": "timing",
                    "title": "优先补齐样本量",
                    "desc": f"当前样本 {sample_size} 条，建议补充到 500 条以上再做强结论判断。",
                }
            )
        missing_skills = [x.get("name") for x in (skills.get("high_value") or [])[:2] if x.get("name")]
        actions.append(
            {
                "priority": "medium",
                "type": "skill",
                "title": "技能补强优先级",
                "desc": f"优先补齐 {', '.join(missing_skills) if missing_skills else 'SQL、Python、数据建模'} 等岗位高频技能。",
            }
        )
        top_cat = (demand_index.get("categories") or [{}])[0]
        actions.append(
            {
                "priority": "medium",
                "type": "market",
                "title": "投递方向调整",
                "desc": f"建议优先投递 {top_cat.get('name') or '需求较高'} 相关岗位，并保留 2-3 个保底岗位。",
            }
        )
        return actions[:3]
    def get_insights(self, filters=None):
        df = self._get_dataframe(filters or {})
        if df.empty:
            return {
                "meta": {
                    "stats": {
                        "count": 0,
                        "sample_size": 0,
                        "valid_salary_count": 0,
                        "city_count": 0,
                        "city_coverage": 0,
                        "avg_salary": 0,
                        "median_salary": 0,
                        "max_salary": 0,
                        "updated_at": "",
                    },
                    "diagnosis": "当前筛选条件下暂无有效样本。",
                },
                "insights": {
                    "highlights": [],
                    "salary_depth": {"median": 0, "q25": 0, "q75": 0, "q90": 0, "std": 0, "cv": 0, "ranges": []},
                    "skills": {"common": [], "high_value": []},
                    "demand_index": {"categories": []},
                    "market": {"level": "--", "score": 0},
                    "factors": [],
                    "competitiveness": {"dimensions": [], "values": []},
                    "conclusions": {},
                    "action_plan": [],
                },
                "charts": {
                    "city": {"labels": [], "avg": [], "count": []},
                    "cloud": [],
                    "salary": {"range_dist": {"labels": [], "values": []}, "exp_trend": {"labels": [], "values": []}},
                    "edu": {"labels": [], "values": [], "counts": []},
                    "time_trend": {"labels": [], "job_counts": [], "salary_trend": []},
                    "heatmap": {"city_edu": {"cities": [], "edus": [], "data": []}},
                    "company": {"salary_rank": [], "size_dist": [], "size_salary": {"labels": [], "values": []}},
                },
            }

        city_chart = self.get_chart_data_city(df)
        cloud_chart = self.get_chart_data_cloud(df)
        salary_chart = self.get_chart_data_salary(df)
        edu_chart = self.get_chart_data_edu(df)
        time_chart = self.get_chart_data_time_trend(df)
        heatmap_chart = self.get_chart_data_heatmap(df)
        company_chart = self.get_chart_data_company(df)
        salary_depth = self._salary_depth(df)
        skills = self._skills_insight(df)
        demand_index = self._demand_index(df)
        pub_date_parse_rate = 0.0
        if "pub_date" in df.columns and len(df):
            pub_date_parse_rate = round(
                (df["pub_date"].astype(str).str.match(r"^\d{4}-\d{2}-\d{2}$").sum() / len(df)) * 100, 1
            )

        stats = {
            "count": int(len(df)),
            "sample_size": int(len(df)),
            "valid_salary_count": int(len(df)),
            "city_count": int(df["city"].nunique()) if "city" in df.columns else 0,
            "city_coverage": int(df["city"].nunique()) if "city" in df.columns else 0,
            "avg_salary": self._safe_int(df["salary_avg"].mean()),
            "median_salary": self._safe_int(df["salary_avg"].median()),
            "max_salary": self._safe_int(df["salary_avg"].max()),
            "updated_at": max([x for x in df["pub_date"].tolist() if x], default="") if "pub_date" in df.columns else "",
        }

        highlights = [
            {"title": "样本量", "value": stats["sample_size"], "text": f"当前有效样本 {stats['sample_size']} 条。"},
            {"title": "城市覆盖", "value": stats["city_coverage"], "text": f"覆盖城市 {stats['city_coverage']} 个。"},
            {"title": "平均薪资", "value": stats["avg_salary"], "text": f"平均薪资 {stats['avg_salary']} 元。"},
            {"title": "中位薪资", "value": stats["median_salary"], "text": f"中位薪资 {stats['median_salary']} 元。"},
            {"title": "最高薪资", "value": stats["max_salary"], "text": f"最高薪资 {stats['max_salary']} 元。"},
        ]

        diagnosis = (
            f"数据可靠性说明：当前样本 {stats['sample_size']} 条，覆盖城市 {stats['city_coverage']} 个，"
            f"最近更新时间 {stats['updated_at'] or '未知'}。"
        )
        market = self._market_insight(df, salary_depth)
        factors = self._factor_weights(df, salary_depth, skills)
        competitiveness = self._competitiveness(stats, skills, pub_date_parse_rate)
        conclusions = self._conclusions(stats, city_chart, edu_chart, salary_depth, skills, time_chart, heatmap_chart, company_chart, demand_index, competitiveness)
        action_plan = self._action_plan(stats, skills, demand_index)

        return {
            "meta": {"stats": stats, "diagnosis": diagnosis},
            "insights": {
                "highlights": highlights,
                "salary_depth": salary_depth,
                "skills": skills,
                "demand_index": demand_index,
                "market": market,
                "factors": factors,
                "competitiveness": competitiveness,
                "conclusions": conclusions,
                "action_plan": action_plan,
            },
            "charts": {
                "city": city_chart,
                "cloud": cloud_chart,
                "salary": salary_chart,
                "edu": edu_chart,
                "time_trend": time_chart,
                "heatmap": heatmap_chart,
                "company": company_chart,
            },
        }

    def evaluate_competitiveness(self, city, edu, exp, skills):
        df = self._get_dataframe({"city": city} if city else {})
        if df.empty or len(df) < 5:
            return {"success": False, "msg": "数据不足，请至少采集 5 条数据"}

        edu_rank = {"不限": 0, "大专": 1, "本科": 2, "硕士": 3, "博士": 4}
        target_edu = normalize_edu_level(edu)
        target_edu_rank = edu_rank.get(target_edu, 0)
        market_edu_rank = np.median([edu_rank.get(normalize_edu_level(x), 0) for x in df["edu_req"].tolist()])
        edu_score = int(max(0, min(100, 60 + (target_edu_rank - market_edu_rank) * 12)))

        target_exp_years = self._exp_to_years(exp)
        market_exp_years = np.median([self._exp_to_years(x) for x in df["exp_req"].tolist()])
        exp_score = int(max(0, min(100, 65 + (target_exp_years - market_exp_years) * 8)))

        all_tokens, _ = self._collect_skills(df)
        token_counter = Counter(all_tokens)
        market_top = [x for x, _ in token_counter.most_common(20)]
        user_tokens = [x.strip() for x in str(skills or "").replace("，", ",").split(",") if x.strip()]
        user_tokens = [x for x in user_tokens if not self._is_noise_skill_token(x)]
        overlap = len([x for x in user_tokens if x in market_top])
        skill_score = int(max(0, min(100, 40 + overlap * 15))) if user_tokens else 50

        market_avg_salary = self._safe_int(df["salary_avg"].mean())
        salary_score = 70
        market_heat = int(max(40, min(100, len(df) / 10)))

        total_score = int(round(edu_score * 0.18 + exp_score * 0.22 + skill_score * 0.35 + salary_score * 0.15 + market_heat * 0.10))
        # 用各维度均值构造“市场基准分”，给出相对分位近似值，便于前端解释。
        baseline = float(np.mean([edu_score, exp_score, skill_score, salary_score, market_heat]))
        percentile = int(max(5, min(99, round(50 + (total_score - baseline) * 1.2))))

        missing = [x for x in market_top[:12] if x not in user_tokens and not self._is_noise_skill_token(x)][:3]
        smart_skills = [{"name": m, "demand": int(token_counter.get(m, 0)), "premium": 10} for m in missing]

        growth_paths = []
        if city:
            growth_paths.append({"type": "city", "title": f"保留 {city} 同时拓展一线城市岗位"})
        growth_paths.append({"type": "skill", "title": "优先补齐高频技能后再冲击更高薪岗位"})
        if total_score >= 80:
            conclusion = "竞争力较强，可进入重点投递阶段"
            suggestion = "优先投递高匹配岗位，并在简历中突出可量化项目成果。"
        elif total_score >= 60:
            conclusion = "竞争力中等，建议先补齐关键短板再集中投递"
            suggestion = "先补高频缺失技能，再按主申/冲刺分层投递。"
        else:
            conclusion = "竞争力偏弱，建议先提升再投递"
            suggestion = "建议先完成技能补齐和项目强化，再开始密集投递。"

        reason = (
            f"技能匹配度 {skill_score}、经验竞争力 {exp_score}、学历竞争力 {edu_score}，"
            f"市场热度 {market_heat}。"
        )

        return {
            "success": True,
            "total_score": total_score,
            "percentile": percentile,
            "market_avg_salary": market_avg_salary,
            "conclusion": conclusion,
            "reason": reason,
            "suggestion": suggestion,
            "dimensions": {
                "labels": ["学历竞争力", "经验竞争力", "技能匹配度", "薪资竞争力", "市场热度"],
                "values": [edu_score, exp_score, skill_score, salary_score, market_heat],
            },
            "smart_skills": smart_skills,
            "growth_paths": growth_paths,
        }

