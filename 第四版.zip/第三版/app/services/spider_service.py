﻿import json
import math
import os
import random
import re
import shutil
import threading
import time
from html import unescape
from collections import deque
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import quote_plus

import requests
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from app.extensions import db
from app.models.job import Job
from app.services.salary_utils import parse_salary_text_to_monthly, sanitize_salary_avg
from app.services.skill_extract import extract_skills
from config import Config

try:
    from webdriver_manager.chrome import ChromeDriverManager
except Exception:
    ChromeDriverManager = None


CITY_CANDIDATES = [
    "北京",
    "上海",
    "深圳",
    "广州",
    "杭州",
    "成都",
    "武汉",
    "南京",
    "苏州",
    "西安",
    "重庆",
    "天津",
    "郑州",
    "长沙",
    "宁波",
    "青岛",
    "佛山",
    "东莞",
]
CITY_PATTERN = re.compile("|".join(sorted(CITY_CANDIDATES, key=len, reverse=True)))
SALARY_PATTERN = re.compile(
    r"(\d+(?:\.\d+)?\s*[-~至到]\s*\d+(?:\.\d+)?\s*(?:k|K|w|W|千|万|元)(?:/\w+|每\w+)?|"
    r"\d+(?:\.\d+)?\s*(?:k|K|w|W|千|万|元)(?:/\w+|每\w+)?|面议|薪资面议)"
)
PUB_DATE_PATTERN = re.compile(
    r"(\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|"
    r"\d{1,2}[-/.]\d{1,2}|"
    r"(?:今天|昨日|昨天|刚刚)|"
    r"\d+\s*天前|\d+\s*(?:小时|分钟)前)"
)
EXP_PATTERN = re.compile(
    r"(应届|实习|经验不限|不限经验|"
    r"\d{1,2}\s*[-~至到]\s*\d{1,2}\s*年|"
    r"\d{1,2}\s*年(?:以上|以内)?)"
)
EDU_PATTERN = re.compile(r"(博士|硕士|本科|大专|中专|高中|学历不限|不限学历)")
COMPANY_SUFFIX_PATTERN = re.compile(r"(公司|科技|集团|研究院|事务所|工作室|股份|有限)")
MOJIBAKE_HINT_PATTERN = re.compile(r"(鍏|鍗|鍓|涓|閮|娑|鏉|闈|瑗)")
SOURCE_ALIAS = {
    "liepin": "猎聘",
    "猎聘网": "猎聘",
    "liepin.com": "猎聘",
    "system": "SYSTEM",
}


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return int(default)


def _clean_space(text):
    t = str(text or "").replace("\u3000", " ").replace("\xa0", " ")
    return re.sub(r"\s+", " ", t).strip()


def _fix_mojibake(text):
    t = _clean_space(text)
    if not t:
        return ""
    if not MOJIBAKE_HINT_PATTERN.search(t):
        return t
    try:
        repaired = t.encode("gbk", errors="ignore").decode("utf-8", errors="ignore")
        repaired = _clean_space(repaired)
        if repaired and repaired != t:
            return repaired
    except Exception:
        pass
    return t


def _normalize_text(text):
    return _fix_mojibake(text)


def _decode_json_escaped(text):
    raw = str(text or "")
    if not raw:
        return ""
    try:
        # 反转义 JSON 字符串中的 unicode（例如 "\\u5317\\u4eac" -> "北京"）
        import json as _json
        return _json.loads(f'"{raw}"')
    except Exception:
        return raw


def _normalize_filter_value(text):
    v = _normalize_text(text).strip().lower()
    if not v:
        return ""
    v = v.replace(" ", "")

    if "全国" in v or v in {"all", "any"}:
        return "全国"
    if "全部" in v:
        return "全部"
    if "不限" in v:
        return "不限"
    if "应届" in v or "实习" in v:
        return "应届"

    return v


def _looks_like_company(name, job_name=""):
    text = _normalize_text(name)
    if not text or text == "未知公司":
        return False
    if job_name and text == _normalize_text(job_name):
        return False
    if re.search(r"(工程师|开发|分析师|经理|专员|顾问|实习|招聘|岗位|职位)", text):
        return False
    if SALARY_PATTERN.search(text) or PUB_DATE_PATTERN.search(text) or EXP_PATTERN.search(text):
        return False
    if EDU_PATTERN.search(text):
        return False
    if text in CITY_CANDIDATES or (len(text) <= 4 and (text.endswith("市") or text.endswith("区"))):
        return False
    if COMPANY_SUFFIX_PATTERN.search(text):
        return True
    if len(text) >= 3 and re.search(r"[A-Za-z]{2,}", text):
        return True
    if 3 <= len(text) <= 32:
        return True
    return False


def _extract_company_inline(text):
    raw = _normalize_text(text)
    if not raw:
        return ""
    pattern = re.compile(
        r"([A-Za-z0-9\u4e00-\u9fa5·（）()\-]{2,40}(?:有限责任公司|股份有限公司|有限公司|集团|科技|研究院|事务所|工作室|公司))"
    )
    m = pattern.search(raw)
    if not m:
        return ""
    company = _clean_space(m.group(1))
    return company[:128]


def _clean_job_name(job_name, context_text=""):
    raw = _normalize_text(job_name)
    if not raw:
        return ""
    s = _clean_space(raw)
    s = re.sub(r"[【\[].{1,20}[】\]]", " ", s)

    cut_points = []
    m_salary = SALARY_PATTERN.search(s)
    if m_salary:
        cut_points.append(m_salary.start())
    m_exp = EXP_PATTERN.search(s)
    if m_exp:
        cut_points.append(m_exp.start())
    m_edu = EDU_PATTERN.search(s)
    if m_edu:
        cut_points.append(m_edu.start())
    if cut_points:
        s = s[: min(cut_points)]

    s = re.sub(r"\s+", " ", s).strip(" -|,，。")
    if len(s) < 2:
        # 回退：用原始标题前 80 字符，避免清洗过头
        s = _clean_space(raw)[:80]
    return s[:128]


def _clean_company_name(company, job_name="", context_text=""):
    s = _clean_space(_normalize_text(company))
    if not s:
        return ""

    if job_name:
        s = s.replace(_normalize_text(job_name), " ").strip()
    s = re.sub(r"[【\[].{1,20}[】\]]", " ", s)
    s = _clean_space(s)

    # 如果字段明显掺杂了岗位/薪资/经验，优先做内联公司名提取
    if len(s) > 48 or SALARY_PATTERN.search(s) or EXP_PATTERN.search(s) or EDU_PATTERN.search(s):
        extracted = _extract_company_inline(f"{s} {context_text}".strip())
        if extracted:
            s = extracted

    if _looks_like_company(s, job_name):
        return s[:128]

    for part in re.split(r"[|｜/、,，;；]+", s):
        p = _clean_space(part)
        if _looks_like_company(p, job_name):
            return p[:128]

    extracted = _extract_company_inline(f"{s} {context_text}".strip())
    return extracted[:128] if extracted else ""

def normalize_pub_date(text):
    raw = _normalize_text(text)
    if not raw:
        return None
    raw = re.sub(r"^(\u53d1\u5e03\u4e8e|\u53d1\u5e03\u65f6\u95f4|\u66f4\u65b0\u4e8e|\u66f4\u65b0|\u53d1\u5e03)\s*[:\uFF1A]?\s*", "", raw).strip()

    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            return datetime.strptime(raw[:10], fmt).strftime("%Y-%m-%d")
        except Exception:
            pass

    m = re.search(r"(\d{1,2})[-/.](\d{1,2})", raw)
    if m:
        today = datetime.now().date()
        mm = _safe_int(m.group(1), 0)
        dd = _safe_int(m.group(2), 0)
        if 1 <= mm <= 12 and 1 <= dd <= 31:
            try:
                return today.replace(month=mm, day=dd).strftime("%Y-%m-%d")
            except Exception:
                pass

    today = datetime.now().date()
    if "昨天" in raw or "昨日" in raw:
        return (today - timedelta(days=1)).strftime("%Y-%m-%d")
    if "今天" in raw or "刚刚" in raw:
        return today.strftime("%Y-%m-%d")

    day_ago = re.search(r"(\d+)\s*天前", raw)
    if day_ago:
        return (today - timedelta(days=max(_safe_int(day_ago.group(1), 0), 0))).strftime("%Y-%m-%d")

    hour_ago = re.search(r"(\d+)\s*(小时|分钟)前?", raw)
    if hour_ago:
        return today.strftime("%Y-%m-%d")

    return None


class SpiderManager:
    def __init__(self):
        self.is_running = False
        self.logs = deque(maxlen=2000)
        self.stats = {}
        self.meta = {}
        self._app = None

        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self.threads = {}
        self.drivers = {}

    def _push_log(self, source, message):
        src = _normalize_text(source) or str(source or "")
        src = SOURCE_ALIAS.get(str(src).strip().lower(), src)
        msg = _normalize_text(message) or str(message or "")
        line = f"[{datetime.now().strftime('%H:%M:%S')}] [{src}] {msg}"
        with self._lock:
            self.logs.append(line)

    def _set_source_error(self, source, err_type, message, suggestion):
        with self._lock:
            src = self.stats.get("sources", {}).get(source, {})
            src["last_error_type"] = str(err_type or "")[:64]
            src["last_error_message"] = str(message or "")[:300]
            src["last_error_suggestion"] = str(suggestion or "")[:160]
            self.stats["sources"][source] = src

    def _init_stats(self, target_count, sources):
        self.stats = {
            "scanned": 0,
            "added": 0,
            "filtered": 0,
            "failed": 0,
            "target": int(target_count),
            "progress": 0,
            "pub_date_total": 0,
            "pub_date_parsed": 0,
            "sources": {},
        }
        for src in sources:
            self.stats["sources"][src] = {
                "status": "idle",
                "current_page": 0,
                "total_pages": 0,
                "scanned": 0,
                "added": 0,
                "filtered": 0,
                "failed": 0,
                "last_error_type": "",
                "last_error_message": "",
                "last_error_suggestion": "",
            }

    def _update_progress(self):
        target = max(int(self.stats.get("target", 0) or 0), 1)
        added = int(self.stats.get("added", 0) or 0)
        self.stats["progress"] = min(100, int(round(added / target * 100)))

    def _snapshot_task_state(self):
        with self._lock:
            stats = json.loads(json.dumps(self.stats or {}))
            meta = json.loads(json.dumps(self.meta or {}))
        return meta, stats

    def _persist_task_start(self, app, uid, keyword, city, exp, sources, target_count, headless, options):
        try:
            from app.models.crawl_task import CrawlTask

            with app.app_context():
                payload = dict(options or {})
                task = CrawlTask(
                    owner_id=int(uid),
                    keyword=str(keyword or "").strip()[:128],
                    city=str(city or "全国").strip()[:32],
                    exp=str(exp or "不限").strip()[:32],
                    sources=json.dumps(list(sources or []), ensure_ascii=False),
                    plan=str(payload.get("plan") or "standard").strip()[:16],
                    target_count=int(target_count or 0),
                    max_pages=_safe_int(payload.get("max_pages"), 0),
                    headless=bool(headless),
                    retry_times=_safe_int(payload.get("retry"), 3),
                    timeout_sec=_safe_int(payload.get("timeout"), 30),
                    status="running",
                )
                db.session.add(task)
                db.session.commit()
                return int(task.id)
        except Exception:
            try:
                db.session.rollback()
            except Exception:
                pass
        return 0

    def _persist_task_finish(self, app, status=None):
        meta, stats = self._snapshot_task_state()
        task_id = _safe_int(meta.get("task_id"), 0)
        if not task_id:
            return

        source_stats = stats.get("sources", {}) if isinstance(stats, dict) else {}
        final_status = str(status or meta.get("final_status") or "").strip()
        if not final_status:
            has_errors = any(
                str((item or {}).get("last_error_type") or "").strip()
                for item in (source_stats or {}).values()
            )
            final_status = "failed" if has_errors and not int(stats.get("added", 0) or 0) else "done"

        error_messages = []
        for source, item in (source_stats or {}).items():
            err_type = str((item or {}).get("last_error_type") or "").strip()
            err_msg = str((item or {}).get("last_error_message") or "").strip()
            if err_type:
                error_messages.append(f"{source}: {err_type}{' - ' + err_msg if err_msg else ''}")

        try:
            from app.models.crawl_task import CrawlTask

            with app.app_context():
                task = CrawlTask.query.get(task_id)
                if not task:
                    return
                task.status = final_status[:16]
                task.scanned = _safe_int(stats.get("scanned"), 0)
                task.added = _safe_int(stats.get("added"), 0)
                task.filtered = _safe_int(stats.get("filtered"), 0)
                task.failed = _safe_int(stats.get("failed"), 0)
                task.progress = _safe_int(stats.get("progress"), 0)
                task.source_stats = json.dumps(source_stats or {}, ensure_ascii=False)
                task.error_message = "\n".join(error_messages)[:4000]
                task.finished_at = datetime.utcnow()
                db.session.commit()
        except Exception:
            try:
                db.session.rollback()
            except Exception:
                pass

    def _create_driver(self, headless=False, timeout=30):
        options = ChromeOptions()
        if headless:
            options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--window-size=1600,1200")
        options.add_argument("--lang=zh-CN")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)
        user_agent = random.choice(
            [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            ]
        )
        options.add_argument(f"--user-agent={user_agent}")

        driver = None
        last_error = None

        # 1) 优先使用本地 driver 可执行路径，避免离线环境下载失败
        local_candidates = []
        env_driver = str(os.environ.get("CHROMEDRIVER") or "").strip()
        if env_driver:
            local_candidates.append(env_driver)
        local_candidates.extend([
            "chromedriver",
            "chromedriver.exe",
            str(Path.cwd() / "chromedriver.exe"),
            str(Path.cwd() / "drivers" / "chromedriver.exe"),
            r"C:\WebDriver\bin\chromedriver.exe",
            r"C:\Program Files\Google\Chrome\Application\chromedriver.exe",
        ])

        for candidate in local_candidates:
            try:
                resolved = shutil.which(candidate) if candidate in {"chromedriver", "chromedriver.exe"} else candidate
                if not resolved or not Path(resolved).exists():
                    continue
                service = ChromeService(executable_path=str(resolved))
                driver = webdriver.Chrome(service=service, options=options)
                break
            except Exception as e:
                last_error = e

        # 2) 尝试 Edge 本地 driver（Windows 上常见）
        if driver is None:
            try:
                edge_options = EdgeOptions()
                if headless:
                    edge_options.add_argument("--headless=new")
                edge_options.add_argument("--disable-gpu")
                edge_options.add_argument("--no-sandbox")
                edge_options.add_argument("--disable-dev-shm-usage")
                edge_options.add_argument("--window-size=1600,1200")
                edge_options.add_argument("--lang=zh-CN")
                edge_options.add_argument(f"--user-agent={user_agent}")

                edge_candidates = []
                env_edge = str(os.environ.get("MSEDGEDRIVER") or "").strip()
                if env_edge:
                    edge_candidates.append(env_edge)
                edge_candidates.extend(
                    [
                        "msedgedriver",
                        "msedgedriver.exe",
                        str(Path.cwd() / "msedgedriver.exe"),
                        str(Path.cwd() / "drivers" / "msedgedriver.exe"),
                        r"C:\WebDriver\bin\msedgedriver.exe",
                        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedgedriver.exe",
                        r"C:\Program Files\Microsoft\Edge\Application\msedgedriver.exe",
                    ]
                )

                edge_driver = None
                for candidate in edge_candidates:
                    try:
                        resolved = (
                            shutil.which(candidate)
                            if candidate in {"msedgedriver", "msedgedriver.exe"}
                            else candidate
                        )
                        if not resolved or not Path(resolved).exists():
                            continue
                        service = EdgeService(executable_path=str(resolved))
                        edge_driver = webdriver.Edge(service=service, options=edge_options)
                        break
                    except Exception:
                        continue

                if edge_driver is None:
                    edge_driver = webdriver.Edge(options=edge_options)
                driver = edge_driver
            except Exception as e:
                last_error = e

        # 3) 再尝试 Selenium 默认 Chrome 流程（可能触发 selenium manager）
        if driver is None:
            try:
                driver = webdriver.Chrome(options=options)
            except Exception as e:
                last_error = e

        # 4) 最后尝试 webdriver_manager（需要网络）
        if driver is None:
            if ChromeDriverManager is None:
                raise last_error if last_error else RuntimeError("chromedriver init failed")
            try:
                service = ChromeService(ChromeDriverManager().install())
                driver = webdriver.Chrome(service=service, options=options)
            except Exception as e:
                raise RuntimeError(
                    "浏览器驱动初始化失败，请先安装本地 chromedriver，"
                    "并设置环境变量 CHROMEDRIVER 或放到项目目录 drivers/chromedriver.exe。"
                ) from e

        driver.set_page_load_timeout(max(10, _safe_int(timeout, 30)))
        try:
            driver.execute_cdp_cmd(
                "Page.addScriptToEvaluateOnNewDocument",
                {
                    "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});",
                },
            )
        except Exception:
            pass
        return driver

    @staticmethod
    def _build_liepin_url(keyword, page, city="全国"):
        kw = quote_plus(str(keyword or "").strip())
        current_page = max(_safe_int(page, 1) - 1, 0)
        city_key = Config.normalize_city_name(_normalize_filter_value(city))
        city_code = str((getattr(Config, "LIEPIN_CITY", {}) or {}).get(city_key, "") or "").strip()
        if city_key in {"", "全国", "不限", "全部"}:
            city_code = ""
        base = (
            f"https://www.liepin.com/zhaopin/?key={kw}&currentPage={current_page}"
            f"&scene=input&workYearCode=0"
        )
        if city_code:
            return f"{base}&dq={city_code}"
        return base

    @staticmethod
    def _build_liepin_alt_urls(keyword, page, city="全国"):
        kw = quote_plus(str(keyword or "").strip())
        current_page = max(_safe_int(page, 1) - 1, 0)
        city_key = Config.normalize_city_name(_normalize_filter_value(city))
        city_code = str((getattr(Config, "LIEPIN_CITY", {}) or {}).get(city_key, "") or "").strip()
        urls = [
            f"https://www.liepin.com/zhaopin/?inputFrom=www_index&key={kw}&currentPage={current_page}",
            f"https://www.liepin.com/zhaopin/?key={kw}&scene=seo&currentPage={current_page}",
        ]
        if city_code:
            urls.append(
                f"https://www.liepin.com/zhaopin/?inputFrom=www_index&key={kw}&currentPage={current_page}&dq={city_code}"
            )
        return urls

    @staticmethod
    def _maybe_blocked_text(page_text):
        text = _normalize_text(page_text).lower()
        if not text:
            return ""
        flags = {
            "captcha": ("验证码", "行为验证", "安全验证", "图形验证码", "captcha"),
            "too_frequent": ("访问频繁", "请求过于频繁", "操作过于频繁"),
            "forbidden": ("拒绝访问", "forbidden", "access denied", "403"),
        }
        for k, words in flags.items():
            for word in words:
                if word.lower() in text:
                    return k
        return ""

    def _extract_cards_liepin(self, driver):
        js = """
        const root = document.querySelector('#lp-search-job-box section.content-left-section')
          || document.querySelector('#lp-search-job-box')
          || document.body;
        const salaryReg = /(\\d+(?:\\.\\d+)?\\s*[-~至到]\\s*\\d+(?:\\.\\d+)?\\s*(?:k|K|w|W|万|千|元)|\\d+(?:\\.\\d+)?\\s*(?:k|K|w|W|万|千|元)|面议|薪资面议)/;
        const out = [];
        const seen = new Set();
        const links = Array.from(root.querySelectorAll('a[href]'));
        for (const a of links) {
          const hrefRaw = (a.getAttribute('href') || '').trim();
          if (!hrefRaw) continue;
          const href = hrefRaw.startsWith('http') ? hrefRaw : (hrefRaw.startsWith('/') ? (location.origin + hrefRaw) : hrefRaw);
          if (!/\\/job\\//i.test(href) && !/\\/a\\//i.test(href)) continue;
          if (/\\/company\\//i.test(href) || /career|city-|topic|campus/i.test(href)) continue;
          if (seen.has(href)) continue;
          const title = (a.textContent || '').trim();
          if (!title || title.length < 2 || title.length > 80) continue;
          let box = a;
          for (let i = 0; i < 8 && box && box.parentElement; i++) {
            box = box.parentElement;
            const t = (box && box.innerText) ? box.innerText : '';
            if (t && t.length > 30 && salaryReg.test(t)) break;
          }
          const boxText = (box && box.innerText) ? box.innerText : '';
          if (!boxText || boxText.length < 8) continue;
          const tags = [];
          if (box && box.querySelectorAll) {
            const nodes = Array.from(box.querySelectorAll('span,li,em'));
            for (const n of nodes) {
              const tx = (n.textContent || '').trim();
              if (!tx) continue;
              if (tx.length < 2 || tx.length > 16) continue;
              if (/^[\\d\\-/.]+$/.test(tx)) continue;
              tags.push(tx);
              if (tags.length >= 10) break;
            }
          }
          out.push({
            job_name: title,
            detail_url: href,
            text: boxText.slice(0, 1500),
            tags: tags
          });
          seen.add(href);
          if (out.length >= 120) break;
        }
        return out;
        """
        data = driver.execute_script(js) or []
        if isinstance(data, list):
            return data
        return []

    @staticmethod
    def _strip_html_text(raw_html):
        text = str(raw_html or "")
        if not text:
            return ""
        text = re.sub(r"<script[\s\S]*?</script>", " ", text, flags=re.I)
        text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
        text = re.sub(r"<[^>]+>", " ", text)
        text = unescape(text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _extract_cards_liepin_http(self, html):
        html_text = str(html or "")
        if not html_text:
            return []

        cards = []
        seen = set()
        for item in self._extract_cards_liepin_http_ldjson(html_text):
            url = str(item.get("detail_url") or "").strip()
            if not url or url in seen:
                continue
            cards.append(item)
            seen.add(url)

        pattern = re.compile(
            r"<a[^>]+href=[\"'](?P<href>[^\"']*(?:/job/|/a/)[^\"']*)[\"'][^>]*>(?P<title>[\s\S]{1,120}?)</a>",
            flags=re.I,
        )

        for m in pattern.finditer(html_text):
            href = (m.group("href") or "").strip()
            title = self._strip_html_text(m.group("title") or "")
            if not href or len(title) < 2 or len(title) > 80:
                continue
            if "/company/" in href.lower():
                continue

            if href.startswith("//"):
                detail_url = f"https:{href}"
            elif href.startswith("http"):
                detail_url = href
            elif href.startswith("/"):
                detail_url = f"https://www.liepin.com{href}"
            else:
                detail_url = href

            if detail_url in seen:
                continue

            start = max(0, m.start() - 1200)
            end = min(len(html_text), m.end() + 1200)
            nearby = self._strip_html_text(html_text[start:end])[:1600]

            cards.append(
                {
                    "job_name": title,
                    "detail_url": detail_url,
                    "text": nearby,
                    "tags": [],
                }
            )
            seen.add(detail_url)
            if len(cards) >= 140:
                break

        # 二次兜底：很多页面由前端渲染，岗位字段在 script JSON 中
        if len(cards) < 20:
            json_cards = self._extract_cards_liepin_http_json(html_text)
            for item in json_cards:
                url = str(item.get("detail_url") or "").strip()
                if not url or url in seen:
                    continue
                cards.append(item)
                seen.add(url)
                if len(cards) >= 180:
                    break

        return cards

    def _extract_cards_liepin_http_ldjson(self, html_text):
        out = []
        if not html_text:
            return out

        script_pattern = re.compile(
            r"<script[^>]*type=[\"']application/ld\+json[\"'][^>]*>(?P<json>[\s\S]*?)</script>",
            flags=re.I,
        )
        for m in script_pattern.finditer(html_text):
            raw = (m.group("json") or "").strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except Exception:
                continue

            items = data if isinstance(data, list) else [data]
            for item in items:
                if not isinstance(item, dict):
                    continue
                typ = str(item.get("@type") or "").strip().lower()
                if typ and typ != "jobposting":
                    continue

                title = _normalize_text(item.get("title") or item.get("name") or "")
                if not title or len(title) > 80:
                    continue

                detail_url = str(item.get("url") or "").strip()
                if not detail_url:
                    continue
                if detail_url.startswith("//"):
                    detail_url = f"https:{detail_url}"
                elif detail_url.startswith("/"):
                    detail_url = f"https://www.liepin.com{detail_url}"

                org = item.get("hiringOrganization") or {}
                company = ""
                if isinstance(org, dict):
                    company = _normalize_text(org.get("name") or "")

                loc = item.get("jobLocation") or {}
                city = ""
                if isinstance(loc, dict):
                    addr = loc.get("address") or {}
                    if isinstance(addr, dict):
                        city = _normalize_text(
                            addr.get("addressLocality")
                            or addr.get("addressRegion")
                            or addr.get("streetAddress")
                            or ""
                        )

                salary = ""
                base_salary = item.get("baseSalary") or {}
                if isinstance(base_salary, dict):
                    val = base_salary.get("value") or {}
                    if isinstance(val, dict):
                        min_v = val.get("minValue")
                        max_v = val.get("maxValue")
                        unit = str(val.get("unitText") or "").strip()
                        if min_v is not None and max_v is not None:
                            salary = f"{min_v}-{max_v} {unit}".strip()
                        elif min_v is not None:
                            salary = f"{min_v} {unit}".strip()

                date_posted = _normalize_text(item.get("datePosted") or "")
                packed_text = _clean_space(f"{title} {company} {city} {salary} {date_posted}")
                out.append(
                    {
                        "job_name": title,
                        "company": company[:128] if company else "",
                        "detail_url": detail_url,
                        "text": packed_text[:1500],
                        "tags": [],
                    }
                )
                if len(out) >= 200:
                    return out
        return out

    def _extract_cards_liepin_http_json(self, html_text):
        out = []
        seen = set()
        name_pattern = re.compile(r'"jobName"\s*:\s*"(?P<name>[^"]{2,120})"', flags=re.I)
        for m in name_pattern.finditer(html_text):
            start = max(0, m.start() - 900)
            end = min(len(html_text), m.end() + 1200)
            chunk = html_text[start:end]

            raw_name = m.group("name") or ""
            job_name = _normalize_text(_decode_json_escaped(raw_name))
            if not job_name or len(job_name) > 80:
                continue

            url_match = re.search(
                r'"(?:link|jobHref|pcLink|jobLink|href)"\s*:\s*"(?P<url>[^"]+)"',
                chunk,
                flags=re.I,
            )
            detail_url = (url_match.group("url") if url_match else "").strip()
            if detail_url.startswith("\\/"):
                detail_url = detail_url.replace("\\/", "/")
            if detail_url.startswith("//"):
                detail_url = f"https:{detail_url}"
            elif detail_url.startswith("/"):
                detail_url = f"https://www.liepin.com{detail_url}"
            elif detail_url and not detail_url.startswith("http"):
                detail_url = f"https://www.liepin.com/{detail_url.lstrip('/')}"

            if not detail_url or detail_url in seen:
                continue

            company_match = re.search(
                r'"(?:company|compName|companyName|brandName|corpName|enterpriseName)"\s*:\s*"(?P<v>[^"]{1,120})"',
                chunk,
                flags=re.I,
            )
            city_match = re.search(r'"(?:city|cityName)"\s*:\s*"(?P<v>[^"]{1,64})"', chunk, flags=re.I)
            salary_match = re.search(
                r'"(?:salary|salaryInfo|salaryDesc|salaryText)"\s*:\s*"(?P<v>[^"]{1,64})"',
                chunk,
                flags=re.I,
            )

            company = _normalize_text(_decode_json_escaped(company_match.group("v") if company_match else ""))
            city = _normalize_text(_decode_json_escaped(city_match.group("v") if city_match else ""))
            salary = _normalize_text(_decode_json_escaped(salary_match.group("v") if salary_match else ""))
            packed_text = f"{job_name} {company} {city} {salary}".strip()

            out.append(
                {
                    "job_name": job_name,
                    "company": company[:128] if company else "",
                    "detail_url": detail_url,
                    "text": packed_text[:1500],
                    "tags": [],
                }
            )
            seen.add(detail_url)
            if len(out) >= 200:
                break
        return out

    @staticmethod
    def _pick_company(lines, job_name):
        for line in lines:
            if not line:
                continue
            if job_name and line == job_name:
                continue
            if SALARY_PATTERN.search(line):
                continue
            if PUB_DATE_PATTERN.search(line):
                continue
            if _looks_like_company(line, job_name):
                return line[:128]
        for line in lines:
            if line and _looks_like_company(line, job_name) and len(line) <= 64:
                return line[:128]
        return "未知公司"

    @staticmethod
    def _pick_city(text):
        m = CITY_PATTERN.search(text or "")
        if m:
            return m.group(0)
        return "未知"

    @staticmethod
    def _pick_first_match(pattern, text):
        m = pattern.search(text or "")
        return m.group(1) if m else ""

    def _to_rows(self, source, cards):
        rows = []
        pub_total = 0
        pub_parsed = 0
        for card in cards:
            text = _normalize_text(card.get("text") or "")
            job_name = _clean_job_name(card.get("job_name") or "", text)
            if not job_name:
                continue
            detail_url = str(card.get("detail_url") or "").strip()
            text = text.replace("|", " ")
            lines = [_clean_space(x) for x in re.split(r"[\r\n]+", text) if _clean_space(x)]

            salary_text = _normalize_text(self._pick_first_match(SALARY_PATTERN, text))
            salary_avg = sanitize_salary_avg(parse_salary_text_to_monthly(salary_text))
            company = _clean_company_name(card.get("company") or "", job_name, text)
            if not _looks_like_company(company, job_name):
                company = _clean_company_name(self._pick_company(lines, job_name), job_name, text)
            if not _looks_like_company(company, job_name):
                company = _clean_company_name(_extract_company_inline(text), job_name, text) or "未知公司"
            city = self._pick_city(text)
            exp_req = _normalize_text(self._pick_first_match(EXP_PATTERN, text))
            edu_req = _normalize_text(self._pick_first_match(EDU_PATTERN, text))

            pub_raw = _normalize_text(self._pick_first_match(PUB_DATE_PATTERN, text))
            pub_date = normalize_pub_date(pub_raw)
            pub_total += 1
            if pub_date:
                pub_parsed += 1

            tags = card.get("tags") or []
            if not isinstance(tags, list):
                tags = []
            norm_tags = []
            for x in tags:
                sx = _normalize_text(str(x or ""))
                if sx and sx not in norm_tags:
                    norm_tags.append(sx)
            tags_text = ",".join(norm_tags[:10])
            raw_desc = text[:4000]
            skills = ",".join(extract_skills(tags_text, raw_desc))

            rows.append(
                {
                    "job_name": job_name[:128],
                    "company": company[:128],
                    "city": city[:64],
                    "salary_text": salary_text[:64],
                    "salary_avg": salary_avg,
                    "edu_req": edu_req[:32],
                    "exp_req": exp_req[:32],
                    "tags": tags_text[:1000],
                    "skills": skills[:1000],
                    "raw_desc": raw_desc,
                    "pub_date": pub_date,
                    "detail_url": detail_url[:2000],
                    "source": source,
                }
            )
        return rows, pub_total, pub_parsed

    @staticmethod
    def _safe_save_debug_html(source, prefix, content):
        try:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"debug_{source}_{prefix}_{stamp}.html"
            with open(filename, "w", encoding="utf-8", errors="ignore") as f:
                f.write(content or "")
            return filename
        except Exception:
            return ""

    def _save_rows(self, uid, source, rows):
        added = 0
        filtered = 0
        for row in rows:
            detail_url = str(row.get("detail_url") or "").strip()
            pub_date = str(row.get("pub_date") or "").strip()
            if detail_url:
                dedupe = Job.query.filter_by(
                    owner_id=uid,
                    job_name=row["job_name"],
                    company=row["company"],
                    city=row["city"],
                    source=source,
                    detail_url=detail_url,
                ).first()
            else:
                dedupe = Job.query.filter_by(
                    owner_id=uid,
                    job_name=row["job_name"],
                    company=row["company"],
                    city=row["city"],
                    source=source,
                    pub_date=pub_date,
                ).first()
            if dedupe:
                filtered += 1
                continue

            job = Job(
                owner_id=uid,
                job_name=row["job_name"],
                company=row["company"],
                city=row["city"],
                job_category="OTHER",
                salary_avg=row["salary_avg"],
                salary_text=row["salary_text"],
                edu_req=row["edu_req"] or "不限",
                exp_req=row["exp_req"] or "不限",
                skills=row["skills"],
                tags=row["tags"],
                company_size="未知规模",
                source=source,
                raw_desc=row["raw_desc"],
                pub_date=row["pub_date"],
                detail_url=row["detail_url"],
            )
            db.session.add(job)
            added += 1

        if added > 0:
            db.session.commit()
        return added, filtered

    def _wait_page_ready(self, driver, timeout):
        wait_timeout = max(8, _safe_int(timeout, 30))
        WebDriverWait(driver, wait_timeout).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        WebDriverWait(driver, wait_timeout).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "#lp-search-job-box"))
        )

    def _wait_manual_verify(self, driver, source, timeout_sec=90):
        """可见浏览器模式下，给用户手动过验证码的时间窗口。"""
        wait_total = max(20, _safe_int(timeout_sec, 90))
        waited = 0
        step = 3
        self._push_log(source, f"[ACTION] 检测到验证码，请在浏览器中完成验证（最长{wait_total}s）")
        while waited < wait_total and not self._stop_event.is_set():
            time.sleep(step)
            waited += step
            try:
                body_text = _normalize_text(driver.find_element(By.TAG_NAME, "body").text)
            except Exception:
                body_text = ""
            block_reason = self._maybe_blocked_text(body_text)
            if not block_reason:
                self._push_log(source, f"[ACTION] 验证已通过，继续采集（耗时{waited}s）")
                return True
        self._push_log(source, "[ACTION] 验证等待超时，继续按异常处理")
        return False

    @staticmethod
    def _match_city_filter(row_city, target_city):
        city = _normalize_filter_value(row_city)
        target = _normalize_filter_value(target_city)
        if not target or target in {"全国", "不限", "全部", "all", "any"}:
            return True
        if not city or city in {"未知"}:
            return False
        return target in city or city in target

    @staticmethod
    def _match_exp_filter(row_exp, target_exp):
        exp_req = _normalize_filter_value(row_exp)
        target = _normalize_filter_value(target_exp)
        if not target or target in {"不限", "全部", "all", "any"}:
            return True
        if target in exp_req:
            return True
        if target == "应届" and ("应届" in exp_req or "实习" in exp_req):
            return True
        if "不限" in exp_req and target in {"应届", "1年以内", "实习"}:
            return True
        return False

    def _apply_city_exp_filter(self, rows, city, exp):
        if not rows:
            return [], 0
        kept = []
        dropped = 0
        for row in rows:
            if not self._match_city_filter(row.get("city"), city):
                dropped += 1
                continue
            if not self._match_exp_filter(row.get("exp_req"), exp):
                dropped += 1
                continue
            kept.append(row)
        return kept, dropped

    def _run_source_http_fallback(self, source, keyword, city, exp, uid, target_count, app, timeout_sec, max_pages_limit=None):
        self._push_log(source, "[FALLBACK] start HTTP mode (no webdriver)")
        added_total = 0
        page = 1
        max_pages = min(max(3, math.ceil(max(target_count, 1) / 10) * 2), 80)
        if max_pages_limit:
            max_pages = max(1, min(max_pages, _safe_int(max_pages_limit, max_pages)))
        session = requests.Session()
        headers = {
            "User-Agent": random.choice(
                [
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                ]
            ),
            "Accept-Language": "zh-CN,zh;q=0.9",
        }

        while page <= max_pages and added_total < target_count and not self._stop_event.is_set():
            url = self._build_liepin_url(keyword=keyword, page=page, city=city)
            candidate_urls = [url] + self._build_liepin_alt_urls(keyword=keyword, page=page, city=city)
            try:
                resp = None
                page_rows = []
                pub_total = 0
                pub_parsed = 0
                scanned_count = 0
                filtered_by_condition = 0

                for candidate in candidate_urls:
                    resp = session.get(candidate, headers=headers, timeout=max(8, int(timeout_sec)))
                    if resp.status_code != 200:
                        continue
                    cards = self._extract_cards_liepin_http(resp.text or "")
                    page_rows, pub_total, pub_parsed = self._to_rows(source=source, cards=cards)
                    scanned_count = len(page_rows)
                    page_rows, filtered_by_condition = self._apply_city_exp_filter(page_rows, city, exp)
                    if scanned_count > 0:
                        break

                if resp is None or resp.status_code != 200:
                    self._push_log(source, f"[WARN] fallback http status!=200 p{page}")
                    page += 1
                    continue

                with app.app_context():
                    added, filtered = self._save_rows(uid, source, page_rows)

                added_total += added
                filtered_total = int(filtered or 0) + int(filtered_by_condition or 0)
                with self._lock:
                    self.stats["scanned"] += scanned_count
                    self.stats["added"] += added
                    self.stats["filtered"] += filtered_total
                    self.stats["pub_date_total"] += pub_total
                    self.stats["pub_date_parsed"] += pub_parsed
                    src_stats = self.stats["sources"].get(source, {})
                    src_stats["current_page"] = page
                    src_stats["scanned"] = int(src_stats.get("scanned", 0)) + scanned_count
                    src_stats["added"] = int(src_stats.get("added", 0)) + added
                    src_stats["filtered"] = int(src_stats.get("filtered", 0)) + filtered_total
                    src_stats["status"] = "running"
                    self.stats["sources"][source] = src_stats
                    self._update_progress()

                self._push_log(
                    source,
                    f"[FALLBACK] p{page}/{max_pages} scanned={scanned_count} added={added} filtered={filtered_total} total_added={added_total}",
                )

                if scanned_count == 0:
                    final_url = str(getattr(resp, "url", "") or "")
                    body_text = str(getattr(resp, "text", "") or "")
                    is_seo_shell = (
                        ("scene=seo" in final_url)
                        or ("id=\"lp-search-job-box\"" in body_text and "/job/" not in body_text)
                        or ("招聘信息_人才网招聘信息" in body_text)
                    )
                    if is_seo_shell:
                        self._set_source_error(
                            source,
                            "seo_page",
                            f"fallback redirected to seo page: {final_url}",
                            "HTTP采集被降级为SEO页面，建议优先配置本地浏览器驱动",
                        )
                    if page <= 3:
                        debug_name = self._safe_save_debug_html(source, f"fallback_p{page}", resp.text or "")
                        if debug_name:
                            self._push_log(source, f"[FALLBACK] empty html snapshot={debug_name}")
                    if page >= 3:
                        break
                page += 1
                time.sleep(random.uniform(0.4, 1.2))
            except Exception as e:
                msg = str(e)
                if "10013" in msg or "Failed to establish a new connection" in msg:
                    self._set_source_error(
                        source,
                        "network_block",
                        msg,
                        "网络连接被系统/安全软件拦截（WinError 10013），请放行 Python/浏览器访问外网后重试",
                    )
                self._push_log(source, f"[WARN] fallback crawl error p{page}: {e}")
                with self._lock:
                    self.stats["failed"] += 1
                    src_stats = self.stats["sources"].get(source, {})
                    src_stats["failed"] = int(src_stats.get("failed", 0)) + 1
                    self.stats["sources"][source] = src_stats
                    self._update_progress()
                page += 1

        with self._lock:
            src_stats = self.stats["sources"].get(source, {})
            if src_stats.get("status") == "running":
                src_stats["status"] = "done"
            self.stats["sources"][source] = src_stats
        self._push_log(source, f"[FALLBACK] done total_added={added_total}")

    def _run_source(self, source, keyword, city, uid, target_count, headless, app, options):
        retry_times = max(1, _safe_int((options or {}).get("retry"), 3))
        timeout_sec = max(10, _safe_int((options or {}).get("timeout"), 30))
        exp = _normalize_filter_value((options or {}).get("exp") or "不限")
        max_pages_limit = max(1, _safe_int((options or {}).get("max_pages"), Config.SPIDER_SETTINGS.get("MAX_PAGE", 30)))
        page_size_estimate = 20
        expect_pages = max(1, math.ceil(max(target_count, 1) / page_size_estimate))
        max_pages = min(max(expect_pages * 3, expect_pages + 2), 120)
        if max_pages_limit:
            max_pages = max(1, min(max_pages, max_pages_limit))

        with self._lock:
            src_stats = self.stats["sources"].get(source, {})
            src_stats["status"] = "running"
            src_stats["total_pages"] = max_pages
            self.stats["sources"][source] = src_stats

        build_tag = "spider-build-20260303-06"
        self._push_log(source, f"task started keyword={keyword} city={city} exp={exp} target={target_count} [{build_tag}]")
        self._push_log(source, f"[INFO] initializing webdriver... [{build_tag}]")
        driver_box = {"driver": None, "error": None}

        def _init_driver():
            try:
                driver_box["driver"] = self._create_driver(headless=headless, timeout=timeout_sec)
            except Exception as e:
                driver_box["error"] = e

        init_timeout = max(25, timeout_sec + 12)
        init_thread = threading.Thread(target=_init_driver, daemon=True)
        init_thread.start()
        waited = 0
        step = 5
        while init_thread.is_alive() and waited < init_timeout:
            remain = max(0, init_timeout - waited)
            this_wait = min(step, remain)
            init_thread.join(timeout=this_wait)
            waited += this_wait
            if init_thread.is_alive():
                self._push_log(source, f"[INFO] webdriver init waiting {waited}/{init_timeout}s")

        if init_thread.is_alive():
            self._set_source_error(
                source,
                "driver_init_timeout",
                f"driver init timeout>{init_timeout}s",
                "浏览器驱动初始化超时，已自动切换HTTP兜底采集",
            )
            self._push_log(source, f"[ERROR] driver init timeout > {init_timeout}s")
            try:
                self._run_source_http_fallback(
                    source=source,
                    keyword=keyword,
                    city=city,
                    exp=exp,
                    uid=uid,
                    target_count=target_count,
                    app=app,
                    timeout_sec=timeout_sec,
                    max_pages_limit=max_pages_limit,
                )
            except Exception as fb_e:
                self._set_source_error(
                    source,
                    "fallback_error",
                    str(fb_e),
                    "HTTP兜底采集执行失败，请检查网络或目标网站访问策略",
                )
                self._push_log(source, f"[ERROR] fallback failed: {fb_e}")
            return

        if driver_box.get("error") is not None or driver_box.get("driver") is None:
            e = driver_box.get("error") or RuntimeError("driver init failed")
            self._set_source_error(
                source,
                "driver_init",
                str(e),
                "浏览器驱动初始化失败，请安装本地 chromedriver/msedgedriver 或检查网络后重试",
            )
            self._push_log(source, f"[ERROR] driver init failed: {e}")
            try:
                self._run_source_http_fallback(
                        source=source,
                        keyword=keyword,
                        city=city,
                        exp=exp,
                        uid=uid,
                        target_count=target_count,
                        app=app,
                        timeout_sec=timeout_sec,
                        max_pages_limit=max_pages_limit,
                    )
            except Exception as fb_e:
                self._set_source_error(
                    source,
                    "fallback_error",
                    str(fb_e),
                    "HTTP兜底采集执行失败，请检查网络或目标网站访问策略",
                )
                self._push_log(source, f"[ERROR] fallback failed: {fb_e}")
            return

        driver = driver_box["driver"]
        self._push_log(source, "[INFO] webdriver initialized, start crawling pages")
        with self._lock:
            self.drivers[source] = driver

        added_total = 0
        empty_pages = 0
        for page in range(1, max_pages + 1):
            if self._stop_event.is_set():
                with self._lock:
                    self.stats["sources"][source]["status"] = "paused"
                self._push_log(source, "收到停止信号，任务已暂停")
                break

            if added_total >= target_count:
                break

            url = self._build_liepin_url(keyword=keyword, page=page, city=city)
            success_page = False
            page_rows = []
            pub_total = 0
            pub_parsed = 0
            scanned_count = 0
            filtered_by_condition = 0

            for attempt in range(1, retry_times + 1):
                if self._stop_event.is_set():
                    break
                try:
                    driver.get(url)
                    self._wait_page_ready(driver, timeout_sec)
                    time.sleep(random.uniform(1.2, 2.3))

                    cards = self._extract_cards_liepin(driver)
                    page_rows, pub_total, pub_parsed = self._to_rows(source=source, cards=cards)
                    scanned_count = len(page_rows)
                    body_text = _normalize_text(driver.find_element(By.TAG_NAME, "body").text)
                    block_reason = self._maybe_blocked_text(body_text)
                    if block_reason and scanned_count == 0:
                        if not headless:
                            verified = self._wait_manual_verify(driver, source, timeout_sec=90)
                            if verified:
                                cards = self._extract_cards_liepin(driver)
                                page_rows, pub_total, pub_parsed = self._to_rows(source=source, cards=cards)
                                scanned_count = len(page_rows)
                        if scanned_count == 0:
                            self._set_source_error(
                                source,
                                "anti_bot",
                                f"blocked reason={block_reason}",
                                "触发网站验证码拦截，请在可见浏览器完成验证后重试",
                            )
                            self._push_log(source, f"[WARN] anti-bot detected: {block_reason}")
                            empty_pages += 1
                            break
                    if scanned_count == 0:
                        html = driver.page_source or ""
                        if "lp-search-job-box" in html and "/job/" not in html and "招聘信息_人才网招聘信息" in html:
                            self._set_source_error(
                                source,
                                "seo_shell",
                                "browser page has seo shell only",
                                "页面仅返回SEO壳数据，可能被反爬或资源加载受限，建议切换非无头并检查网络策略",
                            )
                    page_rows, filtered_by_condition = self._apply_city_exp_filter(page_rows, city, exp)
                    success_page = True
                    break
                except TimeoutException as e:
                    self._set_source_error(
                        source,
                        "page_timeout",
                        str(e),
                        "页面加载超时，建议增大超时时间或降低采集频率",
                    )
                    self._push_log(source, f"[WARN] page timeout p{page} retry {attempt}/{retry_times}")
                except WebDriverException as e:
                    self._set_source_error(
                        source,
                        "webdriver",
                        str(e),
                        "浏览器驱动异常，请检查浏览器是否可正常启动",
                    )
                    self._push_log(source, f"[WARN] webdriver error p{page}: {e}")
                except Exception as e:
                    self._set_source_error(
                        source,
                        "parse_error",
                        str(e),
                        "页面结构可能变化，请更新解析规则",
                    )
                    self._push_log(source, f"[WARN] parse error p{page}: {e}")
                time.sleep(min(2.0 + attempt, 6.0))

            if not success_page:
                with self._lock:
                    self.stats["failed"] += 1
                    self.stats["sources"][source]["failed"] += 1
                    self.stats["sources"][source]["current_page"] = page
                    self._update_progress()
                if empty_pages >= 2:
                    with self._lock:
                        self.stats["sources"][source]["status"] = "blocked"
                    self._push_log(source, "[DEGRADE] 连续空页或异常>=2，暂停当前源")
                    break
                continue

            if scanned_count == 0:
                empty_pages += 1
                page_html = ""
                try:
                    page_html = driver.page_source or ""
                except Exception:
                    pass
                debug_name = self._safe_save_debug_html(source, "empty", page_html) if page_html else ""
                if debug_name:
                    self._push_log(source, f"[WARN] empty page p{page}, debug={debug_name}")
                else:
                    self._push_log(source, f"[WARN] empty page p{page}")

                with self._lock:
                    self.stats["sources"][source]["current_page"] = page
                    self.stats["failed"] += 1
                    self.stats["sources"][source]["failed"] += 1
                    self._update_progress()

                if empty_pages >= 2:
                    with self._lock:
                        self.stats["sources"][source]["status"] = "blocked"
                    self._push_log(source, "[DEGRADE] 连续空页>=2，暂停当前源")
                    break
                continue

            empty_pages = 0
            try:
                with app.app_context():
                    added, filtered = self._save_rows(uid, source, page_rows)
            except Exception as e:
                db.session.rollback()
                added, filtered = 0, 0
                self._set_source_error(
                    source,
                    "db_error",
                    str(e),
                    "数据库写入失败，请检查字段约束与连接状态",
                )
                with self._lock:
                    self.stats["failed"] += scanned_count
                    self.stats["sources"][source]["failed"] += scanned_count
                    self._update_progress()
                self._push_log(source, f"[ERROR] db save failed p{page}: {e}")
                continue

            added_total += added
            filtered_total = filtered + int(filtered_by_condition or 0)
            with self._lock:
                self.stats["scanned"] += scanned_count
                self.stats["added"] += added
                self.stats["filtered"] += filtered_total
                self.stats["pub_date_total"] += pub_total
                self.stats["pub_date_parsed"] += pub_parsed

                self.stats["sources"][source]["current_page"] = page
                self.stats["sources"][source]["scanned"] += scanned_count
                self.stats["sources"][source]["added"] += added
                self.stats["sources"][source]["filtered"] += filtered_total
                self._update_progress()

            self._push_log(
                source,
                f"p{page}/{max_pages} scanned={scanned_count} added={added} filtered={filtered_total} total_added={added_total}",
            )
            time.sleep(random.uniform(0.8, 1.8))

        with self._lock:
            st = self.stats["sources"][source].get("status")
            if st == "running":
                self.stats["sources"][source]["status"] = "done"
        self._push_log(source, f"task finished total_added={added_total}")

        driver = None
        with self._lock:
            driver = self.drivers.pop(source, None)
        if driver:
            try:
                driver.quit()
            except Exception:
                pass

    def _watch_finish(self):
        for name, t in list(self.threads.items()):
            if name == "__watcher__":
                continue
            t.join()
        with self._lock:
            self.is_running = False
            for src, st in self.stats.get("sources", {}).items():
                if st.get("status") == "running":
                    st["status"] = "done"
            self._update_progress()
        self._push_log("SYSTEM", "全部采集任务已结束")
        app = self._app
        if app is not None:
            self._persist_task_finish(app)
        self._app = None

    def run(self, keyword, city, exp, uid, sources, target_count, headless, app, options=None):
        with self._lock:
            if self.is_running:
                return False
            self.is_running = True
            self.logs = deque(maxlen=2000)
            self._stop_event.clear()
            self.threads = {}
            self.drivers = {}
            self._init_stats(target_count, sources)
            self._app = app

            expected_pages = max(1, math.ceil(target_count / 20))
            expected_minutes = max(1, math.ceil(expected_pages * 1.8))
            self.meta = {
                "keyword": keyword,
                "city": city,
                "sources": list(sources),
                "target_count": int(target_count),
                "owner_id": int(uid),
                "expected_pages": expected_pages,
                "expected_minutes": expected_minutes,
                "started_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "options": options or {},
            }

        task_id = self._persist_task_start(
            app=app,
            uid=uid,
            keyword=keyword,
            city=city,
            exp=exp,
            sources=sources,
            target_count=target_count,
            headless=headless,
            options=options or {},
        )
        with self._lock:
            self.meta["task_id"] = task_id

        n = max(1, len(sources))
        base = max(1, target_count // n)
        remain = max(0, target_count - base * n)

        for idx, source in enumerate(sources):
            t_target = base + (1 if idx < remain else 0)
            t = threading.Thread(
                target=self._run_source,
                args=(source, keyword, city, uid, t_target, headless, app, options or {}),
                daemon=True,
            )
            self.threads[source] = t
            t.start()

        watcher = threading.Thread(target=self._watch_finish, daemon=True)
        self.threads["__watcher__"] = watcher
        watcher.start()
        self._push_log("SYSTEM", f"任务已启动 sources={','.join(sources)} target={target_count} [spider-build-20260303-06]")
        return True

    def stop(self):
        self._stop_event.set()
        stopped_sources = []
        join_status = {}

        with self._lock:
            local_drivers = dict(self.drivers)
        for source, driver in local_drivers.items():
            try:
                driver.quit()
                self._push_log(source, "driver 已释放")
            except Exception:
                pass

        for name, t in list(self.threads.items()):
            if name == "__watcher__":
                continue
            if t.is_alive():
                stopped_sources.append(name)
            t.join(timeout=10)
            join_status[name] = not t.is_alive()

        with self._lock:
            self.is_running = False
            for src, st in self.stats.get("sources", {}).items():
                if st.get("status") == "running":
                    st["status"] = "paused"
            self.drivers = {}
            self._update_progress()
            self.meta["final_status"] = "stopped"

        self._push_log("SYSTEM", "收到停止请求，采集任务已停止")
        app = self._app
        if app is not None:
            self._persist_task_finish(app, status="stopped")
        self._app = None
        return {
            "stopped_sources": stopped_sources,
            "join_status": join_status,
        }


spider_instance = SpiderManager()
