import re
from datetime import datetime


_CITY_NOISE_KEYWORDS = (
    "在线",
    "活跃",
    "刚刚",
    "小时前",
    "分钟前",
    "不限",
    "经验",
    "回复",
)

_UNKNOWN_CITY_VALUES = {"unknown", "unk", "na", "null"}
_SKILL_SPLIT_RE = re.compile(r"[,，、/|\s]+")
_DATE_PATTERNS = ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d")


def normalize_date_str(value) -> str:
    """解析日期文本，成功时返回 YYYY-MM-DD。"""
    text = str(value or "").strip()
    if not text:
        return ""
    for fmt in _DATE_PATTERNS:
        try:
            return datetime.strptime(text[:10], fmt).strftime("%Y-%m-%d")
        except Exception:
            continue
    return ""


def is_unknown_city(city_text: str) -> bool:
    city = str(city_text or "").strip()
    if not city:
        return True
    lower = city.lower()
    if lower in _UNKNOWN_CITY_VALUES:
        return True
    return any(keyword in city for keyword in _CITY_NOISE_KEYWORDS)


def is_normalized_skill_text(skill_text: str) -> bool:
    """判断技能字段是否为简洁的技能列表文本。"""
    text = str(skill_text or "").strip()
    if not text or len(text) > 300:
        return False
    tokens = [t.strip() for t in _SKILL_SPLIT_RE.split(text) if t.strip()]
    if not tokens or len(tokens) > 40:
        return False
    return not any(len(token) > 32 for token in tokens)
