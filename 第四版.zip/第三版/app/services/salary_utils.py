﻿import re


SALARY_MIN_VALID = 1000
SALARY_MAX_VALID = 200000

_NO_SALARY_TOKENS = (
    "面议",
    "保密",
    "待定",
    "negotiable",
    "n/a",
    "null",
)

_PERIOD_ANNUAL = ("年薪", "/年", "每年", "年")
_PERIOD_DAILY = ("日薪", "/天", "每天", "天")
_PERIOD_HOURLY = ("时薪", "小时", "/时", "/h", "每小时")

_UNIT_FACTORS = {
    "k": 1000.0,
    "w": 10000.0,
    "万": 10000.0,
    "千": 1000.0,
    "元": 1.0,
}


def _to_float(value):
    try:
        return float(value)
    except Exception:
        return 0.0


def is_reasonable_salary(value, min_valid=SALARY_MIN_VALID, max_valid=SALARY_MAX_VALID):
    num = _to_float(value)
    return min_valid <= num <= max_valid


def sanitize_salary_avg(value, min_valid=SALARY_MIN_VALID, max_valid=SALARY_MAX_VALID):
    num = _to_float(value)
    if num <= 0:
        return 0
    if not is_reasonable_salary(num, min_valid, max_valid):
        return 0
    return int(round(num))


def _normalize_text(text):
    t = str(text or "").strip()
    if not t:
        return ""
    t = t.replace(",", "").replace("，", "")
    t = t.replace("~", "-").replace("～", "-").replace("—", "-").replace("–", "-")
    t = t.replace("至", "-").replace("到", "-")
    t = re.sub(r"\s+", " ", t)
    return t.lower()


def _has_salary_context(text):
    if not re.search(r"\d", text):
        return False
    return bool(re.search(r"(k|w|万|千|元|薪|/月|/年|/天|/时|年薪|月薪|日薪|时薪)", text))


def _resolve_global_unit(text):
    if "万" in text:
        return "万"
    if re.search(r"(?<![a-z])w(?![a-z])", text):
        return "w"
    if "千" in text:
        return "千"
    if re.search(r"(?<![a-z])k(?![a-z])", text):
        return "k"
    if "元" in text:
        return "元"
    return ""


def _months_factor(text):
    m = re.search(r"(\d{2})\s*薪", text)
    if not m:
        return 1.0
    months = int(m.group(1))
    return months / 12.0 if 13 <= months <= 20 else 1.0


def _period_factor(text):
    if any(k in text for k in _PERIOD_HOURLY):
        # 8 小时/天 * 21.75 天/月
        return 174.0
    if any(k in text for k in _PERIOD_DAILY):
        return 21.75
    if any(k in text for k in _PERIOD_ANNUAL):
        return 1.0 / 12.0
    return 1.0


def _convert_with_unit(number, unit):
    u = (unit or "").lower()
    factor = _UNIT_FACTORS.get(u, 0.0)
    if factor <= 0:
        return 0.0
    return _to_float(number) * factor


def parse_salary_text_to_monthly(salary_text, min_valid=SALARY_MIN_VALID, max_valid=SALARY_MAX_VALID):
    text = _normalize_text(salary_text)
    if not text:
        return 0
    if any(token in text for token in _NO_SALARY_TOKENS):
        return 0
    if not _has_salary_context(text):
        # 纯数字或无单位文本不视为可信薪资，避免把岗位编号当薪资。
        return 0

    period_factor = _period_factor(text)
    month_bonus = _months_factor(text)
    global_unit = _resolve_global_unit(text)

    # 区间薪资：12-20k / 1.5-2.2万 / 300-500元/天
    range_match = re.search(
        r"(\d+(?:\.\d+)?)\s*(k|w|万|千|元)?\s*-\s*(\d+(?:\.\d+)?)\s*(k|w|万|千|元)?",
        text,
        flags=re.IGNORECASE,
    )
    if range_match:
        low_num, low_unit, high_num, high_unit = (
            range_match.group(1),
            (range_match.group(2) or "").lower(),
            range_match.group(3),
            (range_match.group(4) or "").lower(),
        )
        low_unit = low_unit or high_unit or global_unit
        high_unit = high_unit or low_unit or global_unit
        if low_unit and high_unit:
            low_val = _convert_with_unit(low_num, low_unit)
            high_val = _convert_with_unit(high_num, high_unit)
            if low_val > 0 and high_val > 0:
                monthly = (low_val + high_val) / 2.0 * period_factor * month_bonus
                return sanitize_salary_avg(monthly, min_valid, max_valid)

    # 单值薪资：15k / 2万 / 8500元
    single_match = re.search(r"(\d+(?:\.\d+)?)\s*(k|w|万|千|元)", text, flags=re.IGNORECASE)
    if single_match:
        num = single_match.group(1)
        unit = single_match.group(2).lower()
        val = _convert_with_unit(num, unit)
        if val > 0:
            monthly = val * period_factor * month_bonus
            return sanitize_salary_avg(monthly, min_valid, max_valid)

    return 0
