﻿import math
import math
import re

from sqlalchemy import func

from app.models.job import Job
from app.services.data_quality_utils import is_normalized_skill_text, is_unknown_city, normalize_date_str
from app.services.salary_utils import sanitize_salary_avg


class StandardOutputService:
    """统一输出层：系统指标、分析标准化、决策解释与建议。"""

    @staticmethod
    def _safe_int(value, default=0):
        try:
            if value is None:
                return default
            return int(round(float(value)))
        except Exception:
            return default

    @staticmethod
    def _safe_float(value, default=0.0, digits=2):
        try:
            if value is None:
                return default
            return round(float(value), digits)
        except Exception:
            return default

    @classmethod
    def _ratio_to_percent(cls, value, digits=1):
        val = cls._safe_float(value, 0.0, 4)
        if val <= 1:
            return round(val * 100, digits)
        return round(val, digits)

    @staticmethod
    def _percentile(values, q):
        if not values:
            return 0
        arr = sorted(float(v) for v in values if v is not None)
        if not arr:
            return 0
        if len(arr) == 1:
            return int(arr[0])
        pos = (len(arr) - 1) * q
        left = int(math.floor(pos))
        right = int(math.ceil(pos))
        if left == right:
            return int(round(arr[left]))
        frac = pos - left
        val = arr[left] * (1 - frac) + arr[right] * frac
        return int(round(val))

    @staticmethod
    def _normalize_date_str(raw):
        return normalize_date_str(raw)

    @staticmethod
    def _line(text):
        return text.strip() if isinstance(text, str) else ""

    @staticmethod
    def _is_noise_gap_token(token):
        t = str(token or "").strip().lower()
        if not t:
            return True
        if len(t) < 2 or len(t) > 24:
            return True
        if t.isdigit():
            return True
        if re.fullmatch(r"\d+[kKwW]?[-~]\d+[kKwW]?", t):
            return True

        noise_terms = {
            "北京", "上海", "深圳", "广州", "杭州", "成都", "西安", "南京", "武汉", "苏州", "全国",
            "公司", "服务", "服务公司", "专业", "学历", "本科", "大专", "硕士", "博士", "应届",
            "岗位", "职位", "工作", "要求", "相关", "方向", "业务", "项目", "平台", "系统", "模块",
            "能力", "经验", "以上", "以下", "优先", "负责", "良好", "沟通", "团队"
        }
        if t in noise_terms:
            return True
        if t.endswith("公司") and len(t) <= 4:
            return True
        if t.endswith("专业") and len(t) <= 6:
            return True
        return False

    @classmethod
    def _clean_gap_tokens(cls, tokens, limit=None):
        out = []
        seen = set()
        for token in (tokens or []):
            text = str(token or "").strip()
            if not text:
                continue
            key = text.lower()
            if key in seen:
                continue
            if cls._is_noise_gap_token(text):
                continue
            seen.add(key)
            out.append(text)
            if limit and len(out) >= limit:
                break
        return out

    @classmethod
    def build_system_metrics(cls, user_id):
        """模块1：系统指标输出层（用户维度）。"""
        base_q = Job.query.filter(Job.owner_id == user_id)
        rows = base_q.with_entities(
            Job.job_name, Job.company, Job.city, Job.source, Job.detail_url, Job.pub_date, Job.salary_avg, Job.skills
        ).all()
        job_total = len(rows)

        if job_total == 0:
            return {
                "job_total": 0,
                "city_count": 0,
                "source_count": 0,
                "updated_at": "",
                "salary_median_all": 0,
                "salary_top20_threshold": 0,
                "salary_valid_rate": 0.0,
                "skill_coverage_rate": 0.0,
                "pub_date_parse_rate": 0.0,
                "duplicate_rate": 0.0,
                "unknown_city_rate": 0.0,
                "avg_salary": 0,
                "high_salary_threshold": 0,
                "skill_coverage": 0.0,
                "data_freshness": "",
            }

        city_set = set()
        source_set = set()
        salaries = []
        parsed_dates = []
        dedupe_counter = {}
        unknown_city_count = 0
        skill_valid_count = 0

        for job_name, company, city, source, detail_url, pub_date, salary_avg, skills in rows:
            city_str = str(city or "").strip()
            source_str = str(source or "").strip()
            if city_str:
                city_set.add(city_str)
            if source_str:
                source_set.add(source_str)

            fixed_salary = sanitize_salary_avg(salary_avg)
            if fixed_salary > 0:
                salaries.append(float(fixed_salary))

            norm_date = cls._normalize_date_str(pub_date)
            if norm_date:
                parsed_dates.append(norm_date)

            if is_unknown_city(city_str):
                unknown_city_count += 1
            if is_normalized_skill_text(skills):
                skill_valid_count += 1

            dedupe_key = (
                str(job_name or "").strip().lower(),
                str(company or "").strip().lower(),
                city_str.lower(),
                source_str.lower(),
                str(detail_url or "").strip().lower() or norm_date,
            )
            dedupe_counter[dedupe_key] = dedupe_counter.get(dedupe_key, 0) + 1

        duplicate_records = sum(max(v - 1, 0) for v in dedupe_counter.values())
        duplicate_rate = round(duplicate_records / job_total, 4)
        pub_date_parse_rate = round(len(parsed_dates) / job_total, 4)
        unknown_city_rate = round(unknown_city_count / job_total, 4)
        skill_coverage = round(skill_valid_count / job_total, 4)
        valid_salary_rate = round(len(salaries) / job_total, 4)

        avg_salary = cls._safe_int(sum(salaries) / len(salaries) if salaries else 0)
        median_salary = cls._percentile(salaries, 0.5)
        high_salary_threshold = cls._percentile(salaries, 0.8)
        data_freshness = max(parsed_dates) if parsed_dates else ""

        return {
            "job_total": int(job_total),
            "city_count": int(len(city_set)),
            "source_count": int(len(source_set)),
            "updated_at": data_freshness,
            "salary_median_all": int(median_salary or 0),
            "salary_top20_threshold": int(high_salary_threshold or 0),
            "salary_valid_rate": float(valid_salary_rate),
            "skill_coverage_rate": float(skill_coverage),
            "pub_date_parse_rate": float(pub_date_parse_rate),
            "duplicate_rate": float(duplicate_rate),
            "unknown_city_rate": float(unknown_city_rate),
            # 兼容旧前端字段
            "avg_salary": avg_salary,
            "high_salary_threshold": high_salary_threshold,
            "skill_coverage": float(skill_coverage),
            "data_freshness": data_freshness,
        }

    @classmethod
    def build_system_interpretation(cls, metrics):
        """生成前端可直接展示的系统解读文案。"""
        if not metrics or not metrics.get("job_total"):
            return ["当前暂无有效岗位数据，请先采集或导入数据。"]

        lines = []
        job_total = metrics.get("job_total", 0)
        city_count = metrics.get("city_count", 0)
        avg_salary = metrics.get("avg_salary", 0)
        high_salary = metrics.get("high_salary_threshold", 0)
        skill_cov = metrics.get("skill_coverage", 0.0)
        freshness = metrics.get("data_freshness") or "未知"

        lines.append(f"当前样本库包含 {job_total} 条岗位记录，覆盖 {city_count} 个城市。")
        if avg_salary > 0:
            lines.append(f"样本平均薪资约 {avg_salary} 元，Top20% 高薪门槛约 {high_salary} 元。")
        lines.append(f"技能字段覆盖率约 {int(round(skill_cov * 100))}%，最近数据日期为 {freshness}。")
        return lines[:3]

    @classmethod
    def build_quality_gate(cls, metrics, scene="analysis"):
        """生成分析/推荐前的质量准入判断。"""
        metrics = metrics or {}
        job_total = cls._safe_int(metrics.get("job_total") or metrics.get("sample_size"))
        salary_valid_rate = cls._ratio_to_percent(metrics.get("salary_valid_rate"))
        skill_coverage_rate = cls._ratio_to_percent(
            metrics.get("skill_coverage_rate") if metrics.get("skill_coverage_rate") is not None else metrics.get("skill_coverage")
        )
        pub_date_parse_rate = cls._ratio_to_percent(metrics.get("pub_date_parse_rate"))
        duplicate_rate = cls._ratio_to_percent(metrics.get("duplicate_rate"))
        unknown_city_rate = cls._ratio_to_percent(metrics.get("unknown_city_rate"))

        scene = str(scene or "analysis").lower()
        sample_block = 20 if scene.startswith("recommend") else 30
        sample_warn = 80 if scene.startswith("recommend") else 120
        salary_block = 35 if scene.startswith("recommend") else 40
        skill_block = 25 if scene.startswith("recommend") else 35
        pub_block = 0 if scene.startswith("recommend") else 45

        blockers = []
        warnings = []

        if job_total < sample_block:
            blockers.append(f"当前样本仅 {job_total} 条，低于最低阈值 {sample_block} 条。")
        elif job_total < sample_warn:
            warnings.append(f"当前样本 {job_total} 条，结论稳定性一般，建议继续补充样本。")

        if salary_valid_rate < salary_block:
            blockers.append(f"有效薪资占比仅 {salary_valid_rate}%，薪资相关结论不可靠。")
        elif salary_valid_rate < 60:
            warnings.append(f"有效薪资占比 {salary_valid_rate}%，建议先补齐薪资字段。")

        if skill_coverage_rate < skill_block:
            blockers.append(f"规范技能覆盖率仅 {skill_coverage_rate}%，个性化推荐依据不足。")
        elif skill_coverage_rate < 60:
            warnings.append(f"规范技能覆盖率 {skill_coverage_rate}%，技能差距分析可信度一般。")

        if pub_block > 0:
            if pub_date_parse_rate < pub_block:
                blockers.append(f"发布时间解析率仅 {pub_date_parse_rate}%，趋势分析不具备参考价值。")
            elif pub_date_parse_rate < 70:
                warnings.append(f"发布时间解析率 {pub_date_parse_rate}%，趋势结论建议谨慎使用。")

        if duplicate_rate >= 15:
            warnings.append(f"重复率 {duplicate_rate}%，建议先执行去重后再分析。")
        if unknown_city_rate >= 18:
            warnings.append(f"未知城市率 {unknown_city_rate}%，城市对比可能失真。")

        readiness_score = int(
            max(
                0,
                min(
                    100,
                    job_total / max(sample_warn, 1) * 25
                    + salary_valid_rate * 0.25
                    + skill_coverage_rate * 0.20
                    + max(pub_date_parse_rate, 60 if scene.startswith("recommend") else pub_date_parse_rate) * 0.20
                    - duplicate_rate * 0.07
                    - unknown_city_rate * 0.03,
                ),
            )
        )
        level = "blocked" if blockers else ("warning" if warnings else "ready")
        if blockers:
            summary = "当前数据质量未达到决策准入门槛，建议先修复数据后再看结论。"
        elif warnings:
            summary = "当前数据可用于分析，但建议结合质量风险谨慎解读。"
        else:
            summary = "当前数据质量达到决策准入门槛，可直接进入分析与投递决策。"

        actions = []
        if job_total < sample_warn:
            actions.append("继续采集或导入岗位数据，优先补足目标岗位最近 30 天样本。")
        if salary_valid_rate < 60:
            actions.append("优先补齐薪资字段，避免薪资预测与定价建议失真。")
        if skill_coverage_rate < 60:
            actions.append("统一技能字段格式，提升技能差距与匹配分析可信度。")
        if pub_block > 0 and pub_date_parse_rate < 70:
            actions.append("统一发布时间格式为 YYYY-MM-DD，再查看趋势分析。")
        if duplicate_rate >= 15:
            actions.append("先按 岗位 + 公司 + 城市 去重，降低重复样本干扰。")
        if not actions:
            actions.append("数据状态良好，可直接进入推荐、岗位评估和投递决策。")

        return {
            "scene": scene,
            "blocking": bool(blockers),
            "level": level,
            "readiness_score": readiness_score,
            "summary": summary,
            "blockers": blockers[:3],
            "warnings": warnings[:3],
            "actions": actions[:4],
            "metrics": {
                "job_total": job_total,
                "salary_valid_rate": salary_valid_rate,
                "skill_coverage_rate": skill_coverage_rate,
                "pub_date_parse_rate": pub_date_parse_rate,
                "duplicate_rate": duplicate_rate,
                "unknown_city_rate": unknown_city_rate,
            },
        }

    @classmethod
    def build_analysis_standard_output(cls, dashboard_payload):
        """模块2：分析模块标准化输出（5类结论，结论+依据+可视化）。"""
        if not dashboard_payload:
            return {}

        meta = dashboard_payload.get("meta", {}) or {}
        insights = dashboard_payload.get("insights", {}) or {}
        charts = dashboard_payload.get("charts", {}) or {}
        system_metrics = dashboard_payload.get("system_metrics", {}) or {}
        stats = meta.get("stats", {}) or {}
        salary_depth = insights.get("salary_depth", {}) or {}
        skills = insights.get("skills", {}) or {}

        city_chart = charts.get("city", {}) or {}
        salary_chart = charts.get("salary", {}) or {}
        edu_chart = charts.get("edu", {}) or {}
        demand_index = insights.get("demand_index", {}) or {}

        city_labels = city_chart.get("labels", []) or []
        city_avgs = city_chart.get("avg", []) or []
        top_city = None
        if city_labels and city_avgs:
            top_city = {"city": city_labels[0], "avg_salary": cls._safe_int(city_avgs[0])}

        high_value_skills = skills.get("high_value", []) or []
        top_skill = high_value_skills[0] if high_value_skills else None

        exp_trend = salary_chart.get("exp_trend", {}) or {}
        exp_labels = exp_trend.get("labels", []) or []
        exp_values = exp_trend.get("values", []) or []
        best_exp = None
        if exp_labels and exp_values:
            idx = max(range(len(exp_values)), key=lambda i: exp_values[i] or 0)
            best_exp = {
                "experience": exp_labels[idx],
                "avg_salary": cls._safe_int(exp_values[idx]),
            }

        demand_categories = demand_index.get("categories", []) or []
        top_category = demand_categories[0] if demand_categories else None

        avg_salary = cls._safe_int(stats.get("avg_salary"))
        median_salary = cls._safe_int(stats.get("median_salary") or salary_depth.get("median"))
        top20_threshold = cls._safe_int(
            system_metrics.get("high_salary_threshold") or salary_depth.get("q75") or salary_depth.get("q90") or stats.get("max_salary")
        )

        salary_item = {
            "conclusion": (
                f"样本平均薪资 {avg_salary} 元，中位数 {median_salary} 元，Top20% 门槛约 {top20_threshold} 元。"
                if stats.get("count", 0) > 0 else "暂无有效薪资样本，无法输出薪资结论。"
            ),
            "evidence": {
                "sample_size": int(stats.get("valid_salary_count", 0)),
                "avg_salary": avg_salary,
                "median_salary": median_salary,
                "top20_threshold": top20_threshold,
                "top10_threshold": cls._safe_int(salary_depth.get("q90") or 0),
            },
            "visualization": {
                "chart_id": "chart-salary-dist",
                "chart_key": "salary",
                "series": ["exp_trend", "range_dist"],
            },
        }

        skills_item = {
            "conclusion": (
                f"高价值技能以「{top_skill.get('name')}」为代表，薪资溢价约 {cls._safe_float(top_skill.get('premium'), 0, 1)}%。"
                if top_skill else "当前样本暂未识别出稳定的高溢价技能。"
            ),
            "evidence": {
                "high_value_skills": high_value_skills[:8],
                "common_skills": skills.get("common", [])[:8],
            },
            "visualization": {
                "chart_id": "chart-cloud-dash",
                "chart_key": "cloud",
                "series": ["high_value_skill_premium", "wordcloud"],
            },
        }

        city_item = {
            "conclusion": (
                f"{top_city['city']} 在样本城市中平均薪资领先（约 {top_city['avg_salary']} 元）。"
                if top_city else "暂无城市维度结论。"
            ),
            "evidence": {
                "city_count": int(stats.get("city_count", 0)),
                "top_cities": [
                    {"city": city_labels[i], "avg_salary": cls._safe_int(city_avgs[i])}
                    for i in range(min(10, len(city_labels), len(city_avgs)))
                ],
            },
            "visualization": {
                "chart_id": "chart-city-dash",
                "chart_key": "city",
                "series": ["avg_salary_by_city"],
            },
        }

        experience_item = {
            "conclusion": (
                f"经验回报最高的样本区间为「{best_exp['experience']}」，对应平均薪资约 {best_exp['avg_salary']} 元。"
                if best_exp else "暂无经验回报结论。"
            ),
            "evidence": {
                "exp_salary_labels": exp_labels,
                "exp_salary_values": [cls._safe_int(v) for v in exp_values],
                "best_experience_band": best_exp,
            },
            "visualization": {
                "chart_id": "chart-salary-dist",
                "chart_key": "salary",
                "series": ["exp_trend"],
            },
        }

        job_type_item = {
            "conclusion": (
                f"岗位类型画像显示「{top_category.get('name')}」需求最旺，热度指数 {top_category.get('heat_index')}。"
                if top_category else "暂无岗位类型画像结论。"
            ),
            "evidence": {
                "top_categories": demand_categories[:10],
                "edu_profile": {
                    "labels": edu_chart.get("labels", []) or [],
                    "values": [cls._safe_int(v) for v in (edu_chart.get("values", []) or [])],
                },
            },
            "visualization": {
                "chart_id": "chart-demand",
                "chart_key": "demand_index",
                "series": ["category_heat_index"],
            },
        }

        items = {
            "salary": salary_item,
            "skills": skills_item,
            "city": city_item,
            "experience": experience_item,
            "job_type": job_type_item,
        }

        summary_lines = []
        for key in ["salary", "city", "skills"]:
            text = cls._line(items.get(key, {}).get("conclusion"))
            if text:
                summary_lines.append(text)
        if not summary_lines and meta.get("diagnosis"):
            summary_lines.append(str(meta.get("diagnosis")))

        return {
            "items": items,
            "summary_lines": summary_lines[:5],
        }

    @classmethod
    def _recommend_bucket(cls, score):
        score = cls._safe_int(score)
        if score >= 80:
            return "主申"
        if score >= 65:
            return "冲刺"
        return "保底"

    @classmethod
    def _build_recommendation_item_decision(cls, item, market_avg):
        score = cls._safe_int(item.get("score"))
        gap = item.get("gap_analysis", {}) or {}
        process_analysis = item.get("process_analysis", {}) or {}
        bucket = cls._recommend_bucket(score)
        missing = cls._clean_gap_tokens(process_analysis.get("missing_skills") or [], limit=3)
        salary_avg = sanitize_salary_avg(item.get("salary_avg"))
        market_avg = cls._safe_int(market_avg)

        if score >= 80:
            conclusion = "建议进入首轮投递"
            suggestion = "优先作为主申岗位处理，并在 48 小时内完成首次跟进。"
        elif score >= 65:
            conclusion = "建议补强后优先投递"
            suggestion = "先补 1-2 项关键短板，再集中投递。"
        else:
            conclusion = "建议作为保底或观察项"
            suggestion = "先补关键短板，避免把核心投递名额消耗在低匹配岗位上。"

        if missing:
            suggestion = f"优先补齐 {'、'.join(missing[:2])}，投递时突出已匹配项目成果。"

        reason_parts = []
        if item.get("reason"):
            reason_parts.append(str(item.get("reason")))
        if salary_avg > 0 and market_avg > 0:
            diff = salary_avg - market_avg
            if abs(diff) >= 1000:
                direction = "高" if diff > 0 else "低"
                reason_parts.append(f"岗位薪资较样本均值{direction}约 {abs(diff)} 元")
        exp_desc = str(gap.get("exp_desc") or "").strip()
        if exp_desc:
            reason_parts.append(f"经验判断：{exp_desc}")

        confidence = int(max(45, min(95, score * 0.72 + (8 if not missing else 0))))
        next_step = "加入主申池并安排投递" if bucket == "主申" else ("加入冲刺池并先补短板" if bucket == "冲刺" else "放入保底池，避免优先消耗时间")

        return {
            "bucket": bucket,
            "conclusion": conclusion,
            "reason": "；".join(reason_parts[:3]) or "综合匹配结果可供参考",
            "suggestion": suggestion,
            "confidence": confidence,
            "next_step": next_step,
        }

    @classmethod
    def build_recommendation_plan(cls, payload):
        """基于推荐结果生成可执行投递计划。"""
        payload = payload if isinstance(payload, dict) else {}
        recs = payload.get("recommendations") or []
        summary = payload.get("summary") or {}
        gate = payload.get("quality_gate") or {}
        persona = payload.get("persona") or {}
        top_missing = cls._clean_gap_tokens([x.get("name") for x in (summary.get("top_missing_skills") or [])], limit=3)

        if gate.get("blocking"):
            return {
                "blocking": True,
                "title": "推荐计划暂缓生成",
                "conclusion": "当前应先修复数据，再进入推荐与投递决策。",
                "reason": gate.get("summary") or "当前数据质量未达标。",
                "suggestion": (gate.get("actions") or ["请先修复样本质量问题。"])[0],
                "confidence": {"score": cls._safe_int(gate.get("readiness_score")), "level": "低"},
                "execution_targets": {"主申": 0, "冲刺": 0, "保底": 0},
                "today_actions": [{"label": "先处理数据质量问题", "detail": x} for x in (gate.get("actions") or [])[:3]],
                "focus_jobs": [],
            }

        bucket_counter = {"主申": 0, "冲刺": 0, "保底": 0}
        for item in recs:
            bucket = ((item.get("decision") or {}).get("bucket")) or cls._recommend_bucket(item.get("score"))
            bucket_counter[bucket] = bucket_counter.get(bucket, 0) + 1

        main_count = bucket_counter.get("主申", 0)
        sprint_count = bucket_counter.get("冲刺", 0)
        safe_count = bucket_counter.get("保底", 0)
        avg_score = cls._safe_float(summary.get("avg_score"), 0, 1)
        confidence_score = int(max(35, min(96, cls._safe_int((gate.get("readiness_score") or 0) * 0.45 + avg_score * 0.55))))
        confidence_level = "高" if confidence_score >= 78 else ("中" if confidence_score >= 60 else "低")

        if main_count >= 3:
            conclusion = "当前可以进入首轮投递执行阶段"
            suggestion = "先完成主申岗位投递，再补充少量冲刺岗位，不要平均分配精力。"
        elif main_count >= 1 or sprint_count >= 2:
            conclusion = "当前可开始小规模试投，并同步补短板"
            suggestion = "优先投递最高分岗位，用首轮反馈校准后续策略。"
        else:
            conclusion = "当前推荐更适合做候选储备，不建议大规模投递"
            suggestion = "先补齐关键技能或调整筛选条件，再生成下一轮推荐计划。"

        reason = f"本次筛出 {cls._safe_int(summary.get('total_matched'))} 个岗位，主申 {main_count} 个，冲刺 {sprint_count} 个，平均匹配分 {avg_score}。"
        if top_missing:
            suggestion = f"先补齐 {'、'.join(top_missing[:2])}，再优先处理主申和高分冲刺岗位。"

        today_actions = []
        if main_count:
            today_actions.append({"label": f"今天先处理 {min(3, main_count)} 个主申岗位", "detail": "完成评估、简历针对性调整和首轮投递。"})
        if sprint_count:
            today_actions.append({"label": f"补充 {min(2, sprint_count)} 个冲刺岗位", "detail": "只保留高薪或高成长性的冲刺岗位，避免分散精力。"})
        if top_missing:
            today_actions.append({"label": "同步补关键短板", "detail": f"优先补齐 {'、'.join(top_missing[:2])}，用于提升下一轮匹配和转化。"})
        if not today_actions:
            today_actions.append({"label": "先完成候选整理", "detail": "把当前推荐岗位按主申、冲刺、保底分层，再决定是否投递。"})

        focus_jobs = []
        for item in recs[:3]:
            decision = item.get("decision") or {}
            focus_jobs.append(
                {
                    "job_id": cls._safe_int(item.get("id")),
                    "job_name": item.get("job_name") or "",
                    "company": item.get("company") or "",
                    "bucket": decision.get("bucket") or cls._recommend_bucket(item.get("score")),
                    "score": cls._safe_int(item.get("score")),
                    "next_step": decision.get("next_step") or "继续评估后再投递",
                }
            )

        return {
            "blocking": False,
            "title": "推荐投递计划",
            "conclusion": conclusion,
            "reason": reason,
            "suggestion": suggestion,
            "confidence": {"score": confidence_score, "level": confidence_level},
            "execution_targets": {"主申": min(main_count, 3), "冲刺": min(sprint_count, 2), "保底": min(safe_count, 2 if main_count == 0 else 1)},
            "today_actions": today_actions[:4],
            "focus_jobs": focus_jobs,
            "persona_snapshot": {
                "keyword": persona.get("keywords") or "",
                "city": persona.get("city") or "不限",
                "experience": persona.get("experience") or "不限",
            },
        }

    @classmethod
    def _build_decision_explain_for_rec(cls, item, market_avg):
        score = cls._safe_int(item.get("score"))
        process_analysis = item.get("process_analysis", {}) or {}
        gap = item.get("gap_analysis", {}) or {}

        skill_match = cls._safe_int(process_analysis.get("skill_match"))
        salary_diff = cls._safe_int(process_analysis.get("salary_diff"))
        salary_match = max(0, min(100, 100 - abs(salary_diff)))
        item_salary = sanitize_salary_avg(item.get("salary_avg"))
        threshold_match = 90 if item_salary >= cls._safe_int(market_avg) else 70
        trend_match = max(50, min(95, cls._safe_int(score)))

        exp_gap_val = cls._safe_int(gap.get("exp_gap_val"))
        if exp_gap_val <= 0:
            experience_match = 95
        elif exp_gap_val == 1:
            experience_match = 85
        elif exp_gap_val == 2:
            experience_match = 70
        else:
            experience_match = 55

        gap_analysis = []
        for s in cls._clean_gap_tokens(process_analysis.get("missing_skills") or [], limit=3):
            gap_analysis.append(f"缺少 {s}")
        if exp_gap_val > 0:
            gap_analysis.append("经验略低")
        if not gap_analysis:
            gap_analysis.append("匹配度良好，无明显短板")

        explain = {
            "score": score,
            "score_detail": {
                # 新版分项（技能/薪资/门槛/趋势）
                "skill_score": skill_match,
                "salary_score": salary_match,
                "threshold_score": threshold_match,
                "trend_score": trend_match,
                # 兼容旧前端字段
                "skill_match": skill_match,
                "salary_match": salary_match,
                "experience_match": experience_match,
            },
            "market_compare": {
                "avg_salary": cls._safe_int(market_avg),
                "your_target": item_salary,
            },
            "gap_analysis": gap_analysis,
        }
        return explain

    @classmethod
    def _build_action_suggestions_for_rec(cls, item, market_avg):
        """模块4：生成闭环建议（至少三类）。"""
        process_analysis = item.get("process_analysis", {}) or {}
        gap = item.get("gap_analysis", {}) or {}
        missing_skills = cls._clean_gap_tokens(process_analysis.get("missing_skills") or [], limit=3)
        salary_avg = sanitize_salary_avg(item.get("salary_avg"))
        salary_diff = cls._safe_int(process_analysis.get("salary_diff"))

        suggestions = []

        if missing_skills:
            suggestions.append({
                "type": "skill_fill",
                "title": "技能补齐建议",
                "text": f"优先补齐 {', '.join(missing_skills)}，可直接提升岗位匹配度。",
            })
        else:
            suggestions.append({
                "type": "skill_fill",
                "title": "技能补齐建议",
                "text": "当前核心技能匹配度较好，建议继续强化项目案例与落地经验。",
            })

        city = item.get("city") or "当前城市"
        if salary_avg and market_avg and salary_avg < market_avg * 0.9:
            suggestions.append({
                "type": "city_or_role_adjust",
                "title": "城市/岗位调整建议",
                "text": f"{city} 该岗位薪资低于推荐样本均值，可尝试同职能更高线城市或更高职级岗位。",
            })
        else:
            suggestions.append({
                "type": "city_or_role_adjust",
                "title": "城市/岗位调整建议",
                "text": f"{city} 当前岗位具备竞争力，可优先投递同类高薪公司。",
            })

        if salary_diff > 20:
            salary_text = "目标薪资高于市场基准较多，建议同步强化作品集/项目深度后再冲刺高薪岗位。"
        elif salary_diff < -20:
            salary_text = "当前岗位薪资明显低于市场均值，可上调薪资预期并尝试更高薪岗位。"
        else:
            salary_text = "当前岗位薪资与市场均值接近，薪资预期设置较合理。"
        suggestions.append({
            "type": "salary_expectation_adjust",
            "title": "薪资预期修正建议",
            "text": salary_text,
        })

        extra_advices = gap.get("advices") or []
        if extra_advices:
            suggestions.append({
                "type": "execution_hint",
                "title": "执行提示",
                "text": str(extra_advices[0]),
            })

        # 强制保证至少 3 条建议，避免前端出现空白区
        while len(suggestions) < 3:
            suggestions.append({
                "type": "execution_hint",
                "title": "执行提示",
                "text": "建议优先投递匹配分最高岗位，并在一周内复盘反馈数据。",
            })

        return suggestions

    @classmethod
    def enhance_recommendation_payload(cls, payload):
        """模块3+4：为推荐结果增加解释层与差距建议闭环。"""
        if not isinstance(payload, dict):
            return payload

        recommendations = payload.get("recommendations") or []
        market_context = payload.get("market_context") or {}
        market_avg = cls._safe_int(market_context.get("avg_salary"))
        query_mode = str(payload.get("query_mode") or "")

        # 统一 persona 字段，保证“技能/经验/城市/期望薪资”闭环
        persona = payload.get("persona") or {}
        persona_skills = persona.get("skills") or []
        if isinstance(persona_skills, str):
            persona_skills = [x.strip() for x in persona_skills.split(",") if x.strip()]
        payload["persona"] = {
            **persona,
            "skills": persona_skills if isinstance(persona_skills, list) else [],
            "experience": str(persona.get("experience") or persona.get("exp_level") or "不限"),
            "city": str(persona.get("city") or "不限"),
            "expected_salary": cls._safe_int(persona.get("expected_salary") or persona.get("target_salary")),
        }

        # 统一市场基准字段
        rec_salaries = [sanitize_salary_avg(x.get("salary_avg")) for x in recommendations if sanitize_salary_avg(x.get("salary_avg")) > 0]
        rec_salaries.sort()
        median_salary = rec_salaries[len(rec_salaries) // 2] if rec_salaries else 0
        payload["market_context"] = {
            **market_context,
            "avg_salary": sanitize_salary_avg(market_context.get("avg_salary") or market_avg),
            "median_salary": sanitize_salary_avg(market_context.get("median_salary") or median_salary),
            "job_count": cls._safe_int(market_context.get("job_count") or len(recommendations)),
        }
        market_avg = cls._safe_int(payload["market_context"].get("avg_salary"))

        for item in recommendations:
            decision_explain = cls._build_decision_explain_for_rec(item, market_avg)
            item["decision_explain"] = decision_explain
            item["score_detail"] = decision_explain.get("score_detail") or {}

            # 不破坏旧结构：gap_analysis 仍保留对象，同时补充 items 便于标准化展示
            gap_obj = item.get("gap_analysis")
            if not isinstance(gap_obj, dict):
                gap_obj = {"exp_gap_val": 0, "exp_desc": "未知", "advices": []}
            gap_items = decision_explain.get("gap_analysis") or []
            gap_obj["items"] = gap_items[:3]
            item["gap_analysis"] = gap_obj

            item["action_suggestions"] = cls._build_action_suggestions_for_rec(item, market_avg)
            item["decision"] = cls._build_recommendation_item_decision(item, market_avg)
            if query_mode == "quick_search":
                item["decision_explain"]["gap_analysis"] = [
                    "当前为全网检索模式，差距分析仅供参考",
                    "如需个性化技能缺口，请使用画像深度分析",
                    "建议先按薪资与城市筛选，再做深度画像分析"
                ]

                # 快速检索模式也保证 3 条建议
                if len(item["action_suggestions"]) < 3:
                    item["action_suggestions"].extend([
                        {
                            "type": "mode_hint",
                            "title": "使用建议",
                            "text": "先用全网检索快速筛岗位，再用画像深度分析查看个性化差距与改进建议。"
                        },
                        {
                            "type": "mode_hint",
                            "title": "投递建议",
                            "text": "优先投递分数与薪资都靠前的岗位，保留 2-3 个保底选项。"
                        }
                    ])
                    item["action_suggestions"] = item["action_suggestions"][:3]

        summary = payload.get("summary") or {}
        summary_missing_items = []
        for x in (summary.get("top_missing_skills") or []):
            if not isinstance(x, dict):
                continue
            name = str(x.get("name") or "").strip()
            if not name or cls._is_noise_gap_token(name):
                continue
            summary_missing_items.append({**x, "name": name})
        if summary_missing_items:
            summary["top_missing_skills"] = summary_missing_items[:5]
        top_missing = cls._clean_gap_tokens([x.get("name") for x in (summary.get("top_missing_skills") or [])], limit=3)
        top_rec = recommendations[0] if recommendations else {}
        top_city = top_rec.get("city") or "当前样本城市"
        top_salary = sanitize_salary_avg(top_rec.get("salary_avg"))

        interpretation = []
        if summary.get("total_matched"):
            interpretation.append(f"本次共筛出 {summary.get('total_matched')} 个可投递岗位，平均匹配分 {summary.get('avg_score', 0)}。")
        if top_salary:
            interpretation.append(f"Top 推荐岗位位于 {top_city}，薪资约 {top_salary} 元。")
        if top_missing:
            interpretation.append(f"当前主要技能缺口集中在：{', '.join(top_missing)}。")

        global_gap_analysis = []
        if top_missing:
            global_gap_analysis.extend([f"缺少 {s}" for s in top_missing[:2]])
        for rec in recommendations[:5]:
            gap_obj = rec.get("gap_analysis") or {}
            if isinstance(gap_obj, dict) and cls._safe_int(gap_obj.get("exp_gap_val")) > 0:
                global_gap_analysis.append("经验存在阶段差距")
                break
        if not global_gap_analysis:
            global_gap_analysis.append("当前样本未识别出显著差距项")

        global_actions = [
            {"type": "skill_fill", "title": "技能补齐建议", "text": [f"优先补齐 {s}" for s in top_missing[:1]][0] if top_missing else "保持技能更新频率，每周补充一个岗位高频技能。"},
            {"type": "city_or_role_adjust", "title": "城市/岗位调整建议", "text": "对比目标城市的同岗中位薪资后再决定投递优先级。"},
            {"type": "salary_expectation_adjust", "title": "薪资预期修正建议", "text": f"以市场均值 {market_avg} 元为锚点，上下浮动 10%-20% 设定预期。" if market_avg else "样本薪资不足，建议先补充数据再设置薪资预期。"},
        ]

        payload["summary"] = {
            **summary,
            "system_interpretation": interpretation[:3],
            "improvement_suggestions": {
                "skill_fill": [f"优先补齐 {s}" for s in top_missing[:3]] or ["暂无明显技能缺口，优先提升项目实战深度。"],
                "city_or_role_adjust": [
                    "对比一线城市同岗位薪资后再决定投递优先级",
                    "若目标岗位偏窄，可扩展到相邻岗位关键词"
                ],
                "salary_expectation_adjust": [
                    f"以推荐样本均薪 {market_avg} 元作为基础锚点，按匹配度上下浮动 10%-20%"
                    if market_avg else "样本薪资不足，建议先补充数据后再设定预期"
                ]
            }
        }
        quality_metrics = payload.get("quality_metrics") or payload.get("system_metrics") or {}
        payload["quality_gate"] = cls.build_quality_gate(quality_metrics, scene="recommendation")
        payload["gap_analysis"] = global_gap_analysis[:3]
        payload["action_suggestions"] = global_actions
        payload["recommendation_plan"] = cls.build_recommendation_plan(payload)

        return payload

    @classmethod
    def enhance_competitiveness_result(cls, result, request_data=None):
        """模块3+4：为竞争力评估接口补充解释层和建议闭环。"""
        if not isinstance(result, dict) or not result.get("success"):
            return result

        values = (result.get("dimensions") or {}).get("values") or []
        labels = (result.get("dimensions") or {}).get("labels") or []
        label_map = {str(labels[i]): cls._safe_int(values[i]) for i in range(min(len(labels), len(values)))}

        skill_match = label_map.get("技能匹配度", label_map.get("技能竞争力", 0))
        salary_match = label_map.get("薪资竞争力", 0)
        experience_match = label_map.get("经验竞争力", 0)

        target_salary = cls._safe_int((request_data or {}).get("target_salary"))
        market_avg = cls._safe_int(result.get("market_avg_salary"))
        if not market_avg:
            smart_skills = result.get("smart_skills") or []
            premiums = [cls._safe_int(x.get("premium")) for x in smart_skills if x.get("premium")]
            market_avg = cls._safe_int(sum(premiums) / len(premiums)) if premiums else 0

        gap_analysis = []
        for sk in (result.get("smart_skills") or [])[:2]:
            if sk.get("name"):
                gap_analysis.append(f"缺少 {sk['name']}")
        if experience_match and experience_match < 70:
            gap_analysis.append("经验略低")
        if not gap_analysis:
            gap_analysis.append("整体匹配良好")

        result["decision_explain"] = {
            "score": cls._safe_int(result.get("total_score")),
            "score_detail": {
                "skill_match": skill_match,
                "salary_match": salary_match,
                "experience_match": experience_match,
            },
            "market_compare": {
                "avg_salary": market_avg,
                "your_target": target_salary,
            },
            "gap_analysis": gap_analysis,
        }

        result["improvement_suggestions"] = {
            "skill_fill": [
                f"优先学习 {sk['name']}（需求 {sk.get('demand', 0)}）" for sk in (result.get("smart_skills") or [])[:3]
            ] or ["暂无明显技能缺口，建议强化项目深度。"],
            "city_or_role_adjust": [
                p.get("title", "") for p in (result.get("growth_paths") or []) if p.get("type") in {"city", "skill"}
            ][:3] or ["可对比一线城市同岗位机会后调整投递策略。"],
            "salary_expectation_adjust": [
                "若当前竞争力评分低于 70，建议先以市场均值或略低区间投递，再逐步上调目标薪资。"
                if cls._safe_int(result.get("total_score")) < 70 else
                "当前竞争力较强，可将目标薪资设为市场均值以上 10%-15%。"
            ]
        }
        # 前端兼容字段：统一提供结论、解释、建议，避免只依赖某一套命名导致空白。
        score = cls._safe_int(result.get("total_score"))
        percentile = cls._safe_int(result.get("percentile"))
        gap_text = "、".join((result.get("decision_explain") or {}).get("gap_analysis") or [])
        if not gap_text:
            gap_text = "整体匹配良好"

        result["interpretation"] = (
            result.get("interpretation")
            or f"当前竞争力指数 {score}，市场分位约 {percentile}%，关键差距：{gap_text}。"
        )
        result["explain"] = result.get("explain") or result["interpretation"]
        result["advice"] = result.get("advice") or (
            (result.get("improvement_suggestions") or {}).get("skill_fill") or ["优先补齐高频技能并强化项目成果表达。"]
        )[0]

        if not result.get("conclusion"):
            if score >= 80:
                result["conclusion"] = "竞争力较强，可进入重点投递阶段"
            elif score >= 60:
                result["conclusion"] = "竞争力中等，建议补关键短板后投递"
            else:
                result["conclusion"] = "竞争力偏弱，建议先补能力再投递"
        if not result.get("reason"):
            result["reason"] = result["interpretation"]
        if not result.get("suggestion"):
            result["suggestion"] = result["advice"]
        return result

