import json
import json
from datetime import datetime

from app.extensions import db
from werkzeug.security import generate_password_hash, check_password_hash

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column('password', db.String(128))
    role = db.Column(db.String(16), default='用户')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class UserProfile(db.Model):
    __tablename__ = 'user_profiles'

    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    target_job = db.Column(db.String(64))
    exp_year = db.Column(db.String(32))
    edu_level = db.Column(db.String(32))
    skills = db.Column(db.Text)
    target_jobs = db.Column(db.Text, default='[]')  # JSON: ["数据分析师", "BI工程师"]
    skill_list = db.Column(db.Text, default='[]')   # JSON: ["python", "sql"]
    exp_years_num = db.Column(db.Float, default=0.0)
    expected_salary_min = db.Column(db.Integer, default=0)
    expected_salary_max = db.Column(db.Integer, default=0)
    profile_score = db.Column(db.Integer, default=0)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('profile', uselist=False))

    def get_target_jobs(self):
        try:
            jobs = json.loads(self.target_jobs or "[]")
            if isinstance(jobs, list):
                cleaned = [str(x).strip() for x in jobs if str(x).strip()]
                if cleaned:
                    return cleaned
        except Exception:
            pass
        if self.target_job:
            return [self.target_job]
        return []

    def get_skill_list(self):
        try:
            skills = json.loads(self.skill_list or "[]")
            if isinstance(skills, list):
                cleaned = [str(x).strip() for x in skills if str(x).strip()]
                if cleaned:
                    return cleaned
        except Exception:
            pass
        if self.skills:
            return [x.strip() for x in str(self.skills).replace("\uFF0C", ",").replace("\u3001", ",").split(",") if x.strip()]
        return []
