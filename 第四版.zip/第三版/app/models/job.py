from app.extensions import db
from datetime import datetime

class Job(db.Model):
    __tablename__ = 'jobs'

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    job_name = db.Column(db.String(128))
    company = db.Column(db.String(128))
    city = db.Column(db.String(64))
    job_category = db.Column(db.String(64))
    salary_avg = db.Column(db.Float)
    salary_text = db.Column(db.String(64))
    edu_req = db.Column(db.String(32))
    exp_req = db.Column(db.String(32))
    skills = db.Column(db.Text)
    tags = db.Column(db.Text)
    company_size = db.Column(db.String(64))
    pub_date = db.Column(db.String(32), default=lambda: datetime.now().strftime('%Y-%m-%d'))
    source = db.Column(db.String(32))
    raw_desc = db.Column(db.Text)
    detail_url = db.Column(db.Text)
    is_favorite = db.Column(db.Boolean, default=False)
    is_ignored = db.Column(db.Boolean, default=False)
    note = db.Column(db.Text, default='')

    owner = db.relationship('User', backref='jobs')
