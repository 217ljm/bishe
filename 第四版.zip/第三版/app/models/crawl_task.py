import json
from datetime import datetime

from app.extensions import db


class CrawlTask(db.Model):
    __tablename__ = "crawl_tasks"

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    keyword = db.Column(db.String(128), nullable=False)
    city = db.Column(db.String(32), default="全国")
    exp = db.Column(db.String(32), default="不限")
    sources = db.Column(db.Text, default="[]")
    plan = db.Column(db.String(16), default="standard")
    target_count = db.Column(db.Integer, default=0)
    max_pages = db.Column(db.Integer, default=0)
    headless = db.Column(db.Boolean, default=False)
    retry_times = db.Column(db.Integer, default=3)
    timeout_sec = db.Column(db.Integer, default=30)
    status = db.Column(db.String(16), nullable=False, default="running", index=True)
    scanned = db.Column(db.Integer, default=0)
    added = db.Column(db.Integer, default=0)
    filtered = db.Column(db.Integer, default=0)
    failed = db.Column(db.Integer, default=0)
    progress = db.Column(db.Integer, default=0)
    error_message = db.Column(db.Text, default="")
    source_stats = db.Column(db.Text, default="{}")
    started_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    finished_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    owner = db.relationship("User", backref=db.backref("crawl_tasks", lazy="dynamic"))

    def get_sources(self):
        try:
            value = json.loads(self.sources or "[]")
            if isinstance(value, list):
                return [str(item).strip() for item in value if str(item).strip()]
        except Exception:
            pass
        return []

    def get_source_stats(self):
        try:
            value = json.loads(self.source_stats or "{}")
            if isinstance(value, dict):
                return value
        except Exception:
            pass
        return {}

    def to_dict(self):
        return {
            "id": self.id,
            "keyword": self.keyword,
            "city": self.city,
            "exp": self.exp,
            "sources": self.get_sources(),
            "plan": self.plan,
            "target_count": self.target_count or 0,
            "max_pages": self.max_pages or 0,
            "headless": bool(self.headless),
            "retry_times": self.retry_times or 0,
            "timeout_sec": self.timeout_sec or 0,
            "status": self.status,
            "scanned": self.scanned or 0,
            "added": self.added or 0,
            "filtered": self.filtered or 0,
            "failed": self.failed or 0,
            "progress": self.progress or 0,
            "error_message": self.error_message or "",
            "source_stats": self.get_source_stats(),
            "started_at": self.started_at.strftime("%Y-%m-%d %H:%M:%S") if self.started_at else "",
            "finished_at": self.finished_at.strftime("%Y-%m-%d %H:%M:%S") if self.finished_at else "",
            "updated_at": self.updated_at.strftime("%Y-%m-%d %H:%M:%S") if self.updated_at else "",
        }
