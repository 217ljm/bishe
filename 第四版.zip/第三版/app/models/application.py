from datetime import datetime

from app.extensions import db


class JobApplication(db.Model):
    __tablename__ = "job_applications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    job_id = db.Column(db.Integer, db.ForeignKey("jobs.id"), nullable=False, index=True)
    status = db.Column(db.String(24), nullable=False, default="已收藏", index=True)
    bucket = db.Column(db.String(8), nullable=False, default="保底", index=True)
    applied_at = db.Column(db.DateTime, nullable=True)
    interview_date = db.Column(db.DateTime, nullable=True)
    notes = db.Column(db.Text, default="")
    match_score = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", backref=db.backref("job_applications", lazy="dynamic"))
    job = db.relationship("Job", backref=db.backref("applications", lazy="dynamic"))
