from datetime import datetime

from app.extensions import db


class WeeklyPlanState(db.Model):
    __tablename__ = "weekly_plan_states"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    week_key = db.Column(db.String(16), nullable=False, index=True)
    task_id = db.Column(db.String(64), nullable=False, index=True)
    completed = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", backref=db.backref("weekly_plan_states", lazy="dynamic"))

    def to_dict(self):
        return {
            "id": self.id,
            "week_key": self.week_key,
            "task_id": self.task_id,
            "completed": bool(self.completed),
            "updated_at": self.updated_at.strftime("%Y-%m-%d %H:%M:%S") if self.updated_at else "",
        }
