﻿import copy

from flask import Blueprint, jsonify, request, session

from config import Config
from app.services.spider_service import spider_instance

spider_bp = Blueprint("spider", __name__)

ALLOWED_SOURCES = {"liepin"}
ALLOWED_PLANS = {"quick", "standard", "deep", "custom"}
PLAN_TARGETS = {"quick": 100, "standard": 300, "deep": 600}


def _task_owner_id():
    meta = spider_instance.meta if isinstance(spider_instance.meta, dict) else {}
    try:
        return int(meta.get("owner_id") or 0)
    except Exception:
        return 0


def _to_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    return default


def _to_int(value, default, min_value=None, max_value=None):
    try:
        parsed = int(value)
    except Exception:
        parsed = int(default)
    if min_value is not None:
        parsed = max(int(min_value), parsed)
    if max_value is not None:
        parsed = min(int(max_value), parsed)
    return parsed


@spider_bp.route("/api/spider/start", methods=["POST"])
def start_spider():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"})

    if spider_instance.is_running:
        owner_id = _task_owner_id()
        if owner_id and owner_id != uid:
            return jsonify({"success": False, "msg": "当前已有采集任务在运行，请稍后再试"})
        return jsonify({"success": False, "msg": "你的采集任务正在运行，请勿重复启动"})

    data = request.json or {}
    from app.routes.config import load_config

    user_config = load_config(uid)
    keyword = str(data.get("keyword") or "").strip()
    if not keyword:
        return jsonify({"success": False, "msg": "请输入岗位关键词"})

    # 允许前端透传过滤参数；未传时使用兼容默认值
    config_city_scope = user_config.get("city_scope") if isinstance(user_config, dict) else None
    default_city = "全国"
    if isinstance(config_city_scope, list) and config_city_scope:
        default_city = str(config_city_scope[0] or "全国").strip() or "全国"
    city = Config.normalize_city_name(str(data.get("city") or default_city).strip() or "全国") or "全国"
    exp = str(data.get("exp") or "不限").strip() or "不限"

    sources = data.get("sources", ["liepin"])
    if not isinstance(sources, list):
        sources = ["liepin"]
    sources = [str(s).strip() for s in sources if str(s).strip() in ALLOWED_SOURCES]
    if not sources:
        sources = ["liepin"]

    plan = str(data.get("plan") or "standard").strip().lower()
    if plan not in ALLOWED_PLANS:
        plan = "standard"
    if plan in PLAN_TARGETS:
        target_count = PLAN_TARGETS[plan]
    else:
        target_count = _to_int(data.get("target_count", 300), 300, 50, 3000)
    retry_times = _to_int(data.get("retry", 3), 3, 1, 8)
    timeout_sec = _to_int(data.get("timeout", 30), 30, 10, 120)
    headless = _to_bool(data.get("headless", False), False)
    default_max_pages = (
        user_config.get("max_pages")
        if isinstance(user_config, dict)
        else Config.SPIDER_SETTINGS.get("MAX_PAGE", 30)
    )
    max_pages = _to_int(
        data.get("max_pages", default_max_pages),
        default_max_pages or Config.SPIDER_SETTINGS.get("MAX_PAGE", 30),
        1,
        Config.SPIDER_SETTINGS.get("MAX_PAGE", 30),
    )

    options = {
        "plan": plan,
        "retry": retry_times,
        "timeout": timeout_sec,
        "exp": exp,
        "max_pages": max_pages,
    }

    from flask import current_app

    app = current_app._get_current_object()

    success = spider_instance.run(
        keyword=keyword,
        city=city,
        exp=exp,
        uid=uid,
        sources=sources,
        target_count=target_count,
        headless=headless,
        app=app,
        options=options,
    )
    if not success:
        return jsonify({"success": False, "msg": "启动失败，请检查采集源与参数"})

    task_meta = spider_instance.meta if isinstance(spider_instance.meta, dict) else {}
    return jsonify(
        {
            "success": True,
            "msg": "采集任务已启动",
            "task": {
                "id": task_meta.get("task_id"),
                "keyword": keyword,
                "scope": city,
                "exp": exp,
                "sources": sources,
                "plan": plan,
                "target_count": target_count,
                "expected_pages": task_meta.get("expected_pages"),
                "expected_minutes": task_meta.get("expected_minutes"),
                "max_pages": max_pages,
                "headless": headless,
                "retry": retry_times,
                "timeout": timeout_sec,
            },
        }
    )


@spider_bp.route("/api/spider/logs")
def get_spider_logs():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    # 在同一把锁里快照，避免 deque 迭代和 stats 读取并发崩溃
    with spider_instance._lock:
        running = bool(spider_instance.is_running)
        logs = list(spider_instance.logs)
        stats = copy.deepcopy(spider_instance.stats)
        meta = copy.deepcopy(spider_instance.meta)

    owner_id = _task_owner_id()
    if running and owner_id and owner_id != uid:
        return jsonify(
            {
                "success": False,
                "running": True,
                "msg": "当前采集任务属于其他账号，暂不可查看日志",
            }
        ), 403

    source_stats = stats.get("sources", {}) if isinstance(stats, dict) else {}
    error_hints = []
    for source, item in (source_stats or {}).items():
        err_type = str(item.get("last_error_type") or "").strip()
        if not err_type:
            continue
        error_hints.append(
            {
                "source": source,
                "type": err_type,
                "message": item.get("last_error_message") or "",
                "suggestion": item.get("last_error_suggestion") or "",
            }
        )

    return jsonify(
        {
            "success": True,
            "running": running,
            "logs": logs,
            "stats": stats,
            "meta": meta,
            "source_stats": source_stats,
            "error_hints": error_hints[:8],
        }
    )


@spider_bp.route("/api/spider/stop", methods=["POST"])
def stop_spider():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    owner_id = _task_owner_id()
    if spider_instance.is_running and owner_id and owner_id != uid:
        return jsonify({"success": False, "msg": "当前采集任务属于其他账号，无法停止"}), 403

    detail = spider_instance.stop() or {}
    return jsonify(
        {
            "success": True,
            "msg": "采集任务已停止",
            "running": spider_instance.is_running,
            "stopped_sources": detail.get("stopped_sources", []),
            "join_status": detail.get("join_status", {}),
        }
    )


@spider_bp.route("/api/spider/history")
def get_spider_history():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    try:
        from app.models.crawl_task import CrawlTask

        rows = (
            CrawlTask.query.filter_by(owner_id=uid)
            .order_by(CrawlTask.started_at.desc(), CrawlTask.id.desc())
            .limit(20)
            .all()
        )
        return jsonify(
            {
                "success": True,
                "data": [row.to_dict() for row in rows],
            }
        )
    except Exception as e:
        return jsonify({"success": False, "msg": str(e)}), 500
