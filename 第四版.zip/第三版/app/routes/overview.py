﻿from datetime import datetime, timedelta

from flask import Blueprint, jsonify, session
from sqlalchemy import func

from app.extensions import db
from app.models.job import Job
from app.services.data_quality_utils import is_normalized_skill_text, is_unknown_city, normalize_date_str
from app.services.salary_utils import SALARY_MAX_VALID, SALARY_MIN_VALID, sanitize_salary_avg
from app.services.standard_output_service import StandardOutputService

overview_bp = Blueprint("overview", __name__)


def _now_date():
    return datetime.now().date()


def _safe_pct(numerator, denominator, digits=1):
    if not denominator:
        return 0.0
    return round(float(numerator) / float(denominator) * 100, digits)


def _split_skills(text):
    raw = str(text or "").strip()
    if not raw:
        return []
    parts = [x.strip() for x in raw.replace("，", ",").split(",")]
    return [x for x in parts if x]


def _calc_quality(uid):
    total = Job.query.filter_by(owner_id=uid).count()
    if total == 0:
        empty = {
            "total": 0,
            "health_score": 0,
            "health_breakdown": [],
            "health_reasons": [
                {
                    "id": "sample_size",
                    "level": "warning",
                    "title": "样本不足",
                    "summary": "当前岗位样本为 0 条，无法形成可靠分析结论",
                    "detail": "请先启动采集任务或导入历史岗位数据，建议至少积累 500 条样本。",
                    "metric": "0 / 500",
                },
                {
                    "id": "pub_date_parse_rate",
                    "level": "warning",
                    "title": "趋势可信度低",
                    "summary": "发布时间解析率为 0%，趋势图不可用",
                    "detail": "请补齐或标准化发布时间字段，统一为 YYYY-MM-DD。",
                    "metric": "0%",
                },
                {
                    "id": "action",
                    "level": "info",
                    "title": "建议操作",
                    "summary": "建议先补齐薪资、技能和发布时间字段",
                    "detail": "优先保证 salary_avg、skills、pub_date 三个字段的完整性。",
                    "metric": "P0",
                },
            ],
            "missing_salary_rate": 0.0,
            "missing_skills_rate": 0.0,
            "duplicate_rate": 0.0,
            "pub_date_parse_rate": 0.0,
            "unknown_city_rate": 0.0,
            "skill_coverage_rate": 0.0,
            "valid_salary_rate": 0.0,
            "abnormal_salary_rate": 0.0,
            "duplicate_groups": 0,
            "duplicate_records": 0,
            "salary_valid": 0,
            "salary_anomaly": 0,
            "source_dist": {},
            "fields": [],
            "suggestions": [
                {"level": "info", "text": "暂无数据，请先采集或导入数据。"},
                {"level": "info", "text": "建议优先补充最近 30 天岗位数据，便于趋势分析。"},
                {"level": "info", "text": "建议先保证薪资、技能、发布时间字段完整。"},
            ],
            "suggestions_text": [
                "暂无数据，请先采集或导入数据。",
                "建议优先补充最近 30 天岗位数据，便于趋势分析。",
                "建议先保证薪资、技能、发布时间字段完整。",
            ],
        }
        return empty

    base_q = Job.query.filter_by(owner_id=uid)

    salary_valid = base_q.filter(
        Job.salary_avg.isnot(None),
        Job.salary_avg >= SALARY_MIN_VALID,
        Job.salary_avg <= SALARY_MAX_VALID,
    ).count()
    city_valid = base_q.filter(Job.city.isnot(None), Job.city != "").count()
    edu_valid = base_q.filter(Job.edu_req.isnot(None), Job.edu_req != "").count()
    exp_valid = base_q.filter(Job.exp_req.isnot(None), Job.exp_req != "").count()
    skills_valid = base_q.filter(Job.skills.isnot(None), Job.skills != "").count()
    company_valid = base_q.filter(Job.company.isnot(None), Job.company != "").count()
    desc_valid = base_q.filter(Job.raw_desc.isnot(None), Job.raw_desc != "").count()

    salary_anomaly = base_q.filter(
        Job.salary_avg.isnot(None),
        Job.salary_avg > 0,
        db.or_(Job.salary_avg < SALARY_MIN_VALID, Job.salary_avg > SALARY_MAX_VALID),
    ).count()

    dedupe_tail = func.coalesce(func.nullif(Job.detail_url, ""), Job.pub_date)
    duplicate_rows = (
        db.session.query(
            Job.job_name,
            Job.company,
            Job.city,
            Job.source,
            dedupe_tail.label("dedupe_tail"),
            func.count(Job.id).label("cnt"),
        )
        .filter_by(owner_id=uid)
        .group_by(Job.job_name, Job.company, Job.city, Job.source, dedupe_tail)
        .having(func.count(Job.id) > 1)
        .all()
    )
    duplicate_groups = len(duplicate_rows)
    duplicate_records = int(sum(max(int(row.cnt) - 1, 0) for row in duplicate_rows))

    pub_date_values = db.session.query(Job.pub_date).filter_by(owner_id=uid).all()
    parsed_pub_date_count = sum(1 for row in pub_date_values if normalize_date_str(row[0] if row else ""))

    city_values = db.session.query(Job.city).filter_by(owner_id=uid).all()
    unknown_city_count = sum(1 for row in city_values if is_unknown_city((row[0] if row else "") or ""))

    skill_values = db.session.query(Job.skills).filter_by(owner_id=uid).all()
    normalized_skill_count = sum(
        1 for row in skill_values if is_normalized_skill_text((row[0] if row else "") or "")
    )

    source_rows = db.session.query(Job.source, func.count(Job.id)).filter_by(owner_id=uid).group_by(Job.source).all()
    source_dist = {str(s[0] or "未知"): int(s[1]) for s in source_rows}

    missing_salary_rate = _safe_pct(total - salary_valid, total)
    missing_skills_rate = _safe_pct(total - skills_valid, total)
    duplicate_rate = _safe_pct(duplicate_records, total)
    pub_date_parse_rate = _safe_pct(parsed_pub_date_count, total)
    unknown_city_rate = _safe_pct(unknown_city_count, total)
    skill_coverage_rate = _safe_pct(normalized_skill_count, total)
    valid_salary_rate = _safe_pct(salary_valid, total)
    abnormal_salary_rate = _safe_pct(salary_anomaly, total)

    # 健康分：覆盖率加分 + 异常惩罚
    sample_score = min(30.0, total / 500.0 * 30.0)
    salary_score = valid_salary_rate * 0.20
    skill_score = skill_coverage_rate * 0.15
    pub_score = pub_date_parse_rate * 0.25
    duplicate_penalty = duplicate_rate * 0.20
    anomaly_penalty = abnormal_salary_rate * 0.10
    health_score = int(
        max(
            0.0,
            min(100.0, sample_score + salary_score + skill_score + pub_score - duplicate_penalty - anomaly_penalty),
        )
    )

    health_breakdown = [
        {"key": "sample_score", "name": "样本规模得分", "value": round(sample_score, 1), "weight": "30%"},
        {"key": "salary_score", "name": "薪资有效得分", "value": round(salary_score, 1), "weight": "20%"},
        {"key": "skill_score", "name": "技能覆盖得分", "value": round(skill_score, 1), "weight": "15%"},
        {"key": "pub_score", "name": "时间解析得分", "value": round(pub_score, 1), "weight": "25%"},
        {"key": "duplicate_penalty", "name": "重复惩罚", "value": round(-duplicate_penalty, 1), "weight": "20%"},
        {"key": "anomaly_penalty", "name": "异常薪资惩罚", "value": round(-anomaly_penalty, 1), "weight": "10%"},
    ]

    health_reasons = []
    if total < 500:
        health_reasons.append(
            {
                "id": "sample_size",
                "level": "warning",
                "title": "样本偏少",
                "summary": f"当前样本 {total} 条，低于推荐阈值 500 条",
                "detail": "样本不足会放大偶然波动，建议补齐多来源、多城市岗位数据后再做趋势判断。",
                "metric": f"{total} / 500",
            }
        )
    else:
        health_reasons.append(
            {
                "id": "sample_size",
                "level": "success",
                "title": "样本充足",
                "summary": f"当前样本 {total} 条，满足可靠分析阈值",
                "detail": "样本规模达到可分析水平，结论稳定性较高。",
                "metric": f"{total} / 500",
            }
        )

    if pub_date_parse_rate < 60:
        health_reasons.append(
            {
                "id": "pub_date_parse_rate",
                "level": "warning",
                "title": "趋势可信度低",
                "summary": f"发布时间解析率仅 {pub_date_parse_rate}%",
                "detail": "发布时间解析率低会导致趋势图失真，建议统一发布时间格式为 YYYY-MM-DD。",
                "metric": f"{pub_date_parse_rate}%",
            }
        )
    else:
        health_reasons.append(
            {
                "id": "pub_date_parse_rate",
                "level": "success",
                "title": "趋势可用",
                "summary": f"发布时间解析率 {pub_date_parse_rate}%，趋势图可参考",
                "detail": "发布时间解析率已达到可用水平，趋势曲线可靠性较好。",
                "metric": f"{pub_date_parse_rate}%",
            }
        )

    key_risk_metric = max(
        [
            ("duplicate_rate", duplicate_rate, "重复率"),
            ("missing_salary_rate", missing_salary_rate, "薪资缺失率"),
            ("missing_skills_rate", missing_skills_rate, "技能缺失率"),
            ("unknown_city_rate", unknown_city_rate, "未知城市率"),
        ],
        key=lambda x: x[1],
    )
    health_reasons.append(
        {
            "id": key_risk_metric[0],
            "level": "warning" if key_risk_metric[1] >= 10 else "info",
            "title": "主要质量风险",
            "summary": f"{key_risk_metric[2]}为 {key_risk_metric[1]}%",
            "detail": "该指标是当前健康分下降的主要来源，建议优先修复后再开展策略分析。",
            "metric": f"{key_risk_metric[1]}%",
        }
    )

    suggestions = []
    if total < 500:
        suggestions.append({"level": "warning", "text": f"样本量仅 {total} 条，建议扩充到 500 条以上。"})
    if missing_salary_rate >= 20:
        suggestions.append({"level": "warning", "text": f"薪资缺失率 {missing_salary_rate}%，请优先补齐薪资字段。"})
    if missing_skills_rate >= 30:
        suggestions.append({"level": "warning", "text": f"技能缺失率 {missing_skills_rate}%，建议启用技能词典抽取。"})
    if duplicate_rate >= 8:
        suggestions.append({"level": "warning", "text": f"重复率 {duplicate_rate}%，建议执行去重清洗。"})
    if pub_date_parse_rate < 85:
        suggestions.append(
            {"level": "warning", "text": f"发布时间解析率 {pub_date_parse_rate}%，建议统一日期格式 YYYY-MM-DD。"}
        )
    if unknown_city_rate >= 12:
        suggestions.append({"level": "warning", "text": f"未知城市率 {unknown_city_rate}%，建议补齐城市字段。"})
    if skill_coverage_rate < 70:
        suggestions.append({"level": "warning", "text": f"规范技能覆盖率 {skill_coverage_rate}%，建议优化技能抽取。"})
    if abnormal_salary_rate >= 8:
        suggestions.append({"level": "warning", "text": f"异常薪资占比 {abnormal_salary_rate}%，建议按城市区间清洗。"})

    if len(suggestions) < 3:
        suggestions.append({"level": "info", "text": "建议每周执行一次质量巡检，保证分析结果稳定。"})
    if len(suggestions) < 3:
        suggestions.append({"level": "info", "text": "建议优先补充最近 30 天样本数据，提高趋势可靠性。"})
    if len(suggestions) < 3:
        suggestions.append({"level": "success", "text": "当前质量整体可用，可进入筛选分析与推荐决策。"})

    suggestions = suggestions[:5]

    fields = [
        {"name": "薪资数据", "valid": salary_valid, "total": total, "percent": _safe_pct(salary_valid, total)},
        {"name": "城市信息", "valid": city_valid, "total": total, "percent": _safe_pct(city_valid, total)},
        {"name": "学历要求", "valid": edu_valid, "total": total, "percent": _safe_pct(edu_valid, total)},
        {"name": "经验要求", "valid": exp_valid, "total": total, "percent": _safe_pct(exp_valid, total)},
        {"name": "技能标签", "valid": skills_valid, "total": total, "percent": _safe_pct(skills_valid, total)},
        {"name": "公司名称", "valid": company_valid, "total": total, "percent": _safe_pct(company_valid, total)},
        {"name": "岗位描述", "valid": desc_valid, "total": total, "percent": _safe_pct(desc_valid, total)},
    ]

    return {
        "total": int(total),
        "health_score": int(health_score),
        "health_breakdown": health_breakdown,
        "health_reasons": health_reasons[:3],
        "missing_salary_rate": missing_salary_rate,
        "missing_skills_rate": missing_skills_rate,
        "duplicate_rate": duplicate_rate,
        "pub_date_parse_rate": pub_date_parse_rate,
        "unknown_city_rate": unknown_city_rate,
        "skill_coverage_rate": skill_coverage_rate,
        "valid_salary_rate": valid_salary_rate,
        "abnormal_salary_rate": abnormal_salary_rate,
        "duplicate_groups": int(duplicate_groups),
        "duplicate_records": int(duplicate_records),
        "salary_valid": int(salary_valid),
        "salary_anomaly": int(salary_anomaly),
        "source_dist": source_dist,
        "fields": fields,
        "suggestions": suggestions,
        "suggestions_text": [s["text"] for s in suggestions if s.get("text")],
        # 兼容旧字段
        "missing_salary_rate_legacy": missing_salary_rate,
        "missing_company_rate": _safe_pct(total - company_valid, total),
        "missing_city_rate": _safe_pct(total - city_valid, total),
    }


def _build_weekly_trends(uid):
    rows = (
        db.session.query(Job.pub_date, Job.salary_avg, Job.skills)
        .filter_by(owner_id=uid)
        .all()
    )
    if not rows:
        return {
            "recent_7d_new_jobs": 0,
            "recent_7d_vs_prev": 0.0,
            "salary_median_recent": 0,
            "salary_median_prev": 0,
            "salary_median_change": 0,
            "salary_median_change_pct": 0.0,
            "hot_skill_changes": [],
            "summary": [
                "最近 7 天暂无新增岗位样本。",
                "暂无可计算的薪资中位数变化。",
                "暂无可计算的热门技能变化。",
            ],
        }

    today = _now_date()
    recent_start = today - timedelta(days=6)
    prev_start = today - timedelta(days=13)
    prev_end = today - timedelta(days=7)

    recent_jobs = []
    prev_jobs = []
    for pub_date, salary_avg, skills in rows:
        date_str = normalize_date_str(pub_date)
        if not date_str:
            continue
        d = datetime.strptime(date_str, "%Y-%m-%d").date()
        row_data = {"salary_avg": salary_avg, "skills": skills}
        if recent_start <= d <= today:
            recent_jobs.append(row_data)
        elif prev_start <= d <= prev_end:
            prev_jobs.append(row_data)

    recent_count = len(recent_jobs)
    prev_count = len(prev_jobs)
    count_delta_pct = round(((recent_count - prev_count) / max(prev_count, 1)) * 100, 1) if prev_count else (
        100.0 if recent_count > 0 else 0.0
    )

    recent_salaries = sorted(
        sanitize_salary_avg(x.get("salary_avg")) for x in recent_jobs if sanitize_salary_avg(x.get("salary_avg")) > 0
    )
    prev_salaries = sorted(
        sanitize_salary_avg(x.get("salary_avg")) for x in prev_jobs if sanitize_salary_avg(x.get("salary_avg")) > 0
    )

    def _median(arr):
        if not arr:
            return 0
        n = len(arr)
        mid = n // 2
        if n % 2 == 1:
            return int(arr[mid])
        return int(round((arr[mid - 1] + arr[mid]) / 2))

    recent_median = _median(recent_salaries)
    prev_median = _median(prev_salaries)
    salary_change = int(recent_median - prev_median)
    salary_change_pct = round((salary_change / max(prev_median, 1)) * 100, 1) if prev_median else (
        100.0 if recent_median > 0 else 0.0
    )

    recent_skill_counter = {}
    prev_skill_counter = {}
    for item in recent_jobs:
        for token in _split_skills(item.get("skills")):
            recent_skill_counter[token] = recent_skill_counter.get(token, 0) + 1
    for item in prev_jobs:
        for token in _split_skills(item.get("skills")):
            prev_skill_counter[token] = prev_skill_counter.get(token, 0) + 1

    skill_keys = set(recent_skill_counter.keys()) | set(prev_skill_counter.keys())
    skill_changes = []
    for skill in skill_keys:
        recent_val = int(recent_skill_counter.get(skill, 0))
        prev_val = int(prev_skill_counter.get(skill, 0))
        delta = recent_val - prev_val
        if recent_val == 0 and prev_val == 0:
            continue
        skill_changes.append(
            {
                "skill": skill,
                "recent": recent_val,
                "prev": prev_val,
                "delta": delta,
                "trend": "up" if delta > 0 else ("down" if delta < 0 else "flat"),
            }
        )
    skill_changes.sort(key=lambda x: abs(x["delta"]), reverse=True)
    hot_skill_changes = skill_changes[:3]

    salary_arrow = "↑" if salary_change > 0 else ("↓" if salary_change < 0 else "→")
    top_skill_line = "暂无热门技能变化数据"
    if hot_skill_changes:
        top_skill_line = "、".join(
            f"{x['skill']}{'↑' if x['delta'] > 0 else ('↓' if x['delta'] < 0 else '→')}{abs(x['delta'])}"
            for x in hot_skill_changes
        )

    summary = [
        f"最近 7 天新增岗位 {recent_count} 条（较前 7 天 {count_delta_pct:+.1f}%）。",
        f"最近 7 天薪资中位数 {recent_median} 元（{salary_arrow}{abs(salary_change)} 元，{salary_change_pct:+.1f}%）。",
        f"热门技能变化 Top3：{top_skill_line}。",
    ]

    return {
        "recent_7d_new_jobs": int(recent_count),
        "recent_7d_vs_prev": float(count_delta_pct),
        "salary_median_recent": int(recent_median),
        "salary_median_prev": int(prev_median),
        "salary_median_change": int(salary_change),
        "salary_median_change_pct": float(salary_change_pct),
        "hot_skill_changes": hot_skill_changes,
        "summary": summary,
    }


@overview_bp.route("/api/system/metrics")
def system_metrics():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "未登录"}), 401

    try:
        metrics = StandardOutputService.build_system_metrics(uid)
        return jsonify(
            {
                "success": True,
                **metrics,
                "data": metrics,
                "system_interpretation": StandardOutputService.build_system_interpretation(metrics),
            }
        )
    except Exception as e:
        return jsonify({"success": False, "msg": str(e)}), 500


@overview_bp.route("/api/data/quality")
def data_quality():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "未登录"}), 401

    try:
        return jsonify({"success": True, "data": _calc_quality(uid)})
    except Exception as e:
        return jsonify({"success": False, "msg": f"数据质量检测失败: {e}"}), 500


@overview_bp.route("/api/system/weekly-trends")
def system_weekly_trends():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "未登录"}), 401

    try:
        data = _build_weekly_trends(uid)
        return jsonify({"success": True, "data": data})
    except Exception as e:
        return jsonify({"success": False, "msg": str(e)}), 500


@overview_bp.route("/api/system/info")
def system_info():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "未登录"}), 401

    try:
        total_jobs = Job.query.filter_by(owner_id=uid).count()
        current_user = session.get("user", "")
        usage_mode = "个人版"

        sources = (
            db.session.query(Job.source, func.count(Job.id))
            .filter(Job.owner_id == uid)
            .group_by(Job.source)
            .all()
        )
        source_stats = [{"name": s[0] or "未知", "count": int(s[1])} for s in sources]

        cities = (
            db.session.query(Job.city, func.count(Job.id))
            .filter(Job.owner_id == uid)
            .group_by(Job.city)
            .order_by(func.count(Job.id).desc())
            .limit(10)
            .all()
        )
        city_stats = [{"name": c[0] or "未知", "count": int(c[1])} for c in cities]

        metrics = StandardOutputService.build_system_metrics(uid)
        return jsonify(
            {
                "success": True,
                "data": {
                    "total_jobs": int(total_jobs),
                    "total_users": 1,
                    "current_role": usage_mode,
                    "current_user": current_user,
                    "usage_mode": usage_mode,
                    "source_stats": source_stats,
                    "city_stats": city_stats,
                    "metrics": metrics,
                    "system_interpretation": StandardOutputService.build_system_interpretation(metrics),
                },
            }
        )
    except Exception as e:
        return jsonify({"success": False, "msg": str(e)}), 500


