from flask import Blueprint, send_file, jsonify, current_app
import os
import time
import shutil

admin_bp = Blueprint('admin', __name__)
print("Admin Blueprint Loaded!")

@admin_bp.route('/api/admin/backup_db', methods=['GET', 'POST'])
def backup_db():
    try:
        db_path = os.path.join(current_app.root_path, '..', 'recruitment.db')
        if not os.path.exists(db_path):
            return jsonify({'success': False, 'msg': 'Database file not found'}), 404

        backup_dir = os.path.join(current_app.root_path, '..', 'backups')
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)

        timestamp = time.strftime('%Y%m%d_%H%M%S')
        backup_filename = f'recruitment_backup_{timestamp}.db'
        backup_path = os.path.join(backup_dir, backup_filename)

        shutil.copy2(db_path, backup_path)

        return send_file(backup_path, as_attachment=True, download_name=backup_filename)
    except Exception as e:
        return jsonify({'success': False, 'msg': str(e)}), 500

@admin_bp.route('/api/admin/download_logs', methods=['GET'])
def download_logs():
    try:
        log_path = os.path.join(current_app.root_path, '..', 'logs', 'spider.log')
        if not os.path.exists(log_path):
            return jsonify({'success': False, 'msg': 'Log file not found'}), 404
        
        return send_file(log_path, as_attachment=True, download_name='spider.log')
    except Exception as e:
        return jsonify({'success': False, 'msg': str(e)}), 500
