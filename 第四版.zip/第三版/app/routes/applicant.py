﻿import json
import logging
import re
from collections import Counter
from datetime import datetime, timedelta

import numpy as np
from flask import Blueprint, jsonify, request, session
from sklearn.ensemble import RandomForestRegressor

from app.extensions import db
from app.models.application import JobApplication
from app.models.job import Job
from app.models.user import UserProfile
from app.models.weekly_plan_state import WeeklyPlanState
from app.services.analysis_service import AnalysisService
from app.services.ai_service import ai_service
from app.services.salary_utils import SALARY_MAX_VALID, SALARY_MIN_VALID, sanitize_salary_avg
from app.services.skill_extract import extract_skills

applicant_bp = Blueprint("applicant", __name__)

APPLICATION_STATUS = {"已收藏", "已投递", "简历筛选", "面试邀约", "Offer", "已拒绝"}
EDU_RANK = {"不限": 0, "中专": 1, "大专": 2, "本科": 3, "硕士": 4, "博士": 5}
WEEKDAY_LABELS = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
APP_BUCKET_MAIN = 80
APP_BUCKET_SPRINT = 65
APP_FOLLOW_DAYS = {
    "favorite": 2,
    "applied": 2,
    "interview": 1,
    "offer": 1,
    "rejected": 7,
}


def _current_week_key(base_dt=None):
    dt = base_dt or datetime.utcnow()
    monday = dt - timedelta(days=dt.weekday())
    return monday.strftime("%Y%m%d")


def _safe_int(v, default=0):
    try:
        if v is None:
            return default
        return int(round(float(v)))
    except Exception:
        return default


def _safe_float(v, default=0.0):
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


def _parse_exp_to_years(text):
    s = str(text or "").strip()
    if not s:
        return 0.0
    if any(k in s for k in ("应届", "在校", "实习")):
        return 0.0
    if "不限" in s:
        return 1.0
    if "1年以内" in s:
        return 1.0
    if "1-3" in s:
        return 2.0
    if "3-5" in s:
        return 4.0
    if "5-10" in s:
        return 7.0
    if "10" in s:
        return 10.0

    m = re.search(r"(\d+(?:\.\d+)?)", s)
    return float(m.group(1)) if m else 0.0


def _normalize_edu_level(text):
    s = str(text or "").strip()
    for k in EDU_RANK:
        if k in s:
            return k
    return "不限"


def _json_list(value):
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    if value is None:
        return []
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return []
        try:
            arr = json.loads(s)
            if isinstance(arr, list):
                return [str(x).strip() for x in arr if str(x).strip()]
        except Exception:
            pass
        normalized = s.replace("\uFF0C", ",").replace("\u3001", ",").replace(";", ",")
        return [x.strip() for x in normalized.split(",") if x.strip()]
    return []


def _parse_datetime(value):
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    s = str(value).strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y/%m/%d", "%Y/%m/%d %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            pass
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return None


def _to_iso(dt):
    if not dt:
        return ""
    if isinstance(dt, str):
        return dt
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _status_key(status):
    s = _normalize_status(status, default="已收藏") or "已收藏"
    if s == "已收藏":
        return "favorite"
    if s in {"已投递", "简历筛选"}:
        return "applied"
    if s == "面试邀约":
        return "interview"
    if s == "Offer":
        return "offer"
    if s == "已拒绝":
        return "rejected"
    return "favorite"


def _normalize_bucket(bucket, score=0, notes=""):
    text = str(bucket or "").strip()
    if text in {"主申", "冲刺", "保底"}:
        return text
    return _score_bucket(score, notes)


def _score_bucket(score, notes=""):
    note_text = str(notes or "")
    if "主申" in note_text:
        return "主申"
    if "冲刺" in note_text:
        return "冲刺"
    if "保底" in note_text:
        return "保底"

    val = _safe_int(score)
    if val >= APP_BUCKET_MAIN:
        return "主申"
    if val >= APP_BUCKET_SPRINT:
        return "冲刺"
    return "保底"


def _days_since(value):
    dt = _parse_datetime(value)
    if not dt:
        return None
    return max(0, int((datetime.utcnow() - dt).total_seconds() // 86400))


def _next_follow_date(status_key, base_dt):
    if not base_dt:
        return ""
    days = APP_FOLLOW_DAYS.get(status_key, 2)
    return _to_iso(base_dt + timedelta(days=days))


def _recommended_action(status_key, overdue, bucket):
    if status_key == "offer":
        return "优先确认薪资结构、入职时间和试用期条款"
    if status_key == "interview":
        return "优先准备项目复盘与面试问答，保持当天确认"
    if status_key == "applied":
        return "已超过建议跟进窗口，今天补一次跟进" if overdue else "等待反馈中，准备下一轮补充材料"
    if status_key == "rejected":
        return "记录拒绝原因，复盘后调整后续投递策略"
    if bucket == "主申":
        return "高匹配候选，建议优先投递并在 48 小时内跟进"
    if bucket == "冲刺":
        return "先补齐关键短板，再安排小批量投递"
    return "保留为保底候选，避免占用过多投递资源"


def _application_priority(item):
    status_key = _status_key(item.status)
    days_since = _days_since(item.updated_at or item.applied_at)
    overdue = bool(
        days_since is not None
        and status_key in {"applied", "interview"}
        and days_since >= APP_FOLLOW_DAYS.get(status_key, 2)
    )
    bucket = _normalize_bucket(getattr(item, "bucket", ""), item.match_score, item.notes)

    if status_key == "offer":
        return "high", overdue, bucket
    if status_key == "interview":
        return ("high" if overdue else "medium"), overdue, bucket
    if status_key == "applied":
        if overdue:
            return "high", True, bucket
        return ("medium" if bucket != "保底" else "low"), False, bucket
    if status_key == "favorite":
        return ("high" if bucket == "主申" else "medium"), False, bucket
    return "low", False, bucket


def _parse_job_pub_date(value):
    dt = _parse_datetime(value)
    if dt:
        return dt
    s = str(value or "").strip()
    if not s:
        return None
    if len(s) == 10:
        dt = _parse_datetime(s)
        if dt:
            return dt
    return None


def _get_uid():
    return session.get("user_id")


def _normalize_status(status, default=None):
    if status is None:
        return default
    raw = str(status).strip()
    if not raw:
        return default
    if raw in APPLICATION_STATUS:
        return raw

    s = raw.lower()
    mapping = {
        "favorite": "已收藏",
        "favourite": "已收藏",
        "collected": "已收藏",
        "applied": "已投递",
        "screening": "简历筛选",
        "interview": "面试邀约",
        "offer": "Offer",
        "rejected": "已拒绝",
        "reject": "已拒绝",
    }
    if s in mapping:
        return mapping[s]
    if "收藏" in raw:
        return "已收藏"
    if "投递" in raw:
        return "已投递"
    if "筛选" in raw:
        return "简历筛选"
    if "面试" in raw:
        return "面试邀约"
    if "拒" in raw:
        return "已拒绝"
    return default
def _profile_to_dict(profile):
    target_jobs = profile.get_target_jobs() if profile else []
    skills = profile.get_skill_list() if profile else []
    return {
        "target_job": (profile.target_job if profile else "") or "",
        "target_jobs": target_jobs,
        "exp_year": (profile.exp_year if profile else "") or "",
        "exp_years_num": _safe_float(profile.exp_years_num if profile else 0),
        "edu_level": (profile.edu_level if profile else "") or "",
        "skills": (profile.skills if profile else "") or "",
        "skill_list": skills,
        "expected_salary_min": _safe_int(profile.expected_salary_min if profile else 0),
        "expected_salary_max": _safe_int(profile.expected_salary_max if profile else 0),
        "profile_score": _safe_int(profile.profile_score if profile else 0),
        "last_updated": _to_iso(profile.last_updated if profile else None),
    }


def _calc_profile_score(profile_dict):
    target_jobs = _json_list(profile_dict.get("target_jobs") or profile_dict.get("target_job"))
    skill_list = _json_list(profile_dict.get("skill_list") or profile_dict.get("skills"))
    edu = str(profile_dict.get("edu_level") or "").strip()
    exp_year = str(profile_dict.get("exp_year") or "").strip()
    exp_num = _safe_float(profile_dict.get("exp_years_num"))
    salary_min = _safe_int(profile_dict.get("expected_salary_min"))
    salary_max = _safe_int(profile_dict.get("expected_salary_max"))
    exp_years = exp_num if exp_num > 0 else _parse_exp_to_years(exp_year)

    parts = []

    # 目标岗位：单目标也给分，多目标表示方向更清晰
    if len(target_jobs) >= 2:
        target_score = 20
    elif len(target_jobs) == 1:
        target_score = 14
    else:
        target_score = 0
    parts.append({"field": "目标岗位", "score": target_score, "max": 20})

    # 技能标签：细粒度评分，避免长期卡在同一分数
    skill_count = len(skill_list)
    if skill_count >= 6:
        skill_score = 30
    elif skill_count == 5:
        skill_score = 27
    elif skill_count == 4:
        skill_score = 23
    elif skill_count == 3:
        skill_score = 19
    elif skill_count == 2:
        skill_score = 14
    elif skill_count == 1:
        skill_score = 8
    else:
        skill_score = 0
    parts.append({"field": "技能标签", "score": skill_score, "max": 30})

    edu_score = 10 if edu else 0
    parts.append({"field": "学历信息", "score": edu_score, "max": 10})

    # 经验信息：按经验层级打分
    if exp_years >= 5:
        exp_score = 15
    elif exp_years >= 3:
        exp_score = 13
    elif exp_years >= 1:
        exp_score = 10
    elif exp_year:
        exp_score = 7
    else:
        exp_score = 0
    parts.append({"field": "经验信息", "score": exp_score, "max": 15})

    # 期望薪资：填写完整且区间合理得分更高
    if salary_min > 0 and salary_max > 0 and salary_max >= salary_min:
        spread = salary_max - salary_min
        salary_score = 10
        if salary_min >= 3000:
            salary_score += 2
        if spread >= 3000:
            salary_score += 3
        if spread >= 6000:
            salary_score += 3
        if spread >= 12000:
            salary_score += 2
        salary_score = min(20, salary_score)
    elif salary_min > 0 or salary_max > 0:
        salary_score = 6
    else:
        salary_score = 0
    parts.append({"field": "期望薪资", "score": salary_score, "max": 20})

    # 信息完整性：跨字段一致性补分，鼓励形成可执行画像
    consistency_hits = 0
    if target_jobs:
        consistency_hits += 1
    if skill_count >= 3:
        consistency_hits += 1
    if edu:
        consistency_hits += 1
    if exp_year:
        consistency_hits += 1
    if salary_score >= 10:
        consistency_hits += 1
    consistency_score = min(5, consistency_hits)
    parts.append({"field": "信息完整性", "score": consistency_score, "max": 5})

    score = int(sum(x["score"] for x in parts))
    missing = [x["field"] for x in parts if x["score"] == 0]
    return {
        "score": max(0, min(100, score)),
        "details": parts,
        "missing_fields": missing,
    }


def _build_confidence(profile_score=0, data_quality_score=55, market_sample=0):
    profile_score = max(0, min(100, _safe_int(profile_score)))
    data_quality_score = max(0, min(100, _safe_int(data_quality_score, 55)))
    market_sample = max(0, _safe_int(market_sample))
    if market_sample >= 1500:
        sample_score = 100
    elif market_sample >= 800:
        sample_score = 90
    elif market_sample >= 300:
        sample_score = 75
    elif market_sample >= 100:
        sample_score = 60
    elif market_sample >= 30:
        sample_score = 45
    else:
        sample_score = 35
    score = int(round(profile_score * 0.45 + data_quality_score * 0.35 + sample_score * 0.20))
    level = "高" if score >= 75 else ("中" if score >= 58 else "低")
    tone = "good" if score >= 75 else ("mid" if score >= 58 else "risk")
    reasons = [
        f"画像完整度 {profile_score} 分",
        f"数据质量 {data_quality_score} 分",
        f"样本规模 {market_sample} 条",
    ]
    return {"score": score, "level": level, "tone": tone, "reasons": reasons}


def _build_profile_decision(profile_payload, score_result, percentile=0):
    profile_payload = profile_payload or {}
    score_result = score_result or {}
    score = _safe_int(score_result.get("score"))
    missing_fields = list(score_result.get("missing_fields") or [])
    skill_list = _json_list(profile_payload.get("skill_list") or profile_payload.get("skills"))

    actions = []
    if "目标岗位" in missing_fields:
        actions.append({"title": "补齐目标岗位", "desc": "明确目标岗位后，系统才能稳定输出岗位决策。", "priority": "high", "action_id": "profile"})
    if "技能标签" in missing_fields or len(skill_list) < 4:
        actions.append({"title": "补齐核心技能", "desc": "建议至少填写 4 项技能，包含技术栈和项目能力。", "priority": "high", "action_id": "profile"})
    if "经验信息" in missing_fields:
        actions.append({"title": "补充经验信息", "desc": "补充经验年限后，可提高岗位层级和竞争力判断准确度。", "priority": "mid", "action_id": "profile"})
    if "期望薪资" in missing_fields:
        actions.append({"title": "补齐薪资区间", "desc": "补齐期望薪资后，系统才能给出更稳定的投递和谈薪建议。", "priority": "mid", "action_id": "profile"})
    if not actions and score < 85:
        actions.append({"title": "补充技能细分", "desc": "继续补充技能细分和目标城市，可提升推荐与决策精度。", "priority": "mid", "action_id": "profile"})
    if not actions:
        actions.append({"title": "进入岗位决策", "desc": "画像质量已较高，可直接进入岗位决策与首轮投递。", "priority": "high", "action_id": "data"})

    if score >= 85:
        conclusion = "画像质量较高，可以直接进入岗位决策阶段"
        suggestion = "优先评估主申岗位，并把高匹配岗位转入执行池。"
        tone = "good"
    elif score >= 60:
        conclusion = "画像已可用，但仍建议补齐少量关键字段"
        suggestion = "补齐技能细分和薪资区间后，再进入推荐计划与投递执行。"
        tone = "mid"
    else:
        conclusion = "画像基础仍偏弱，建议先完善后再做投递决策"
        suggestion = "优先补齐目标岗位、技能、经验和薪资区间，再开始岗位评估。"
        tone = "risk"

    reason = f"当前画像评分 {score} 分，市场分位约 {percentile}%。"
    if missing_fields:
        reason += f" 当前主要短板：{'、'.join(missing_fields[:3])}。"
    elif skill_list:
        reason += f" 当前已录入 {len(skill_list)} 项技能，画像基础较完整。"

    return {
        "conclusion": conclusion,
        "reason": reason,
        "suggestion": suggestion,
        "tone": tone,
        "actions": actions[:4],
    }


def _build_workbench_decision(ctx):
    ctx = ctx if isinstance(ctx, dict) else {}
    profile_score = _safe_int(ctx.get("profileScore"))
    rec_count = _safe_int(ctx.get("recCount"))
    shortlist_count = _safe_int(ctx.get("shortlistCount"))
    applied_count = _safe_int(ctx.get("appliedCount"))
    interview_count = _safe_int(ctx.get("interviewCount"))
    offer_count = _safe_int(ctx.get("offerCount"))
    top_missing = [str(x).strip() for x in list(ctx.get("topMissing") or []) if str(x).strip()]
    data_quality_score = _safe_int(ctx.get("dataQualityScore"), 55)
    market_sample = _safe_int(ctx.get("marketSample"))

    conclusion = "先完成岗位决策，形成首批候选"
    reason = f"画像完整度 {profile_score} 分，高匹配岗位 {rec_count} 个，候选 {shortlist_count} 个，已投递 {applied_count} 个。"
    suggestion = "进入岗位决策筛出 Top3 候选，再进入投递执行跟踪状态。"
    tone = "mid"
    primary_action = "evaluate"

    if profile_score < 60:
        conclusion = "先完善画像，再开始投递"
        reason = f"当前画像完整度 {profile_score} 分，低于建议阈值 60 分。"
        suggestion = f"优先补齐技能、经验、期望薪资字段{'，并补强 ' + '、'.join(top_missing[:2]) if top_missing else ''}。"
        tone = "risk"
        primary_action = "profile"
    elif rec_count <= 0:
        conclusion = "画像已可用，但缺少可投候选岗位"
        reason = "当前高匹配岗位数量为 0，说明岗位筛选范围或关键词需要调整。"
        suggestion = "先去岗位决策页重新筛选关键词和城市，再生成候选岗位。"
        primary_action = "evaluate"
    elif shortlist_count <= 0:
        conclusion = "已有可投岗位，先完成候选归类"
        reason = f"识别到 {rec_count} 个高匹配岗位，但执行池仍为空。"
        suggestion = "先将 Top3 岗位加入执行池，再进入投递执行排优先级。"
        primary_action = "evaluate"
    elif applied_count <= 0:
        conclusion = "候选已形成，进入首轮投递"
        reason = f"候选岗位 {shortlist_count} 个，但尚未形成投递记录。"
        suggestion = "优先投递主申岗位 2-3 个，并设置 48 小时跟进提醒。"
        tone = "good"
        primary_action = "applications"
    elif (interview_count + offer_count) <= 0:
        conclusion = "进入跟进阶段，重点提升面试转化"
        reason = f"已投递 {applied_count} 个岗位，但面试和 Offer 仍为 0。"
        suggestion = f"优先跟进已投递岗位，并补齐 {top_missing[0] if top_missing else '关键短板技能'} 提升转化率。"
        primary_action = "applications"
    else:
        conclusion = "流程推进良好，进入持续提升阶段"
        reason = f"当前面试 {interview_count} 个，Offer {offer_count} 个，已形成正向反馈。"
        suggestion = "继续维护投递节奏，并根据反馈迭代画像与技能策略。"
        tone = "good"
        primary_action = "compet"

    if profile_score < 60:
        actions = [
            {"title": "补齐画像关键字段", "desc": "至少补齐目标岗位、核心技能、经验和期望薪资。", "priority": "high", "action_id": "profile"},
            {"title": "补齐高频缺失技能", "desc": f"建议先补：{'、'.join(top_missing[:2])}。" if top_missing else "先补 1-2 项岗位高频技能。", "priority": "high", "action_id": "profile"},
            {"title": "完成竞争力分析", "desc": "先生成竞争力与技能差距，再决定投递节奏。", "priority": "mid", "action_id": "compet"},
        ]
    elif rec_count <= 0:
        actions = [
            {"title": "调整筛选条件并重评", "desc": "先放宽城市或经验条件，重新执行岗位决策。", "priority": "high", "action_id": "data"},
            {"title": "查看市场分析校准方向", "desc": "确认目标岗位在目标城市是否有足够样本。", "priority": "mid", "action_id": "dashboard"},
            {"title": "更新画像目标岗位", "desc": "若方向过窄，补充 1-2 个相邻岗位方向。", "priority": "mid", "action_id": "profile"},
        ]
    elif shortlist_count <= 0:
        actions = [
            {"title": "从评估结果中选出 Top3", "desc": "将高匹配岗位分别标记为主申或冲刺。", "priority": "high", "action_id": "data"},
            {"title": "加入执行池", "desc": "把候选岗位加入看板，避免重复评估。", "priority": "high", "action_id": "applications"},
            {"title": "补齐关键短板技能", "desc": f"优先补：{top_missing[0]}。" if top_missing else "继续补齐岗位高频技能。", "priority": "mid", "action_id": "profile"},
        ]
    elif applied_count <= 0:
        actions = [
            {"title": "首批投递 2-3 个岗位", "desc": "优先主申岗位，冲刺岗位控制在少量。", "priority": "high", "action_id": "applications"},
            {"title": "设置 48 小时跟进提醒", "desc": "每次投递后记录时间和下一步跟进节点。", "priority": "high", "action_id": "applications"},
            {"title": "准备投递亮点表达", "desc": "围绕岗位要求改写简历中的项目成果表达。", "priority": "mid", "action_id": "profile"},
        ]
    elif (interview_count + offer_count) <= 0:
        actions = [
            {"title": "更新投递状态与跟进结果", "desc": "把已投递、沟通中、面试邀约状态及时更新。", "priority": "high", "action_id": "applications"},
            {"title": "对未回复岗位进行跟进", "desc": "投递后 48-72 小时未回复可发送一次简短跟进。", "priority": "mid", "action_id": "applications"},
            {"title": "补齐转化关键技能", "desc": f"优先补：{'、'.join(top_missing[:2])}。" if top_missing else "根据反馈补齐高频硬技能。", "priority": "mid", "action_id": "profile"},
        ]
    else:
        actions = [
            {"title": "复盘面试反馈并更新画像", "desc": "把面试反馈同步到技能与项目经历中。", "priority": "mid", "action_id": "profile"},
            {"title": "动态调整主申/冲刺比例", "desc": "根据近两周结果优化投递结构。", "priority": "mid", "action_id": "applications"},
            {"title": "每周补齐 1 项高频技能", "desc": "持续提升竞争力，抬升薪资与岗位上限。", "priority": "low", "action_id": "compet"},
        ]

    confidence = _build_confidence(profile_score, data_quality_score, market_sample)
    return {
        "conclusion": conclusion,
        "reason": reason,
        "suggestion": suggestion,
        "tone": tone,
        "primaryAction": primary_action,
        "actions": actions[:3],
        "confidence": confidence,
    }


def _tokenize_job_skills(job):
    tokens = extract_skills(job.skills or "", job.raw_desc or "")
    if not tokens and job.tags:
        tokens = extract_skills(job.tags, "")
    return [str(x).strip() for x in tokens if str(x).strip()]


def _build_job_match(profile, job):
    user_skills = [x.lower() for x in profile.get_skill_list()]
    user_skill_set = set(user_skills)
    job_skills = _tokenize_job_skills(job)
    job_skill_set = {x.lower() for x in job_skills}

    if job_skill_set:
        overlap = user_skill_set & job_skill_set
        skill_match = int(round((len(overlap) / max(1, len(job_skill_set))) * 100))
        missing = [x for x in job_skills if x.lower() not in user_skill_set][:8]
        matched = [x for x in job_skills if x.lower() in user_skill_set][:8]
    else:
        skill_match = 60
        missing = []
        matched = []

    req_exp = _parse_exp_to_years(job.exp_req)
    user_exp = _safe_float(profile.exp_years_num) or _parse_exp_to_years(profile.exp_year)
    diff_exp = user_exp - req_exp
    if req_exp <= 0:
        exp_match = 90
    elif diff_exp >= 1:
        exp_match = 100
    elif diff_exp >= 0:
        exp_match = 90
    elif diff_exp >= -1:
        exp_match = 75
    elif diff_exp >= -2:
        exp_match = 60
    else:
        exp_match = 40

    user_edu_rank = EDU_RANK.get(_normalize_edu_level(profile.edu_level), 0)
    job_edu_rank = EDU_RANK.get(_normalize_edu_level(job.edu_req), 0)
    if job_edu_rank <= 0:
        edu_match = 90
    elif user_edu_rank >= job_edu_rank:
        edu_match = 100
    elif user_edu_rank + 1 == job_edu_rank:
        edu_match = 70
    else:
        edu_match = 40

    salary_fit = 60
    job_salary = sanitize_salary_avg(job.salary_avg)
    expected_min = _safe_int(profile.expected_salary_min)
    expected_max = _safe_int(profile.expected_salary_max)
    if expected_min > expected_max and expected_max > 0:
        expected_min, expected_max = expected_max, expected_min

    if job_salary > 0 and expected_min > 0 and expected_max > 0:
        low, high = int(job_salary * 0.7), int(job_salary * 1.3)
        if expected_min <= high and expected_max >= low:
            salary_fit = 95
        else:
            center = (expected_min + expected_max) / 2
            distance = abs(center - job_salary) / max(job_salary, 1)
            salary_fit = int(max(20, min(90, 100 - distance * 100)))
    elif job_salary > 0 and (expected_min > 0 or expected_max > 0):
        target = expected_max if expected_max > 0 else expected_min
        distance = abs(target - job_salary) / max(job_salary, 1)
        salary_fit = int(max(20, min(90, 100 - distance * 100)))

    total = int(round(skill_match * 0.40 + exp_match * 0.25 + edu_match * 0.20 + salary_fit * 0.15))
    total = max(0, min(99, total))

    if total >= 85:
        level = "高度匹配"
    elif total >= 70:
        level = "中等匹配"
    else:
        level = "待提升"

    highlights = []
    if matched:
        highlights.append(f"技能已匹配：{', '.join(matched[:3])}")
    if missing:
        highlights.append(f"建议补齐：{', '.join(missing[:3])}")
    if diff_exp < 0:
        highlights.append(f"经验约差 {abs(round(diff_exp, 1))} 年，可在简历中强化项目成果")
    if salary_fit < 70:
        highlights.append("期望薪资与岗位区间偏离，建议调整谈判区间")
    if not highlights:
        highlights.append("核心维度较均衡，可直接进入投递")

    return {
        "score": total,
        "level": level,
        "radar": {
            "skill_match": skill_match,
            "exp_match": exp_match,
            "edu_match": edu_match,
            "salary_fit": salary_fit,
        },
        "skills": {
            "matched": matched,
            "missing": missing,
            "job_required": job_skills,
            "user_skills": profile.get_skill_list(),
        },
        "explain": highlights[:4],
    }


def _risk_block(level, text):
    color_map = {"高": "#ef4444", "中": "#f59e0b", "低": "#10b981"}
    return {
        "level": level,
        "color": color_map.get(level, "#94a3b8"),
        "text": text,
    }


def _build_job_decision(match_result):
    score = _safe_int(match_result.get("score"))
    radar = match_result.get("radar") or {}
    skills = match_result.get("skills") or {}
    matched = list(skills.get("matched") or [])
    missing = list(skills.get("missing") or [])
    skill_score = _safe_int(radar.get("skill_match"))
    exp_score = _safe_int(radar.get("exp_match"))
    edu_score = _safe_int(radar.get("edu_match"))
    salary_score = _safe_int(radar.get("salary_fit"))

    bucket = _score_bucket(score)
    invest_index = max(
        0,
        min(100, int(round(score * 0.6 + exp_score * 0.15 + salary_score * 0.15 + skill_score * 0.1))),
    )

    skill_risk = "高" if len(missing) >= 4 else ("中" if len(missing) >= 2 else "低")
    salary_risk = "高" if salary_score < 60 else ("中" if salary_score < 75 else "低")
    competition_risk = "高" if score < 60 else ("中" if score < 75 else "低")
    if "高" in {skill_risk, salary_risk, competition_risk}:
        risk_level = "高风险"
    elif "中" in {skill_risk, salary_risk, competition_risk}:
        risk_level = "中风险"
    else:
        risk_level = "低风险"

    if score >= 80:
        conclusion = "适合投递"
        suggestion = "建议优先投递，并在 48 小时内完成首次跟进。"
        state_text = "已评估（建议投递）"
    elif score >= 65:
        conclusion = "可投递，建议补强后优先"
        suggestion = "建议先补齐 1-2 项关键短板，再进入集中投递。"
        state_text = "已评估（谨慎可投）"
    else:
        conclusion = "暂缓投递，先补短板"
        suggestion = "建议先补技能和项目表达，再重新评估投递时机。"
        state_text = "已评估（待补短板）"

    if missing:
        suggestion = f"优先补齐：{'、'.join(missing[:2])}；投递时突出已匹配技能与项目成果。"
    elif matched and score >= 80:
        suggestion = f"优先突出：{'、'.join(matched[:3])} 等已匹配能力，并尽快进入主申投递。"

    reason = f"技能匹配 {skill_score}，经验匹配 {exp_score}，学历匹配 {edu_score}，薪资匹配 {salary_score}"
    risk_summary = f"技能{skill_risk}/薪资{salary_risk}/竞争{competition_risk}"
    next_actions = [
        f"先按“{bucket}”分层处理，避免盲目投递。",
        f"风险重点：{risk_summary}。",
        suggestion,
    ]

    return {
        "score": score,
        "bucket": bucket,
        "invest_index": invest_index,
        "conclusion": conclusion,
        "reason": reason,
        "suggestion": suggestion,
        "state_text": state_text,
        "risk_level": risk_level,
        "risk_summary": risk_summary,
        "next_actions": next_actions,
        "matched_skills": matched[:6],
        "missing_skills": missing[:6],
        "risks": {
            "skill": _risk_block(skill_risk, "技能缺口越多，投递转化越依赖简历补强"),
            "salary": _risk_block(salary_risk, "薪资偏离越大，谈判与转化阻力越高"),
            "competition": _risk_block(competition_risk, "综合匹配越低，竞争压力通常越大"),
        },
        "actions": [
            {"type": "bucket", "bucket": "主申", "label": "归类主申", "style": "default", "icon": "ri-medal-line"},
            {"type": "bucket", "bucket": "冲刺", "label": "归类冲刺", "style": "default", "icon": "ri-rocket-line"},
            {"type": "bucket", "bucket": "保底", "label": "归类保底", "style": "default", "icon": "ri-shield-line"},
            {"type": "favorite", "label": "收藏到看板", "style": "default", "icon": "ri-star-line"},
            {"type": "applied", "label": "标记已投递", "style": "primary", "icon": "ri-send-plane-line"},
        ],
    }


def _build_job_evaluation_payload(profile, job):
    match_result = _build_job_match(profile, job)
    decision = _build_job_decision(match_result)
    return {
        "job": {
            "id": job.id,
            "job_name": job.job_name,
            "company": job.company,
            "city": job.city,
            "salary_avg": _safe_int(sanitize_salary_avg(job.salary_avg)),
            "salary_text": job.salary_text or "",
            "edu_req": job.edu_req,
            "exp_req": job.exp_req,
        },
        "match": match_result,
        "decision": decision,
    }


def _serialize_application(item):
    job = item.job
    status_key = _status_key(item.status)
    priority, overdue, bucket = _application_priority(item)
    base_dt = _parse_datetime(item.interview_date or item.updated_at or item.applied_at)
    days_since = _days_since(item.updated_at or item.applied_at)
    return {
        "id": item.id,
        "job_id": item.job_id,
        "status": item.status,
        "status_key": status_key,
        "applied_at": _to_iso(item.applied_at),
        "interview_date": _to_iso(item.interview_date),
        "notes": item.notes or "",
        "match_score": _safe_int(item.match_score),
        "updated_at": _to_iso(item.updated_at),
        "bucket": bucket,
        "priority": priority,
        "follow_up_overdue": overdue,
        "days_since_update": days_since,
        "next_follow_date": _next_follow_date(status_key, base_dt),
        "recommended_action": _recommended_action(status_key, overdue, bucket),
        "job": {
            "id": job.id if job else 0,
            "job_name": job.job_name if job else "",
            "company": job.company if job else "",
            "city": job.city if job else "",
            "salary_avg": _safe_int(sanitize_salary_avg(job.salary_avg) if job else 0),
        },
    }

def _get_or_create_profile(uid):
    profile = UserProfile.query.get(uid)
    if profile:
        return profile
    profile = UserProfile(user_id=uid)
    db.session.add(profile)
    db.session.flush()
    return profile


def _build_application_dashboard(items):
    rows = list(items or [])
    now = datetime.utcnow()
    applied_rows = [x for x in rows if x.get("status_key") in {"applied", "interview", "offer", "rejected"}]
    interview_rows = [x for x in rows if x.get("status_key") == "interview"]
    offer_rows = [x for x in rows if x.get("status_key") == "offer"]
    favorite_rows = [x for x in rows if x.get("status_key") == "favorite"]

    total_applied = len(applied_rows)
    interview_rate = round((len(interview_rows) / total_applied) * 100, 1) if total_applied else 0.0
    offer_rate = round((len(offer_rows) / max(1, len(interview_rows))) * 100, 1) if interview_rows else 0.0
    response_rate = round(((total_applied - len([x for x in rows if x.get("status") == "已投递"])) / total_applied) * 100, 1) if total_applied else 0.0

    recent_applied = 0
    for item in applied_rows:
        dt = _parse_datetime(item.get("applied_at") or item.get("updated_at"))
        if dt and (now - dt).days <= 7:
            recent_applied += 1

    todos = []
    priority_pool = {"主申": [], "冲刺": [], "保底": []}
    timeline = []
    for item in rows:
        bucket = item.get("bucket") or "保底"
        if bucket in priority_pool and item.get("status_key") in {"favorite", "applied", "interview"}:
            priority_pool[bucket].append(item)

        updated = _parse_datetime(item.get("updated_at") or item.get("applied_at"))
        if updated:
            timeline.append(
                {
                    "id": item.get("id"),
                    "time": _to_iso(updated),
                    "status": item.get("status"),
                    "title": (item.get("job") or {}).get("job_name") or "岗位",
                    "company": (item.get("job") or {}).get("company") or "",
                }
            )

        if item.get("follow_up_overdue"):
            todos.append(
                {
                    "id": item.get("id"),
                    "job_id": (item.get("job") or {}).get("id") or item.get("job_id"),
                    "level": "high",
                    "title": f"跟进 {(item.get('job') or {}).get('job_name') or '目标岗位'}",
                    "desc": item.get("recommended_action") or "已超过建议跟进窗口，建议今天补一次跟进",
                    "status": item.get("status"),
                    "bucket": bucket,
                }
            )
        elif item.get("status_key") == "favorite" and item.get("bucket") == "主申":
            todos.append(
                {
                    "id": item.get("id"),
                    "job_id": (item.get("job") or {}).get("id") or item.get("job_id"),
                    "level": "medium",
                    "title": f"优先投递 {(item.get('job') or {}).get('job_name') or '主申岗位'}",
                    "desc": "高匹配候选仍未投递，建议今天完成首轮投递",
                    "status": item.get("status"),
                    "bucket": bucket,
                }
            )

    for key in priority_pool:
        priority_pool[key] = sorted(
            priority_pool[key],
            key=lambda x: (x.get("priority") == "high", _safe_int(x.get("match_score"))),
            reverse=True,
        )[:6]

    todos = sorted(
        todos,
        key=lambda x: ((x.get("level") == "high"), x.get("bucket") == "主申"),
        reverse=True,
    )[:8]
    timeline = sorted(timeline, key=lambda x: x.get("time") or "", reverse=True)[:12]

    primary_count = sum(1 for x in rows if x.get("bucket") == "主申" and x.get("status_key") in {"favorite", "applied", "interview"})
    sprint_count = sum(1 for x in rows if x.get("bucket") == "冲刺" and x.get("status_key") in {"favorite", "applied", "interview"})
    backup_count = sum(1 for x in rows if x.get("bucket") == "保底" and x.get("status_key") in {"favorite", "applied", "interview"})
    bucket_total = max(1, primary_count + sprint_count + backup_count)
    primary_rate = round(primary_count / bucket_total * 100, 1)
    sprint_rate = round(sprint_count / bucket_total * 100, 1)
    backup_rate = round(backup_count / bucket_total * 100, 1)

    if total_applied == 0:
        review_conclusion = "当前还没有形成投递节奏，先完成首批投递"
        review_suggestion = "从主申岗位中先投递 2-3 个，并在 48 小时内完成首次跟进。"
    elif interview_rate < 20:
        review_conclusion = "投递量有了，但面试转化偏低"
        review_suggestion = "提高主申岗位占比，投递前强化简历关键词和项目成果表达。"
    elif offer_rows and offer_rate < 30:
        review_conclusion = "已进入面试推进阶段，Offer 转化仍有提升空间"
        review_suggestion = "重点复盘面试反馈，优先推进已进入面试的高匹配岗位。"
    else:
        review_conclusion = "当前投递节奏基本稳定，可继续执行"
        review_suggestion = "保持主申优先，并持续维护 48 小时跟进节奏。"

    cockpit_suggestion = review_suggestion
    if todos:
        cockpit_suggestion = f"今天优先处理 {len(todos)} 条待办，先做高优先跟进，再推进主申岗位投递。"

    focus_jobs = []
    for bucket_name in ["主申", "冲刺", "保底"]:
        for item in (priority_pool.get(bucket_name) or [])[:2]:
            focus_jobs.append(
                {
                    "id": item.get("id"),
                    "job_id": (item.get("job") or {}).get("id") or item.get("job_id"),
                    "job_name": (item.get("job") or {}).get("job_name") or "未知岗位",
                    "company": (item.get("job") or {}).get("company") or "",
                    "bucket": bucket_name,
                    "status": item.get("status") or "",
                    "match_score": _safe_int(item.get("match_score")),
                    "recommended_action": item.get("recommended_action") or "",
                    "next_follow_date": item.get("next_follow_date") or "",
                }
            )
            if len(focus_jobs) >= 5:
                break
        if len(focus_jobs) >= 5:
            break

    if total_applied == 0:
        delivery_conclusion = "先完成首批投递，再建立稳定跟进节奏"
        delivery_reason = f"当前候选池共 {primary_count + sprint_count + backup_count} 个岗位，但还没有有效投递记录。"
        delivery_suggestion = "今天优先投递 2-3 个主申岗位，投递后 48 小时内完成首次跟进。"
        delivery_tone = "mid"
    elif todos:
        delivery_conclusion = "先处理待办，再推进新的投递动作"
        delivery_reason = f"当前有 {len(todos)} 条待办，其中高优先 {len([x for x in todos if x.get('level') == 'high'])} 条。"
        delivery_suggestion = "先完成逾期跟进和主申岗位状态更新，再安排新的投递。"
        delivery_tone = "mid"
    elif interview_rows or offer_rows:
        delivery_conclusion = "当前进入转化推进阶段，重点关注面试与 Offer"
        delivery_reason = f"当前面试 {len(interview_rows)} 个，Offer {len(offer_rows)} 个，主申占比 {primary_rate}%。"
        delivery_suggestion = "优先推进在途流程，同时保持少量主申岗位持续补充，避免断档。"
        delivery_tone = "good"
    else:
        delivery_conclusion = "当前可继续执行主申优先的投递策略"
        delivery_reason = f"主申 {primary_count} 个，冲刺 {sprint_count} 个，保底 {backup_count} 个，面试率 {interview_rate}%。"
        delivery_suggestion = "保持主申优先、冲刺控制数量、保底只作兜底的投递结构。"
        delivery_tone = "good"

    today_actions = []
    for todo in todos[:3]:
        today_actions.append(
            {
                "label": todo.get("title") or "处理待办",
                "detail": todo.get("desc") or "",
                "level": todo.get("level") or "medium",
                "bucket": todo.get("bucket") or "保底",
            }
        )
    if primary_count and len(today_actions) < 4:
        today_actions.append(
            {
                "label": "完成主申岗位首轮投递",
                "detail": f"当前主申池 {primary_count} 个，建议优先处理匹配分最高的 2-3 个岗位。",
                "level": "medium",
                "bucket": "主申",
            }
        )
    if sprint_count and len(today_actions) < 4:
        today_actions.append(
            {
                "label": "补充少量冲刺岗位",
                "detail": f"当前冲刺池 {sprint_count} 个，仅保留高薪或成长性明确的岗位推进。",
                "level": "low",
                "bucket": "冲刺",
            }
        )

    weekly_plan_tasks = []
    for idx, focus in enumerate(focus_jobs[:6]):
        weekly_plan_tasks.append(
            {
                "task_id": f"{focus.get('bucket')}-{focus.get('id') or focus.get('job_id') or idx}",
                "role": focus.get("bucket") or "主申",
                "job_id": focus.get("job_id") or 0,
                "title": focus.get("job_name") or "未知岗位",
                "company": focus.get("company") or "-",
                "follow_date": focus.get("next_follow_date") or "",
                "action": focus.get("recommended_action") or "建议优先推进当前岗位",
            }
        )
    if not weekly_plan_tasks:
        for todo in todos[:4]:
            weekly_plan_tasks.append(
                {
                    "task_id": f"todo-{todo.get('id') or len(weekly_plan_tasks)}",
                    "role": todo.get("bucket") or "主申",
                    "job_id": todo.get("job_id") or 0,
                    "title": todo.get("title") or "处理待办",
                    "company": "",
                    "follow_date": "",
                    "action": todo.get("desc") or "建议今天优先处理",
                }
            )

    return {
        "overview": {
            "total": len(rows),
            "favorite": len(favorite_rows),
            "applied": total_applied,
            "interview": len(interview_rows),
            "offer": len(offer_rows),
            "response_rate": response_rate,
            "interview_rate": interview_rate,
            "offer_rate": offer_rate,
        },
        "cockpit": {
            "today_tasks": len(todos),
            "high_priority_tasks": len([x for x in todos if x.get("level") == "high"]),
            "recent_applied": recent_applied,
            "interview_rate": interview_rate,
            "offer_rate": offer_rate,
            "suggestion": cockpit_suggestion,
        },
        "priority_pool": priority_pool,
        "todos": todos,
        "timeline": timeline,
        "weekly_review": {
            "conclusion": review_conclusion,
            "suggestion": review_suggestion,
            "primary_rate": primary_rate,
            "sprint_rate": sprint_rate,
            "backup_rate": backup_rate,
        },
        "delivery_decision": {
            "conclusion": delivery_conclusion,
            "reason": delivery_reason,
            "suggestion": delivery_suggestion,
            "tone": delivery_tone,
            "focus_jobs": focus_jobs,
            "today_actions": today_actions[:4],
            "structure": {
                "primary": primary_count,
                "sprint": sprint_count,
                "backup": backup_count,
                "primary_rate": primary_rate,
                "sprint_rate": sprint_rate,
                "backup_rate": backup_rate,
            },
        },
        "weekly_plan": {
            "tasks": weekly_plan_tasks[:6],
            "summary": review_suggestion,
            "focus": delivery_conclusion,
        },
    }


def _dedupe_plan_jobs(raw_jobs):
    job_map = {}
    for raw in list(raw_jobs or []):
        if not isinstance(raw, dict):
            continue
        job_id = _safe_int(raw.get("job_id") or raw.get("id"))
        if job_id <= 0:
            continue
        score = _safe_int(raw.get("match_score") or raw.get("score") or raw.get("_quick_match"))
        title = str(raw.get("job_name") or raw.get("title") or "").strip()
        company = str(raw.get("company") or "").strip()
        current = job_map.get(job_id)
        if not current or score > current.get("match_score", 0):
            job_map[job_id] = {
                "job_id": job_id,
                "match_score": score,
                "job_name": title,
                "company": company,
            }
    return sorted(
        job_map.values(),
        key=lambda x: (x.get("match_score", 0), x.get("job_id", 0)),
        reverse=True,
    )


def _build_execution_seed_plan(raw_jobs, limit=9):
    ranked = _dedupe_plan_jobs(raw_jobs)
    limit = max(1, min(_safe_int(limit, 9), 12))
    ranked = ranked[: max(limit * 2, limit)]
    if not ranked:
        return []

    high = [x for x in ranked if x.get("match_score", 0) >= APP_BUCKET_MAIN]
    mid = [x for x in ranked if APP_BUCKET_SPRINT <= x.get("match_score", 0) < APP_BUCKET_MAIN]
    low = [x for x in ranked if x.get("match_score", 0) < APP_BUCKET_SPRINT]

    primary_target = 1 if limit <= 1 else (2 if limit <= 4 else min(4, max(2, round(limit * 0.45))))
    sprint_target = 0 if limit <= 2 else min(3, max(1, round(limit * 0.3)))
    backup_target = max(0, limit - primary_target - sprint_target)

    picked = []
    used_job_ids = set()

    def push(group, bucket, max_count):
        for item in group:
            if len([x for x in picked if x["bucket"] == bucket]) >= max_count:
                break
            if item["job_id"] in used_job_ids:
                continue
            picked.append({**item, "bucket": bucket})
            used_job_ids.add(item["job_id"])

    push(high, "主申", primary_target)
    push(mid, "冲刺", sprint_target)
    push(low, "保底", backup_target)

    if len(picked) < limit:
        remaining = [x for x in ranked if x["job_id"] not in used_job_ids]
        for item in remaining:
            if len(picked) >= limit:
                break
            picked.append({**item, "bucket": _score_bucket(item.get("match_score", 0))})
            used_job_ids.add(item["job_id"])

    return picked[:limit]


def _persist_execution_seed_plan(uid, planned_jobs):
    plan = list(planned_jobs or [])
    if not plan:
        return {"created": 0, "updated": 0, "items": [], "summary": {"主申": 0, "冲刺": 0, "保底": 0}}

    job_ids = [x["job_id"] for x in plan if _safe_int(x.get("job_id")) > 0]
    jobs = Job.query.filter(Job.id.in_(job_ids), Job.owner_id == uid).all()
    job_map = {job.id: job for job in jobs}
    existing = JobApplication.query.filter(
        JobApplication.user_id == uid,
        JobApplication.job_id.in_(job_ids),
    ).all()
    existing_map = {item.job_id: item for item in existing}

    created = 0
    updated = 0
    summary = {"主申": 0, "冲刺": 0, "保底": 0}
    touched = []

    for item in plan:
        job_id = _safe_int(item.get("job_id"))
        if job_id <= 0 or job_id not in job_map:
            continue

        bucket = _normalize_bucket(item.get("bucket"), item.get("match_score"))
        summary[bucket] = summary.get(bucket, 0) + 1
        rec = existing_map.get(job_id)
        if not rec:
            rec = JobApplication(user_id=uid, job_id=job_id, status="已收藏")
            db.session.add(rec)
            existing_map[job_id] = rec
            created += 1
        else:
            updated += 1

        rec.bucket = bucket
        rec.match_score = _safe_int(item.get("match_score") or rec.match_score)
        if rec.status not in {"已投递", "简历筛选", "面试邀约", "Offer", "已拒绝"}:
            rec.status = "已收藏"
        rec.updated_at = datetime.utcnow()
        touched.append(rec)

    db.session.commit()
    return {
        "created": created,
        "updated": updated,
        "items": [_serialize_application(x) for x in touched],
        "summary": summary,
    }


def _auto_organize_active_applications(uid):
    active_rows = (
        JobApplication.query.join(Job, Job.id == JobApplication.job_id)
        .filter(
            JobApplication.user_id == uid,
            Job.owner_id == uid,
            JobApplication.status.in_(["已收藏", "已投递", "简历筛选", "面试邀约"]),
        )
        .order_by(JobApplication.updated_at.desc(), JobApplication.id.desc())
        .all()
    )

    changed = []
    summary = {"主申": 0, "冲刺": 0, "保底": 0}
    for rec in active_rows:
        score = _safe_int(rec.match_score)
        bucket = _score_bucket(score, rec.notes)
        summary[bucket] = summary.get(bucket, 0) + 1
        if rec.bucket != bucket:
            rec.bucket = bucket
            rec.updated_at = datetime.utcnow()
            changed.append(rec)

    if changed:
        db.session.commit()
    return {
        "changed": len(changed),
        "summary": summary,
        "items": [_serialize_application(x) for x in active_rows],
    }


def _get_weekly_plan_state_map(uid, week_key=None):
    week_key = str(week_key or _current_week_key()).strip() or _current_week_key()
    rows = WeeklyPlanState.query.filter_by(user_id=uid, week_key=week_key).all()
    return {str(item.task_id): bool(item.completed) for item in rows if str(item.task_id).strip()}


def _attach_weekly_plan_state(uid, dashboard, week_key=None):
    dashboard = dashboard if isinstance(dashboard, dict) else {}
    weekly_plan = dashboard.get("weekly_plan") or {}
    tasks = list(weekly_plan.get("tasks") or [])
    week_key = str(week_key or _current_week_key()).strip() or _current_week_key()
    state_map = _get_weekly_plan_state_map(uid, week_key)
    total = len(tasks)
    done = 0
    overdue = 0
    for item in tasks:
        task_id = str(item.get("task_id") or "").strip()
        completed = bool(state_map.get(task_id))
        item["completed"] = completed
        if completed:
            done += 1
        elif item.get("follow_date"):
            follow_dt = _parse_datetime(item.get("follow_date"))
            if follow_dt and follow_dt.date() < datetime.utcnow().date():
                overdue += 1

    weekly_plan["week_key"] = week_key
    weekly_plan["completed_map"] = state_map
    weekly_plan["progress"] = {
        "total": total,
        "completed": done,
        "completion_rate": round((done / total) * 100, 1) if total else 0.0,
        "overdue": overdue,
    }
    weekly_plan["tasks"] = tasks
    dashboard["weekly_plan"] = weekly_plan
    return dashboard


def _attach_execution_feedback(dashboard):
    dashboard = dashboard if isinstance(dashboard, dict) else {}
    weekly_plan = dashboard.get("weekly_plan") or {}
    progress = weekly_plan.get("progress") or {}
    tasks = list(weekly_plan.get("tasks") or [])
    overview = dashboard.get("overview") or {}
    delivery = dashboard.get("delivery_decision") or {}
    weekly_review = dashboard.get("weekly_review") or {}

    total = _safe_int(progress.get("total"))
    completed = _safe_int(progress.get("completed"))
    completion_rate = _safe_float(progress.get("completion_rate"))
    overdue = _safe_int(progress.get("overdue"))

    bucket_counts = {"主申": 0, "冲刺": 0, "保底": 0}
    bucket_done = {"主申": 0, "冲刺": 0, "保底": 0}
    for item in tasks:
        role = str(item.get("role") or "主申").strip()
        if role not in bucket_counts:
            continue
        bucket_counts[role] += 1
        if item.get("completed"):
            bucket_done[role] += 1

    main_execution_rate = round((bucket_done["主申"] / bucket_counts["主申"]) * 100, 1) if bucket_counts["主申"] else 0.0
    sprint_execution_rate = round((bucket_done["冲刺"] / bucket_counts["冲刺"]) * 100, 1) if bucket_counts["冲刺"] else 0.0

    if total <= 0:
        conclusion = "当前还没有形成稳定执行计划"
        reason = "执行清单为空，系统暂时无法判断本周执行质量。"
        suggestion = "先生成执行池并安排本周主申与冲刺任务。"
        tone = "mid"
    elif completion_rate < 40:
        conclusion = "本周执行推进偏慢，建议先保证主申动作完成"
        reason = f"当前周计划完成率 {completion_rate}%，仍有 {max(0, total - completed)} 项未完成。"
        suggestion = "先完成主申岗位投递和逾期跟进，再处理冲刺岗位。"
        tone = "risk"
    elif overdue > 0:
        conclusion = "计划执行尚可，但存在逾期待跟进任务"
        reason = f"当前周计划完成率 {completion_rate}%，仍有 {overdue} 条逾期待跟进。"
        suggestion = "优先清理逾期跟进，再继续推进新的投递动作。"
        tone = "mid"
    else:
        conclusion = "本周执行节奏稳定，可继续保持当前推进方式"
        reason = f"当前周计划完成率 {completion_rate}%，主申执行率 {main_execution_rate}%。"
        suggestion = "继续保持主申优先，并根据转化结果微调冲刺和保底比例。"
        tone = "good"

    dashboard["execution_feedback"] = {
        "conclusion": conclusion,
        "reason": reason,
        "suggestion": suggestion,
        "tone": tone,
        "metrics": {
            "planned_tasks": total,
            "completed_tasks": completed,
            "completion_rate": completion_rate,
            "overdue_tasks": overdue,
            "main_execution_rate": main_execution_rate,
            "sprint_execution_rate": sprint_execution_rate,
            "applied": _safe_int(overview.get("applied")),
            "interview_rate": _safe_float(overview.get("interview_rate")),
            "offer_rate": _safe_float(overview.get("offer_rate")),
        },
        "structure": {
            "main_planned": bucket_counts["主申"],
            "main_done": bucket_done["主申"],
            "sprint_planned": bucket_counts["冲刺"],
            "sprint_done": bucket_done["冲刺"],
            "backup_planned": bucket_counts["保底"],
            "backup_done": bucket_done["保底"],
        },
        "next_focus": delivery.get("suggestion") or weekly_review.get("suggestion") or "保持主申优先的推进节奏。",
    }
    return dashboard


def _extract_json_block(raw_text):
    text = str(raw_text or "").strip()
    if not text:
        return None
    m = re.search(r"\{[\s\S]*\}", text)
    if not m:
        return None
    try:
        data = json.loads(m.group(0))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _normalize_ai_struct(data, fallback):
    if not isinstance(data, dict):
        return fallback

    def _to_list(v):
        if isinstance(v, list):
            return [str(x).strip() for x in v if str(x).strip()][:3]
        if isinstance(v, str) and v.strip():
            return [v.strip()]
        return []

    result = {
        "conclusion": str(data.get("conclusion") or fallback.get("conclusion") or "").strip(),
        "reason": _to_list(data.get("reason")) or fallback.get("reason", []),
        "suggestion": _to_list(data.get("suggestion")) or fallback.get("suggestion", []),
        "risk": _to_list(data.get("risk")) or fallback.get("risk", []),
        "ai_generated": bool(data.get("conclusion")),
    }
    if not result["conclusion"]:
        result["conclusion"] = fallback.get("conclusion") or "建议结合岗位原文继续人工判断。"
    return result


def _is_ai_error_text(text):
    s = str(text or "").strip().lower()
    if not s:
        return True
    keywords = [
        "大模型服务请求失败",
        "request timed out",
        "timeout",
        "ollama",
        "localhost:11434",
        "model not found",
        "connection",
        "unavailable",
        "error",
        "失败",
    ]
    return any(k in s for k in keywords)


def _build_job_ai_rule_advice(profile, job):
    payload = _build_job_evaluation_payload(profile, job)
    decision = payload.get("decision") or {}
    conclusion = decision.get("conclusion") or "建议结合岗位原文继续判断"
    reason = decision.get("reason") or "规则评估已完成"
    suggestion = decision.get("suggestion") or "建议先补齐短板后再投递"
    return f"{conclusion}。原因：{reason}。建议：{suggestion}"


@applicant_bp.route("/api/profile/update", methods=["POST"])
def update_profile_v2():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    data = request.get_json(silent=True) or {}
    profile = _get_or_create_profile(uid)

    target_jobs = _json_list(data.get("target_jobs"))
    if not target_jobs:
        target_jobs = _json_list(data.get("target_job"))
    target_jobs = target_jobs[:3]

    raw_skill_list = data.get("skill_list")
    if raw_skill_list is None:
        raw_skill_list = data.get("skills")
    normalized_skills = extract_skills(raw_skill_list, "")
    if not normalized_skills and isinstance(raw_skill_list, list):
        normalized_skills = [str(x).strip().lower() for x in raw_skill_list if str(x).strip()]
    if not normalized_skills and isinstance(raw_skill_list, str):
        normalized_skills = [
            x.strip().lower()
            for x in raw_skill_list.replace("\uFF0C", ",").replace("\u3001", ",").split(",")
            if x.strip()
        ]

    exp_year = str(data.get("exp_year") or profile.exp_year or "").strip()
    exp_years_num = _safe_float(data.get("exp_years_num"))
    if exp_years_num <= 0:
        exp_years_num = _parse_exp_to_years(exp_year)

    expected_min = _safe_int(data.get("expected_salary_min"))
    expected_max = _safe_int(data.get("expected_salary_max"))
    if expected_min <= 0 and _safe_int(data.get("expected_salary")) > 0:
        expected_min = int(_safe_int(data.get("expected_salary")) * 0.9)
    if expected_max <= 0 and _safe_int(data.get("expected_salary")) > 0:
        expected_max = int(_safe_int(data.get("expected_salary")) * 1.1)
    if expected_min > expected_max and expected_max > 0:
        expected_min, expected_max = expected_max, expected_min

    try:
        profile.target_jobs = json.dumps(target_jobs, ensure_ascii=False)
        profile.skill_list = json.dumps(normalized_skills, ensure_ascii=False)
        profile.target_job = (
            target_jobs[0] if target_jobs else str(data.get("target_job") or profile.target_job or "")
        )[:64]
        profile.skills = ",".join(normalized_skills)[:2000]
        profile.exp_year = exp_year[:32]
        profile.exp_years_num = exp_years_num
        profile.edu_level = str(data.get("edu_level") or profile.edu_level or "").strip()[:32]
        profile.expected_salary_min = expected_min
        profile.expected_salary_max = expected_max
        profile.last_updated = datetime.utcnow()

        profile_payload = _profile_to_dict(profile)
        score_result = _calc_profile_score(profile_payload)
        profile.profile_score = score_result["score"]
        profile_payload["profile_score"] = score_result["score"]

        db.session.commit()
        return jsonify(
            {
                "success": True,
                "data": profile_payload,
                "score": score_result["score"],
                "score_detail": score_result,
            }
        )
    except Exception as e:
        db.session.rollback()
        logging.exception("profile update failed")
        return jsonify({"success": False, "msg": f"画像保存失败: {str(e)[:120]}"}), 500


@applicant_bp.route("/api/profile/score", methods=["GET"])
def get_profile_score():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    profile = UserProfile.query.get(uid)
    profile_payload = _profile_to_dict(profile) if profile else {}
    score_result = _calc_profile_score(profile_payload)
    
    score = score_result.get("score", 0)
    if score >= 90:
        percentile = 95
    elif score >= 80:
        percentile = 85 + (score - 80)
    elif score >= 60:
        percentile = 50 + (score - 60) * 1.5
    else:
        percentile = score * 0.8
    percentile = int(min(99, max(1, percentile)))
    score_result["percentile"] = percentile

    details = score_result.get("details", [])
    good_fields = [d["field"] for d in details if d["max"] > 0 and d["score"] / d["max"] >= 0.8]
    bad_fields = [d["field"] for d in details if d["max"] > 0 and d["score"] / d["max"] <= 0.5]
    
    text = f"您的画像竞争力超越了全站 {percentile}% 的求职者。"
    if not good_fields and not bad_fields:
        text += " 基础画像尚未成型，请先完成填报。"
    else:
        if good_fields:
            text += f" 【{'、'.join(good_fields[:2])}】表现拔尖；"
        if bad_fields:
            text += f" 但在【{'、'.join(bad_fields[:2])}】方面仍有提升空间，建议优先补充。"
        elif good_fields:
            text += " 各项信息均无明显短板，画像健康度极佳。"
            
    score_result["analysis_text"] = text
    score_result["decision"] = _build_profile_decision(profile_payload, score_result, percentile)
    return jsonify({"success": True, "data": score_result, "profile": profile_payload})


@applicant_bp.route("/api/workbench/decision", methods=["POST"])
def get_workbench_decision():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    payload = request.get_json(silent=True) or {}
    decision = _build_workbench_decision(payload)
    return jsonify({"success": True, "data": decision})


@applicant_bp.route("/api/job/<int:job_id>/match", methods=["POST"])
def match_job_with_profile(job_id):
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    profile = UserProfile.query.get(uid)
    if not profile:
        return jsonify({"success": False, "msg": "请先完善个人画像"}), 400

    job = Job.query.filter_by(id=job_id, owner_id=uid).first()
    if not job:
        return jsonify({"success": False, "msg": "岗位不存在"}), 404

    payload = _build_job_evaluation_payload(profile, job)
    return jsonify(
        {
            "success": True,
            "data": {
                **payload["match"],
                "job": payload["job"],
                "decision": payload["decision"],
            },
        }
    )


@applicant_bp.route("/api/job/<int:job_id>/decision", methods=["POST"])
def get_job_decision(job_id):
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    profile = UserProfile.query.get(uid)
    if not profile:
        return jsonify({"success": False, "msg": "请先完善个人画像"}), 400

    job = Job.query.filter_by(id=job_id, owner_id=uid).first()
    if not job:
        return jsonify({"success": False, "msg": "岗位不存在"}), 404

    payload = _build_job_evaluation_payload(profile, job)
    return jsonify({"success": True, "data": payload})


@applicant_bp.route("/api/skill-gap", methods=["GET"])
def get_skill_gap():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    profile = UserProfile.query.get(uid)
    if not profile:
        return jsonify({"success": False, "msg": "请先完善个人画像"}), 400

    target_jobs = profile.get_target_jobs()
    q = Job.query.filter(Job.owner_id == uid)
    if target_jobs:
        from sqlalchemy import or_

        conditions = [Job.job_name.like(f"%{name}%") for name in target_jobs]
        q = q.filter(or_(*conditions))

    sample_jobs = q.limit(500).all()
    if not sample_jobs:
        return jsonify({"success": True, "data": {"sample_size": 0, "missing_skills": [], "target_jobs": target_jobs}})

    user_skills = {x.lower() for x in profile.get_skill_list()}
    demand_counter = Counter()
    skill_salary_sum = Counter()
    skill_salary_count = Counter()
    valid_salary_values = []
    for job in sample_jobs:
        tokens = {x.lower() for x in _tokenize_job_skills(job)}
        demand_counter.update(tokens)
        salary_val = _safe_int(sanitize_salary_avg(getattr(job, "salary_avg", 0)))
        if salary_val > 0:
            valid_salary_values.append(salary_val)
            for token in tokens:
                skill_salary_sum[token] += salary_val
                skill_salary_count[token] += 1

    overall_salary_avg = int(sum(valid_salary_values) / len(valid_salary_values)) if valid_salary_values else 0

    total = len(sample_jobs)
    missing_items = []
    for token, count in demand_counter.most_common(40):
        if token in user_skills:
            continue
        ratio = round((count / max(1, total)) * 100, 1)
        if ratio >= 60:
            priority = "高频必备"
        elif ratio >= 35:
            priority = "中频加分"
        else:
            priority = "低频拓展"
        token_avg_salary = 0
        salary_premium = 0
        if skill_salary_count.get(token, 0) > 0:
            token_avg_salary = int(skill_salary_sum[token] / max(1, skill_salary_count[token]))
            if overall_salary_avg > 0:
                salary_premium = int(token_avg_salary - overall_salary_avg)
        missing_items.append(
            {
                "skill": token,
                "count": int(count),
                "demand_rate": ratio,
                "priority": priority,
                "avg_salary": int(token_avg_salary),
                "salary_premium": int(salary_premium),
            }
        )

    return jsonify(
        {
            "success": True,
            "data": {
                "sample_size": total,
                "market_avg_salary": int(overall_salary_avg),
                "target_jobs": target_jobs,
                "user_skills": profile.get_skill_list(),
                "missing_skills": missing_items[:20],
            },
        }
    )


@applicant_bp.route("/api/salary/predict", methods=["POST"])
def predict_salary_for_applicant():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    payload = request.get_json(silent=True) or {}
    profile = UserProfile.query.get(uid)

    city = str(payload.get("city") or "").strip()
    edu = str(payload.get("edu_level") or payload.get("edu") or "").strip()
    exp = str(payload.get("exp_year") or payload.get("exp") or "").strip()
    expected_min = _safe_int(payload.get("expected_salary_min") or 0)
    expected_max = _safe_int(payload.get("expected_salary_max") or 0)

    if profile:
        city = city or str(payload.get("target_city") or "")
        edu = edu or str(profile.edu_level or "")
        exp = exp or str(profile.exp_year or "")
        if expected_min <= 0:
            expected_min = _safe_int(profile.expected_salary_min)
        if expected_max <= 0:
            expected_max = _safe_int(profile.expected_salary_max)

    service = AnalysisService(uid)
    df = service._get_dataframe()
    if df.empty or len(df) < 8:
        return jsonify({"success": False, "msg": "样本不足，至少需要 8 条有效数据"})

    if "city" not in df or "edu_req" not in df or "exp_req" not in df:
        return jsonify({"success": False, "msg": "样本字段不完整，无法预测薪资"})

    df = df[(df["salary_avg"] >= SALARY_MIN_VALID) & (df["salary_avg"] <= SALARY_MAX_VALID)].copy()
    if df.empty:
        return jsonify({"success": False, "msg": "有效薪资样本不足"})

    df["city_code"] = df["city"].astype("category").cat.codes
    df["edu_code"] = df["edu_req"].astype("category").cat.codes
    df["exp_code"] = df["exp_req"].astype("category").cat.codes
    X = df[["city_code", "edu_code", "exp_code"]]
    y = df["salary_avg"]

    model = RandomForestRegressor(n_estimators=140, random_state=42)
    model.fit(X, y)

    city_to_code = {v: i for i, v in enumerate(df["city"].astype("category").cat.categories)}
    edu_to_code = {v: i for i, v in enumerate(df["edu_req"].astype("category").cat.categories)}
    exp_to_code = {v: i for i, v in enumerate(df["exp_req"].astype("category").cat.categories)}

    p_city = city_to_code.get(city, int(df["city_code"].mode().iloc[0]))
    p_edu = edu_to_code.get(edu, int(df["edu_code"].mode().iloc[0]))
    p_exp = exp_to_code.get(exp, int(df["exp_code"].mode().iloc[0]))

    pred_salary = int(model.predict([[p_city, p_edu, p_exp]])[0])
    pred_salary = _safe_int(sanitize_salary_avg(pred_salary))
    if pred_salary <= 0:
        pred_salary = _safe_int(df["salary_avg"].median())

    percentile = int((df["salary_avg"] < pred_salary).mean() * 100)
    low = int(pred_salary * 0.85)
    high = int(pred_salary * 1.15)

    target_floor = max(int(pred_salary * 0.9), low)
    target_ask = int(pred_salary * 1.1)
    target_top = int(pred_salary * 1.2)

    expected_center = 0
    if expected_min > 0 and expected_max > 0:
        expected_center = int((expected_min + expected_max) / 2)
    elif expected_max > 0:
        expected_center = expected_max
    elif expected_min > 0:
        expected_center = expected_min

    diagnosis = "暂无期望薪资输入"
    expected_percentile = None
    if expected_center > 0:
        expected_percentile = int((df["salary_avg"] < expected_center).mean() * 100)
        if expected_center > pred_salary * 1.2:
            diagnosis = "期望偏高，建议先投递匹配度高的岗位积累面试反馈"
        elif expected_center < pred_salary * 0.85:
            diagnosis = "期望偏保守，可适度上调谈判目标"
        else:
            diagnosis = "期望区间基本合理，可按市场中位上浮谈判"

    return jsonify(
        {
            "success": True,
            "data": {
                "predicted_salary": pred_salary,
                "range": {"min": low, "max": high},
                "percentile": percentile,
                "expected_salary_percentile": expected_percentile,
                "diagnosis": diagnosis,
                "negotiation": {
                    "initial_offer": target_ask,
                    "bottom_line": target_floor,
                    "target": target_top,
                },
                "sample_size": int(len(df)),
            },
        }
    )


@applicant_bp.route("/api/applications", methods=["GET"])
def list_applications():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    status = str(request.args.get("status") or "").strip()
    q = (
        JobApplication.query.join(Job, Job.id == JobApplication.job_id)
        .filter(JobApplication.user_id == uid, Job.owner_id == uid)
        .order_by(JobApplication.updated_at.desc(), JobApplication.id.desc())
    )
    if status:
        q = q.filter(JobApplication.status == status)

    items = q.limit(500).all()
    data = [_serialize_application(x) for x in items]
    summary = {k: 0 for k in APPLICATION_STATUS}
    for item in data:
        st = item.get("status") or "已收藏"
        summary[st] = summary.get(st, 0) + 1
        
    total_applied = sum(summary.get(k, 0) for k in ["已投递", "简历筛选", "面试邀约", "Offer", "已拒绝"])
    interview_count = summary.get("面试邀约", 0) + summary.get("Offer", 0)
    
    metrics = {
        "total_applied": total_applied,
        "response_rate": round((total_applied - summary.get("已投递", 0)) / total_applied * 100, 1) if total_applied > 0 else 0,
        "interview_rate": round(interview_count / total_applied * 100, 1) if total_applied > 0 else 0,
        "offer_rate": round(summary.get("Offer", 0) / interview_count * 100, 1) if interview_count > 0 else 0
    }
    
    return jsonify({"success": True, "data": data, "summary": summary, "metrics": metrics})


@applicant_bp.route("/api/applications/dashboard", methods=["GET"])
def applications_dashboard():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    q = (
        JobApplication.query.join(Job, Job.id == JobApplication.job_id)
        .filter(JobApplication.user_id == uid, Job.owner_id == uid)
        .order_by(JobApplication.updated_at.desc(), JobApplication.id.desc())
    )
    items = q.limit(500).all()
    rows = [_serialize_application(x) for x in items]
    dashboard = _build_application_dashboard(rows)
    dashboard = _attach_weekly_plan_state(uid, dashboard)
    dashboard = _attach_execution_feedback(dashboard)
    return jsonify({"success": True, "data": {**dashboard, "items": rows}})


@applicant_bp.route("/api/applications/auto-plan", methods=["POST"])
def auto_plan_applications():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    payload = request.get_json(silent=True) or {}
    raw_jobs = payload.get("jobs") or []
    plan = _build_execution_seed_plan(raw_jobs, payload.get("limit") or 9)
    if not plan:
        return jsonify({"success": False, "msg": "缺少可用于生成执行池的岗位数据"}), 400

    result = _persist_execution_seed_plan(uid, plan)
    total = sum(result["summary"].values())
    suggestion = (
        f"已生成 {total} 个执行候选，建议先从主申 {result['summary'].get('主申', 0)} 个岗位开始，"
        "再补充少量冲刺与保底岗位。"
    )
    return jsonify(
        {
            "success": True,
            "data": {
                **result,
                "suggestion": suggestion,
            },
        }
    )


@applicant_bp.route("/api/applications/auto-organize", methods=["POST"])
def auto_organize_applications():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    result = _auto_organize_active_applications(uid)
    suggestion = (
        f"已按当前匹配分重排执行池：主申 {result['summary'].get('主申', 0)} 个，"
        f"冲刺 {result['summary'].get('冲刺', 0)} 个，保底 {result['summary'].get('保底', 0)} 个。"
    )
    return jsonify({"success": True, "data": {**result, "suggestion": suggestion}})


@applicant_bp.route("/api/applications/weekly-plan", methods=["POST"])
def update_weekly_plan_state():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    payload = request.get_json(silent=True) or {}
    task_id = str(payload.get("task_id") or "").strip()
    if not task_id:
        return jsonify({"success": False, "msg": "缺少 task_id"}), 400

    week_key = str(payload.get("week_key") or _current_week_key()).strip() or _current_week_key()
    completed = bool(payload.get("completed"))
    rec = WeeklyPlanState.query.filter_by(user_id=uid, week_key=week_key, task_id=task_id).first()
    if not rec:
        rec = WeeklyPlanState(user_id=uid, week_key=week_key, task_id=task_id)
        db.session.add(rec)

    rec.completed = completed
    rec.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"success": True, "data": rec.to_dict()})


@applicant_bp.route("/api/applications/timing", methods=["GET"])
def application_timing():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    jobs = Job.query.filter(
        Job.owner_id == uid,
        db.or_(Job.is_ignored.is_(False), Job.is_ignored.is_(None)),
    ).all()
    if not jobs:
        return jsonify(
            {
                "success": True,
                "data": {
                    "sample_size_jobs": 0,
                    "sample_size_apps": 0,
                    "weekday_rank": [],
                    "daily_trend": [],
                    "best_windows": [],
                    "conversion": {
                        "applied": 0,
                        "interview": 0,
                        "offer": 0,
                        "interview_rate": 0.0,
                        "offer_rate": 0.0,
                    },
                },
            }
        )

    today = datetime.now().date()
    start_date = today - timedelta(days=59)

    weekday_counter = Counter()
    daily_counter = Counter()
    for job in jobs:
        dt = _parse_job_pub_date(job.pub_date)
        if not dt:
            continue
        d = dt.date()
        if d < start_date:
            continue
        weekday_counter.update([dt.weekday()])
        daily_counter.update([d.strftime("%Y-%m-%d")])

    weekday_rank = []
    total_recent = max(1, sum(weekday_counter.values()))
    for idx, count in sorted(weekday_counter.items(), key=lambda x: x[1], reverse=True):
        weekday_rank.append(
            {
                "weekday_index": int(idx),
                "weekday": WEEKDAY_LABELS[idx] if 0 <= idx < len(WEEKDAY_LABELS) else str(idx),
                "count": int(count),
                "ratio": round((count / total_recent) * 100, 1),
            }
        )

    daily_trend = []
    for k in sorted(daily_counter.keys()):
        daily_trend.append({"date": k, "count": int(daily_counter[k])})
    daily_trend = daily_trend[-14:]

    apps = JobApplication.query.filter_by(user_id=uid).all()
    applied = len([x for x in apps if x.status in {"已投递", "简历筛选", "面试邀约", "Offer", "已拒绝"}])
    interview = len([x for x in apps if x.status in {"面试邀约", "Offer"}])
    offer = len([x for x in apps if x.status == "Offer"])
    interview_rate = round((interview / applied) * 100, 1) if applied else 0.0
    offer_rate = round((offer / applied) * 100, 1) if applied else 0.0

    best_windows = []
    for item in weekday_rank[:2]:
        best_windows.append(
            {
                "window": f"{item['weekday']} 09:00-11:00",
                "reason": f"近30天该日新发岗位占比 {item['ratio']}%",
            }
        )
        best_windows.append(
            {
                "window": f"{item['weekday']} 19:00-22:00",
                "reason": "晚间活跃度高，适合集中投递与补充沟通",
            }
        )

    return jsonify(
        {
            "success": True,
            "data": {
                "sample_size_jobs": len(jobs),
                "sample_size_apps": len(apps),
                "weekday_rank": weekday_rank,
                "daily_trend": daily_trend,
                "best_windows": best_windows[:4],
                "conversion": {
                    "applied": applied,
                    "interview": interview,
                    "offer": offer,
                    "interview_rate": interview_rate,
                    "offer_rate": offer_rate,
                },
            },
        }
    )


@applicant_bp.route("/api/applications", methods=["POST"])
def create_application():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    payload = request.get_json(silent=True) or {}
    job_id = _safe_int(payload.get("job_id"))
    if job_id <= 0:
        return jsonify({"success": False, "msg": "缺少 job_id"}), 400

    job = Job.query.filter_by(id=job_id, owner_id=uid).first()
    if not job:
        return jsonify({"success": False, "msg": "岗位不存在"}), 404

    status = _normalize_status(payload.get("status"), default="已收藏")
    if status not in APPLICATION_STATUS:
        return jsonify({"success": False, "msg": "状态非法"}), 400

    rec = JobApplication.query.filter_by(user_id=uid, job_id=job_id).first()
    if not rec:
        rec = JobApplication(user_id=uid, job_id=job_id)
        db.session.add(rec)

    rec.status = status
    rec.bucket = _normalize_bucket(payload.get("bucket"), payload.get("match_score") or rec.match_score, payload.get("notes") or rec.notes)
    rec.notes = str(payload.get("notes") or rec.notes or "")
    rec.match_score = _safe_int(payload.get("match_score") or rec.match_score)
    if "applied_at" in payload:
        applied_at = _parse_datetime(payload.get("applied_at"))
        if applied_at:
            rec.applied_at = applied_at
    interview_date = _parse_datetime(payload.get("interview_date"))
    if interview_date:
        rec.interview_date = interview_date
    if status != "已收藏" and not rec.applied_at:
        rec.applied_at = datetime.utcnow()
    rec.updated_at = datetime.utcnow()

    db.session.commit()
    return jsonify({"success": True, "data": _serialize_application(rec)})


@applicant_bp.route("/api/applications/<int:app_id>", methods=["PATCH"])
def update_application(app_id):
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    rec = (
        JobApplication.query.join(Job, Job.id == JobApplication.job_id)
        .filter(JobApplication.id == app_id, JobApplication.user_id == uid, Job.owner_id == uid)
        .first()
    )
    if not rec:
        return jsonify({"success": False, "msg": "记录不存在"}), 404

    payload = request.get_json(silent=True) or {}
    status = payload.get("status")
    if status is not None:
        status = _normalize_status(status, default=None)
        if status not in APPLICATION_STATUS:
            return jsonify({"success": False, "msg": "状态非法"}), 400
        rec.status = status
        if status != "已收藏" and not rec.applied_at:
            rec.applied_at = datetime.utcnow()

    if "notes" in payload:
        rec.notes = str(payload.get("notes") or "")
    if "match_score" in payload:
        rec.match_score = _safe_int(payload.get("match_score"))
    if "bucket" in payload:
        rec.bucket = _normalize_bucket(payload.get("bucket"), payload.get("match_score") or rec.match_score, payload.get("notes") or rec.notes)
    if "applied_at" in payload:
        applied_at = _parse_datetime(payload.get("applied_at"))
        if applied_at:
            rec.applied_at = applied_at
    if "interview_date" in payload:
        rec.interview_date = _parse_datetime(payload.get("interview_date"))

    rec.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"success": True, "data": _serialize_application(rec)})


@applicant_bp.route("/api/job/<int:job_id>/ai-advice", methods=["POST"])
def get_job_ai_advice(job_id):
    """
    针对某个特定岗位，生成一句话点评和简历优化建议。"""
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    profile = UserProfile.query.get(uid)
    if not profile:
        return jsonify({"success": False, "msg": "请先完善个人画像"}), 400

    job = Job.query.filter_by(id=job_id, owner_id=uid).first()
    if not job:
        return jsonify({"success": False, "msg": "找不到该岗位信息"}), 404

    # 1. 组装用户信息用于提示词
    user_info = (
        f"学历: {_normalize_edu_level(profile.edu_level)}, "
        f"经验: {_safe_float(profile.exp_years_num) or profile.exp_year}年, "
        f"已有技能: {profile.get_skill_list()}, "
        f"期望薪资: {_safe_int(profile.expected_salary_min)}-{_safe_int(profile.expected_salary_max)}"
    )

    # 2. 组装岗位信息
    job_info = (
        f"岗位名: {job.job_name}, "
        f"公司: {job.company}, "
        f"要求学历: {job.edu_req}, "
        f"要求经验: {job.exp_req}, "
        f"薪资: {job.salary_avg}, "
        f"岗位技能需求: {_tokenize_job_skills(job)}"
    )

    # 3. 构造 System Prompt（基于现有业务能力输出）
    system_prompt = (
        "你是求职决策助手。请基于用户画像和岗位信息，"
        "输出可执行、简洁、客观的中文建议。"
    )

    user_message = (
        f"用户信息：\n{user_info}\n\n"
        f"岗位信息：\n{job_info}\n\n"
        "请输出 1-2 段结论：\n"
        "1. 该岗位是否建议投递及理由；\n"
        "2. 简历应优先补强的关键词与表达方式。\n"
        "仅输出中文，不要包含多余前后缀。"
    )

    # 4. 调用 AI（可能耗时数秒），失败则自动降级为规则建议
    advice_text = ai_service.generate_analysis(
        system_prompt=system_prompt,
        user_message=user_message,
        max_tokens=600
    )
    if _is_ai_error_text(advice_text):
        return jsonify({
            "success": True,
            "advice": _build_job_ai_rule_advice(profile, job),
            "ai_generated": False,
            "mode": "rule"
        })

    return jsonify({
        "success": True,
        "advice": str(advice_text).strip(),
        "ai_generated": True,
        "mode": "ai"
    })


@applicant_bp.route("/api/ai/status", methods=["GET"])
def get_ai_status():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    ollama_reachable = False
    model_ready = False
    fallback_ready = bool(getattr(ai_service, "fallback_client", None))
    model_name = str(getattr(ai_service, "default_model", "") or "")

    try:
        checker = getattr(ai_service, "_is_ollama_reachable", None)
        if callable(checker):
            ollama_reachable = bool(checker())
    except Exception:
        ollama_reachable = False

    if ollama_reachable and model_name:
        try:
            model_checker = getattr(ai_service, "_is_model_available", None)
            if callable(model_checker):
                model_ready = bool(model_checker(model_name))
        except Exception:
            model_ready = False

    if ollama_reachable and model_ready:
        mode = "ollama"
        message = "AI增强模式可用（本地模型）"
        tips = "可直接使用 AI 解读与 AI 建议。"
    elif fallback_ready:
        mode = "cloud"
        message = "AI增强模式可用（云端回退）"
        tips = "当前已切换云端模型，响应速度可能受网络影响。"
    else:
        mode = "rule"
        message = "AI服务暂不可用，已自动切换规则模式"
        tips = "核心结论与行动建议仍可正常使用，不影响主流程。"

    return jsonify({
        "success": True,
        "data": {
            "mode": mode,
            "ai_available": mode in {"ollama", "cloud"},
            "ollama_reachable": ollama_reachable,
            "model_name": model_name,
            "model_ready": model_ready,
            "fallback_ready": fallback_ready,
            "message": message,
            "tips": tips
        }
    })


@applicant_bp.route("/api/job/<int:job_id>/ai-summary", methods=["POST"])
def get_job_ai_summary(job_id):
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    profile = UserProfile.query.get(uid)
    if not profile:
        return jsonify({"success": False, "msg": "请先完善个人画像"}), 400

    job = Job.query.filter_by(id=job_id, owner_id=uid).first()
    if not job:
        return jsonify({"success": False, "msg": "岗位不存在"}), 404

    payload = _build_job_evaluation_payload(profile, job)
    match_result = payload.get("match") or {}
    decision = payload.get("decision") or {}
    score = _safe_int(match_result.get("score"))
    missing = ((match_result.get("skills") or {}).get("missing") or [])[:3]
    radar = match_result.get("radar") or {}
    fallback = {
        "conclusion": decision.get("conclusion") or ("适合投递" if score >= 80 else ("可投递，建议补强后优先" if score >= 65 else "暂缓投递，建议先补短板")),
        "reason": [
            decision.get("reason") or f"综合匹配分 {score}，技能匹配 {radar.get('skill_match', 0)}，经验匹配 {radar.get('exp_match', 0)}。",
            f"缺失技能：{('、'.join(missing) if missing else '无明显缺口')}。",
        ],
        "suggestion": [
            decision.get("suggestion") or "投递时突出与你岗位要求重合的项目成果。",
            f"优先补齐：{('、'.join(missing) if missing else '持续复盘面试反馈')}。",
        ],
        "risk": [f"当前风险：{decision.get('risk_level') or '中风险'}（{decision.get('risk_summary') or '请结合岗位原文人工复核'}）。"],
        "ai_generated": False,
    }

    system_prompt = (
        "你是求职决策助手。必须严格返回 JSON 对象，字段只能是 "
        "conclusion, reason, suggestion, risk。"
        "其中 reason/suggestion/risk 为字符串数组，每个数组最多 2 条。"
        "不得编造数据，不得输出 JSON 以外内容。"
    )
    user_message = (
        f"岗位={job.job_name}，公司={job.company}，匹配分={score}，"
        f"技能匹配={radar.get('skill_match', 0)}，经验匹配={radar.get('exp_match', 0)}，"
        f"学历匹配={radar.get('edu_match', 0)}，薪资匹配={radar.get('salary_fit', 0)}，"
        f"缺失技能={missing}。请输出简洁决策 JSON。"
    )

    try:
        raw = ai_service.generate_analysis(system_prompt=system_prompt, user_message=user_message, max_tokens=260)
        parsed = _extract_json_block(raw)
        result = _normalize_ai_struct(parsed, fallback)
    except Exception:
        result = fallback
    return jsonify({"success": True, "data": result})


@applicant_bp.route("/api/applications/ai-action", methods=["GET"])
def get_applications_ai_action():
    uid = _get_uid()
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    rows = (
        JobApplication.query.join(Job, Job.id == JobApplication.job_id)
        .filter(JobApplication.user_id == uid, Job.owner_id == uid)
        .all()
    )
    if not rows:
        return jsonify({"success": True, "data": {
            "conclusion": "暂无投递记录，先从岗位评估页建立候选池。",
            "reason": ["当前还没有收藏/投递数据。"],
            "suggestion": ["先完成画像并评估岗位，再将 Top 岗位加入看板。"],
            "risk": ["无投递记录时，系统无法生成有效跟进节奏。"],
            "ai_generated": False,
        }})

    norm = [_serialize_application(x) for x in rows]
    dashboard = _build_application_dashboard(norm)
    dashboard = _attach_weekly_plan_state(uid, dashboard)
    favorite = [x for x in norm if _normalize_status(x.get("status"), "") == "已收藏"]
    applied = [x for x in norm if _normalize_status(x.get("status"), "") == "已投递"]
    interview = [x for x in norm if _normalize_status(x.get("status"), "") == "面试邀约"]
    offer = [x for x in norm if _normalize_status(x.get("status"), "") == "Offer"]
    top_applied = sorted(applied, key=lambda x: _safe_int(x.get("match_score")), reverse=True)[:3]
    top_names = [((x.get("job") or {}).get("job_name") or "未知岗位") for x in top_applied]
    delivery_decision = dashboard.get("delivery_decision") or {}
    weekly_plan = dashboard.get("weekly_plan") or {}
    fallback = {
        "conclusion": delivery_decision.get("conclusion") or "建议优先推进主申岗位并同步跟进节奏",
        "reason": [
            delivery_decision.get("reason") or f"当前看板：收藏 {len(favorite)}，已投递 {len(applied)}，面试 {len(interview)}，Offer {len(offer)}。",
            f"高匹配已投递岗位：{('、'.join(top_names) if top_names else '暂无')}。",
        ],
        "suggestion": [
            delivery_decision.get("suggestion") or "本周优先跟进已投递高匹配岗位，48 小时内更新状态。",
            weekly_plan.get("summary") or "冲刺岗位控制在少量，避免分散精力。",
        ],
        "risk": [
            "若超过 3 天未跟进，面试转化率会明显下降。"
        ],
        "ai_generated": False,
    }

    system_prompt = (
        "你是投递决策助手。必须严格返回 JSON，对象字段只能是 "
        "conclusion, reason, suggestion, risk。不得编造。"
    )
    user_message = (
        f"收藏={len(favorite)} 已投递={len(applied)} 面试={len(interview)} Offer={len(offer)} "
        f"主申候选={top_names}。请给出本周行动 JSON。"
    )
    try:
        raw = ai_service.generate_analysis(system_prompt=system_prompt, user_message=user_message, max_tokens=260)
        parsed = _extract_json_block(raw)
        result = _normalize_ai_struct(parsed, fallback)
    except Exception:
        result = fallback
    return jsonify({"success": True, "data": result})



