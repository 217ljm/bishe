﻿import pandas as pd
import json
import numpy as np
import re
from flask import Blueprint, jsonify, request, session
from sklearn.ensemble import RandomForestRegressor
from sqlalchemy import or_
from app.extensions import db
from app.models.job import Job
from app.models.user import UserProfile
from app.services.ai_service import ai_service
from app.services.salary_utils import SALARY_MAX_VALID, SALARY_MIN_VALID, sanitize_salary_avg

analysis_bp = Blueprint('analysis', __name__)


def _build_salary_decision(pred_salary, low, high, expected_min=0, expected_max=0):
    pred_salary = int(round(float(pred_salary or 0))) if pred_salary else 0
    low = int(round(float(low or 0))) if low else 0
    high = int(round(float(high or 0))) if high else 0
    expected_min = int(round(float(expected_min or 0))) if expected_min else 0
    expected_max = int(round(float(expected_max or 0))) if expected_max else 0
    target = expected_max if expected_max > 0 else expected_min

    tone = 'good'
    conclusion = '当前薪资预期与市场较匹配，可按该区间优先投递'
    if target > 0 and high > 0 and target > high * 1.1:
        tone = 'risk'
        conclusion = '当前薪资预期偏高，直接投递成功率可能受影响'
    elif target > 0 and low > 0 and target < low * 0.9:
        tone = 'mid'
        conclusion = '当前薪资预期偏保守，存在议价空间'

    reason = f"预测月薪约 ¥{pred_salary:,}，参考区间 ¥{low:,} - ¥{high:,}"
    if target > 0:
        reason += f"，当前目标约 ¥{target:,}。"
    else:
        reason += "，当前尚未设置明确薪资目标。"

    if tone == 'risk':
        suggestion = '建议先用主申岗位验证面试通过率，谈薪时先报区间中位，再根据反馈上调。'
    elif tone == 'mid':
        suggestion = '可将目标薪资适度上调到预测中位附近，并在简历中强化项目成果以支撑报价。'
    else:
        suggestion = '建议优先投递匹配度高岗位，并把期望薪资设置在预测区间中高位。'

    return {
        'conclusion': conclusion,
        'reason': reason,
        'suggestion': suggestion,
        'tone': tone,
    }


def _safe_int(value, default=0):
    try:
        if value is None:
            return default
        return int(round(float(value)))
    except Exception:
        return default


def _safe_salary(value):
    return sanitize_salary_avg(_safe_int(value, 0))


def _extract_json_block(raw_text):
    text = str(raw_text or "").strip()
    if not text:
        return None
    m = re.search(r"\{[\s\S]*\}", text)
    if not m:
        return None
    try:
        data = json.loads(m.group(0))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _normalize_dashboard_filters(raw_filters):
    """只保留仪表盘允许的筛选字段，避免脏参数影响查询。"""
    data = raw_filters or {}
    allowed = {}
    for key in ['keyword', 'city', 'source', 'edu', 'exp', 'date_range']:
        val = data.get(key)
        if val is None:
            continue
        if isinstance(val, str):
            val = val.strip()
        if val == '' or val == [] or val == {}:
            continue
        allowed[key] = val
    return allowed


def _ensure_dashboard_standard_output(result, system_metrics):
    """兜底生成 dashboard 标准结构，保证 meta/insights/charts 必备字段齐全。"""
    if not isinstance(result, dict):
        result = {}

    result.setdefault('meta', {})
    result.setdefault('insights', {})
    result.setdefault('charts', {})
    meta = result['meta'] if isinstance(result['meta'], dict) else {}
    insights = result['insights'] if isinstance(result['insights'], dict) else {}
    charts = result['charts'] if isinstance(result['charts'], dict) else {}
    result['meta'], result['insights'], result['charts'] = meta, insights, charts

    stats = meta.get('stats') if isinstance(meta.get('stats'), dict) else {}
    stats['sample_size'] = _safe_int(stats.get('sample_size', stats.get('valid_salary_count', stats.get('count', 0))))
    stats['city_coverage'] = _safe_int(stats.get('city_coverage', stats.get('city_count', 0)))
    stats['avg_salary'] = _safe_salary(stats.get('avg_salary'))
    stats['median_salary'] = _safe_salary(stats.get('median_salary'))
    stats['max_salary'] = _safe_salary(stats.get('max_salary'))
    stats['updated_at'] = stats.get('updated_at') or system_metrics.get('updated_at') or system_metrics.get('data_freshness') or '未知'
    meta['stats'] = stats

    if not meta.get('diagnosis'):
        meta['diagnosis'] = (
            f"数据可靠性说明：当前样本 {stats['sample_size']} 条，覆盖城市 {stats['city_coverage']} 个，"
            f"最近更新 {stats['updated_at']}。"
        )

    highlights = insights.get('highlights') if isinstance(insights.get('highlights'), list) else []
    if len(highlights) < 5:
        fallback = [
            {'title': '样本规模', 'value': _safe_int(stats.get('sample_size')), 'text': f"样本量 { _safe_int(stats.get('sample_size')) } 条。"},
            {'title': '城市覆盖', 'value': _safe_int(stats.get('city_coverage')), 'text': f"覆盖城市 { _safe_int(stats.get('city_coverage')) } 个。"},
            {'title': '平均薪资', 'value': _safe_int(stats.get('avg_salary')), 'text': f"平均薪资 {_safe_int(stats.get('avg_salary'))} 元。"},
            {'title': '中位薪资', 'value': _safe_int(stats.get('median_salary')), 'text': f"中位薪资 {_safe_int(stats.get('median_salary'))} 元。"},
            {'title': '最高薪资', 'value': _safe_int(stats.get('max_salary')), 'text': f"最高薪资 {_safe_int(stats.get('max_salary'))} 元。"},
        ]
        highlights = (highlights + fallback)[:5]
    insights['highlights'] = highlights
    result['insights_list'] = highlights
    return result


@analysis_bp.route('/api/summary/charts')
def get_summary_charts():
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False, 'msg': '未登录'})

    try:
        from app.services.analysis_service import AnalysisService
        service = AnalysisService(uid)
        df = service._get_dataframe()

        if df.empty:
            return jsonify({'success': True, 'empty': True})

        chart_city = service.get_chart_data_city(df)
        chart_cloud = service.get_chart_data_cloud(df)
        chart_salary = service.get_chart_data_salary(df)
        chart_edu = service.get_chart_data_edu(df)

        return jsonify({
            'success': True,
            'empty': False,
            'city': chart_city,
            'cloud': chart_cloud,
            'salary': chart_salary,
            'edu': chart_edu
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'msg': str(e)})


@analysis_bp.route('/api/analysis/dashboard', methods=['POST'])
def get_analysis_dashboard():
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False, 'msg': '未登录'})

    # 获取筛选参数
    filters = _normalize_dashboard_filters(request.get_json(silent=True) or {})

    try:
        from app.services.analysis_service import AnalysisService
        service = AnalysisService(uid)

        # 1. 获取核心结构化结论 (KPIs, 诊断, 因子分析)
        insights = service.get_insights(filters)
        from app.services.standard_output_service import StandardOutputService
        try:
            system_metrics = StandardOutputService.build_system_metrics(uid)
            insights = _ensure_dashboard_standard_output(insights, system_metrics)
            insights['system_metrics'] = system_metrics
            insights['quality_gate'] = StandardOutputService.build_quality_gate(system_metrics, scene='analysis')
            insights['system_interpretation'] = StandardOutputService.build_system_interpretation(system_metrics)
            insights['analysis_standard_output'] = StandardOutputService.build_analysis_standard_output(insights)
        except Exception:
            # 指标增强层异常时不影响高级分析主链路输出，避免前端反复降级。
            insights = _ensure_dashboard_standard_output(insights, {})
            insights['system_metrics'] = {}
            insights['quality_gate'] = {}
            insights['system_interpretation'] = ['系统指标增强暂不可用，已返回基础高级分析结果。']
            insights['analysis_standard_output'] = {}

        return jsonify({
            'success': True,
            'data': insights
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"Dashboard Error: {e}")
        return jsonify({'success': False, 'msg': f"服务器内部错误: {str(e)}"}), 500


@analysis_bp.route('/api/stats')
def get_stats_legacy():
    """兼容旧前端统计接口。"""
    uid = session.get('user_id')
    empty = {
        'total_jobs': 0,
        'city_labels': [],
        'city_values': [],
        'city_counts': [],
        'avg_salary': 0,
        'city_count': 0
    }
    if not uid:
        return jsonify(empty)

    try:
        from app.services.analysis_service import AnalysisService
        service = AnalysisService(uid)
        df = service._get_dataframe()
        if df.empty:
            return jsonify(empty)
        city_data = service.get_chart_data_city(df)
        return jsonify({
            'total_jobs': int(len(df)),
            'city_labels': city_data.get('labels', []),
            'city_values': city_data.get('avg', []),
            'city_counts': city_data.get('count', []),
            'avg_salary': int(df['salary_avg'].mean()) if 'salary_avg' in df else 0,
            'city_count': int(df['city'].nunique()) if 'city' in df else 0
        })
    except Exception as e:
        return jsonify({'success': False, 'msg': str(e)})


@analysis_bp.route('/api/stats/summary')
def get_stats_summary():
    uid = session.get('user_id')
    if not uid:
        return jsonify({'avg_salary': 0, 'total': 0, 'city_count': 0})

    from app.services.analysis_service import AnalysisService
    service = AnalysisService(uid)
    df = service._get_dataframe()
    if df.empty:
        return jsonify({'avg_salary': 0, 'total': 0, 'city_count': 0})

    return jsonify({
        'avg_salary': int(df['salary_avg'].mean()) if 'salary_avg' in df else 0,
        'total': len(df),
        'city_count': int(df['city'].nunique()) if 'city' in df else 0
    })


@analysis_bp.route('/api/stats/advanced', methods=['GET', 'POST'])
def get_advanced_stats():
    uid = session.get('user_id')
    empty = {'salary_dist': {'labels': [], 'values': []}, 'edu_salary': {'labels': [], 'values': [], 'counts': []},
             'exp_salary': {'labels': [], 'values': []}, 'kpi': {'max': 0, 'median': 0, 'best_exp': '-'}}
    if not uid: return jsonify(empty)

    filters = request.json or {} if request.method == 'POST' else {}

    from app.services.analysis_service import AnalysisService
    service = AnalysisService(uid)
    df = service._get_dataframe(filters)

    if df.empty: return jsonify(empty)

    bins = [0, 10000, 20000, 30000, 50000, 100000]
    labels = ['10k以下', '10k-20k', '20k-30k', '30k-50k', '50k以上']
    df['range'] = pd.cut(df['salary_avg'], bins=bins, labels=labels)
    dist = df['range'].value_counts().reindex(labels).fillna(0).to_dict()

    edu_grp = df.groupby('edu_req')['salary_avg'].agg(['mean', 'count']).round(0)
    exp_mean = df.groupby('exp_req')['salary_avg'].mean().round(0).to_dict()
    exp_sort = {"在校": 0, "应届": 1, "不限": 2, "1年": 3, "1-3年": 4, "3-5年": 5, "5-10年": 6, "10年以上": 7}
    sorted_exp = sorted(exp_mean.items(), key=lambda x: next((v for k, v in exp_sort.items() if k in str(x[0])), 99))

    return jsonify({
        'salary_dist': {'labels': list(dist.keys()), 'values': list(dist.values())},
        'edu_salary': {'labels': edu_grp.index.tolist(), 'values': edu_grp['mean'].tolist(),
                       'counts': edu_grp['count'].tolist()},
        'exp_salary': {'labels': [x[0] for x in sorted_exp], 'values': [x[1] for x in sorted_exp]},
        'kpi': {'max': int(df['salary_avg'].max()), 'median': int(df['salary_avg'].median()), 'best_exp': '3-5年'}
    })


@analysis_bp.route('/api/stats/wordcloud')
def get_wordcloud():
    uid = session.get('user_id')
    if not uid: return jsonify([])
    skills = db.session.query(Job.skills).filter(Job.skills != '', Job.owner_id == uid).all()

    # 过滤岗位名关键词 + 福利词黑名单
    blacklist = {
        '工程师', '开发', '专家', '经理', '主管', '总监', '架构师', '设计师',
        '分析师', '运营', '实习', '助理', '顾问', '负责人', '主任', '资深',
        '高级', '初级', '中级', '招聘', '方向',
        '五险一金', '五险', '一金', '双休', '带薪年假', '年终奖', '弹性工作',
        '餐补', '交通补贴', '住房补贴', '股票期权', '绩效奖金', '节日福利',
        '团建', '定期体检', '扁平化管理', '晋升空间', '培训机会',
        '热招', '急招', '无标签', '不限',
    }

    words = []
    for s in skills:
        if s and s[0]:
            for w in s[0].split(','):
                w = w.strip()
                if (len(w) >= 2 and len(w) <= 20
                        and w not in blacklist
                        and not any(bl in w for bl in blacklist)):
                    words.append(w)

    counts = pd.Series(words).value_counts().head(50)
    return jsonify([{'name': k, 'value': int(v)} for k, v in counts.items()])


def _parse_exp(exp_str):
    """简单解析经验字符串为数字 (最低年限)"""
    if not exp_str: return 0
    if '应届' in exp_str or '在校' in exp_str: return 0
    if '1年' in exp_str: return 1
    if '1-3' in exp_str: return 1
    if '3-5' in exp_str: return 3
    if '5-10' in exp_str: return 5
    if '10年' in exp_str: return 10
    import re
    m = re.search(r'(\d+)', exp_str)
    return int(m.group(1)) if m else 0


def _is_noise_missing_skill(token):
    t = str(token or "").strip()
    if not t:
        return True
    if len(t) < 2 or len(t) > 24:
        return True
    lower = t.lower()
    if re.fullmatch(r"\d+[kKwW]?(?:[-~至到]\d+[kKwW]?)?", lower):
        return True
    noise_words = {
        "北京", "上海", "深圳", "广州", "杭州", "成都", "武汉", "苏州", "南京", "西安", "重庆", "天津", "全国",
        "岗位", "职位", "工作", "经验", "学历", "相关", "公司", "团队", "能力", "负责", "要求", "不限",
    }
    if t in noise_words:
        return True
    if t.endswith("市") and len(t) <= 4:
        return True
    if t.endswith("区") and len(t) <= 4:
        return True
    return False


def _clean_missing_skill_tokens(tokens):
    out = []
    seen = set()
    for token in tokens or []:
        s = str(token or "").strip()
        key = s.lower()
        if not s or key in seen:
            continue
        if _is_noise_missing_skill(s):
            continue
        seen.add(key)
        out.append(s)
    return out


@analysis_bp.route('/api/recommend', methods=['POST'])
def recommend():
    uid = session.get('user_id')
    if not uid:
        return jsonify({'success': False, 'msg': '未登录'}), 401

    # 获取筛选条件
    req_data = request.get_json(silent=True) or {}
    kw = str(req_data.get('keyword', '') or '').strip().lower()
    deep_mode = bool(req_data.get('deep_analysis'))
    req_city = str(req_data.get('city') or '').strip()
    req_exp = str(req_data.get('exp') or req_data.get('experience') or '').strip()
    req_skills = str(req_data.get('skills') or '').strip()
    expected_salary = _safe_int(req_data.get('expected_salary') or req_data.get('target_salary'))

    # 获取用户画像（若有）
    profile = UserProfile.query.get(uid)
    user_skills = profile.skills if profile else ""
    target_job = profile.target_job if profile else ""
    profile_exp = profile.exp_year if profile else ""
    merged_skills_text = ",".join([x for x in [user_skills, req_skills] if x]).strip(",")
    quick_user_text = kw
    deep_user_text = f"{target_job} {merged_skills_text} {kw}".strip()
    user_text = deep_user_text if deep_mode else (quick_user_text or deep_user_text)
    query_mode = 'profile_deep' if deep_mode else 'quick_search'

    # 1. 用户画像摘要 (Input)
    persona_skills = [x.strip() for x in merged_skills_text.split(',') if x.strip()]
    persona = {
        'keywords': kw or target_job,
        'skills': persona_skills if (deep_mode and persona_skills) else [],
        'mode': query_mode,
        'exp_level': req_exp or profile_exp or '不限',
        'experience': req_exp or profile_exp or '不限',
        'city': req_city or '不限',
        'expected_salary': expected_salary
    }

    jobs = Job.query.filter(
        Job.owner_id == uid,
        db.or_(Job.is_ignored.is_(False), Job.is_ignored.is_(None))
    ).all()
    if not jobs:
        from app.services.standard_output_service import StandardOutputService
        empty_payload = {
            'query_mode': query_mode,
            'persona': persona,
            'market_context': {
                'avg_salary': 0,
                'median_salary': 0,
                'job_count': 0
            },
            'recommendations': [],
            'summary': {
                'total_matched': 0,
                'avg_score': 0,
                'max_salary': 0,
                'avg_salary': 0,
                'top_missing_skills': [],
                'salary_distribution': {'0-5k': 0, '5-10k': 0, '10-15k': 0, '15-20k': 0, '20-30k': 0, '30k+': 0},
                'score_label': '匹配指数' if deep_mode else '相关度指数',
                'mode_note': (
                    '全网检索按关键词和岗位内容相关度排序，适合快速筛岗位。'
                    if not deep_mode else
                    '画像深度分析会在关键词基础上叠加目标岗位与技能画像进行匹配排序。'
                )
            }
        }
        return jsonify(StandardOutputService.enhance_recommendation_payload(empty_payload))

    # 准备职位数据供 NLP 服务使用
    job_list_for_nlp = []
    for j in jobs:
        # 构建职位描述文本
        text = f"{j.job_name} {j.skills} {j.company} {j.raw_desc}"
        job_list_for_nlp.append({
            'id': j.id,
            'text': text,
            'original': j  # 保留原始对象引用以便后续使用
        })

    # 调用 NLP 服务计算匹配度
    from app.services.nlp_service import nlp_service
    scored_jobs = nlp_service.calculate_match_score(user_text, job_list_for_nlp)

    # 构建结构化返回数据
    # 2. 市场基准 (Process Context)
    # 计算当前推荐列表的平均薪资作为对照
    rec_salaries = [
        sanitize_salary_avg(j['original'].salary_avg)
        for j in scored_jobs
        if sanitize_salary_avg(j['original'].salary_avg) > 0
    ]
    market_avg = int(sum(rec_salaries) / len(rec_salaries)) if rec_salaries else 0

    # 计算“该岗位/城市”市场口径（中位数+岗位量）
    market_query = Job.query.filter(
        Job.owner_id == uid,
        db.or_(Job.is_ignored.is_(False), Job.is_ignored.is_(None))
    )
    if kw:
        market_query = market_query.filter(or_(
            Job.job_name.like(f'%{kw}%'),
            Job.skills.like(f'%{kw}%'),
            Job.company.like(f'%{kw}%'),
            Job.raw_desc.like(f'%{kw}%')
        ))
    if req_city:
        market_query = market_query.filter(Job.city.like(f'%{req_city}%'))
    market_query = market_query.filter(
        Job.salary_avg.isnot(None),
        Job.salary_avg >= SALARY_MIN_VALID,
        Job.salary_avg <= SALARY_MAX_VALID,
    )
    market_jobs = market_query.all()
    market_job_count = len(market_jobs)
    market_salaries = [sanitize_salary_avg(x.salary_avg) for x in market_jobs if sanitize_salary_avg(x.salary_avg) > 0]
    market_median = int(np.median(market_salaries)) if market_salaries else 0

    rec_list = []
    for item in scored_jobs:
        j = item['original']
        job_salary = sanitize_salary_avg(j.salary_avg)
        nlp_score = item.get('nlp_score', 60)
        analysis = item.get('analysis', {'matched': [], 'missing': []})

        # 综合评分 = NLP (70%) + 薪资 (20%) + 关键词 (10%)
        salary_bonus = min(20, int(job_salary / 1000)) if job_salary > 0 else 0
        keyword_bonus = 10 if kw and kw in j.job_name.lower() else 0
        final_score = int(nlp_score * 0.7 + salary_bonus + keyword_bonus)
        final_score = min(99, final_score)
        
        from app.routes.applicant import _build_job_match, _build_job_ai_rule_advice
        match_res = _build_job_match(profile, j) if profile else {}
        radar_data = match_res.get("radar", {
            "skill_match": nlp_score,
            "exp_match": 80,
            "edu_match": 80,
            "salary_fit": 80
        })
        ai_advice_text = _build_job_ai_rule_advice(profile, j) if profile else ""

        # 3. 结构化结论 (Output)
        # 显性化匹配理由
        reason_parts = []
        if nlp_score > 80: reason_parts.append("技能高度匹配")
        if job_salary > 0 and market_avg > 0 and job_salary > market_avg * 1.1: reason_parts.append("薪资高于基准")
        if keyword_bonus > 0: reason_parts.append("核心词命中")
        match_reason = ai_advice_text or (" + ".join(reason_parts) if reason_parts else "综合匹配良好")

        tags = j.tags.split(',')[:3] if j.tags else ['热招']

        # --- 4. 深度差距分析 (Gap Analysis) ---
        # 经验差距
        user_exp_val = _parse_exp(profile.exp_year) if profile and profile.exp_year else 0
        job_exp_val = _parse_exp(j.exp_req)
        exp_gap = job_exp_val - user_exp_val

        # 市场竞争差距 (薪资对比)
        salary_percentile = 50  # 默认中位数

        # --- 5. 可执行建议 (Actionable Advice) ---
        advices = []

        # 技能建议
        if analysis.get('missing'):
            top_missing = analysis['missing'][:2]
            advices.append(f"建议补充核心技能: {', '.join(top_missing)}")

        # 经验建议
        if exp_gap > 2:
            advices.append(f"经验要求较高({j.exp_req})，建议在简历中突出项目负责程度以弥补年限不足。")
        elif exp_gap < -2:
            advices.append(f"该岗位经验要求({j.exp_req})低于您的资历，可能存在薪资天花板。")

        # 薪资建议
        if job_salary > 0 and market_avg > 0 and job_salary > market_avg * 1.2:
            advices.append(f"薪资显著高于市场均值，竞争可能激烈，建议优化作品集。")
        elif job_salary > 0 and market_avg > 0 and job_salary < market_avg * 0.8:
            advices.append(f"薪资低于市场水平，建议作为保底选项或争取更高定薪。")

        rec_list.append({
            'id': j.id, 'job_name': j.job_name, 'company': j.company,
            'city': j.city, 'salary_avg': job_salary, 'score': final_score,
            'detail_url': j.detail_url or '',
            'is_favorite': bool(j.is_favorite),
            'is_ignored': bool(j.is_ignored),
            'note': j.note or '',
            'tags': tags,
            'desc': j.raw_desc[:100] + '...' if j.raw_desc else '暂无描述',
            'reason': match_reason,
            'radar': radar_data,
            'process_analysis': {
                'skill_match': nlp_score,
                'salary_diff': int((job_salary - market_avg) / market_avg * 100) if (market_avg and job_salary > 0) else 0,
                'missing_skills': _clean_missing_skill_tokens(analysis.get('missing', []))
            },
            'gap_analysis': {
                'exp_gap_val': exp_gap,
                'exp_desc': f"相差 {exp_gap} 年" if exp_gap > 0 else "符合/超过要求",
                'advices': advices
            }
        })

    sorted_recs = sorted(rec_list, key=lambda x: x['score'], reverse=True)[:10]

    # 汇总统计
    all_missing = []
    for r in sorted_recs:
        all_missing.extend(r.get('process_analysis', {}).get('missing_skills', []))
    from collections import Counter as Ctr
    missing_counter = Ctr(all_missing)
    top_missing_skills = [{'name': s, 'count': c} for s, c in missing_counter.most_common(5)]

    rec_scores = [r['score'] for r in sorted_recs]
    rec_salaries_sorted = [r['salary_avg'] for r in sorted_recs if r.get('salary_avg', 0) > 0]

    # 薪资区间分布
    salary_ranges = {'0-5k': 0, '5-10k': 0, '10-15k': 0, '15-20k': 0, '20-30k': 0, '30k+': 0}
    for s in rec_salaries_sorted:
        if s < 5000:
            salary_ranges['0-5k'] += 1
        elif s < 10000:
            salary_ranges['5-10k'] += 1
        elif s < 15000:
            salary_ranges['10-15k'] += 1
        elif s < 20000:
            salary_ranges['15-20k'] += 1
        elif s < 30000:
            salary_ranges['20-30k'] += 1
        else:
            salary_ranges['30k+'] += 1

    summary = {
        'total_matched': len(sorted_recs),
        'avg_score': round(sum(rec_scores) / len(rec_scores), 1) if rec_scores else 0,
        'max_salary': max(rec_salaries_sorted) if rec_salaries_sorted else 0,
        'avg_salary': int(sum(rec_salaries_sorted) / len(rec_salaries_sorted)) if rec_salaries_sorted else 0,
        'top_missing_skills': top_missing_skills,
        'salary_distribution': salary_ranges,
        'score_label': '匹配指数' if deep_mode else '相关度指数',
        'mode_note': (
            '全网检索按关键词和岗位内容相关度排序，适合快速筛岗位。'
            if not deep_mode else
            '画像深度分析会在关键词基础上叠加目标岗位与技能画像进行匹配排序。'
        )
    }

    payload = {
        'query_mode': query_mode,
        'persona': persona,
        'market_context': {
            'avg_salary': market_avg,
            'median_salary': market_median,
            'job_count': market_job_count or len(jobs)
        },
        'recommendations': sorted_recs,
        'summary': summary
    }
    from app.services.standard_output_service import StandardOutputService
    payload['quality_metrics'] = StandardOutputService.build_system_metrics(uid)
    payload = StandardOutputService.enhance_recommendation_payload(payload)
    return jsonify(payload)


@analysis_bp.route('/api/competitiveness', methods=['GET', 'POST'])
def get_competitiveness():
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False, 'msg': '未登录'})

    data = request.get_json(silent=True) or {} if request.method == 'POST' else request.args.to_dict()
    city = data.get('city', '')
    edu = data.get('edu', '本科')
    exp = data.get('exp', '应届生')
    skills = data.get('skills', '')

    from app.services.analysis_service import AnalysisService
    service = AnalysisService(uid)
    result = service.evaluate_competitiveness(city, edu, exp, skills)
    from app.services.standard_output_service import StandardOutputService
    result = StandardOutputService.enhance_competitiveness_result(result, data)
    return jsonify(result)


@analysis_bp.route('/api/competitiveness/ai-interpret', methods=['POST'])
def get_competitiveness_ai_interpret():
    uid = session.get('user_id')
    if not uid:
        return jsonify({'success': False, 'msg': '未登录'}), 401

    payload = request.get_json(silent=True) or {}
    score = _safe_int(payload.get('total_score') or payload.get('score'))
    percentile = _safe_int(payload.get('percentile'))
    explain_obj = payload.get('decision_explain') if isinstance(payload.get('decision_explain'), dict) else {}
    improve_obj = payload.get('improvement_suggestions') if isinstance(payload.get('improvement_suggestions'), dict) else {}
    gap_list = explain_obj.get('gap_analysis') if isinstance(explain_obj.get('gap_analysis'), list) else []
    skill_fill = improve_obj.get('skill_fill') if isinstance(improve_obj.get('skill_fill'), list) else []

    fallback = {
        'conclusion': '竞争力较强，可进入重点投递阶段' if score >= 80 else ('竞争力中等，建议补关键短板后投递' if score >= 65 else '竞争力偏弱，建议先补技能与项目经历'),
        'reason': [
            f'当前竞争力指数 {score}，市场分位约 {percentile}%。',
            f"主要短板：{('、'.join(gap_list[:2]) if gap_list else '暂无明显短板。')}",
        ],
        'suggestion': [
            (skill_fill[0] if skill_fill else '优先补 SQL、数据可视化等高频技能。'),
            '补齐短板后回到岗位评估页，优先投递高匹配岗位。',
        ],
        'risk': ['若只看分数不落地行动，竞争力优势难以转化为面试机会。'],
        'ai_generated': False,
    }

    system_prompt = (
        '你是竞争力解读助手。必须严格返回 JSON 对象，字段只能是 '
        'conclusion, reason, suggestion, risk；不得编造数据。'
    )
    user_message = (
        f'竞争力分={score}，百分位={percentile}，短板={gap_list[:3]}，建议={skill_fill[:3]}。'
        '请输出可执行、简洁的竞争力解读 JSON。'
    )
    try:
        raw = ai_service.generate_analysis(system_prompt=system_prompt, user_message=user_message, max_tokens=260)
        parsed = _extract_json_block(raw)
        if isinstance(parsed, dict):
            parsed.setdefault('ai_generated', True)
            return jsonify({'success': True, 'data': parsed})
    except Exception:
        pass
    return jsonify({'success': True, 'data': fallback})


@analysis_bp.route('/api/predict_salary', methods=['POST'])
def predict_salary():
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False, 'msg': '未登录'})

    data = request.json or {}
    target_city = data.get('city')
    target_exp = data.get('exp')
    target_edu = data.get('edu')
    expected_salary_min = data.get('expected_salary_min') or 0
    expected_salary_max = data.get('expected_salary_max') or 0

    try:
        from app.services.analysis_service import AnalysisService
        service = AnalysisService(uid)
        df = service._get_dataframe()

        if df.empty or len(df) < 5:
            return jsonify({'success': False, 'msg': '数据不足，请至少采集 5 条数据'})

        # 数据预处理
        df['city_code'] = df['city'].astype('category').cat.codes
        df['edu_code'] = df['edu_req'].astype('category').cat.codes
        df['exp_code'] = df['exp_req'].astype('category').cat.codes

        # 建立映射字典以便反查/转换输入
        city_map = dict(enumerate(df['city'].astype('category').cat.categories))
        edu_map = dict(enumerate(df['edu_req'].astype('category').cat.categories))
        exp_map = dict(enumerate(df['exp_req'].astype('category').cat.categories))

        # 反转映射: Name -> Code
        city_to_code = {v: k for k, v in city_map.items()}
        edu_to_code = {v: k for k, v in edu_map.items()}
        exp_to_code = {v: k for k, v in exp_map.items()}

        # 准备训练数据
        X = df[['city_code', 'edu_code', 'exp_code']]
        y = df['salary_avg']

        # 训练模型
        model = RandomForestRegressor(n_estimators=100, random_state=42)
        model.fit(X, y)

        # 准备预测输入
        # 如果用户未指定，默认使用众数
        p_city = city_to_code.get(target_city, df['city_code'].mode()[0])
        p_edu = edu_to_code.get(target_edu, df['edu_code'].mode()[0])
        p_exp = exp_to_code.get(target_exp, df['exp_code'].mode()[0])

        input_vector = [[p_city, p_edu, p_exp]]
        pred_salary = int(model.predict(input_vector)[0])

        # 计算特征重要性
        importances = model.feature_importances_
        keys = ['城市', '学历', '经验']
        drivers = sorted(zip(keys, importances), key=lambda x: x[1], reverse=True)
        top_driver = drivers[0][0]

        # 预测范围 (简单估算 +/- 15%)
        low = int(pred_salary * 0.85)
        high = int(pred_salary * 1.15)

        # 计算百分位排名
        percentile = int((df['salary_avg'] < pred_salary).mean() * 100)

        # 计算学历提升空间
        edu_order_list = ['大专', '本科', '硕士', '博士']
        current_edu_idx = edu_order_list.index(target_edu) if target_edu in edu_order_list else 1
        next_edu = edu_order_list[current_edu_idx + 1] if current_edu_idx < len(edu_order_list) - 1 else target_edu

        # 学历提升预测
        uplift_edu = 0
        if next_edu != target_edu and next_edu in edu_to_code:
            next_edu_code = edu_to_code[next_edu]
            next_input = [[p_city, next_edu_code, p_exp]]
            next_pred = int(model.predict(next_input)[0])
            uplift_edu = next_pred - pred_salary

        # 经验提升预测（增加一级经验）
        uplift_exp = 0
        exp_codes_sorted = sorted(exp_to_code.values())
        current_exp_idx = exp_codes_sorted.index(p_exp) if p_exp in exp_codes_sorted else 0
        if current_exp_idx < len(exp_codes_sorted) - 1:
            next_exp_code = exp_codes_sorted[current_exp_idx + 1]
            exp_input = [[p_city, p_edu, next_exp_code]]
            exp_pred = int(model.predict(exp_input)[0])
            uplift_exp = exp_pred - pred_salary

        # 新增：增强预测 — 置信区间（基于各棵树的预测方差）
        tree_preds = [tree.predict(input_vector)[0] for tree in model.estimators_]
        pred_std = float(np.std(tree_preds))
        ci_lower = max(0, int(pred_salary - 1.96 * pred_std))
        ci_upper = int(pred_salary + 1.96 * pred_std)
        if len(df) > 100:
            conf_level = '高'
        elif len(df) > 30:
            conf_level = '中'
        else:
            conf_level = '低'

        # 新增：情景模拟
        scenarios = []
        # 当前情景
        scenarios.append({'label': '当前条件', 'salary': pred_salary, 'diff': 0})
        # 学历提升情景
        if next_edu != target_edu and next_edu in edu_to_code:
            scenarios.append({'label': f'学历→{next_edu}', 'salary': pred_salary + uplift_edu, 'diff': uplift_edu})
        # 经验提升情景
        if uplift_exp != 0:
            scenarios.append({'label': '经验+1级', 'salary': pred_salary + uplift_exp, 'diff': uplift_exp})
        # 热门城市情景
        hot_cities = ['北京', '上海', '深圳', '杭州']
        for hc in hot_cities:
            if hc != target_city and hc in city_to_code:
                hc_code = city_to_code[hc]
                hc_pred = int(model.predict([[hc_code, p_edu, p_exp]])[0])
                scenarios.append({'label': f'城市→{hc}', 'salary': hc_pred, 'diff': hc_pred - pred_salary})
                break  # 只加一个热门城市

        salary_decision = _build_salary_decision(pred_salary, low, high, expected_salary_min, expected_salary_max)

        return jsonify({
            'success': True,
            'salary': pred_salary,
            'predicted_salary': pred_salary,
            'range': f"{low} - {high}",
            'top_driver': top_driver,
            'confidence': conf_level,
            'sample_size': len(df),
            'percentile': percentile,
            'salary_decision': salary_decision,
            'analysis': {
                'uplift_edu': uplift_edu,
                'next_edu': next_edu,
                'uplift_exp': uplift_exp
            },
            'enhanced': {
                'confidence': {
                    'level': conf_level,
                    'lower': ci_lower,
                    'upper': ci_upper,
                    'sample_size': len(df)
                },
                'scenarios': scenarios
            }
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'msg': f'预测失败: {str(e)}'})

