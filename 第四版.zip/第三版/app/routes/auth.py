import json
from datetime import datetime

from flask import request, jsonify, session

from app.extensions import db
from app.models.user import User, UserProfile
from . import main_bp


def _safe_float(v, default=0.0):
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


def _safe_int(v, default=0):
    try:
        if v is None:
            return default
        return int(float(v))
    except Exception:
        return default


@main_bp.route('/api/register', methods=['POST'])
def register():
    data = request.json or {}
    username = str(data.get('username') or '').strip()
    password = str(data.get('password') or '')

    if not username or not password:
        return jsonify({'success': False, 'msg': '用户名和密码不能为空'})

    if User.query.filter_by(username=username).first():
        return jsonify({'success': False, 'msg': '用户名已存在'})

    new_user = User(username=username, role='用户')
    new_user.set_password(password)
    db.session.add(new_user)
    db.session.commit()

    return jsonify({'success': True, 'msg': '注册成功'})


@main_bp.route('/api/login', methods=['POST'])
def login():
    data = request.json or {}
    username = str(data.get('username') or '').strip()
    password = str(data.get('password') or '')

    user = User.query.filter_by(username=username).first()
    if user and user.check_password(password):
        user_role = getattr(user, 'role', '用户') or '用户'
        session.permanent = True
        session['user'] = username
        session['user_id'] = user.id
        session['role'] = user_role
        return jsonify({'success': True, 'username': username, 'role': user_role})

    return jsonify({'success': False, 'msg': '用户名或密码错误'})


@main_bp.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})


def get_current_user_id():
    return session.get('user_id')


@main_bp.route('/api/user/profile', methods=['GET', 'POST'])
def handle_profile():
    uid = get_current_user_id()
    if not uid:
        return jsonify({'success': False, 'msg': '请先登录'}), 401

    profile = UserProfile.query.get(uid)

    if request.method == 'GET':
        if not profile:
            return jsonify({'success': True, 'data': None})
        target_jobs = profile.get_target_jobs()
        skill_list = profile.get_skill_list()
        return jsonify({
            'success': True,
            'data': {
                'target_job': profile.target_job,
                'target_jobs': target_jobs,
                'exp_year': profile.exp_year,
                'exp_years_num': profile.exp_years_num or 0,
                'edu_level': profile.edu_level,
                'skills': profile.skills,
                'skill_list': skill_list,
                'expected_salary_min': profile.expected_salary_min or 0,
                'expected_salary_max': profile.expected_salary_max or 0,
                'profile_score': profile.profile_score or 0,
                'last_updated': profile.last_updated.strftime('%Y-%m-%d %H:%M:%S') if profile.last_updated else ''
            }
        })

    d = request.json or {}
    if not profile:
        profile = UserProfile(user_id=uid)
        db.session.add(profile)

    target_jobs = d.get('target_jobs')
    if not isinstance(target_jobs, list):
        target_jobs = [
            x.strip()
            for x in str(d.get('target_job') or '').replace('\uFF0C', ',').replace('\u3001', ',').split(',')
            if x.strip()
        ]
    target_jobs = target_jobs[:3]

    skill_list = d.get('skill_list')
    if not isinstance(skill_list, list):
        skill_list = [
            x.strip()
            for x in str(d.get('skills') or '').replace('\uFF0C', ',').replace('\u3001', ',').split(',')
            if x.strip()
        ]

    try:
        profile.target_job = str(d.get('target_job') or (target_jobs[0] if target_jobs else '')).strip()[:64]
        profile.target_jobs = json.dumps(target_jobs, ensure_ascii=False)
        profile.exp_year = str(d.get('exp_year') or '').strip()[:32]
        profile.exp_years_num = _safe_float(d.get('exp_years_num'), 0.0)
        profile.edu_level = str(d.get('edu_level') or '').strip()[:32]
        profile.skills = str(d.get('skills') or ",".join(skill_list))[:2000]
        profile.skill_list = json.dumps(skill_list, ensure_ascii=False)

        expected_min = _safe_int(d.get('expected_salary_min'), 0)
        expected_max = _safe_int(d.get('expected_salary_max'), 0)
        expected_salary = _safe_int(d.get('expected_salary'), 0)
        if expected_min <= 0 and expected_salary > 0:
            expected_min = int(expected_salary * 0.9)
        if expected_max <= 0 and expected_salary > 0:
            expected_max = int(expected_salary * 1.1)
        if expected_min > expected_max and expected_max > 0:
            expected_min, expected_max = expected_max, expected_min
        profile.expected_salary_min = expected_min
        profile.expected_salary_max = expected_max

        profile.profile_score = _safe_int(d.get('profile_score'), _safe_int(profile.profile_score, 0))
        profile.last_updated = datetime.utcnow()

        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'msg': f'画像保存失败: {str(e)[:120]}'}), 500
