import json
import os

from flask import Blueprint, jsonify, request, session

from app.extensions import db
from app.models.job import Job
from config import Config

config_bp = Blueprint("config", __name__)

DEFAULT_SPIDER_CONFIG = {
    "city_scope": ["全国"],
    "max_pages": 5,
    "frequency": "manual",
}

DIRTY_CITY_KEYWORDS = {
    "在线",
    "分钟",
    "小时",
    "天前",
    "刚刚",
    "月前",
    "经验",
    "学历",
    "本科",
    "硕士",
    "大专",
    "博士",
    "不限",
    "年",
    "招",
}


def _user_config_dir(uid):
    base_dir = os.path.join(Config.UPLOAD_FOLDER, f"user_{int(uid)}", "settings")
    os.makedirs(base_dir, exist_ok=True)
    return base_dir


def _user_config_file(uid):
    return os.path.join(_user_config_dir(uid), "spider_config.json")


def _normalize_city_scope(value):
    if isinstance(value, str):
        candidates = [value]
    elif isinstance(value, list):
        candidates = value
    else:
        candidates = []

    cleaned = []
    seen = set()
    for raw in candidates:
        city = Config.normalize_city_name(raw)
        if not city:
            continue
        if city == "全国":
            return ["全国"]
        if city not in seen:
            seen.add(city)
            cleaned.append(city)
    return cleaned or ["全国"]


def _normalize_spider_config(raw):
    data = raw if isinstance(raw, dict) else {}
    try:
        max_pages = int(data.get("max_pages", DEFAULT_SPIDER_CONFIG["max_pages"]))
    except Exception:
        max_pages = DEFAULT_SPIDER_CONFIG["max_pages"]
    max_pages = max(1, min(max_pages, Config.SPIDER_SETTINGS.get("MAX_PAGE", 30)))

    frequency = str(data.get("frequency") or DEFAULT_SPIDER_CONFIG["frequency"]).strip().lower()
    if frequency not in {"manual", "daily"}:
        frequency = DEFAULT_SPIDER_CONFIG["frequency"]

    return {
        "city_scope": _normalize_city_scope(data.get("city_scope")),
        "max_pages": max_pages,
        "frequency": frequency,
    }


def load_config(uid):
    path = _user_config_file(uid)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return _normalize_spider_config(json.load(f))
        except Exception:
            pass
    return dict(DEFAULT_SPIDER_CONFIG)


def save_config(uid, cfg):
    path = _user_config_file(uid)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(_normalize_spider_config(cfg), f, ensure_ascii=False, indent=2)


def _is_valid_city(name, known_cities):
    city = Config.normalize_city_name(name)
    if not city:
        return False
    if city in known_cities:
        return True
    if len(city) < 2 or len(city) > 8:
        return False
    if any(ch.isdigit() for ch in city):
        return False
    return not any(keyword in city for keyword in DIRTY_CITY_KEYWORDS)


@config_bp.route("/api/config/spider", methods=["GET", "POST"])
def handle_spider_config():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    if request.method == "GET":
        return jsonify({"success": True, "data": load_config(uid)})

    new_cfg = _normalize_spider_config(request.get_json(silent=True) or {})
    save_config(uid, new_cfg)
    return jsonify({"success": True, "data": new_cfg})


@config_bp.route("/api/config/cities")
def get_available_cities():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"success": False, "msg": "请先登录"}), 401

    try:
        known_cities = {Config.normalize_city_name(name) for name in Config.COMMON_CITIES}
        db_cities = db.session.query(Job.city).filter(Job.owner_id == uid).distinct().all()
        db_city_names = [Config.normalize_city_name(row[0]) for row in db_cities if row[0]]
        valid_db_cities = [city for city in db_city_names if _is_valid_city(city, known_cities)]
        all_cities = ["全国"] + sorted(set(city for city in valid_db_cities if city and city != "全国"))
        for city in Config.COMMON_CITIES:
            if city != "全国" and city not in all_cities:
                all_cities.append(city)
        return jsonify({"success": True, "data": all_cities})
    except Exception as e:
        return jsonify({"success": False, "msg": str(e)}), 500
