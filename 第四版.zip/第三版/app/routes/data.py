from flask import Blueprint, jsonify, request, session, send_file, current_app, after_this_request
from app.extensions import db
from app.models.job import Job
from app.models.user import UserProfile
from sqlalchemy import or_, desc, asc
import pandas as pd
import os
import re
import json
import uuid
import jieba.analyse
from datetime import datetime
from werkzeug.utils import secure_filename
from config import Config
from app.services.data_quality_utils import normalize_date_str, is_normalized_skill_text
from app.services.edu_utils import apply_edu_filter, normalize_edu_level
from app.services.filter_utils import (
    apply_city_filter,
    apply_exp_filter,
    normalize_city_value,
    normalize_source_value,
    normalize_exp_level,
)
from app.services.salary_utils import (
    SALARY_MAX_VALID,
    SALARY_MIN_VALID,
    parse_salary_text_to_monthly,
    sanitize_salary_avg,
)

data_bp = Blueprint('data', __name__)

UPLOAD_FOLDER = Config.UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

JOB_MAP = {
    "Java开发": ["java"],
    "前端开发": ["前端", "vue", "react"],
    "数据分析": ["数据", "分析"],
    "软件测试": ["测试"],
    "算法工程师": ["算法"],
    "运维安全": ["运维", "安全"],
}

MATCH_MODES = {'all', 'high', 'medium', 'gap1'}


def normalize_job(name):
    for cat, kws in JOB_MAP.items():
        if any(k in str(name).lower() for k in kws): return cat
    return "其他"


def parse_salary_val(txt):
    return float(parse_salary_text_to_monthly(txt))


def _user_storage_dir(uid, category):
    base_dir = os.path.join(UPLOAD_FOLDER, f"user_{int(uid)}", category)
    os.makedirs(base_dir, exist_ok=True)
    return base_dir


def _unique_user_file(uid, category, original_name):
    safe_name = secure_filename(str(original_name or "").strip()) or "data.csv"
    ext = os.path.splitext(safe_name)[1].lower()
    token = uuid.uuid4().hex[:10]
    return os.path.join(_user_storage_dir(uid, category), f"{token}{ext}"), safe_name, ext


def _upload_impl():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"msg": "请先登录"}), 401

    if "file" not in request.files:
        return jsonify({"msg": "未上传文件"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"msg": "文件名不能为空"}), 400

    path, _, ext = _unique_user_file(uid, "imports", file.filename)
    if ext not in {".csv", ".txt"}:
        return jsonify({"msg": "仅支持 CSV 文本导入"}), 400

    file.save(path)

    try:
        try:
            df = pd.read_csv(path, encoding="utf-8-sig")
        except Exception:
            try:
                df = pd.read_csv(path, encoding="gbk")
            except Exception:
                return jsonify({"msg": "文件编码错误，请使用 UTF-8 或 GBK 编码的 CSV"}), 400

        rename_map = {
            "job_title": "岗位名称",
            "positionName": "岗位名称",
            "company_name": "公司名称",
            "city": "搜索城市",
            "salary": "薪资文本",
            "description": "岗位描述",
            "edu": "学历要求",
            "exp": "工作年限要求",
        }
        df.rename(columns=rename_map, inplace=True)

        if "岗位名称" not in df.columns:
            return jsonify({"msg": "CSV 缺少 [岗位名称] 列"}), 400

        Job.query.filter_by(owner_id=uid, source="手动导入").delete()

        count = 0
        for i, row in df.iterrows():
            desc = str(row.get("岗位描述", ""))
            skills = ",".join(jieba.analyse.extract_tags(desc, topK=5)) if i < 1000 else ""

            job = Job(
                owner_id=uid,
                job_name=row.get("岗位名称", "未知岗位"),
                company=row.get("公司名称", "匿名公司"),
                city=row.get("搜索城市", "全国"),
                job_category=normalize_job(row.get("岗位名称")),
                salary_avg=parse_salary_val(row.get("薪资文本")),
                salary_text=str(row.get("薪资文本")),
                edu_req=row.get("学历要求", "不限"),
                exp_req=row.get("工作年限要求", "不限"),
                skills=skills,
                tags="",
                company_size="未知规模",
                source="手动导入",
                raw_desc=desc[:200],
                pub_date=datetime.now().strftime("%Y-%m-%d"),
            )
            db.session.add(job)
            count += 1

        db.session.commit()
        return jsonify({"message": f"成功导入 {count} 条数据"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"msg": str(e)}), 500
    finally:
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass


def _export_data_impl():
    uid = session.get("user_id")
    if not uid:
        return "Unauthorized", 401

    data = request.json or {} if request.method == "POST" else request.args
    query = Job.query.filter_by(owner_id=uid)

    kw = data.get("keyword", "")
    city = data.get("city", "")
    edu = data.get("education", "")
    exp = data.get("exp", "")
    salary_min = data.get("salary_min")
    salary_max = data.get("salary_max")
    date_start = data.get("date_start")
    date_end = data.get("date_end")

    if kw:
        query = query.filter(
            or_(
                Job.job_name.like(f"%{kw}%"),
                Job.company.like(f"%{kw}%"),
                Job.tags.like(f"%{kw}%"),
                Job.skills.like(f"%{kw}%"),
            )
        )

    if edu:
        query = apply_edu_filter(query, Job.edu_req, edu, fallback_columns=[Job.tags, Job.raw_desc])
    if city:
        query = apply_city_filter(query, Job.city, city)
    if exp:
        query = apply_exp_filter(query, Job.exp_req, exp, fallback_columns=[Job.tags, Job.raw_desc])
    if salary_min and str(salary_min).isdigit():
        query = query.filter(Job.salary_avg >= int(salary_min))
    if salary_max and str(salary_max).isdigit():
        query = query.filter(Job.salary_avg <= int(salary_max))
    if date_start:
        query = query.filter(Job.pub_date >= date_start)
    if date_end:
        query = query.filter(Job.pub_date <= date_end)

    try:
        records = query.all()
        df = pd.DataFrame([r.__dict__ for r in records]) if records else pd.DataFrame()
        if "_sa_instance_state" in df.columns:
            df = df.drop(columns=["_sa_instance_state"])
    except Exception as e:
        return jsonify({"msg": str(e)}), 500

    fmt = str(data.get("format", "xlsx")).strip().lower()
    if fmt not in {"xlsx", "csv"}:
        fmt = "xlsx"

    base_name = str(data.get("filename") or "招聘数据导出").strip() or "招聘数据导出"
    safe_name = secure_filename(base_name) or "job_export"
    export_dir = _user_storage_dir(uid, "exports")
    export_name = f"{safe_name}_{uuid.uuid4().hex[:8]}.{fmt}"
    export_path = os.path.join(export_dir, export_name)

    try:
        if fmt == "csv":
            df.to_csv(export_path, index=False, encoding="utf-8-sig")
            mimetype = "text/csv"
        else:
            df.to_excel(export_path, index=False)
            mimetype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

        @after_this_request
        def _cleanup_export(response):
            try:
                if os.path.exists(export_path):
                    os.remove(export_path)
            except OSError:
                current_app.logger.warning("failed to cleanup export file: %s", export_path)
            return response

        return send_file(
            export_path,
            as_attachment=True,
            download_name=f"{base_name}.{fmt}",
            mimetype=mimetype,
        )
    except Exception as e:
        return jsonify({"msg": f"导出失败: {str(e)}"}), 500


def _parse_skill_tokens(text):
    return [
        s.strip().lower()
        for s in re.split(r"[,，、;\s]+", str(text or ""))
        if s and s.strip()
    ]


def _profile_skill_set(profile):
    if not profile:
        return set()

    tokens = []
    raw_list = profile.skill_list
    if isinstance(raw_list, list):
        tokens.extend([str(x).strip().lower() for x in raw_list if str(x).strip()])
    elif isinstance(raw_list, str):
        raw = raw_list.strip()
        if raw:
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, list):
                    tokens.extend([str(x).strip().lower() for x in parsed if str(x).strip()])
            except Exception:
                tokens.extend(_parse_skill_tokens(raw))

    if not tokens:
        tokens.extend(_parse_skill_tokens(profile.skills or ''))

    return {x for x in tokens if x}


def _profile_is_complete(profile):
    if not profile:
        return False
    has_job = bool(str(profile.target_job or '').strip())
    has_edu = bool(str(profile.edu_level or '').strip())
    has_exp = bool(str(profile.exp_year or '').strip())
    has_skills = len(_profile_skill_set(profile)) >= 2
    return has_job and has_edu and has_exp and has_skills


def _match_score_gap(skill_set, job_skills_text):
    job_skills = _parse_skill_tokens(job_skills_text or '')
    if not skill_set or not job_skills:
        return None, None
    overlap = sum(1 for s in job_skills if s in skill_set)
    score = int(round((overlap / max(1, len(job_skills))) * 100))
    score = max(0, min(99, score))
    gap = max(0, len(job_skills) - overlap)
    return score, gap


def _hit_match_mode(score, gap, mode):
    if mode == 'all':
        return True
    if score is None:
        return False
    if mode == 'high':
        return score >= 75
    if mode == 'medium':
        return 50 <= score < 75
    if mode == 'gap1':
        return gap is not None and gap <= 1
    return True


def _build_row_quality(job):
    flags = []

    salary = sanitize_salary_avg(job.salary_avg)
    if salary <= 0:
        flags.append("salary_abnormal")

    if not normalize_date_str(job.pub_date):
        flags.append("pub_date_missing")

    skills_text = str(job.skills or "").strip()
    if not skills_text or not is_normalized_skill_text(skills_text):
        flags.append("skills_missing")

    if "salary_abnormal" in flags or len(flags) >= 2:
        level = "red"
        label = "高风险"
    elif len(flags) == 1:
        level = "yellow"
        label = "需关注"
    else:
        level = "green"
        label = "健康"

    score = max(0, 100 - len(flags) * 30 - (20 if "salary_abnormal" in flags else 0))
    return {
        "quality_level": level,
        "quality_label": label,
        "quality_flags": flags,
        "quality_score": int(score),
    }


@data_bp.route('/upload', methods=['POST'])
def upload():
    return _upload_impl()


@data_bp.route('/api/data/search', methods=['POST'])
def search_data():
    uid = session.get('user_id')
    if not uid: return jsonify({'rows': [], 'total': 0})

    data = request.json or {}
    page = data.get('page', 1)
    page_size = min(int(data.get('page_size', 20)), 100)  # 默认20条，最多100条
    kw = data.get('keyword', '')
    city = data.get('city', '')
    edu = data.get('education', '')
    exp = data.get('exp', '')  # Experience requirement
    salary_min = data.get('salary_min')
    salary_max = data.get('salary_max')
    sort_by = data.get('sort_by', 'id')
    sort_order = data.get('sort_order', 'desc')
    favorites_only = bool(data.get('favorites_only'))
    ignored_mode = str(data.get('ignored_mode') or 'exclude').strip()  # exclude/include/only
    match_mode = str(data.get('match_mode') or 'all').strip().lower()
    if match_mode not in MATCH_MODES:
        match_mode = 'all'

    query = Job.query.filter_by(owner_id=uid)
    profile = UserProfile.query.get(uid)
    profile_ready_for_match = _profile_is_complete(profile)
    profile_skill_set = _profile_skill_set(profile) if profile_ready_for_match else set()
    match_filter_applied = False

    if kw:
        query = query.filter(or_(
            Job.job_name.like(f'%{kw}%'),
            Job.company.like(f'%{kw}%'),
            Job.tags.like(f'%{kw}%'),
            Job.skills.like(f'%{kw}%')
        ))

    if edu:
        query = apply_edu_filter(
            query,
            Job.edu_req,
            edu,
            fallback_columns=[Job.tags, Job.raw_desc],
        )
    if city:
        query = apply_city_filter(query, Job.city, city)
    if exp:
        query = apply_exp_filter(query, Job.exp_req, exp, fallback_columns=[Job.tags, Job.raw_desc])

    if salary_min and str(salary_min).isdigit():
        query = query.filter(Job.salary_avg >= int(salary_min))
    if salary_max and str(salary_max).isdigit():
        query = query.filter(Job.salary_avg <= int(salary_max))

    if favorites_only:
        query = query.filter(Job.is_favorite.is_(True))
    if ignored_mode == 'exclude':
        query = query.filter(db.or_(Job.is_ignored.is_(False), Job.is_ignored.is_(None)))
    elif ignored_mode == 'only':
        query = query.filter(Job.is_ignored.is_(True))

    if match_mode != 'all' and profile_skill_set:
        matched_ids = []
        for row_id, row_skills in query.with_entities(Job.id, Job.skills).all():
            score, gap = _match_score_gap(profile_skill_set, row_skills)
            if _hit_match_mode(score, gap, match_mode):
                matched_ids.append(int(row_id))
        if matched_ids:
            query = query.filter(Job.id.in_(matched_ids))
        else:
            query = query.filter(Job.id == -1)
        match_filter_applied = True

    # 排序字段白名单，避免非法排序参数
    ALLOWED_SORT_FIELDS = {'id', 'job_name', 'company', 'city', 'salary_avg', 'pub_date', 'edu_req', 'exp_req', 'source'}
    
    if sort_by == 'match' and profile_ready_for_match:
        all_jobs = query.all()
        # 计算匹配分数
        def _get_score(j):
            s, _ = _match_score_gap(profile_skill_set, j.skills)
            return s if s is not None else -1
        
        all_jobs.sort(key=_get_score, reverse=(sort_order == 'desc'))
        total_items = len(all_jobs)
        start = (page - 1) * page_size
        items = all_jobs[start:start + page_size]
    else:
        if sort_by in ALLOWED_SORT_FIELDS and hasattr(Job, sort_by):
            col = getattr(Job, sort_by)
            if sort_order == 'desc':
                query = query.order_by(desc(col))
            else:
                query = query.order_by(asc(col))
        elif sort_by != 'match':
            query = query.order_by(desc(Job.id))
        else:
            query = query.order_by(desc(Job.id))
            
        pagination = query.paginate(page=page, per_page=page_size, error_out=False)
        items = pagination.items
        total_items = pagination.total

    rows = []
    for job in items:
        q = _build_row_quality(job)
        match_score, gap_count = _match_score_gap(profile_skill_set, job.skills)
        rows.append({
            'id': job.id,
            'source': normalize_source_value(job.source) or job.source,
            'job_name': job.job_name,
            'company': job.company,
            'city': normalize_city_value(job.city) or job.city,
            'salary_text': job.salary_text,
            'salary_avg': job.salary_avg,
            'pub_date': job.pub_date,
            'tags': job.tags,
            'detail_url': job.detail_url,
            'raw_desc': job.raw_desc,
            'skills': job.skills,
            'edu': normalize_edu_level(job.edu_req),
            'exp': normalize_exp_level(job.exp_req) or job.exp_req,
            'quality_level': q['quality_level'],
            'quality_label': q['quality_label'],
            'quality_flags': q['quality_flags'],
            'quality_score': q['quality_score'],
            'is_favorite': bool(job.is_favorite),
            'is_ignored': bool(job.is_ignored),
            'note': job.note or '',
            '_quick_match': match_score,
            '_gap_count': gap_count,
        })

    return jsonify({
        'rows': rows,
        'total': total_items,
        'match_filter_applied': bool(match_filter_applied),
        'profile_ready_for_match': bool(profile_ready_for_match),
    })


@data_bp.route('/api/data/delete', methods=['POST'])
def delete_data():
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False})

    payload = request.json or {}
    ids = payload.get('ids')
    if isinstance(ids, list) and ids:
        norm_ids = []
        for v in ids:
            try:
                norm_ids.append(int(v))
            except Exception:
                continue
        if not norm_ids:
            return jsonify({'success': False, 'msg': '参数错误'})
        deleted = Job.query.filter(Job.owner_id == uid, Job.id.in_(norm_ids)).delete(synchronize_session=False)
        db.session.commit()
        return jsonify({'success': True, 'deleted': int(deleted)})

    job_id = payload.get('id')
    try:
        job_id = int(job_id)
    except Exception:
        return jsonify({'success': False, 'msg': '参数错误'})

    job = Job.query.filter_by(id=job_id, owner_id=uid).first()
    if not job:
        return jsonify({'success': False, 'msg': '岗位不存在'})

    db.session.delete(job)
    db.session.commit()
    return jsonify({'success': True, 'deleted': 1})


@data_bp.route('/api/export', methods=['GET', 'POST'])
def export_data():
    return _export_data_impl()


@data_bp.route('/api/data/clean', methods=['POST'])
def clean_data():
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False, 'msg': '请先登录'}), 401

    try:
        num = Job.query.filter_by(owner_id=uid).delete()
        db.session.commit()
        return jsonify({'success': True, 'msg': f'已清空 {num} 条数据'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'msg': str(e)}), 500


@data_bp.route('/api/data/quick-fix', methods=['POST'])
def data_quick_fix():
    """数据质量快速修复动作（供前端质量建议按钮调用）。"""
    uid = session.get('user_id')
    if not uid:
        return jsonify({'success': False, 'msg': '请先登录'}), 401

    payload = request.json or {}
    action = str(payload.get('action', '')).strip()

    def _norm_text(v):
        return re.sub(r'\s+', '', str(v or '')).strip().lower()

    try:
        affected = 0
        msg = '未执行任何修复动作'

        if action == 'remove_abnormal_salary':
            abnormal_rows = Job.query.filter_by(owner_id=uid).filter(
                Job.salary_avg.isnot(None),
                Job.salary_avg > 0,
                db.or_(Job.salary_avg < SALARY_MIN_VALID, Job.salary_avg > SALARY_MAX_VALID)
            ).all()
            for row in abnormal_rows:
                row.salary_avg = 0
            affected = len(abnormal_rows)
            msg = f'已修复异常薪资 {affected} 条'

        elif action == 'repair_salary_from_text':
            rows = Job.query.filter_by(owner_id=uid).all()
            for row in rows:
                parsed = parse_salary_text_to_monthly(row.salary_text)
                fixed = sanitize_salary_avg(parsed)
                current = sanitize_salary_avg(row.salary_avg)
                if fixed != current:
                    row.salary_avg = fixed
                    affected += 1
            msg = f'已根据 salary_text 修复薪资 {affected} 条'

        elif action == 'dedupe_job_company_city':
            # 按(岗位, 公司, 城市)去重，保留最新 id
            rows = db.session.query(
                Job.id, Job.job_name, Job.company, Job.city
            ).filter_by(owner_id=uid).order_by(Job.id.desc()).all()

            seen = set()
            delete_ids = []
            for row in rows:
                key = (_norm_text(row.job_name), _norm_text(row.company), _norm_text(row.city))
                if key in seen:
                    delete_ids.append(row.id)
                else:
                    seen.add(key)

            if delete_ids:
                affected = Job.query.filter(
                    Job.owner_id == uid,
                    Job.id.in_(delete_ids)
                ).delete(synchronize_session=False)
            msg = f'已删除重复岗位 {affected} 条'

        elif action == 'fill_missing_city_unknown':
            affected = Job.query.filter_by(owner_id=uid).filter(
                db.or_(Job.city.is_(None), Job.city == '')
            ).update({Job.city: '未知'}, synchronize_session=False)
            msg = f'已补全缺失城市 {affected} 条'

        else:
            return jsonify({'success': False, 'msg': '不支持的修复动作'}), 400

        db.session.commit()
        return jsonify({
            'success': True,
            'action': action,
            'affected': int(affected or 0),
            'msg': msg
        })
    except Exception as e:
        db.session.rollback()
        current_app.logger.exception('data_quick_fix failed')
        return jsonify({'success': False, 'msg': str(e)}), 500


@data_bp.route('/api/job/<int:jid>/favorite', methods=['POST'])
def toggle_favorite(jid):
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False}), 401

    job = Job.query.filter_by(id=jid, owner_id=uid).first()
    if not job: return jsonify({'success': False, 'msg': '岗位不存在'})

    job.is_favorite = not job.is_favorite
    db.session.commit()
    return jsonify({'success': True, 'is_favorite': job.is_favorite})


@data_bp.route('/api/job/<int:jid>/ignore', methods=['POST'])
def toggle_ignore(jid):
    uid = session.get('user_id')
    if not uid:
        return jsonify({'success': False}), 401

    job = Job.query.filter_by(id=jid, owner_id=uid).first()
    if not job:
        return jsonify({'success': False, 'msg': '岗位不存在'})

    job.is_ignored = not bool(job.is_ignored)
    db.session.commit()
    return jsonify({'success': True, 'is_ignored': bool(job.is_ignored)})


@data_bp.route('/api/job/<int:jid>/note', methods=['POST'])
def update_note(jid):
    uid = session.get('user_id')
    if not uid: return jsonify({'success': False}), 401

    note = request.json.get('note', '')
    job = Job.query.filter_by(id=jid, owner_id=uid).first()
    if not job: return jsonify({'success': False, 'msg': '岗位不存在'})

    job.note = note
    db.session.commit()
    return jsonify({'success': True})
