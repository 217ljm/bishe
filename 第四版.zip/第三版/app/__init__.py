from flask import Flask
from flask_cors import CORS

from config import Config

from .extensions import db


def _import_models():
    # Ensure create_all discovers all model tables.
    from .models.application import JobApplication  # noqa: F401
    from .models.crawl_task import CrawlTask  # noqa: F401
    from .models.job import Job  # noqa: F401
    from .models.user import User, UserProfile  # noqa: F401
    from .models.weekly_plan_state import WeeklyPlanState  # noqa: F401


def create_app(config_class=Config):
    app = Flask(__name__, template_folder="../templates", static_folder="../static")
    app.config.from_object(config_class)

    db.init_app(app)
    app.config["TEMPLATES_AUTO_RELOAD"] = True
    CORS(app)

    from .routes import main_bp
    from .routes.analysis import analysis_bp
    from .routes.applicant import applicant_bp
    from .routes.config import config_bp
    from .routes.data import data_bp
    from .routes.overview import overview_bp
    from .routes.spider import spider_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(spider_bp)
    app.register_blueprint(data_bp)
    app.register_blueprint(analysis_bp)
    app.register_blueprint(config_bp)
    app.register_blueprint(applicant_bp)
    app.register_blueprint(overview_bp)

    with app.app_context():
        _import_models()
        db.create_all()

    return app
