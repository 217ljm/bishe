import os

file_path = r"d:\PyCharmprojects\analysis project\templates\index.html"

with open(file_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
in_summary = False
skip_mode = False

bento_html = """
                <div class="bento-grid">
                    <div class="bento-card span-8">
                        <div>
                            <div id="welcome-msg" class="summary-hero-title" style="font-size:20px; font-weight:800; color:#1e3a8a;">欢迎回来</div>
                            <div class="summary-hero-tagline" style="margin-top:8px; font-size:15px; color:#334155;">
                                面向求职者，提供客观的岗位评估、竞争力分析和投递决策支持
                            </div>
                            <div class="summary-hero-meta" style="margin-top:10px; font-size:13px; color:#64748b;">
                                <i class="ri-time-line"></i> 最后更新：<span id="stat-last-update">--</span>
                            </div>
                        </div>
                    </div>

                    <div class="bento-card span-4" style="background: linear-gradient(135deg, #eff6ff 0%, #eef2ff 100%); padding: 20px;">
                        <div style="font-size:13px; font-weight:700; color:#1e3a8a; margin-bottom:12px;"><i class="ri-user-settings-line"></i> 基础完整度</div>
                        <div style="display:flex; justify-content:space-between; align-items:flex-end;">
                            <div>
                                <div style="font-size:12px; color:#475569;">高匹配岗位(市场)</div>
                                <div id="stat-market-avg" style="font-size:24px; font-weight:800; color:#1d4ed8; line-height:1;">0</div>
                            </div>
                            <div style="text-align:right;">
                                <div style="font-size:12px; color:#475569;">画像评价</div>
                                <div id="stat-total-jobs" style="font-size:24px; font-weight:800; color:#6d28d9; line-height:1;">0分</div>
                            </div>
                        </div>
                    </div>
                 </div>
"""

for line in lines:
    if '<div id="tab-summary" class="tab-content active">' in line:
        in_summary = True
        new_lines.append(line)
        new_lines.append(bento_html)
        skip_mode = True
        continue
        
    if skip_mode and '<div class="summary-kpi-grid">' in line:
        skip_mode = False
        
    if not skip_mode:
        new_lines.append(line)

with open(file_path, 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("Done")
