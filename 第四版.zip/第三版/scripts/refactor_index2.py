import os
import re

file_path = r"d:\PyCharmprojects\analysis project\templates\index.html"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# == 下半程目标 ==
# 清除旧的分散 action-card 和 fusion panel 等零碎杂陈，并换成 Bento 网格元素
# 使用正则匹配将整个下半区的堆叠框全部合并为更宽阔整洁的 span-8 和 span-12


old_action_block = r'''                    <div class="card summary-action-card">[\s\S]*?<div class="summary-fusion-bottom">[\s\S]*?</div>[\s\S]*?</div>'''

new_action_block = """
                    <!-- 中部行动区 = span-8 -->
                    <div class="bento-card span-8">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:12px;">
                            <div class="section-heading-sm" style="margin:0;"><i class="ri-flag-line" style="color:#ef4444;"></i> 本周核心求职行动与决策</div>
                            <div class="flex-gap8" style="margin-bottom:0;">
                                <button class="btn btn-primary" onclick="switchTab('data')"><i class="ri-search-line"></i> 搜刮新岗位</button>
                                <button class="btn btn-default" onclick="toggleSummaryAdvancedView()"><i class="ri-bar-chart-grouped-line"></i> 展开市场诊断</button>
                            </div>
                        </div>

                        <!-- 行动决策区内嵌 -->
                        <div id="summary-action-list" style="margin-top:16px; border-top:1px dashed #e2e8f0; padding-top:16px;">
                            <div class="summary-placeholder">等待诊断指令...</div>
                        </div>
                    </div>

                    <!-- 状态补缺与周期展示 = span-4 -->
                    <div class="bento-card span-4" style="background:#fff;">
                        <div class="section-heading-sm"><i class="ri-compass-3-line" style="color:#f59e0b;"></i> 所处求职周期关键节点</div>
                        <div style="display:grid; gap:12px; border:1px solid #e2e8f0; border-radius:12px; padding:16px; background:#f8fafc; margin-bottom:16px;">
                            <div>
                                <div style="font-size:12px; color:#64748b;">当前诊断阶段</div>
                                <div id="summary-phase-name" style="font-weight:700; color:#1e293b; margin-top:4px;">识别中...</div>
                            </div>
                            <div>
                                <div style="font-size:12px; color:#64748b;">核心阻塞点预警</div>
                                <div id="summary-phase-blocker" style="color:#b45309; margin-top:4px; font-size:13px;">无</div>
                            </div>
                            <div>
                                <div style="font-size:12px; color:#64748b;">系统分析建议</div>
                                <div id="summary-phase-next" style="font-weight:700; color:#0f172a; margin-top:4px;">评估中...</div>
                            </div>
                        </div>
                    </div>

                    <!-- 底部数据质量与市场看板整合 = span-12 宽屏平滑铺开 -->
                    <div class="bento-card span-12 summary-advanced-block" id="data-quality-panel">
                        <div class="flex-between">
                            <div class="section-heading-sm" style="margin:0;"><i class="ri-shield-check-line" style="color:#10b981;"></i> 底层数据质量检查与市场行情</div>
                            <div class="flex-gap8">
                                <span id="dq-health-badge" class="tag-pill" style="margin:0;">健康度检测中</span>
                                <button class="btn btn-default" onclick="loadDataQuality()"><i class="ri-refresh-line"></i></button>
                            </div>
                        </div>

                        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px; margin-top:20px;">
                             <div style="padding-right:20px; border-right:1px dashed #e2e8f0;">
                                 <div id="dq-score-bar" class="summary-quality-score">
                                     <div class="summary-quality-score-top"><span>综合基准健康分</span><span id="dq-score-text">--</span></div>
                                     <div class="summary-quality-track"><div id="dq-score-fill"></div></div>
                                 </div>
                                 <div id="dq-fields" class="summary-quality-fields"></div>
                             </div>

                             <div>
                                <div class="text-hint-sm" style="margin-bottom:8px;">市场核心指标摘要</div>
                                <div class="grid-3-180">
                                    <div class="mini-panel" style="background:#f8fafc; border:none;">
                                        <div class="text-hint">热门需求岗位</div>
                                        <div id="summary-hot-jobs" class="mt4 fw-700">加载中...</div>
                                    </div>
                                    <div class="mini-panel" style="background:#f8fafc; border:none;">
                                        <div class="text-hint">热门发榜城市</div>
                                        <div id="summary-hot-cities" class="mt4 fw-700">加载中...</div>
                                    </div>
                                    <div class="mini-panel" style="background:#f8fafc; border:none;">
                                        <div class="text-hint">市场薪资概况</div>
                                        <div id="summary-salary-overview" class="mt4 fw-700">加载中...</div>
                                    </div>
                                </div>
                             </div>
                        </div>
                    </div>
                 </div> <!-- end of bento-grid -->
"""

content = re.sub(old_action_block, new_action_block, content, flags=re.MULTILINE|re.DOTALL)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Second phase replacement completed.")

