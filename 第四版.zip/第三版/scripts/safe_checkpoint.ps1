param(
    [string]$Name = "manual"
)

$ErrorActionPreference = "Stop"

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$root = Split-Path -Parent $PSScriptRoot
$dst = Join-Path $root ".recovery/checkpoint_${ts}_$Name"

New-Item -ItemType Directory -Force -Path $dst | Out-Null

# 仅备份项目内核心源码，避免把虚拟环境复制进去
$targets = @(
    "app",
    "templates",
    "static",
    "config.py",
    "migrate_db.py",
    "app.py"
)

foreach ($t in $targets) {
    $src = Join-Path $root $t
    if (Test-Path $src) {
        $to = Join-Path $dst $t
        $toDir = Split-Path -Parent $to
        if (-not (Test-Path $toDir)) {
            New-Item -ItemType Directory -Force -Path $toDir | Out-Null
        }
        Copy-Item $src $to -Recurse -Force
    }
}

git -C $root status --short | Out-File -Encoding utf8 (Join-Path $dst "git_status.txt")
git -C $root diff | Out-File -Encoding utf8 (Join-Path $dst "git_diff.patch")

Write-Output "checkpoint created: $dst"
