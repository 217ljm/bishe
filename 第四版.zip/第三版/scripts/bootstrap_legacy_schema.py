import sqlite3
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parents[1]
DB_PATH = BASE_DIR / "recruitment.db"

TABLE_PATCHES = {
    "user_profiles": [
        ("target_jobs", "TEXT DEFAULT '[]'"),
        ("skill_list", "TEXT DEFAULT '[]'"),
        ("exp_years_num", "FLOAT DEFAULT 0"),
        ("expected_salary_min", "INTEGER DEFAULT 0"),
        ("expected_salary_max", "INTEGER DEFAULT 0"),
        ("profile_score", "INTEGER DEFAULT 0"),
        ("last_updated", "DATETIME"),
    ],
    "job_applications": [
        ("bucket", "TEXT DEFAULT '保底'"),
    ],
}


def get_columns(conn, table_name):
    return {row[1] for row in conn.execute(f"PRAGMA table_info({table_name})").fetchall()}


def main():
    if not DB_PATH.exists():
        raise SystemExit(f"database not found: {DB_PATH}")

    conn = sqlite3.connect(DB_PATH)
    try:
        for table_name, patches in TABLE_PATCHES.items():
            existing = get_columns(conn, table_name)
            for column_name, ddl in patches:
                if column_name in existing:
                    continue
                sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {ddl}"
                print(f"[patch] {sql}")
                conn.execute(sql)
        conn.commit()
        print("legacy schema bootstrap completed")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
