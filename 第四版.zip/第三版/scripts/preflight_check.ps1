$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot

Write-Host "[1/3] check script.js syntax"
node --check (Join-Path $root "static/js/script.js")
node --check (Join-Path $root "static/js/script.core.js")
node --check (Join-Path $root "static/js/script.auth.js")
node --check (Join-Path $root "static/js/script.legacy.js")
node --check (Join-Path $root "static/js/script.profile.js")
node --check (Join-Path $root "static/js/script.recommend.js")
node --check (Join-Path $root "static/js/script.dashboard.js")
node --check (Join-Path $root "static/js/script.dataops.js")
node --check (Join-Path $root "static/js/script.export_spider.js")
node --check (Join-Path $root "static/js/script.summary_flow.js")

Write-Host "[2/3] compile key route files"
python -m py_compile `
    (Join-Path $root "app/routes/spider.py") `
    (Join-Path $root "app/routes/data.py") `
    (Join-Path $root "app/routes/analysis.py") `
    (Join-Path $root "app/routes/applicant.py")

Write-Host "[3/3] compile key service files"
python -m py_compile `
    (Join-Path $root "app/services/spider_service.py") `
    (Join-Path $root "app/services/analysis_service.py") `
    (Join-Path $root "app/services/ai_service.py")

Write-Output "preflight passed"
