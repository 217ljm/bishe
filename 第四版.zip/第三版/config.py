import os
import secrets
from datetime import timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

_CITY_PAIRS = [
    ("全国", ""),
    ("上海", "410"),
    ("北京", "010"),
    ("广州", "020"),
    ("深圳", "050090"),
    ("杭州", "070020"),
    ("成都", "280020"),
    ("武汉", "180020"),
]

_JOB51_CITY_PAIRS = [
    ("全国", "000000"),
    ("上海", "020000"),
    ("北京", "010000"),
    ("广州", "030200"),
    ("深圳", "040000"),
    ("杭州", "080200"),
    ("成都", "090200"),
    ("武汉", "180200"),
]

_CITY_ALIASES = {
    "全国": "全国",
    "全国范围": "全国",
    "不限": "全国",
    "全部": "全国",
    "上海": "上海",
    "上海市": "上海",
    "北京": "北京",
    "北京市": "北京",
    "广州": "广州",
    "广州市": "广州",
    "深圳": "深圳",
    "深圳市": "深圳",
    "杭州": "杭州",
    "杭州市": "杭州",
    "成都": "成都",
    "成都市": "成都",
    "武汉": "武汉",
    "武汉市": "武汉",
}


def _load_or_create_local_secret():
    env_secret = os.environ.get("SECRET_KEY")
    if env_secret:
        return env_secret

    secret_file = BASE_DIR / ".flask_secret"
    try:
        if secret_file.exists():
            value = secret_file.read_text(encoding="utf-8").strip()
            if value:
                return value
        value = secrets.token_urlsafe(48)
        secret_file.write_text(value, encoding="utf-8")
        return value
    except Exception:
        # 本地文件不可写时仍保证应用可启动，但不再使用固定密钥。
        return secrets.token_urlsafe(48)


class Config:
    SECRET_KEY = _load_or_create_local_secret()
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or (
        "sqlite:///" + str(BASE_DIR / "recruitment.db")
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = str(BASE_DIR / "uploads")
    USER_STORAGE_ROOT = str(Path(UPLOAD_FOLDER))

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = False
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)

    SPIDER_SETTINGS = {
        "MAX_PAGE": 30,
        "PAGE_LOAD_TIMEOUT": 30,
        "RETRY_TIMES": 3,
        "HEADLESS": False,
    }

    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    ]

    LIEPIN_CITY = dict(_CITY_PAIRS)
    JOB51_CITY = dict(_JOB51_CITY_PAIRS)
    CITY_ALIASES = dict(_CITY_ALIASES)
    COMMON_CITIES = [name for name, _ in _CITY_PAIRS]

    @staticmethod
    def normalize_city_name(value):
        text = str(value or "").strip()
        if not text:
            return ""
        return Config.CITY_ALIASES.get(text, text)


os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
