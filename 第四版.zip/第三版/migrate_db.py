﻿import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'recruitment.db')


def _ensure_column(cursor, table_name, column_name, ddl):
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [row[1] for row in cursor.fetchall()]
    if column_name not in columns:
        print(f"Adding {column_name} column to {table_name}...")
        cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {ddl}")


def migrate():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    try:
        # jobs 表扩展字段
        _ensure_column(c, "jobs", "is_favorite", "BOOLEAN DEFAULT 0")
        _ensure_column(c, "jobs", "note", "TEXT DEFAULT ''")
        _ensure_column(c, "jobs", "is_ignored", "BOOLEAN DEFAULT 0")
        
        # 用户表扩展：添加角色字段
        c.execute("PRAGMA table_info(users)")
        user_columns = [row[1] for row in c.fetchall()]
        if 'role' not in user_columns:
            print("Adding role column to users...")
            c.execute("ALTER TABLE users ADD COLUMN role VARCHAR(16) DEFAULT '用户'")
            # 首个用户自动设为管理员
            c.execute("UPDATE users SET role = '管理员' WHERE id = (SELECT MIN(id) FROM users)")

        # 用户画像扩展字段
        _ensure_column(c, "user_profiles", "target_jobs", "TEXT DEFAULT '[]'")
        _ensure_column(c, "user_profiles", "skill_list", "TEXT DEFAULT '[]'")
        _ensure_column(c, "user_profiles", "exp_years_num", "FLOAT DEFAULT 0")
        _ensure_column(c, "user_profiles", "expected_salary_min", "INTEGER DEFAULT 0")
        _ensure_column(c, "user_profiles", "expected_salary_max", "INTEGER DEFAULT 0")
        _ensure_column(c, "user_profiles", "profile_score", "INTEGER DEFAULT 0")
        _ensure_column(c, "user_profiles", "last_updated", "TEXT")

        # 求职进度看板表
        c.execute("""
            CREATE TABLE IF NOT EXISTS job_applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                job_id INTEGER NOT NULL,
                status VARCHAR(24) NOT NULL DEFAULT '已收藏',
                applied_at TEXT,
                interview_date TEXT,
                notes TEXT DEFAULT '',
                match_score INTEGER DEFAULT 0,
                created_at TEXT,
                updated_at TEXT
            )
        """)

        c.execute("CREATE INDEX IF NOT EXISTS idx_job_applications_user_id ON job_applications(user_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_job_applications_job_id ON job_applications(job_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_job_applications_status ON job_applications(status)")

        conn.commit()
        print("Migration completed successfully.")
    except Exception as e:
        print(f"Migration failed: {e}")
    finally:
        conn.close()

if __name__ == '__main__':
    if os.path.exists(DB_PATH):
        migrate()
    else:
        print(f"Database not found at {DB_PATH}")
