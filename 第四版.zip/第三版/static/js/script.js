﻿// 轻量入口壳：历史上页面只加载 script.js。
(function(){
  if (window.__script_modularized_loaded) return;
  window.__script_modularized_loaded = true;
  console.log('script modular shell loaded');
})();
