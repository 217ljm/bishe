﻿// 5. 个人画像与预测逻辑 (保留原样)
// =========================================================

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (typeof initProfileSkillInput === 'function') initProfileSkillInput();
    });
} else {
    setTimeout(() => {
        if (typeof initProfileSkillInput === 'function') initProfileSkillInput();
    }, 0);
}

const PROFILE_SKILL_FALLBACK = ['Python', 'Java', 'SQL', 'Spring Boot', 'Docker', 'Redis', 'MySQL', 'Vue', 'React', '微服务', '数据分析'];
let profileSkillSuggestPool = [];
let profileSkillUiInited = false;
let profileSkillSyncLock = false;
let profileRadarLast = { labels: [], values: [] };
let profileRadarActiveIdx = -1;

function parseProfileSkillTokens(raw) {
    return String(raw || '')
        .replace(/[；;\/|]/g, ',')
        .split(/[，,、\n]/)
        .map(x => x.trim())
        .filter(Boolean);
}

function uniqueProfileSkills(tokens) {
    const out = [];
    const seen = new Set();
    (tokens || []).forEach(t => {
        const key = String(t || '').trim().toLowerCase();
        if (!key || seen.has(key)) return;
        seen.add(key);
        out.push(String(t).trim());
    });
    return out;
}

function getProfileSkillList() {
    const hidden = document.getElementById('p-skills');
    return uniqueProfileSkills(parseProfileSkillTokens((hidden || {}).value || ''));
}

function renderProfileSkillTags(skillList) {
    const tagBox = document.getElementById('profile-skill-tags');
    if (!tagBox) return;
    const tags = uniqueProfileSkills(skillList || []);
    tagBox.innerHTML = tags.length
        ? tags.map(s => `<span class="profile-skill-tag">${s}<button type="button" title="移除" onclick="removeProfileSkillTag('${String(s).replace(/'/g, "\\'")}')">×</button></span>`).join('')
        : '<span class="text-hint">暂无技能，输入后按回车添加</span>';
}

function renderProfileSkillSuggest(keyword = '') {
    const box = document.getElementById('profile-skill-suggest');
    if (!box) return;
    const q = String(keyword || '').trim().toLowerCase();
    const current = new Set(getProfileSkillList().map(x => x.toLowerCase()));
    const source = (profileSkillSuggestPool && profileSkillSuggestPool.length) ? profileSkillSuggestPool : PROFILE_SKILL_FALLBACK;
    const picks = source
        .filter(s => !current.has(String(s).toLowerCase()))
        .filter(s => !q || String(s).toLowerCase().includes(q))
        .slice(0, 10);
    box.innerHTML = picks.map(s => `<span class="suggest-item" onclick="appendProfileSkillTag('${String(s).replace(/'/g, "\\'")}')">${s}</span>`).join('');
}

async function loadProfileSkillSuggestPool() {
    try {
        const r = await fetch('/api/stats/wordcloud');
        const d = await r.json();
        const arr = Array.isArray(d) ? d : [];
        const names = arr.map(x => String((x || {}).name || '').trim()).filter(Boolean);
        profileSkillSuggestPool = uniqueProfileSkills([...names, ...PROFILE_SKILL_FALLBACK]);
    } catch (_) {
        profileSkillSuggestPool = [...PROFILE_SKILL_FALLBACK];
    }
}

function setProfileSkillList(skillList, markDirty = true) {
    const hidden = document.getElementById('p-skills');
    const tags = uniqueProfileSkills(skillList || []);
    if (hidden) hidden.value = tags.join(', ');
    renderProfileSkillTags(tags);
    if (markDirty && typeof markProfileFormDirty === 'function') markProfileFormDirty();
}

function appendProfileSkillTag(skillText) {
    const s = String(skillText || '').trim();
    if (!s) return;
    const merged = uniqueProfileSkills([...getProfileSkillList(), s]);
    setProfileSkillList(merged, true);
    const editor = document.getElementById('profile-skill-editor');
    if (editor) editor.value = '';
    renderProfileSkillSuggest('');
    if (typeof updateCard === 'function') updateCard();
}

function removeProfileSkillTag(skillText) {
    const key = String(skillText || '').trim().toLowerCase();
    if (!key) return;
    const filtered = getProfileSkillList().filter(x => String(x).toLowerCase() !== key);
    setProfileSkillList(filtered, true);
    renderProfileSkillSuggest('');
    if (typeof updateCard === 'function') updateCard();
}

function syncProfileSkillTagsFromHidden(markDirty = false) {
    if (profileSkillSyncLock) return;
    profileSkillSyncLock = true;
    try {
        renderProfileSkillTags(getProfileSkillList());
        renderProfileSkillSuggest('');
        if (markDirty && typeof markProfileFormDirty === 'function') markProfileFormDirty();
    } finally {
        profileSkillSyncLock = false;
    }
}

function bindProfileSkillEditor() {
    const editor = document.getElementById('profile-skill-editor');
    if (!editor) return;
    editor.oninput = () => renderProfileSkillSuggest(editor.value);
    editor.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ',' || e.key === '，') {
            e.preventDefault();
            appendProfileSkillTag(editor.value);
            return;
        }
        if (e.key === 'Backspace' && !editor.value.trim()) {
            const cur = getProfileSkillList();
            if (cur.length) {
                cur.pop();
                setProfileSkillList(cur, true);
            }
        }
    };
    editor.onblur = () => {
        const txt = editor.value.trim();
        if (txt) appendProfileSkillTag(txt);
    };
}

async function initProfileSkillInput() {
    const hidden = document.getElementById('p-skills');
    const editor = document.getElementById('profile-skill-editor');
    const tagBox = document.getElementById('profile-skill-tags');
    if (!hidden || !editor || !tagBox) {
        profileSkillUiInited = false;
        return;
    }
    if (profileSkillUiInited) {
        syncProfileSkillTagsFromHidden(false);
        return;
    }
    profileSkillUiInited = true;
    await loadProfileSkillSuggestPool();
    bindProfileSkillEditor();
    syncProfileSkillTagsFromHidden(false);
}

function updateProfileScoreBand(score, percentile) {
    const fill = document.getElementById('card-score-band-fill');
    const explain = document.getElementById('card-score-explain');
    const sc = Number(score || 0);
    const pc = Number(percentile || 0);
    if (fill) fill.style.width = `${Math.max(0, Math.min(100, sc))}%`;
    if (explain) {
        if (sc <= 0) explain.innerText = '完善画像后可生成市场分位解释。';
        else explain.innerText = `综合分 ${Math.round(sc)}，超过市场同类求职者约 ${Math.round(pc)}%。`;
    }
}

function toggleProfileRadarExplain() {
    const box = document.getElementById('profile-radar-explain');
    if (!box) return;
    box.style.display = box.style.display === 'none' ? 'block' : 'none';
}

function getRadarDimMeaning(label, score) {
    const txt = String(label || '');
    if (txt.includes('技能')) return `技能匹配：你填写的技能与岗位高频技能的重合程度。当前得分 ${score}/100，分数越高说明技能覆盖越完整。`;
    if (txt.includes('经验')) return `经验匹配：你的经验区间与目标岗位要求的匹配程度。当前得分 ${score}/100。`;
    if (txt.includes('学历')) return `学历匹配：你的学历与岗位门槛要求的一致性。当前得分 ${score}/100。`;
    if (txt.includes('薪资')) return `薪资匹配：你的期望薪资与市场可达区间的匹配程度。当前得分 ${score}/100。`;
    if (txt.includes('热度') || txt.includes('市场')) return `市场热度：目标岗位在目标城市的需求活跃度。当前得分 ${score}/100。`;
    return `${txt}：当前得分 ${score}/100。`;
}

function renderProfileRadarDims(labels, values) {
    const wrap = document.getElementById('profile-radar-dims');
    const detail = document.getElementById('profile-radar-dim-detail');
    if (!wrap || !detail) return;
    if (!Array.isArray(labels) || !labels.length) {
        wrap.innerHTML = '';
        detail.style.display = 'none';
        return;
    }
    wrap.innerHTML = labels.map((lb, idx) => {
        const v = Number((values || [])[idx] || 0);
        const active = idx === profileRadarActiveIdx ? 'active' : '';
        return `<span class="profile-radar-dim-chip ${active}" onclick="showProfileRadarDimDetail(${idx})">${lb} ${Math.round(v)}</span>`;
    }).join('');
}

function showProfileRadarDimDetail(idx) {
    const detail = document.getElementById('profile-radar-dim-detail');
    if (!detail) return;
    const labels = profileRadarLast.labels || [];
    const values = profileRadarLast.values || [];
    if (!labels.length || idx < 0 || idx >= labels.length) {
        detail.style.display = 'none';
        return;
    }
    profileRadarActiveIdx = idx;
    const lb = labels[idx];
    const sc = Math.round(Number(values[idx] || 0));
    detail.style.display = 'block';
    detail.innerText = getRadarDimMeaning(lb, sc);
    renderProfileRadarDims(labels, values);
}

window.showProfileRadarDimDetail = showProfileRadarDimDetail;

window.appendProfileSkillTag = appendProfileSkillTag;
window.removeProfileSkillTag = removeProfileSkillTag;
window.syncProfileSkillTagsFromHidden = syncProfileSkillTagsFromHidden;
window.initProfileSkillInput = initProfileSkillInput;
window.toggleProfileRadarExplain = toggleProfileRadarExplain;

function updateCard() {
    const jobInput = document.getElementById('p-job');
    const expInput = document.getElementById('p-exp');
    const eduInput = document.getElementById('p-edu');
    const skillsInput = document.getElementById('p-skills');
    const cityInput = document.getElementById('p-city');
    if (!jobInput || !expInput || !eduInput || !skillsInput || !cityInput) return;

    const job = jobInput.value;
    const exp = expInput.value;
    const edu = eduInput.value;
    const skills = skillsInput.value;
    const city = cityInput.value;

    const jobEl = document.getElementById('card-target-job');
    const statusBox = document.querySelector('.identity-badge');
    const statusText = document.getElementById('card-status');

    if (job) {
        if (jobEl) jobEl.innerText = job;
        if (statusBox) statusBox.classList.add('active');
        if (statusText) statusText.innerText = "画像已同步";
    } else {
        if (jobEl) jobEl.innerText = "未设定目标";
        if (statusBox) statusBox.classList.remove('active');
        if (statusText) statusText.innerText = "请先完善画像";
    }

    // 如果无目标职位则不调用后端
    if (!job && !skills) {
        document.getElementById('card-total-score').innerText = "--";
        const rankEl = document.getElementById('stat-rank');
        if (rankEl) rankEl.innerText = '--%';
        const matchEl = document.getElementById('stat-match');
        if (matchEl) matchEl.innerText = '0 项';
        updateProfileScoreBand(0, 0);
        renderMiniRadar([40, 40, 40, 40, 40]);
        return;
    }

    // 调用后端竞争力评估接口
    fetch('/api/competitiveness', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ city, edu, exp, skills })
    })
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                // 数据不足时降级为本地计算
                updateCardFallback(edu, exp, skills, city);
                return;
            }

            // 1. 五维雷达图 — 使用后端真实百分位数据
            const dims = data.dimensions;
            renderMiniRadar(dims.values, dims.labels);

            // 2. 综合竞争力指数
            const totalScore = Number(data.total_score || 0);
            const percentile = Number(data.percentile || 0);
            const scoreEl = document.getElementById('card-total-score');
            animateValue(scoreEl, 0, totalScore, 800);

            // 3. 市场排位
            const rankEl = document.getElementById('stat-rank');
            if (rankEl) rankEl.innerText = `${Math.round(percentile)}%`;
            updateProfileScoreBand(totalScore, percentile);

            // 新增: 雷达图下方的分项解读与综合建议
            const aiReasonBox = document.getElementById('profile-ai-reason');
            if (aiReasonBox && data.conclusion && data.suggestion) {
                aiReasonBox.style.display = 'block';
                document.getElementById('profile-ai-conclusion').innerText = `📊 综合评价: ${data.conclusion}`;
                document.getElementById('profile-ai-suggestion').innerText = data.suggestion;
                document.getElementById('profile-ai-details').innerText = data.reason;
            }

            // 4. 历史匹配
            const matchEl = document.getElementById('stat-match');
            if (matchEl) matchEl.innerText = `${Number(data.match_count || 0)} 项`;
            const suggestEl = document.getElementById('smart-skill-suggest');
            if (suggestEl && data.smart_skills && data.smart_skills.length > 0) {
                suggestEl.innerHTML = data.smart_skills.slice(0, 5).map(s => {
                    const premiumTag = s.premium > 0 ? ` <span style="color:#10b981; font-size:11px;">+¥${s.premium}</span>` : '';
                    return `<span style="color:var(--primary); cursor:pointer; margin-right:8px;" onclick="addSkill('${s.name}')">${s.name}${premiumTag}</span>`;
                }).join('、');
            }

            // 6. 成长路径
            if (data.growth_paths && data.growth_paths.length > 0) {
                renderGrowthPath(data.growth_paths);
            }
        })
        .catch(() => {
            updateCardFallback(edu, exp, skills, city);
        });
}

// 后端不可用时的降级本地计算
function updateCardFallback(edu, exp, skills, city) {
    const eduMap = { '大专': 60, '本科': 75, '硕士': 90, '博士': 100 };
    const eduScore = eduMap[edu] || 60;
    const expMap = { '应届': 40, '应届生': 40, '应届/实习': 40, '1年以内': 50, '1-3年': 60, '3-5年': 80, '5-10年': 90, '10年以上': 100 };
    const expScore = expMap[exp] || 50;

    let skillScore = 40;
    const skillList = skills.split(/[,， ]/).filter(s => s);
    skillScore += skillList.length * 10;
    if (skills.toLowerCase().match(/java|python|go|c\+\+|算法|架构/)) skillScore += 10;
    skillScore = Math.min(skillScore, 100);

    const marketMap = { '北京': 95, '上海': 95, '深圳': 90, '杭州': 85, '广州': 80, '其他': 60 };
    const marketScore = marketMap[city] || 70;

    let potentialScore = (eduScore * 0.6) + (100 - expScore) * 0.4;
    potentialScore = Math.min(Math.max(potentialScore, 50), 100);

    const totalIndex = ((eduScore + expScore + skillScore + marketScore + potentialScore) / 5).toFixed(1);
    const scoreEl = document.getElementById('card-total-score');
    animateValue(scoreEl, 0, parseFloat(totalIndex), 800);
    const fallbackPercentile = Math.max(5, Math.min(95, Math.round((parseFloat(totalIndex) / 100) * 100)));
    const rankEl = document.getElementById('stat-rank');
    if (rankEl) rankEl.innerText = `${fallbackPercentile}%`;
    const matchEl = document.getElementById('stat-match');
    if (matchEl) matchEl.innerText = `${skillList.length} 项`;
    updateProfileScoreBand(parseFloat(totalIndex), fallbackPercentile);
    renderMiniRadar([eduScore, expScore, skillScore, marketScore, potentialScore]);
}

function renderMiniRadar(dataValues, labels) {
    const chartDom = document.getElementById('mini-radar');
    if (!chartDom) return;
    if (!charts.miniRadar) charts.miniRadar = echarts.init(chartDom);

    const defaultLabels = ['学历竞争力', '经验竞争力', '技能匹配度', '薪资竞争力', '市场热度'];
    const dimLabels = labels || defaultLabels;
    profileRadarLast = { labels: dimLabels.slice(), values: (dataValues || []).slice() };
    if (profileRadarActiveIdx < 0 || profileRadarActiveIdx >= dimLabels.length) {
        profileRadarActiveIdx = 0;
    }

    const option = {
        radar: {
            indicator: dimLabels.map(name => ({ name, max: 100 })),
            radius: '65%', center: ['50%', '55%'], splitNumber: 4,
            axisName: { color: '#666', fontSize: 11, fontWeight: 500 },
            splitArea: { areaStyle: { color: ['rgba(255,255,255,0)', 'rgba(255,255,255,0)'] } },
            axisLine: { lineStyle: { color: 'rgba(37,99,235,0.2)' } },
            splitLine: { lineStyle: { color: 'rgba(37,99,235,0.2)' } }
        },
        series: [{
            type: 'radar',
            data: [{
                value: dataValues,
                name: '竞争力模型',
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: 'rgba(37,99,235,0.6)' },
                        { offset: 1, color: 'rgba(37,99,235,0.1)' }
                    ])
                },
                lineStyle: { color: '#2563eb', width: 2 },
                itemStyle: { color: '#2563eb', borderColor: '#fff', borderWidth: 2 }
            }]
        }]
    };
    charts.miniRadar.setOption(option);
    renderProfileRadarDims(dimLabels, dataValues);
    showProfileRadarDimDetail(profileRadarActiveIdx);
}

function renderGrowthPath(paths) {
    let container = document.getElementById('growth-path-box');
    if (!container) return;

    container.style.display = 'block';
    const safePaths = (Array.isArray(paths) ? paths : [])
        .map(p => ({
            type: p && p.type ? p.type : '',
            icon: (p && p.icon) ? p.icon : 'ri-lightbulb-line',
            title: String((p && p.title) || '').trim(),
            desc: String((p && p.desc) || '').trim(),
            impact: Number((p && p.impact) || 0)
        }))
        .map(p => ({
            ...p,
            title: (/^(undefined|null)$/i.test(p.title) ? '' : p.title),
            desc: (/^(undefined|null)$/i.test(p.desc) ? '' : p.desc)
        }))
        .filter(p => p.title || p.desc);

    if (!safePaths.length) {
        container.innerHTML = '<div style="color:#ccc; text-align:center; padding:16px;">暂无成长建议</div>';
        return;
    }

    let html = `<div class="card" style="padding:16px; margin-top:16px;">
        <div style="font-size:14px; font-weight:bold; margin-bottom:12px;">
            <i class="ri-route-line" style="color:#7c3aed; margin-right:4px;"></i> 成长路径建议
        </div>`;

    safePaths.forEach(p => {
        const colors = { edu: '#2563eb', skill: '#10b981', city: '#f59e0b' };
        const color = colors[p.type] || '#7c3aed';

        html += `
        <div style="display:flex; align-items:center; padding:10px; background:#fafafa; border-radius:8px; margin-bottom:8px; border-left:3px solid ${color};">
            <div style="width:36px; height:36px; border-radius:50%; background:${color}15; display:flex; align-items:center; justify-content:center; margin-right:12px;">
                <i class="${p.icon}" style="color:${color}; font-size:18px;"></i>
            </div>
            <div style="flex:1;">
                <div style="font-weight:bold; font-size:13px; color:#333;">${p.title || '成长建议'}</div>
                <div style="font-size:12px; color:#888; margin-top:2px;">${p.desc || '请结合画像结果持续优化求职策略。'}</div>
            </div>
            ${p.impact > 0 ? `<div style="text-align:right; min-width:70px;">
                <div style="font-size:16px; font-weight:bold; color:#10b981;">+¥${p.impact} <span title="该数值基于样本中掌握该能力与未掌握该能力岗位薪资中位数差值估算，仅供参考" style="cursor:help;color:#64748b;font-size:12px;">(?)</span></div>
                <div style="font-size:11px; color:#999;">预期提升</div>
            </div>` : ''}
        </div>`;
    });

    html += `</div>`;
    container.innerHTML = html;
}

function addSkill(txt) {
    appendProfileSkillTag(txt);
}

async function predictSalary() {
    const city = document.getElementById('p-city').value;
    const edu = document.getElementById('p-edu').value;
    const exp = document.getElementById('p-exp').value;

    if (!city || !edu || !exp) return showToast("请先完善意向城市、学历和经验", "error");
    const actionBtn = document.querySelector('#tab-profile button[onclick="predictSalary()"]');
    setButtonLoading(actionBtn, '评估中...');

    const box = document.getElementById('pred-res');
    const insightBox = document.getElementById('insight-box');
    const txt = document.getElementById('pred-text');
    const salarySummary = document.getElementById('salary-decision-summary');

    box.style.display = 'block';
    if (salarySummary) {
        salarySummary.style.display = 'none';
        salarySummary.innerHTML = '';
    }
    if (insightBox) insightBox.style.display = 'none';
    txt.innerHTML = '🤖 系统正在全维计算您的市场身价...';

    if (!charts.gauge) charts.gauge = echarts.init(document.getElementById('gauge-chart'));
    charts.gauge.showLoading({ text: '深度分析中', color: '#7c3aed', textColor: '#7c3aed', maskColor: 'rgba(255, 255, 255, 0.8)' });

    try {
        const r = await fetch('/api/predict_salary', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                city,
                edu,
                exp,
                expected_salary_min: parseInt((document.getElementById('p-salary-min') || {}).value || '0', 10) || 0,
                expected_salary_max: parseInt((document.getElementById('p-salary-max') || {}).value || '0', 10) || 0
            })
        });
        const d = await r.json();
        charts.gauge.hideLoading();

        if (d.success) {
            const salary = Math.round(d.salary);
            const maxVal = salary > 45000 ? 100000 : 50000;

            charts.gauge.setOption({
                series: [{
                    type: 'gauge',
                    radius: '90%',
                    center: ['50%', '60%'],
                    startAngle: 180, endAngle: 0,
                    min: 0, max: maxVal, splitNumber: 5,
                    itemStyle: { color: '#7c3aed' },
                    progress: { show: true, width: 22 },
                    pointer: { show: true, length: '60%', width: 6, itemStyle: { color: '#7c3aed' } },
                    axisLine: { lineStyle: { width: 22, color: [[1, '#f0f0f0']] } },
                    axisTick: { show: false },
                    splitLine: { length: 12, lineStyle: { width: 2, color: '#999' } },
                    axisLabel: { distance: 25, color: '#999', fontSize: 12 },
                    detail: {
                        valueAnimation: true,
                        offsetCenter: [0, '30%'],
                        fontSize: 36,
                        fontWeight: 'bold',
                        formatter: '{value}',
                        color: '#333'
                    },
                    data: [{ value: salary, name: '月薪预测 (¥)' }],
                    title: { offsetCenter: [0, '65%'], fontSize: 14, color: '#999' }
                }]
            });

            // 打字机效果
            txt.innerHTML = `✅ 预测完成：你的市场薪资分位约 ${d.percentile}%`;

            if (d.analysis && insightBox) {
                setTimeout(() => {
                    insightBox.style.display = 'grid';
                    insightBox.style.opacity = 0;
                    insightBox.style.transform = 'translateY(10px)';
                    insightBox.style.transition = 'all 0.5s ease';

                    setTimeout(() => {
                        insightBox.style.opacity = 1;
                        insightBox.style.transform = 'translateY(0)';
                    }, 50);

                    if (document.getElementById('res-percent')) document.getElementById('res-percent').innerText = d.percentile + '%';
                    if (document.getElementById('res-edu-up')) document.getElementById('res-edu-up').innerText = '+' + (d.analysis.uplift_edu || 0);
                    if (document.getElementById('res-next-edu')) document.getElementById('res-next-edu').innerText = '补技能/项目';
                    if (document.getElementById('res-exp-up')) document.getElementById('res-exp-up').innerText = '+' + d.analysis.uplift_exp;
                }, 500);
            }

            // 薪资诊断决策摘要：输出“结论-原因-建议”
            if (salarySummary) {
                const expMin = parseInt((document.getElementById('p-salary-min') || {}).value || '0', 10) || 0;
                const expMax = parseInt((document.getElementById('p-salary-max') || {}).value || '0', 10) || 0;
                const lower = d.enhanced && d.enhanced.confidence ? Number(d.enhanced.confidence.lower || 0) : Math.round(salary * 0.85);
                const upper = d.enhanced && d.enhanced.confidence ? Number(d.enhanced.confidence.upper || 0) : Math.round(salary * 1.15);
                const target = expMax > 0 ? expMax : (expMin > 0 ? expMin : salary);
                const salaryDecision = d.salary_decision || {};
                const tone = salaryDecision.tone || 'good';
                const conclusion = salaryDecision.conclusion || '当前薪资预期与市场较匹配，可按该区间优先投递';
                const reason = salaryDecision.reason || `预测月薪约 ¥${salary.toLocaleString()}，参考区间 ¥${Math.round(lower).toLocaleString()} - ¥${Math.round(upper).toLocaleString()}，你的目标约 ¥${Math.round(target).toLocaleString()}。`;
                const suggestion = salaryDecision.suggestion || (tone === 'risk'
                    ? '建议先用主申岗位验证面试通过率，谈薪时先报区间中位，再根据面试反馈上调。'
                    : (tone === 'mid'
                        ? '可将目标薪资适度上调到预测中位附近，并在简历中强化项目成果以支撑报价。'
                        : '建议优先投递匹配度高岗位，并把期望薪资设置在预测区间中高位。'));
                salarySummary.style.display = 'block';
                if (typeof renderDecisionCardLite === 'function') {
                    salarySummary.innerHTML = renderDecisionCardLite('薪资投递决策摘要', conclusion, reason, suggestion, tone);
                } else {
                    salarySummary.innerHTML = `<div><b>结论：</b>${conclusion}<br><b>原因：</b>${reason}<br><b>建议：</b>${suggestion}</div>`;
                }
            }

            // 新增：展示增强预测数据（置信区间+情景模拟）
            showEnhancedPrediction(d);
            renderSalaryRanges(d, salary);

            // 新增：叠加用户期望薪资在市场中的分位定位
            try {
                const expectPayload = {
                    city,
                    edu_level: edu,
                    exp_year: exp,
                    expected_salary_min: parseInt((document.getElementById('p-salary-min') || {}).value || '0', 10) || 0,
                    expected_salary_max: parseInt((document.getElementById('p-salary-max') || {}).value || '0', 10) || 0
                };
                const sr = await fetch('/api/salary/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(expectPayload)
                });
                const sd = await sr.json();
                renderSalaryPositionCard(sd);
            } catch (_) {
                renderSalaryPositionCard(null);
            }
        } else {
            txt.innerHTML = `⚠️ ${d.msg}`;
            renderSalaryPositionCard(null);
            renderSalaryRanges(null, 0);
        }
    } catch (e) {
        charts.gauge.hideLoading();
        txt.innerHTML = '❌ 计算出错，请稍后重试';
        renderSalaryPositionCard(null);
        renderSalaryRanges(null, 0);
    } finally {
        clearButtonLoading(actionBtn);
    }
}

function renderSalaryRanges(data, salary) {
    const box = document.getElementById('salary-range-box');
    if (!box) return;
    if (!data || !data.success) {
        box.style.display = 'none';
        return;
    }
    const s = Number(salary || data.salary || 0);
    const lower = (data.enhanced && data.enhanced.confidence) ? Number(data.enhanced.confidence.lower || 0) : Math.round(s * 0.85);
    const upper = (data.enhanced && data.enhanced.confidence) ? Number(data.enhanced.confidence.upper || 0) : Math.round(s * 1.15);
    const safeLowMax = Math.max(lower, Math.round(s * 0.95));
    const normalMin = safeLowMax;
    const normalMax = upper;
    const highMin = Math.round(upper * 1.06);
    box.style.display = 'grid';
    box.innerHTML = `
        <div class="salary-range-row low">保守区间：¥${Math.round(lower).toLocaleString()} ~ ¥${Math.round(safeLowMax).toLocaleString()}</div>
        <div class="salary-range-row mid">正常区间：¥${Math.round(normalMin).toLocaleString()} ~ ¥${Math.round(normalMax).toLocaleString()}（推荐起点）</div>
        <div class="salary-range-row high">冲刺目标：¥${Math.round(highMin).toLocaleString()}+（建议补齐关键技能后冲刺）</div>
    `;
}

function renderSalaryPositionCard(payload) {
    const card = document.getElementById('salary-position-card');
    const text = document.getElementById('salary-position-text');
    const pMarker = document.getElementById('salary-position-predict');
    const eMarker = document.getElementById('salary-position-expect');
    if (!card || !text || !pMarker || !eMarker) return;

    if (!payload || !payload.success || !payload.data) {
        card.style.display = 'none';
        return;
    }
    const data = payload.data || {};
    const marketPct = Math.max(0, Math.min(100, Number(data.percentile || 0)));
    const expectedRaw = data.expected_salary_percentile;
    const expectedPct = (expectedRaw === null || expectedRaw === undefined) ? null : Math.max(0, Math.min(100, Number(expectedRaw)));

    card.style.display = 'block';
    pMarker.style.left = `${marketPct}%`;
    pMarker.title = `市场预测分位 ${marketPct}%`;
    if (expectedPct === null || Number.isNaN(expectedPct)) {
        eMarker.style.display = 'none';
        text.innerText = `市场预测位置约 ${marketPct}% 分位。${data.diagnosis || '填写期望薪资后可查看个性化定位。'}`;
    } else {
        eMarker.style.display = 'block';
        eMarker.style.left = `${expectedPct}%`;
        eMarker.title = `你的期望分位 ${expectedPct}%`;
        const diff = expectedPct - marketPct;
        const sign = diff >= 0 ? '+' : '';
        text.innerText = `你的期望薪资位于市场约 ${expectedPct}% 分位；预测位置约 ${marketPct}% 分位（差值 ${sign}${Math.round(diff)}%）。${data.diagnosis || ''}`;
    }
}

// 新增：展示增强预测数据（置信区间+情景模拟）
function showEnhancedPrediction(predData) {
    const confBox = document.getElementById('pred-confidence');
    const scenBox = document.getElementById('pred-scenarios');

    // 从仪表盘缓存的增强预测数据中读取，或者直接使用预测接口返回的数据
    const enhanced = predData.enhanced || null;

    if (enhanced && confBox) {
        confBox.style.display = 'block';
        confBox.style.opacity = 0;
        confBox.style.transition = 'opacity 0.5s ease';
        setTimeout(() => { confBox.style.opacity = 1; }, 100);

        const confLevel = document.getElementById('pred-conf-level');
        const confRange = document.getElementById('pred-conf-range');
        const sampleSize = document.getElementById('pred-sample-size');

        if (confLevel && enhanced.confidence) {
            confLevel.textContent = enhanced.confidence.level || '--';
        }
        if (confRange && enhanced.confidence) {
            const low = enhanced.confidence.lower || 0;
            const up = enhanced.confidence.upper || 0;
            confRange.textContent = '¥' + low.toLocaleString() + ' ~ ¥' + up.toLocaleString();
        }
        if (sampleSize && enhanced.confidence) {
            sampleSize.textContent = (enhanced.confidence.sample_size || '--') + ' 份';
        }
        const friendly = document.getElementById('pred-conf-friendly');
        if (friendly && enhanced.confidence) {
            const level = String(enhanced.confidence.level || '中').trim();
            const dotCls = level.includes('高') ? 'good' : (level.includes('低') ? 'low' : 'mid');
            friendly.innerHTML = `<span class="pred-conf-dot ${dotCls}"></span>本次预测基于 ${enhanced.confidence.sample_size || '--'} 条相似岗位数据，可信度为${level}，建议结合面试反馈动态调整期望薪资。`;
        }

        // 情景模拟卡片化重构
        if (enhanced.scenarios && enhanced.scenarios.length > 0 && scenBox) {
            scenBox.style.display = 'block';
            scenBox.style.opacity = 0;
            scenBox.style.transition = 'opacity 0.5s ease';
            setTimeout(() => { scenBox.style.opacity = 1; }, 300);

            const tableBox = document.getElementById('scenario-table-box');
            if (tableBox) {
                let html = '<div style="display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#64748b;margin-bottom:8px;"><span>场景</span><span>预测薪资</span><span>相对当前变化</span></div><div style="display:flex; flex-direction:column; gap:12px;">';
                enhanced.scenarios.forEach((s, idx) => {
                    const diff = s.diff || 0;
                    const diffColor = diff > 0 ? '#10b981' : (diff < 0 ? '#ef4444' : '#64748b');
                    const diffText = diff > 0 ? '+¥' + diff.toLocaleString() : (diff < 0 ? '-¥' + Math.abs(diff).toLocaleString() : '持平');

                    const bgStyle = diff > 0 ? 'background: linear-gradient(to right, #ffffff, #f0fdf4); border: 1px solid #d1fae5;' :
                        (diff < 0 ? 'background: linear-gradient(to right, #ffffff, #fef2f2); border: 1px solid #fee2e2;' : 'background: #ffffff; border: 1px solid #e2e8f0;');

                    const isCurrent = String(s.label || '').includes('当前');
                    html += `
                    <div class="scenario-card" style="${bgStyle} padding: 16px; border-radius: 12px; display: flex; align-items: center; justify-content: space-between; position: relative; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.02); transition: all 0.3s ease;">
                        <div style="display: flex; flex-direction: column; gap: 4px; z-index: 1;">
                            <div style="font-size: 14px; font-weight: 600; color: #334155;">${s.label}${isCurrent ? ' <span style="font-size:11px;color:#1d4ed8;background:#dbeafe;border-radius:999px;padding:1px 6px;">你在这里</span>' : ''}</div>
                            <div style="font-size: 12px; color: #64748b;">方案 ${idx + 1}</div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 20px; z-index: 1;">
                            <div style="text-align: right;">
                                <div style="font-size: 12px; color: #94a3b8; margin-bottom: 2px;">预测薪资</div>
                                <div style="font-size: 18px; font-weight: 700; color: #0f172a;">¥${s.salary.toLocaleString()}</div>
                            </div>
                            <div class="diff-indicator" style="background: ${diffColor}15; color: ${diffColor}; padding: 6px 12px; border-radius: 20px; font-weight: 700; font-size: 14px; min-width: 80px; text-align: center;">
                                ${diff > 0 ? '<i class="ri-arrow-up-line"></i>' : (diff < 0 ? '<i class="ri-arrow-down-line"></i>' : '')} ${diffText}
                            </div>
                        </div>
                    </div>`;
                });
                html += '</div>';
                tableBox.innerHTML = html;
            }
        }
    } else {
        if (confBox) confBox.style.display = 'none';
        if (scenBox) scenBox.style.display = 'none';
    }
}

// 辅助：执行步骤演示动画 (适配顶部的引擎动画区)
function runAnalysisAnimation(container, steps, onComplete) {
    // 隐藏主结果区，清理当前内容
    container.innerHTML = `<div style="text-align:center; padding: 60px 0;">
        <div class="ai-avatar" style="width:64px; height:64px; margin: 0 auto 24px; animation: pulseRing 2s infinite; background: var(--primary-gradient); color: white;">
            <i class="ri-brain-line"></i>
        </div>
        <h3 style="color: var(--gray-800); margin-bottom: 8px;">系统引擎深度运算中...</h3>
        <p style="color: var(--text-secondary); font-size: 14px;" id="ai-loading-text">正在初始化模型参数</p>
    </div>`;

    // 重置所有顶部步骤状态
    for (let i = 1; i <= 3; i++) {
        const icon = document.getElementById(`step${i}-icon`);
        const pct = document.getElementById(`step${i}-pct`);
        if (icon) icon.className = 'step-circle';
        if (pct) pct.innerText = '等待';
    }

    let current = 0;
    const loadingText = document.getElementById('ai-loading-text');

    const nextStep = () => {
        if (current >= 3) { // 3个固定步骤
            if (onComplete) onComplete();
            return;
        }

        const stepNum = current + 1;
        const icon = document.getElementById(`step${stepNum}-icon`);
        const pct = document.getElementById(`step${stepNum}-pct`);

        // 标记当前进行中
        if (icon) icon.className = 'step-circle is-active';
        if (pct) pct.innerText = '0%';
        if (loadingText && steps[current]) loadingText.innerText = steps[current].text;

        // 模拟进度增加
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.floor(Math.random() * 20) + 10;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                if (icon) icon.className = 'step-circle is-done';
                if (pct) pct.innerText = '完成';
                current++;
                setTimeout(nextStep, 300); // 步骤间停顿
            } else {
                if (pct) pct.innerText = progress + '%';
            }
        }, 80);
    };

    setTimeout(nextStep, 100);
}

// =========================================================
