﻿// 7. 导出 (保留原样)
// =========================================================
function openExportModal() {
    document.getElementById('export-modal').style.display = 'flex';
}

function selectExportType(type, el) {
    currentExportType = type;
    document.getElementById('export-suffix').innerText = '.' + type;
    document.querySelectorAll('.export-option').forEach(opt => opt.classList.remove('selected'));
    if (el) el.classList.add('selected');
}

async function executeExport() {
    const filename = document.getElementById('export-name').value;
    if (!filename) return showToast('请输入文件名', 'error');
    const actionBtn = document.querySelector('#export-modal button[onclick="executeExport()"]');
    setButtonLoading(actionBtn, '导出中...');

    // Collect filters
    const city = document.getElementById('exp-city').value;
    const kw = document.getElementById('exp-kw').value;
    const salary = document.getElementById('exp-salary').value;
    const dateStart = document.getElementById('exp-date').value;

    showToast('🚀 正在生成报告...');
    document.getElementById('export-modal').style.display = 'none';

    try {
        const r = await fetch('/api/export', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: filename,
                format: currentExportType,
                city: city,
                keyword: kw,
                salary_min: salary,
                date_start: dateStart
            })
        });
        if (!r.ok) throw new Error('Export failed');
        const blob = await r.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename + '.' + currentExportType;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        showToast('✅ 导出成功');
    } catch (e) {
        console.error(e);
        showToast('导出失败, 请重试', 'error');
    } finally {
        clearButtonLoading(actionBtn);
    }
}

async function startSpider() {
    const kwInput = document.getElementById('new-spider-kw');
    const cityInput = document.getElementById('spider-city');
    const expInput = document.getElementById('spider-exp');
    const planInput = document.getElementById('spider-plan');
    const targetInput = document.getElementById('spider-target');
    const headlessInput = document.getElementById('chk-headless');
    const sourceCheckbox = document.getElementById('chk-liepin');
    const useLiepin = sourceCheckbox ? !!sourceCheckbox.checked : true;
    const mode = ((document.getElementById('spider-ui-mode') || {}).value || 'simple').toLowerCase();

    if (!kwInput || !kwInput.value) return showToast("请输入关键词", "error");
    if (!useLiepin) return showToast("请勾选猎聘网", "error");

    const btnStart = document.getElementById('btn-spider');
    const btnStop = document.getElementById('btn-spider-stop');

    // 切换按钮状态 & 显示加载
    btnStart.style.display = 'none';
    if (btnStop) btnStop.style.display = 'inline-flex';

    // 启动扫描线动画
    const scanLine = document.getElementById('scan-line');
    if (scanLine) scanLine.classList.add('active');

    // 重置进度条
    document.getElementById('spider-progress').style.width = '0%';
    document.getElementById('progress-text').innerText = '正在初始化...';
    document.getElementById('progress-percent').innerText = '0%';

    // 清空并初始化日志 (注意：现在是 log-content)
    const logBox = document.getElementById('log-content');
    const uiCity = (cityInput && cityInput.value) ? cityInput.value : '全国';
    const uiExp = (expInput && expInput.value) ? expInput.value : '不限';
    const uiTarget = (targetInput && targetInput.value) ? targetInput.value : '300';
    const uiPlan = (planInput && planInput.value) ? planInput.value : 'standard';
    if (logBox) {
        logBox.innerHTML = '';
        appendLogLine('info', '🚀 智能采集任务已启动...');
        appendLogLine('info', `🎯 目标：${uiCity} - ${kwInput.value} (策略${uiPlan}, 目标${uiTarget}条, 模式${mode === 'expert' ? '专家' : '极简'})`);
    }

    let sources = [];
    if (useLiepin) sources.push('liepin');

    try {
        const r = await fetch('/api/spider/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                keyword: kwInput.value,
                city: uiCity,
                exp: uiExp,
                sources: sources,
                plan: uiPlan,
                target_count: parseInt(uiTarget) || 300,
                headless: headlessInput ? !!headlessInput.checked : false
            })
        });
        const d = await r.json();

        if (d.success) {
            showToast('引擎调度成功', 'success');
            loadSpiderHistory();
            if (spiderTimer) clearInterval(spiderTimer);
            spiderTimer = setInterval(pollLogs, 1500);
        } else {
            showToast(d.msg, 'error');
            resetSpiderButton();
        }
    } catch (e) {
        showToast("服务连接失败", "error");
        resetSpiderButton();
    }
}

function setSpiderTargetPreset(val) {
    const target = document.getElementById('spider-target');
    if (target) target.value = String(val);
}

function resetSpiderForm() {
    const kw = document.getElementById('new-spider-kw');
    const plan = document.getElementById('spider-plan');
    const target = document.getElementById('spider-target');
    const headless = document.getElementById('chk-headless');
    const mode = document.getElementById('spider-ui-mode');
    if (kw) kw.value = '';
    if (plan) plan.value = 'standard';
    if (target) target.value = '300';
    if (headless) headless.checked = false;
    if (mode) mode.value = 'simple';
    toggleSpiderUiMode();
    const progress = document.getElementById('spider-progress');
    const text = document.getElementById('progress-text');
    const percent = document.getElementById('progress-percent');
    if (progress) progress.style.width = '0%';
    if (text) text.innerText = '就绪';
    if (percent) percent.innerText = '0%';
}

function toggleSpiderUiMode() {
    const mode = ((document.getElementById('spider-ui-mode') || {}).value || 'simple').toLowerCase();
    const advanced = document.getElementById('spider-advanced-options');
    const summary = document.getElementById('spider-filter-summary');
    if (advanced) advanced.style.display = mode === 'expert' ? 'grid' : 'none';
    if (summary) {
        const target = ((document.getElementById('spider-target') || {}).value || '300');
        const plan = ((document.getElementById('spider-plan') || {}).value || 'standard');
        if (mode === 'expert') {
            const retry = ((document.getElementById('spider-retry') || {}).value || '3');
            const timeout = ((document.getElementById('spider-timeout') || {}).value || '30');
            summary.innerText = `策略${plan} / 目标${target}条 / 重试${retry}次 / 超时${timeout}s`;
        } else {
            summary.innerText = `策略${plan} / 目标${target}条 / 已启用极简模式`;
        }
    }
}

async function pollLogs() {
    try {
        const r = await fetch('/api/spider/logs');
        const d = await r.json();
        if (!d.success) return;

        const logs = Array.isArray(d.logs) ? d.logs : [];
        const box = document.getElementById('log-content');
        if (box) {
            box.innerHTML = logs.map(line => `<div class="log-item">${line}</div>`).join('');
            box.scrollTop = box.scrollHeight;
        }

        const stats = d.stats || {};
        const progressVal = Number(stats.progress || 0);
        const progress = document.getElementById('spider-progress');
        const text = document.getElementById('progress-text');
        const percent = document.getElementById('progress-percent');
        if (progress) progress.style.width = `${Math.max(0, Math.min(100, progressVal))}%`;
        if (text) text.innerText = `已采集 ${stats.added || 0} / 目标 ${stats.target || 0}`;
        if (percent) percent.innerText = `${progressVal}%`;

        if (!d.running) {
            if (spiderTimer) {
                clearInterval(spiderTimer);
                spiderTimer = null;
            }
            resetSpiderButton();
            loadSpiderHistory();
            if (progressVal >= 100 || (stats.added || 0) > 0) {
                showToast(`采集结束，新增 ${stats.added || 0} 条`, 'success');
                if ((stats.added || 0) > 0) {
                    loadData(1);
                    updateSummary();
                }
            } else {
                const hints = Array.isArray(d.error_hints) ? d.error_hints : [];
                if (hints.length > 0) {
                    const msg = hints[0].suggestion ? `${hints[0].type || '异常'}：${hints[0].suggestion}` : `${hints[0].type || '异常'}，请查看日志`;
                    showToast(`采集结束：${msg}`, 'error');
                } else {
                    showToast('采集结束，未获取到数据', 'error');
                }
            }
        }
    } catch (e) {
        // 轮询异常不打断采集，只提示一次
        if (spiderTimer) {
            clearInterval(spiderTimer);
            spiderTimer = null;
        }
        resetSpiderButton();
        showToast('日志轮询失败，请稍后重试', 'error');
    }
}

// 辅助：追加日志行 (打字机特效)
function appendLogLine(type, text) {
    const box = document.getElementById('log-content');
    if (!box) return;

    // 移除初始状态的占位提示语
    const placeholder = box.querySelector('.log-placeholder');
    if (placeholder) placeholder.remove();

    const div = document.createElement('div');
    div.className = `log-item ${type}`;
    const time = new Date().toLocaleTimeString();

    const timeSpan = document.createElement('span');
    timeSpan.style.cssText = 'opacity:0.5; font-size:11px; margin-right:6px;';
    timeSpan.innerText = `[${time}]`;
    div.appendChild(timeSpan);

    const textSpan = document.createElement('span');
    div.appendChild(textSpan);
    box.appendChild(div);

    // 黑客终端式的逐字输出动画
    let i = 0;
    function typeChar() {
        if (i < text.length) {
            textSpan.innerHTML += text.charAt(i);
            i++;
            // 自动推到最底部
            box.scrollTop = box.scrollHeight;
            // 随机 5 到 25 ms 间隔产生真实打字感
            setTimeout(typeChar, Math.random() * 20 + 5);
        }
    }
    typeChar();
}

// 2. 🔥🔥 核心修复：日志轮询 (适配新UI) 🔥🔥


// 3. 新增：停止采集函数
function stopSpider() {
    showConfirm('停止采录', '确定要强制停止采集吗？可能导致当前页数据断层。', '停止', 'danger', async () => {
        try {
            await fetch('/api/spider/stop', { method: 'POST' });
            showToast("已发送停止指令...", "warning");
            appendLogLine('warning', '🛑 正在停止任务...');
        } catch (e) {
            showToast("停止失败", "error");
        }
    });
}

function formatSpiderTaskLabel(item) {
    const started = item && item.started_at ? item.started_at : '--';
    const finished = item && item.finished_at ? item.finished_at : '进行中';
    return `${started} -> ${finished}`;
}

function renderSpiderHistory(items) {
    const root = document.getElementById('spider-history-list');
    if (!root) return;
    const list = Array.isArray(items) ? items : [];
    if (!list.length) {
        root.innerHTML = '<div style="font-size:13px; color:#64748b;">暂无采集记录</div>';
        return;
    }
    root.innerHTML = list.map(item => {
        const statusTone = item.status === 'done'
            ? '#16a34a'
            : (item.status === 'stopped' ? '#d97706' : (item.status === 'failed' ? '#dc2626' : '#2563eb'));
        const sources = Array.isArray(item.sources) && item.sources.length ? item.sources.join(' / ') : '猎聘';
        return `
            <div style="border:1px solid #e2e8f0; border-radius:10px; padding:12px; background:#f8fafc;">
                <div style="display:flex; justify-content:space-between; gap:12px; align-items:flex-start;">
                    <div>
                        <div style="font-weight:700; color:#0f172a;">${item.keyword || '未命名任务'} <span style="font-size:12px; color:#64748b;">${item.city || '全国'} / ${item.exp || '不限'}</span></div>
                        <div style="font-size:12px; color:#64748b; margin-top:4px;">${formatSpiderTaskLabel(item)} / 来源：${sources}</div>
                    </div>
                    <span style="font-size:12px; padding:4px 10px; border-radius:999px; background:${statusTone}15; color:${statusTone};">${item.status || 'unknown'}</span>
                </div>
                <div style="display:flex; gap:16px; flex-wrap:wrap; margin-top:10px; font-size:12px; color:#334155;">
                    <span>目标 ${item.target_count || 0}</span>
                    <span>入库 ${item.added || 0}</span>
                    <span>扫描 ${item.scanned || 0}</span>
                    <span>过滤 ${item.filtered || 0}</span>
                    <span>页数上限 ${item.max_pages || 0}</span>
                    <span>进度 ${item.progress || 0}%</span>
                </div>
                ${item.error_message ? `<div style="margin-top:8px; font-size:12px; color:#b91c1c;">${item.error_message.replace(/\n/g, '<br>')}</div>` : ''}
            </div>
        `;
    }).join('');
}

async function loadSpiderHistory() {
    const root = document.getElementById('spider-history-list');
    if (!root) return;
    try {
        const r = await fetch('/api/spider/history');
        const d = await r.json();
        if (!d.success) return;
        renderSpiderHistory(d.data || []);
    } catch (e) {
        if (root && !root.innerHTML.trim()) {
            root.innerHTML = '<div style="font-size:13px; color:#64748b;">采集记录加载失败</div>';
        }
    }
}

function clearProfileInputs() {
    const clearIds = ['p-job', 'p-edu', 'p-exp', 'p-skills'];
    clearIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const cityEl = document.getElementById('p-city');
    if (cityEl) cityEl.value = '北京';
}

function resetSpiderButton() {
    const btnStart = document.getElementById('btn-spider');
    const btnStop = document.getElementById('btn-spider-stop');
    const btnAutoStart = document.getElementById('btn-spider-auto');
    const btnAutoStop = document.getElementById('btn-spider-auto-stop');
    const scanLine = document.getElementById('scan-line');

    if (btnStart) {
        btnStart.style.display = 'inline-flex';
        btnStart.disabled = false;
        btnStart.innerHTML = '<i class="ri-rocket-2-fill" style="margin-right:6px"></i> 启动采集';
    }
    if (btnStop) btnStop.style.display = 'none';

    if (btnAutoStart) {
        btnAutoStart.style.display = 'inline-flex';
        btnAutoStart.disabled = false;
        btnAutoStart.innerHTML = '<i class="ri-rocket-2-fill"></i> 一键智能采集';
    }
    if (btnAutoStop) btnAutoStop.style.display = 'none';

    if (scanLine) scanLine.classList.remove('active');
}

function backupDatabase() {
    showToast('个人版暂不提供数据库备份入口，请使用系统导出功能。', 'warning');
}

function downloadLogs() {
    showToast('个人版暂不提供日志下载入口。', 'warning');
}

function switchSpiderMode(mode) {
    const autoPanel = document.getElementById('spider-auto-panel');
    const manualPanel = document.getElementById('spider-manual-panel');
    const tabAuto = document.getElementById('tab-auto-mode');
    const tabManual = document.getElementById('tab-manual-mode');
    if (!autoPanel || !manualPanel) return;

    if (mode === 'auto') {
        autoPanel.style.display = 'block';
        manualPanel.style.display = 'none';
        if (tabAuto) {
            tabAuto.classList.add('active');
            tabAuto.style.borderBottom = '2px solid #10b981';
            tabAuto.style.color = '#064e3b';
            tabAuto.style.fontWeight = '700';
        }
        if (tabManual) {
            tabManual.classList.remove('active');
            tabManual.style.borderBottom = 'none';
            tabManual.style.color = '#64748b';
            tabManual.style.fontWeight = 'normal';
        }
    } else {
        autoPanel.style.display = 'none';
        manualPanel.style.display = 'block';
        if (tabManual) {
            tabManual.classList.add('active');
            tabManual.style.borderBottom = '2px solid #10b981';
            tabManual.style.color = '#064e3b';
            tabManual.style.fontWeight = '700';
        }
        if (tabAuto) {
            tabAuto.classList.remove('active');
            tabAuto.style.borderBottom = 'none';
            tabAuto.style.color = '#64748b';
            tabAuto.style.fontWeight = 'normal';
        }
    }
}

async function startSpiderAuto() {
    const btnStart = document.getElementById('btn-spider-auto');
    const btnStop = document.getElementById('btn-spider-auto-stop');
    const logBox = document.getElementById('log-content');

    setButtonLoading(btnStart, '分析画像中...');
    let keyword = 'Python';
    let city = '全国';
    try {
        const pRes = await fetch('/api/profile/load');
        const pData = await pRes.json();
        if (pData.success && pData.data) {
            const profile = pData.data;
            if (profile.target_jobs) {
                const jobs = profile.target_jobs.split(/[,\/，、]/).filter(x => x).map(x => x.trim());
                if (jobs.length > 0) keyword = jobs[0];
            }
            if (profile.city) {
                const c = profile.city.split(',')[0].trim();
                if (c) city = c;
            }
        }
    } catch (e) {
        console.warn('获取画像失败，使用默认值');
    }

    clearButtonLoading(btnStart);
    btnStart.style.display = 'none';
    if (btnStop) btnStop.style.display = 'inline-flex';

    if (logBox) {
        logBox.innerHTML = '';
        appendLogLine('info', '🚀 智能一键模式启动！自动匹配专属画像...');
        appendLogLine('info', `🎯 推导目标：${city} - ${keyword} (标准策略, 300条)`);
    }

    try {
        const r = await fetch('/api/spider/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                keyword: keyword,
                city: city,
                exp: '不限',
                sources: ['liepin'],
                plan: 'standard',
                target_count: 300,
                headless: false
            })
        });
        const d = await r.json();

        if (d.success) {
            showToast('一键调度成功', 'success');
            loadSpiderHistory();
            if (spiderTimer) clearInterval(spiderTimer);
            spiderTimer = setInterval(pollLogs, 1500);
        } else {
            showToast(d.msg, 'error');
            resetSpiderButton();
        }
    } catch (e) {
        showToast("服务连接失败", "error");
        resetSpiderButton();
    }
}

window.onresize = () => Object.values(charts).forEach(c => c && c.resize && c.resize());
document.addEventListener('DOMContentLoaded', () => {
    toggleSpiderUiMode();
    loadSpiderHistory();
});
// =========================================================
