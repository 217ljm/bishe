﻿// =========================================================
// 3. 认证与菜单逻辑 (保留原样)
// =========================================================
function toggleAuthMode() {
    isRegister = !isRegister;
    const titleEl = document.getElementById('auth-title');
    const toggleEl = document.getElementById('auth-toggle');
    const actionEl = document.getElementById('btn-auth-action');
    const toggleTextEl = document.getElementById('auth-toggle-text');
    if (titleEl) titleEl.innerText = isRegister ? '创建新账号' : '欢迎登录';
    if (toggleEl) toggleEl.innerText = isRegister ? '去登录' : '去注册';
    if (actionEl) actionEl.innerText = isRegister ? '立即注册' : '立即登录';
    if (toggleTextEl) toggleTextEl.innerText = isRegister ? '已有账号？' : '还没有账号？';
    setAuthInlineMsg('');
}

function closeModal() {
    const modal = document.getElementById('analysis-modal');
    if (modal) modal.style.display = 'none';
}

function setAuthInlineMsg(msg, type = 'error') {
    const el = document.getElementById('auth-inline-msg');
    if (!el) return;
    const text = String(msg || '').trim();
    el.classList.remove('is-error', 'is-success');
    if (!text) {
        el.innerText = '';
        return;
    }
    el.classList.add(type === 'success' ? 'is-success' : 'is-error');
    el.innerText = text;
}

function applyRememberedAccount() {
    const remember = localStorage.getItem('auth_remember') === '1';
    const savedUser = localStorage.getItem('auth_saved_username') || '';
    const rememberEl = document.getElementById('auth-remember');
    const userEl = document.getElementById('login-u');
    if (rememberEl) rememberEl.checked = remember;
    if (userEl && remember && savedUser) userEl.value = savedUser;
}

function bindAuthEnterSubmit() {
    const userEl = document.getElementById('login-u');
    const passEl = document.getElementById('login-p');
    const onKeydown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            handleAuth();
        }
    };
    if (userEl) userEl.addEventListener('keydown', onKeydown);
    if (passEl) passEl.addEventListener('keydown', onKeydown);
}

function setAppAuthLock(locked) {
    document.body.classList.toggle('app-auth-locked', !!locked);
}

function ensureMainScrollLayout() {
    if (document.body.classList.contains('app-auth-locked')) return;
    const main = document.querySelector('.main');
    const header = document.querySelector('.main > header') || document.querySelector('header');
    const viewBody = document.querySelector('.view-body');
    const sidebar = document.querySelector('.sidebar');
    if (!main || !viewBody) return;
    // 用 JS 兜底锁定滚动模型，防止多份 CSS 相互覆盖导致部分页面无法滚动。
    document.body.style.setProperty('overflow', 'hidden', 'important');
    document.body.style.setProperty('height', '100vh', 'important');

    if (sidebar) {
        sidebar.style.setProperty('height', '100vh', 'important');
        sidebar.style.setProperty('overflow-y', 'auto', 'important');
        sidebar.style.setProperty('overflow-x', 'hidden', 'important');
    }

    main.style.setProperty('display', 'flex', 'important');
    main.style.setProperty('flex-direction', 'column', 'important');
    main.style.setProperty('flex', '1 1 auto', 'important');
    main.style.setProperty('min-height', '0', 'important');
    main.style.setProperty('overflow-y', 'auto', 'important');
    main.style.setProperty('overflow-x', 'hidden', 'important');
    main.style.setProperty('height', '100vh', 'important');

    if (header) {
        header.style.setProperty('flex-shrink', '0', 'important');
    }

    viewBody.style.setProperty('display', 'block', 'important');
    viewBody.style.setProperty('flex', '0 0 auto', 'important');
    viewBody.style.setProperty('min-height', 'auto', 'important');
    viewBody.style.setProperty('overflow', 'visible', 'important');
    viewBody.style.setProperty('height', 'auto', 'important');
    viewBody.style.setProperty('max-height', 'none', 'important');

    document.querySelectorAll('.view-body > .tab-content').forEach((tab) => {
        tab.style.setProperty('height', 'auto', 'important');
        tab.style.setProperty('max-height', 'none', 'important');
        tab.style.setProperty('overflow', 'visible', 'important');
    });
}

async function handleAuth() {
    console.log("HandleAuth Triggered");
    const userEl = document.getElementById('login-u');
    const passEl = document.getElementById('login-p');
    if (!userEl || !passEl) {
        showToast("登录表单未找到，请刷新页面后重试", 'error');
        return;
    }
    const u = userEl.value, p = passEl.value;
    if (!u || !p) {
        setAuthInlineMsg('请输入账号密码', 'error');
        return showToast("请输入账号密码", 'error');
    }
    setAuthInlineMsg('');
    try {
        const res = await fetch(isRegister ? '/api/register' : '/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: u, password: p })
        });
        const d = await res.json();
        if (d.success) {
            if (isRegister) {
                showToast('注册成功');
                setAuthInlineMsg('注册成功，请登录', 'success');
                toggleAuthMode();
            } else {
                const overlay = document.getElementById('auth-overlay');
                if (overlay) overlay.style.display = 'none';
                setAppAuthLock(false);
                ensureMainScrollLayout();
                const nameEl = document.getElementById('display-username');
                if (nameEl) nameEl.innerText = d.username || u;
                if (d.role) {
                    const roleElem = document.getElementById('display-role');
                    if (roleElem) roleElem.innerText = d.role;
                }
                const rememberEl = document.getElementById('auth-remember');
                const remember = !!(rememberEl && rememberEl.checked);
                if (remember) {
                    localStorage.setItem('auth_remember', '1');
                    localStorage.setItem('auth_saved_username', d.username || u);
                } else {
                    localStorage.removeItem('auth_remember');
                    localStorage.removeItem('auth_saved_username');
                }
                clearProfileInputs();
                if (!window.__dashboard_initialized_once) {
                    window.__dashboard_initialized_once = true;
                    initDashboard();
                } else {
                    updateSummary();
                }
                if (typeof loadSystemInfo === 'function') {
                    setTimeout(() => loadSystemInfo(), 200);
                }
                checkAndShowOnboarding(d.username || u);
            }
        } else {
            const msg = d.msg || (isRegister ? '注册失败' : '登录失败');
            setAuthInlineMsg(msg, 'error');
            showToast(msg, 'error');
        }
    } catch (e) {
        console.error(e);
        setAuthInlineMsg("请求失败，请检查网络或服务器状态", 'error');
        showToast("请求失败，请检查网络或服务器状态", 'error');
    }
}

async function handleLogout() {
    if (confirm('确定要退出登录吗？')) {
        try {
            await fetch('/api/logout', { method: 'POST' });
        } catch (e) {
        }
        localStorage.removeItem('job_flow_step');
        localStorage.removeItem('competitiveness_done');
        localStorage.removeItem('improve_action_done');
        localStorage.removeItem('competitiveness_profile_fp');
        localStorage.removeItem('improve_profile_fp');
        location.reload();
    }
}

function logout() {
    return handleLogout();
}

function initAuthOverlayState() {
    const overlay = document.getElementById('auth-overlay');
    if (!overlay) return;
    window.__dashboard_initialized_once = false;
    setAppAuthLock(true);
    overlay.style.display = 'flex';
    applyRememberedAccount();
    bindAuthEnterSubmit();
    setAuthInlineMsg('');
    // 默认展示登录界面，不再自动按历史会话跳过登录。
    // 用户明确登录后再初始化主系统页面。
    window.addEventListener('resize', ensureMainScrollLayout);
}

document.addEventListener('DOMContentLoaded', initAuthOverlayState);
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (typeof loadSystemInfo === 'function') {
            loadSystemInfo();
        }
    }, 1200);
    setTimeout(ensureMainScrollLayout, 120);
});



function isNarrowLayout() {
    return window.innerWidth <= 1024;
}

function toggleSidebar() {
    if (!isNarrowLayout()) return;
    document.body.classList.toggle('sidebar-open');
}

function closeSidebar() {
    document.body.classList.remove('sidebar-open');
}

async function fetchJsonWithTimeout(url, options = {}, timeoutMs = 12000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        const resp = await fetch(url, { ...options, signal: controller.signal });
        const body = await resp.json().catch(() => ({}));
        return { ok: resp.ok, status: resp.status, body };
    } finally {
        clearTimeout(timer);
    }
}

function goToProfileStart() {
    switchTab('profile');
    setTimeout(() => {
        if (typeof switchProfileSubTab === 'function') switchProfileSubTab('basic');
        const input = document.getElementById('p-job');
        if (input && input.focus) input.focus();
    }, 60);
}

function goToDataEvaluate() {
    switchTab('data');
    setTimeout(() => {
        const panel = document.getElementById('job-eval-panel');
        if (panel && panel.scrollIntoView) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
}

function goToCompetitiveness() {
    switchTab('profile');
    setTimeout(() => {
        if (typeof switchProfileSubTab === 'function') switchProfileSubTab('compet');
        const panel = document.getElementById('compet-core-summary');
        if (panel && panel.scrollIntoView) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 90);
}

function dismissFirstUseGuide() {
    localStorage.setItem('first_use_guide_dismissed', '1');
    const el = document.getElementById('first-use-guide');
    if (el) el.style.display = 'none';
}

function switchTab(id, el) {
    const requestedId = id;
    if (id === 'competitiveness') {
        id = 'profile';
    }
    document.querySelectorAll('.tab-content').forEach(t => {
        t.style.display = 'none';
        t.classList.remove('active');
    });
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    const tab = document.getElementById('tab-' + id);
    if (!tab) return;
    tab.style.display = 'block';
    tab.classList.add('active');
    if (el) el.classList.add('active');

    const tabNameMap = {
        summary: '工作台',
        profile: '个人画像',
        data: '岗位决策',
        ai: '推荐计划',
        applications: '投递执行',
        dashboard: '市场分析',
        spider: '数据准备',
        settings: '系统设置'
    };
    const tabName = el
        ? el.innerText.replace(/^[^\u4e00-\u9fa5]+/, '').trim()
        : (tabNameMap[id] || id);
    const curTabEl = document.getElementById('cur-tab-title');
    if (curTabEl) curTabEl.innerText = tabName;

    const viewBody = document.querySelector('.view-body');
    if (viewBody) {
        // 切页后重新校正滚动容器样式，并回到顶部
        ensureMainScrollLayout();
        viewBody.scrollTop = 0;
    }
    const main = document.querySelector('.main');
    if (main) main.scrollTop = 0;
    tab.scrollTop = 0;

    setTimeout(() => {
        Object.values(charts).forEach(c => c && c.resize && c.resize());
        Object.values(dashCharts).forEach(c => c && c.resize && c.resize());
    }, 200);

    if (id === 'data') { loadData(1); loadDataQuality(); }
    if (id === 'profile') loadProfile();
    if (
        id === 'profile' &&
        (
            requestedId === 'competitiveness' ||
            (el && (el.getAttribute('title') || '').indexOf('竞争力') >= 0)
        )
    ) {
        setTimeout(() => switchProfileSubTab('compet'), 50);
    }
    if (id === 'summary' || id.startsWith('chart-')) updateSummary();
    if (id === 'chart-city' && cityDataCache.labels.length > 0) renderCityChart();
    if (id === 'dashboard') initAnalysisDashboard();
    if (id === 'spider' && typeof loadSpiderHistory === 'function') {
        loadSpiderHistory();
    }
    if (id === 'applications') {
        loadApplicationBoard();
        loadDeliveryDecisionPanel();
        loadApplicationTiming();
    }
    if (id === 'settings') {
        const run = () => {
            if (typeof loadSystemInfo === 'function') loadSystemInfo();
        };
        run();
        setTimeout(run, 300);
        setTimeout(run, 1000);
    }
    if (isNarrowLayout()) closeSidebar();
}

function updateSidebarBadges(profileScore = null, appRows = null) {
    const profileBadge = document.getElementById('sidebar-profile-badge');
    if (profileBadge) {
        const scoreNum = Number(profileScore);
        if (Number.isFinite(scoreNum) && scoreNum > 0) {
            profileBadge.innerText = scoreNum >= 80 ? `完成${scoreNum}%` : `${scoreNum}%`;
        } else {
            profileBadge.innerText = '待完善';
        }
    }

    const appBadge = document.getElementById('sidebar-app-badge');
    if (appBadge && Array.isArray(appRows)) {
        const todo = appRows.filter(x => {
            const key = normalizeAppStatusKey(x.status);
            return key === 'favorite' || key === 'applied';
        }).length;
        appBadge.innerText = `${todo}待跟进`;
    }
}

function checkAndShowOnboarding(username) {
    const key = `onboarding_passed_${username}`;
    if (!localStorage.getItem(key)) {
        const el = document.getElementById('onboarding-overlay');
        if (el) {
            el.style.display = 'flex';
            el.dataset.user = username;
        }
    }
}

function startOnboarding() {
    const el = document.getElementById('onboarding-overlay');
    if (el) {
        const username = el.dataset.user;
        if (username) {
            localStorage.setItem(`onboarding_passed_${username}`, '1');
        }
        el.style.display = 'none';
        if (typeof goToProfileStart === 'function') {
            goToProfileStart();
        } else {
            switchTab('profile');
        }
    }
}

function setTextById(id, value, fallback = '--') {
    const el = document.getElementById(id);
    if (!el) return;
    const text = value === undefined || value === null || value === '' ? fallback : value;
    el.textContent = String(text);
}

function formatPercentValue(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '--';
    const p = n <= 1 ? n * 100 : n;
    return `${Math.round(p)}%`;
}

function formatMoneyValue(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) return '--';
    return `${Math.round(n).toLocaleString()} 元`;
}

async function loadSystemInfo() {
    try {
        const [infoResp, metricsResp] = await Promise.all([
            fetch('/api/system/info').catch(() => null),
            fetch('/api/system/metrics').catch(() => null)
        ]);

        let infoData = null;
        let metricsData = null;

        if (infoResp && infoResp.ok) {
            const json = await infoResp.json();
            if (json && json.success) infoData = json.data || null;
        }
        if (metricsResp && metricsResp.ok) {
            const json = await metricsResp.json();
            if (json && json.success) metricsData = json.data || json || null;
        }

        const metrics = (infoData && infoData.metrics) || metricsData || {};
        const interpretation = (infoData && infoData.system_interpretation) || (metricsData && metricsData.system_interpretation) || [];

        setTextById('sys-total-jobs', infoData ? infoData.total_jobs : metrics.job_total);
        setTextById('sys-total-users', infoData ? infoData.current_user : '--');
        setTextById('sys-current-role', infoData ? infoData.usage_mode : '个人版');

        setTextById('sys-m-job-total', metrics.job_total);
        setTextById('sys-m-city-count', metrics.city_count);
        setTextById('sys-m-avg-salary', formatMoneyValue(metrics.avg_salary));
        setTextById('sys-m-high-salary', formatMoneyValue(metrics.high_salary_threshold));
        setTextById('sys-m-skill-coverage', formatPercentValue(metrics.skill_coverage));
        setTextById('sys-m-freshness', metrics.data_freshness || metrics.updated_at || '--');

        const interpretationText = Array.isArray(interpretation)
            ? interpretation.filter(Boolean).join('；')
            : String(interpretation || '').trim();
        setTextById('sys-interpretation', interpretationText || '暂无系统解读');

        const jsonEl = document.getElementById('sys-metrics-json');
        if (jsonEl) {
            jsonEl.textContent = JSON.stringify(metrics || {}, null, 2);
        }
    } catch (err) {
        console.warn('loadSystemInfo failed:', err);
        setTextById('sys-interpretation', '系统信息加载失败，请稍后重试');
        const jsonEl = document.getElementById('sys-metrics-json');
        if (jsonEl) jsonEl.textContent = '{}';
    }
}
