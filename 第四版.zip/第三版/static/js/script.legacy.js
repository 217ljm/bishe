﻿// =========================================================
// 7. 系统概览数据卡片恢复与渲染（历史版本，保留以便回溯）
// =========================================================
async function updateSummaryLegacyCards() {
    try {
        const [qRes, sRes] = await Promise.all([
            fetch('/api/data/quality').catch(() => null),
            fetch('/api/stats/summary').catch(() => null) // 使用旧有的全局摘要接口补偿缺失数据
        ]);

        let qData = {}, sData = {};
        if (qRes && qRes.ok) {
            const r = await qRes.json();
            if (r.success) qData = r.data || {};
        }
        if (sRes && sRes.ok) sData = await sRes.json();

        // 卡片 1: 全市场均薪
        const avg = sData.avg_salary || 0;
        const avgEl = document.getElementById('stat-market-avg');
        if (avgEl) {
            if (avg > 0) animateValue(avgEl, 0, avg, 800);
            else avgEl.innerText = '¥0';
            // 添加前缀
            setTimeout(() => { if (avg > 0) avgEl.innerText = '¥' + parseInt(avgEl.innerText).toLocaleString(); }, 850);
        }

        // 卡片 2: 高薪门槛（按均薪比例估算）
        const top20El = document.getElementById('stat-top20');
        if (top20El) {
            if (avg > 0) {
                const top20 = parseInt(avg * 1.45);
                animateValue(top20El, 0, top20, 800);
                setTimeout(() => { top20El.innerText = '¥' + parseInt(top20El.innerText).toLocaleString(); }, 850);
            } else top20El.innerText = '¥0';
        }

        // 卡片 3: 技能覆盖率（无数据时不再造数）
        const covEl = document.getElementById('stat-skill-cov');
        let cov = qData.valid_salary_rate || 0;
        if (covEl) covEl.innerText = avg > 0 ? cov.toFixed(1) + '%' : '--%';

        // 卡片 4: 岗位总量
        const total = sData.total || qData.total_jobs || 0;
        const totalEl = document.getElementById('stat-total-jobs');
        if (totalEl) {
            if (total > 0) animateValue(totalEl, 0, total, 800);
            else totalEl.innerText = '0';
        }

        // 卡片 5: 城市概况
        const cityEl = document.getElementById('stat-city-cov');
        if (cityEl) {
            const cityCount = sData.city_count || 0;
            if (cityCount > 0) animateValue(cityEl, 0, cityCount, 800);
            else cityEl.innerText = '0';
        }

        // 卡片 6: 薪资覆盖率（无数据时不再造数）
        const srateEl = document.getElementById('stat-salary-rate');
        if (srateEl) {
            let srate = 0;
            if (qData.abnormal_salary_rate !== undefined) srate = 100 - parseFloat(qData.abnormal_salary_rate);
            srateEl.innerText = avg > 0 ? srate.toFixed(1) + '%' : '--%';
        }

        // 更新最后更新时间标签
        const updateEl = document.getElementById('stat-last-update');
        if (updateEl) {
            const d = new Date();
            updateEl.innerText = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
        }
    } catch (e) {
        console.error("加载首页概述数据失败", e);
    }
}

async function handleUpload(input) {
    if (!input.files[0]) return;
    let fd = new FormData();
    fd.append('file', input.files[0]);
    showToast("正在处理...", 'success');
    try {
        const r = await fetch('/upload', { method: 'POST', body: fd });
        if (r.ok) {
            showToast((await r.json()).message);
            initDashboard();
            loadDataQuality();
            const btn = document.querySelector('.menu-item[onclick*="summary"]');
            if (btn) switchTab('summary', btn);
        } else showToast("失败", 'error');
    } catch (e) {
        showToast("上传错", 'error');
    }
    input.value = '';
}

// =========================================================
// 4. 数据概览与图表逻辑（历史版本，保留以便回溯）
// =========================================================
async function updateSummaryLegacyGlobal() {
    try {
        const r = await fetch('/api/stats/global');
        const d = await r.json();

        // 安全设置元素内容的辅助函数
        const safeSet = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };
        const safeHtml = (id, val) => { const el = document.getElementById(id); if (el) el.innerHTML = val; };

        // 1. 系统数据状态
        const totalEl = document.getElementById('stat-total');
        if (totalEl) animateValue(totalEl, 0, d.total_jobs || 0, 600);
        refreshOverviewWorkbench(d.total_jobs || 0);
        safeSet('stat-city', d.city_count || 0);
        safeSet('stat-cat', d.cat_count || 0);
        safeSet('stat-last-update', d.last_update || '--');

        // 时间问候（包含用户名）
        const hour = new Date().getHours();
        const greetMap = { 0: '🌙 晚上好', 12: '☀️ 下午好', 18: '🌙 晚上好' };
        let greeting = hour < 12 ? '🌞 早上好' : hour < 18 ? '☀️ 下午好' : '🌙 晚上好';
        const userEl = document.getElementById('display-username');
        const userName = (userEl && userEl.innerText !== '未登录') ? userEl.innerText : '';
        safeSet('welcome-msg', userName ? `${greeting}，${userName}！` : `${greeting}！`);

        let sourceHtml = '';
        if (d.sources) {
            for (let [k, v] of Object.entries(d.sources)) {
                sourceHtml += `<span style="background:rgba(255,255,255,0.2); color:#fff; padding:3px 10px; border-radius:12px; font-size:12px; backdrop-filter:blur(4px);">${k} ${v}条</span>`;
            }
        }
        safeHtml('stat-sources', sourceHtml || '<span style="opacity:0.7;">暂无数据来源</span>');

        // 2. 核心指标
        safeSet('stat-market-avg', '¥' + (d.avg_salary || 0).toLocaleString());
        if (d.reliability) {
            safeSet('stat-reliability', (d.reliability.salary_coverage || 0) + '%');
            safeSet('stat-skill-cov', (d.reliability.skill_coverage || 0) + '%');
        }
        safeSet('stat-top20', '¥' + (d.top_20_threshold || 0).toLocaleString());

        // 3. 空状态控制
        const gridDiv = document.querySelector('#tab-summary .summary-chart-grid');
        const emptyDiv = document.getElementById('home-empty-state');

        if (d.total_jobs === 0) {
            if (gridDiv) gridDiv.style.display = 'none';
            if (emptyDiv) emptyDiv.style.display = 'flex';
        } else {
            if (gridDiv) gridDiv.style.display = 'grid';
            if (emptyDiv) emptyDiv.style.display = 'none';
        }
    } catch (e) {
        console.error("概览加载失败", e);
    }
}

async function initDashboard() {
    // 安全获取欢迎信息
    const hour = new Date().getHours();
    let greet = hour < 12 ? '🌞 上午好' : (hour < 18 ? '☕ 下午好' : '🌙 晚上好');
    const userEl = document.getElementById('display-username');
    const user = userEl ? userEl.innerText : '朋友';
    const welcomeEl = document.getElementById('welcome-msg');
    if (welcomeEl) welcomeEl.innerText = `${greet}，${user === '未登录' ? '朋友' : user}！`;

    await updateSummary();
    await loadSummaryDashboard();

    try {
        const r1 = await fetch('/api/stats');
        const d1 = await r1.json();
        cityDataCache = { labels: d1.city_labels, values: d1.city_values };
        // 概览四图统一由 loadSummaryDashboard 渲染，避免旧逻辑覆盖新布局。
        generateAIReport();

    } catch (e) {
        console.error("图表加载失败", e);
    }
}

async function generateAIReport() {
    const insightEl = document.getElementById('daily-insight');
    if (!insightEl) return;
    try {
        const [r1, r2] = await Promise.all([fetch('/api/stats'), fetch('/api/stats/wordcloud')]);
        const cityData = await r1.json();
        const skillData = await r2.json();
        let topCity = '暂无数据', topSalary = 0;
        if (cityData.city_labels && cityData.city_labels.length > 0) {
            let maxIdx = 0;
            cityData.city_values.forEach((v, i) => {
                if (v > cityData.city_values[maxIdx]) maxIdx = i;
            });
            topCity = cityData.city_labels[maxIdx];
            topSalary = cityData.city_values[maxIdx];
        }
        let topSkill = '通用技能';
        if (skillData && skillData.length > 0) {
            skillData.sort((a, b) => b.value - a.value);
            topSkill = skillData[0].name;
        }
        insightEl.innerHTML = `🚀 <b>大数据市场洞察：</b> 本周 <span style="background:#fff7e6; color:#f59e0b; padding:0 4px;">${topSkill}</span> 需求领跑，<span style="background:#e6f7ff; color:#2563eb; padding:0 4px;">${topCity}</span> 薪资竞争力强（¥${topSalary.toLocaleString()}）。`;
    } catch (e) {
        insightEl.innerText = "系统繁忙，大数据洞察暂时无法送达。";
    }
}

// ---------------- 图表渲染细节 (完整保留) ----------------
function bindChartClick(chartInstance, switchId, desc) {
    if (!chartInstance) return;
    chartInstance.off('click');
    chartInstance.on('click', function (params) {
        if (!document.getElementById(switchId).checked) return;
        showToast(`正在${desc}：${params.name}...`);
    });
}



function renderCityChart() {
    const type = currentCityChartType;
    const option = {
        tooltip: { trigger: 'axis' },
        grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
        xAxis: type === 'bar' ? {
            type: 'category',
            data: cityDataCache.labels,
            axisLabel: { rotate: 30 }
        } : { type: 'value' },
        yAxis: type === 'bar' ? { type: 'value' } : { type: 'category', data: cityDataCache.labels, inverse: true },
        series: [{
            type: 'bar',
            data: cityDataCache.values,
            itemStyle: { color: '#2563eb', borderRadius: [4, 4, 0, 0] }
        }]
    };

    if (cityDataCache.labels.length === 0) {
        const emptyOpt = {
            backgroundColor: '#fff',
            title: { text: '暂无数据', subtext: '请先运行爬虫采集数据', left: 'center', top: 'center', textStyle: { color: '#999', fontSize: 14 } },
            series: [], xAxis: { show: false }, yAxis: { show: false }
        };
        if (charts.c1) charts.c1.setOption(emptyOpt, true);
        if (charts.homeC1) charts.homeC1.setOption(emptyOpt, true);
        return;
    }

    if (charts.c1) charts.c1.setOption(option);
    if (charts.homeC1) charts.homeC1.setOption(option);
}











async function renderEduChart() {
    if (!charts.c4 && !charts.homeC4) return;
    try {
        const r = await fetch('/api/stats/advanced', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dashboardState)
        });
        const d = await r.json();

        // Empty State Check
        if (!d.edu_salary || d.edu_salary.labels.length === 0) {
            const emptyOpt = {
                backgroundColor: '#fff',
                title: { text: '暂无学历分析', left: 'center', top: 'center', textStyle: { color: '#999' } },
                series: [], xAxis: { show: false }, yAxis: { show: false }
            };
            if (charts.c4) charts.c4.setOption(emptyOpt, true);
            if (charts['c4-demand']) charts['c4-demand'].setOption(emptyOpt, true);
            if (charts.homeC4) charts.homeC4.setOption(emptyOpt, true);
            return;
        }

        // 学历图：改用南丁格尔玫瑰图，能更直观地体现不同学历薪资规模的相对厚度
        let petalData = [];
        for (let i = 0; i < d.edu_salary.labels.length; i++) {
            if (d.edu_salary.values[i] > 0) {
                petalData.push({
                    name: d.edu_salary.labels[i],
                    value: d.edu_salary.values[i]
                });
            }
        }
        // 按薪资大小降序排列
        petalData.sort((a, b) => b.value - a.value);

        const option = {
            tooltip: { trigger: 'item', formatter: '{b} <br/>平均薪资 : ¥{c}' },
            legend: {
                top: 'bottom',
                icon: 'circle',
                itemWidth: 10,
                itemHeight: 10,
                textStyle: { color: '#64748b', fontSize: 11 }
            },
            series: [{
                name: '学历溢价',
                type: 'pie',
                radius: ['20%', '65%'],
                center: ['50%', '42%'],
                roseType: 'area', // 南丁格尔玫瑰面积
                itemStyle: {
                    borderRadius: 8,
                    borderColor: '#fff',
                    borderWidth: 2,
                    color: function (params) {
                        const colors = ['#ec4899', '#8b5cf6', '#3b82f6', '#10b981', '#f59e0b'];
                        return colors[params.dataIndex % colors.length];
                    }
                },
                data: petalData,
                label: {
                    show: true,
                    formatter: '{b}\n¥{c}',
                    color: '#334155',
                    fontWeight: 'bold',
                    fontSize: 11
                },
                labelLine: { length: 10, length2: 12, smooth: true }
            }]
        };

        if (charts.c4) {
            charts.c4.setOption(option);
            bindChartClick(charts.c4, 'switch-sync-c4', '同步学历');
        }
        if (charts.homeC4) charts.homeC4.setOption(option);

        // 如果存在需求占比饼图则按原封保存其展示，但样式做微调
        if (charts['c4-demand']) {
            const opt2 = {
                tooltip: { trigger: 'item', formatter: '{b}: {c}个 ({d}%)' },
                series: [{
                    type: 'pie',
                    radius: ['45%', '75%'],
                    itemStyle: {
                        borderRadius: 8,
                        borderColor: '#fff',
                        borderWidth: 2
                    },
                    label: { show: false },
                    data: d.edu_salary.labels.map((l, i) => ({ value: d.edu_salary.counts[i], name: l }))
                }]
            };

            charts['c4-demand'].setOption(opt2);
        }

    } catch (e) {
        console.error(e);
    }
}

// =========================================================
