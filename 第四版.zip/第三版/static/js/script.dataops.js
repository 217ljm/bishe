﻿// === 新增：分页跳转逻辑 ===
function jumpToPage() {
    const input = document.getElementById('jump-page-input');
    if (!input) return;

    let page = parseInt(input.value);
    if (isNaN(page) || page < 1) {
        showToast('请输入有效的页码', 'error');
        return;
    }
    loadData(page);
}

const DATA_COL_STATE_KEY = 'data_table_cols_v2';
let dataTableColumnState = { hardTags: false, sourceMeta: false };

function initDataColumnControls() {
    const wrap = document.getElementById('data-column-controls');
    if (!wrap || wrap.dataset.inited === '1') return;
    wrap.dataset.inited = '1';
    const saved = (() => {
        try { return JSON.parse(localStorage.getItem(DATA_COL_STATE_KEY) || '{}'); } catch (_) { return {}; }
    })();
    dataTableColumnState.hardTags = !!saved.hardTags;
    dataTableColumnState.sourceMeta = !!saved.sourceMeta;
    const hard = document.getElementById('col-hard-tags');
    const source = document.getElementById('col-source-meta');
    if (hard) hard.checked = dataTableColumnState.hardTags;
    if (source) source.checked = dataTableColumnState.sourceMeta;
    const onChange = () => {
        dataTableColumnState = {
            hardTags: !!(hard && hard.checked),
            sourceMeta: !!(source && source.checked)
        };
        localStorage.setItem(DATA_COL_STATE_KEY, JSON.stringify(dataTableColumnState));
        loadData(currentPage || 1);
    };
    if (hard) hard.addEventListener('change', onChange);
    if (source) source.addEventListener('change', onChange);
}

function readProfileValue(id, fallback = '') {
    const el = document.getElementById(id);
    return el ? String(el.value || '').trim() : fallback;
}

function getExpectedSalaryRange() {
    const min = Number(readProfileValue('p-salary-min', '0') || 0);
    const max = Number(readProfileValue('p-salary-max', '0') || 0);
    return { min: Number.isFinite(min) ? min : 0, max: Number.isFinite(max) ? max : 0 };
}

function normalizeLevelToScore(level) {
    if (level === 'high') return 28;
    if (level === 'medium') return 16;
    return 6;
}

function compareExp(profileExp, jobExp) {
    const p = String(profileExp || '');
    const j = String(jobExp || '');
    if (!p || !j || j.includes('不限') || p.includes('不限')) return 75;
    if (p.includes('应届') && (j.includes('应届') || j.includes('1年'))) return 88;
    if (p.includes('1-3') && (j.includes('1-3') || j.includes('1年'))) return 86;
    if (p.includes('3-5') && (j.includes('3-5') || j.includes('1-3'))) return 86;
    if (p.includes('5-10') && (j.includes('5-10') || j.includes('3-5'))) return 84;
    if (p.includes('10') && j.includes('10')) return 84;
    return 62;
}

function compareEdu(profileEdu, jobEdu) {
    const rank = { '不限': 0, '大专': 1, '本科': 2, '硕士': 3, '博士': 4 };
    const p = String(profileEdu || '不限');
    const j = String(jobEdu || '不限');
    const pv = rank[p] ?? 0;
    const jv = rank[j] ?? 0;
    if (jv === 0) return 85;
    if (pv >= jv) return 92;
    if (jv - pv === 1) return 68;
    return 48;
}

function compareSalary(expected, actual) {
    const expMin = Number(expected.min || 0);
    const expMax = Number(expected.max || 0);
    const salary = Number(actual || 0);
    if (!salary) return 65;
    if (!expMin && !expMax) return 78;
    if (expMin && salary < expMin) {
        const gapRatio = Math.min(1, (expMin - salary) / Math.max(1, expMin));
        return Math.max(35, Math.round(86 - gapRatio * 55));
    }
    if (expMax && salary > expMax) return 92;
    return 90;
}

function buildRiskLevel(score, low = 35, high = 65) {
    if (score >= high) return { level: '低', color: '#10b981' };
    if (score >= low) return { level: '中', color: '#f59e0b' };
    return { level: '高', color: '#ef4444' };
}

function computeRuleEvaluation(row = {}) {
    const skill = Number(row._quick_match);
    const skillScore = Number.isFinite(skill) ? Math.max(0, Math.min(99, skill)) : 58;
    const expScore = compareExp(readProfileValue('p-exp', ''), row.exp || row.exp_req || '');
    const eduScore = compareEdu(readProfileValue('p-edu', ''), row.edu || row.edu_req || '');
    const salaryScore = compareSalary(getExpectedSalaryRange(), row.salary_avg || 0);
    const score = Math.round(skillScore * 0.55 + expScore * 0.15 + eduScore * 0.15 + salaryScore * 0.15);
    const bucket = score >= 80 ? '主申' : (score >= 65 ? '冲刺' : '保底');
    const gapCount = Number(row._gap_count || 0);
    const skillRiskRaw = 100 - Math.min(100, skillScore + gapCount * 6);
    const salaryRiskRaw = 100 - salaryScore;
    const compPressure = (Number(row.salary_avg || 0) >= 25000 ? 72 : 55) + (String(row.city || '').includes('北京') || String(row.city || '').includes('上海') ? 12 : 0);
    const compRiskRaw = Math.max(0, Math.min(100, compPressure - score * 0.25));
    const skillRisk = buildRiskLevel(100 - skillRiskRaw, 45, 75);
    const salaryRisk = buildRiskLevel(100 - salaryRiskRaw, 45, 75);
    const competitionRisk = buildRiskLevel(100 - compRiskRaw, 45, 75);
    const worst = [skillRisk, salaryRisk, competitionRisk].some(x => x.level === '高')
        ? '高风险'
        : ([skillRisk, salaryRisk, competitionRisk].some(x => x.level === '中') ? '中风险' : '低风险');
    return {
        score,
        bucket,
        investIndex: Math.max(0, Math.min(100, Math.round(score * 0.92))),
        risks: {
            skill: skillRisk,
            salary: salaryRisk,
            competition: competitionRisk
        },
        riskLevel: worst,
        reason: `技能匹配 ${skillScore}，经验匹配 ${expScore}，学历匹配 ${eduScore}，薪资匹配 ${salaryScore}`,
        suggestion: score >= 80
            ? '可优先投递，聚焦主申岗位并快速跟进反馈。'
            : (score >= 65 ? '建议先补齐1-2个关键短板，再进入集中投递。' : '建议先补技能和项目表达，再评估投递。')
    };
}

function renderRiskTriplet(evalResult = {}) {
    const risks = evalResult.risks || {};
    const item = (label, risk) => {
        const lv = risk && risk.level ? risk.level : '-';
        const color = risk && risk.color ? risk.color : '#94a3b8';
        return `<span class="risk-chip" style="border-color:${color}; color:${color};">${label}${lv}</span>`;
    };
    return `${item('技能', risks.skill)}${item('薪资', risks.salary)}${item('竞争', risks.competition)}`;
}

function preEvaluateRows(rows = []) {
    return (Array.isArray(rows) ? rows : []).map(row => {
        const evalResult = computeRuleEvaluation(row);
        return { ...row, _pre_eval: evalResult, _pre_score: evalResult.score };
    });
}

window.computeRuleEvaluation = computeRuleEvaluation;

function updateDataSortTip(rows = []) {
    const tip = document.getElementById('data-sort-tip');
    if (!tip) return;
    const list = Array.isArray(rows) ? rows : [];
    if (!list.length) {
        tip.innerText = '当前无可评估岗位，请先调整筛选条件。';
        return;
    }
    if (currentSortField === 'match') {
        const top = [...list].sort((a, b) => Number(b._pre_score || 0) - Number(a._pre_score || 0))[0];
        tip.innerText = `已按匹配度排序 | 当前最高匹配：${Number(top._pre_score || 0)}分（${top.job_name || '未知岗位'}）`;
    } else {
        const sortTextMap = { salary_avg: '薪资优先', pub_date: '最新发布', id: '入库时间' };
        tip.innerText = `当前按「${sortTextMap[currentSortField] || currentSortField}」排序，建议切回“智能匹配度”查看最优投递顺序。`;
    }
}

// === 新增：重置筛选逻辑 ===
function resetDataFilters() {
    document.getElementById('search-kw').value = '';
    document.getElementById('filter-city').value = '';
    document.getElementById('filter-edu').value = '';
    document.getElementById('filter-exp').value = '';
    document.getElementById('filter-min').value = '';
    document.getElementById('filter-max').value = '';
    const fav = document.getElementById('filter-favorites');
    const ign = document.getElementById('filter-ignored');
    if (fav) fav.checked = false;
    if (ign) ign.value = 'exclude';
    const sort = document.getElementById('filter-sort');
    if (sort) sort.value = 'match';
    currentSortField = 'match';

    showToast('筛选条件已重置', 'success');
    loadData(1);
}


async function loadDataQuality() {
    const panel = document.getElementById('data-quality-panel');
    if (!panel) return;

    const legacySuggestion = document.getElementById('data-quality-suggestion');
    const modernFields = document.getElementById('dq-fields');
    const modernSuggest = document.getElementById('dq-suggestions');
    const modernScoreText = document.getElementById('dq-score-text');
    const modernScoreFill = document.getElementById('dq-score-fill');
    const modernBadge = document.getElementById('dq-health-badge');
    const trustStrip = document.getElementById('data-trust-strip');

    if (modernFields) {
        modernFields.innerHTML = '<div style="color:#94a3b8; font-size:12px;">质量分析中...</div>';
        if (modernSuggest) modernSuggest.innerHTML = '';
    } else {
        panel.innerHTML = '<div style="color:#94a3b8; font-size:12px;">质量分析中...</div>';
        if (legacySuggestion) legacySuggestion.innerHTML = '';
    }

    try {
        const d = await fetchDataQualityCached(true);
        if (!d.success) throw new Error(d.msg || 'quality failed');

        const q = d.data || {};
        const cards = [
            { k: '有效薪资', v: `${q.valid_salary_rate || 0}%`, c: '#10b981' },
            { k: '公司缺失', v: `${q.missing_company_rate || 0}%`, c: '#f59e0b' },
            { k: '城市缺失', v: `${q.missing_city_rate || 0}%`, c: '#f97316' },
            { k: '重复率', v: `${q.duplicate_rate || 0}%`, c: '#6366f1' },
            { k: '异常薪资', v: `${q.abnormal_salary_rate || 0}%`, c: '#ef4444' }
        ];

        const cardsHtml = cards.map(item => `
            <div style="background:#fff; border:1px solid #e2e8f0; border-radius:10px; padding:10px 12px;">
                <div style="font-size:12px; color:#64748b;">${item.k}</div>
                <div style="font-size:20px; font-weight:700; color:${item.c}; margin-top:2px;">${item.v}</div>
            </div>
        `).join('');

        const tips = [];
        if ((q.duplicate_rate || 0) > 10) tips.push('重复数据较多，建议增加去重规则并保留最新发布时间。');
        if ((q.abnormal_salary_rate || 0) > 8) tips.push('异常薪资偏高，建议按行业区间进行清洗。');
        if ((q.missing_city_rate || 0) > 12) tips.push('城市缺失较高，建议补齐城市字段后再做区域对比。');
        if ((q.missing_company_rate || 0) > 12) tips.push('公司名缺失较高，建议优先保留可溯源数据。');
        const reasonList = Array.isArray(q.health_reasons) ? q.health_reasons : [];
        const reasonHtml = reasonList.length
            ? `<div style="margin-top:8px; font-size:12px; color:#334155;">诊断理由：${reasonList.slice(0, 3).map(x => `${x.title || '质量项'}（${x.summary || '--'}）`).join('；')}</div>`
            : '';

        const tipHtml = tips.length
            ? `<i class="ri-lightbulb-flash-line" style="color:#f59e0b"></i> 优化建议：${tips.join(' ')}${reasonHtml}`
            : `<i class="ri-checkbox-circle-line" style="color:#10b981"></i> 当前数据质量良好，可直接用于分析与推荐。${reasonHtml}`;

        if (modernFields) {
            modernFields.innerHTML = cardsHtml;
            if (modernSuggest) modernSuggest.innerHTML = tipHtml;
            const score = Math.max(0, Math.min(100, Math.round(
                (q.valid_salary_rate || 0) * 0.4 +
                (100 - (q.duplicate_rate || 0)) * 0.2 +
                (100 - (q.abnormal_salary_rate || 0)) * 0.2 +
                (100 - (q.missing_city_rate || 0)) * 0.1 +
                (100 - (q.missing_company_rate || 0)) * 0.1
            )));
            latestDataQualityScore = score;
            if (modernScoreText) modernScoreText.innerText = `${score}分`;
            if (modernScoreFill) modernScoreFill.style.width = `${score}%`;
            if (modernBadge) {
                modernBadge.innerText = score >= 80 ? '健康' : (score >= 60 ? '一般' : '风险');
                modernBadge.style.background = score >= 80 ? '#ecfdf5' : (score >= 60 ? '#fffbeb' : '#fef2f2');
                modernBadge.style.color = score >= 80 ? '#166534' : (score >= 60 ? '#92400e' : '#991b1b');
                modernBadge.style.borderColor = score >= 80 ? '#86efac' : (score >= 60 ? '#fcd34d' : '#fecaca');
            }
            if (trustStrip) {
                const msg = score >= 80
                    ? '数据可信度较高：可直接用于岗位评估与投递决策。'
                    : (score >= 60
                        ? '数据可信度中等：建议结合岗位详情与人工判断。'
                        : '数据可信度偏低：建议先采集/清洗后再做关键决策。');
                trustStrip.innerHTML = `<b>数据可信度 ${score} 分：</b>${msg}`;
                trustStrip.style.background = score >= 80 ? '#ecfdf5' : (score >= 60 ? '#fffbeb' : '#fef2f2');
                trustStrip.style.borderColor = score >= 80 ? '#86efac' : (score >= 60 ? '#fcd34d' : '#fecaca');
                trustStrip.style.color = score >= 80 ? '#166534' : (score >= 60 ? '#92400e' : '#991b1b');
            }
        } else {
            panel.innerHTML = cardsHtml;
            if (legacySuggestion) legacySuggestion.innerHTML = tipHtml;
        }
    } catch (e) {
        latestDataQualityScore = null;
        if (modernFields) {
            modernFields.innerHTML = '<div style="color:#ef4444; font-size:12px;">质量面板加载失败</div>';
            if (modernSuggest) modernSuggest.innerHTML = '';
            if (modernScoreText) modernScoreText.innerText = '--';
            if (modernScoreFill) modernScoreFill.style.width = '0%';
            if (modernBadge) {
                modernBadge.innerText = '异常';
                modernBadge.style.background = '#fef2f2';
                modernBadge.style.color = '#991b1b';
                modernBadge.style.borderColor = '#fecaca';
            }
        } else {
            panel.innerHTML = '<div style="color:#ef4444; font-size:12px;">质量面板加载失败</div>';
            if (legacySuggestion) legacySuggestion.innerHTML = '';
        }
        if (trustStrip) {
            trustStrip.innerHTML = '数据可信度：质量面板加载失败，请刷新后重试。';
            trustStrip.style.background = '#fef2f2';
            trustStrip.style.borderColor = '#fecaca';
            trustStrip.style.color = '#991b1b';
        }
    }
}

async function loadData(p) {
    currentPage = p;
    initDataColumnControls();
    const k = document.getElementById('search-kw').value;
    const edu = document.getElementById('filter-edu').value;
    const tableBox = document.getElementById('table-box');
    tableBox.innerHTML = '<div class="loader-container"><div class="loader"></div><div class="loader-text">加载中...</div></div>';

    try {
        const r = await fetch('/api/data/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                page: p,
                keyword: k,
                education: edu,
                city: document.getElementById('filter-city').value,
                exp: document.getElementById('filter-exp').value,
                salary_min: document.getElementById('filter-min').value,
                salary_max: document.getElementById('filter-max').value,
                favorites_only: (document.getElementById('filter-favorites') || {}).checked || false,
                ignored_mode: (document.getElementById('filter-ignored') || {}).value || 'exclude',
                sort_by: currentSortField,
                sort_order: currentSortOrder
            })
        });
        const d = await r.json();
        const rowsRaw = Array.isArray(d.rows) ? d.rows : [];
        let rows = preEvaluateRows(rowsRaw);
        if (currentSortField === 'match') {
            rows = rows.sort((a, b) => Number(b._pre_score || 0) - Number(a._pre_score || 0));
        }
        lastDataTotal = Number(d.total || 0);
        const pageCount = Math.max(1, Math.ceil(lastDataTotal / DATA_PAGE_SIZE));
        const pageEl = document.getElementById('cur-page');
        if (pageEl) pageEl.innerText = `第 ${currentPage} / ${pageCount} 页`;
        const summaryEl = document.getElementById('page-summary');
        if (summaryEl) summaryEl.innerText = `共 ${lastDataTotal} 条`;
        updateDataSortTip(rows);

        if (rows.length === 0) {
            tableBox.innerHTML = '<div class="empty-state"><i class="ri-inbox-2-line empty-icon"></i><div class="empty-hint">无数据</div></div>';
            document.getElementById('page-info').innerText = '';
            if (typeof window.syncJobEvalPanelFromList === 'function') window.syncJobEvalPanelFromList([]);
            return;
        }

        const showHardTags = !!dataTableColumnState.hardTags;
        const showSourceMeta = !!dataTableColumnState.sourceMeta;

        let thead = `
            <tr>
                <th style="width: 50px; text-align:center;">#</th>
                <th style="min-width: 260px;">岗位与公司</th>
                <th style="min-width: 120px;">薪资</th>
                <th style="min-width: 120px;">综合匹配分</th>
                <th style="min-width: 220px;">投递风险（三维）</th>
                <th style="min-width: 110px;">状态</th>
        `;
        if (showHardTags) thead += `<th style="min-width: 180px;">硬性标签</th>`;
        if (showSourceMeta) thead += `<th style="min-width: 130px;">采录信息</th>`;
        thead += `<th style="width: 180px; text-align:right;">操作</th></tr>`;

        let h = `<div class="bento-table-wrapper"><table class="bento-table-premium"><thead>${thead}</thead><tbody>`;
        rows.forEach((i, index) => {
            const rowData = encodeURIComponent(JSON.stringify(i));
            const displaySalary = i.salary_text || (i.salary_avg ? `¥ ${Number(i.salary_avg).toLocaleString()}` : '--');
            const rowNum = (currentPage - 1) * DATA_PAGE_SIZE + index + 1;
            const evalResult = i._pre_eval || computeRuleEvaluation(i);
            const score = Number(evalResult.score || i._pre_score || 0);
            const scoreTone = score >= MATCH_SCORE_MAIN ? 'good' : (score >= MATCH_SCORE_SPRINT ? 'mid' : 'risk');
            const scoreCls = scoreTone === 'good' ? 'match-chip-good' : (scoreTone === 'mid' ? 'match-chip-mid' : 'match-chip-risk');
            const statusText = i.is_ignored ? '已忽略' : (i.is_favorite ? '已收藏' : `${evalResult.bucket}建议`);
            const statusCls = i.is_ignored ? 'status-chip-risk' : (i.is_favorite ? 'status-chip-good' : 'status-chip-mid');
            const hasNote = i.note ? 'has-note' : '';
            let linkBtn = '';
            if (i.detail_url && i.detail_url.startsWith('http')) {
                linkBtn = `<button onclick="window.open('${i.detail_url}','_blank')" class="grid-act-btn btn-link" title="直达原站"><i class="ri-external-link-line"></i></button>`;
            }
            let sourceBadge = `<span class="grid-badge badge-default">${i.source || '其他'}</span>`;
            if (i.source === '猎聘网' || String(i.source || '').includes('猎聘')) sourceBadge = `<span class="grid-badge badge-liepin">猎聘</span>`;
            if (i.source === '前程无忧' || String(i.source || '').includes('51')) sourceBadge = `<span class="grid-badge badge-job51">51Job</span>`;

            h += `<tr>
                <td style="text-align:center; color:var(--text-secondary); font-size:13px; font-weight:600;">${rowNum}</td>
                <td>
                    <div class="grid-title-group">
                        <i class="grid-fav ${i.is_favorite ? 'ri-star-fill' : 'ri-star-line'}" style="color:${i.is_favorite ? '#faad14' : '#d9d9d9'};" onclick="toggleFavorite(${i.id}, this)"></i>
                        <div class="grid-texts">
                            <span class="grid-job-name" title="${i.job_name || ''}">${i.job_name || '未知岗位'}</span>
                            <span class="grid-company" title="${i.company || ''}"><i class="ri-building-4-line" style="margin-right:2px"></i>${i.company || '未知公司'}</span>
                        </div>
                    </div>
                </td>
                <td><span class="grid-salary-text">${displaySalary}</span></td>
                <td><span class="match-chip ${scoreCls}">${score || '--'} 分</span></td>
                <td><div class="risk-triplet">${renderRiskTriplet(evalResult)}</div></td>
                <td><span class="status-chip ${statusCls}">${statusText}</span></td>`;

            if (showHardTags) {
                h += `<td>
                    <div class="grid-tags">
                        <span class="grid-tag"><i class="ri-map-pin-2-line"></i> ${i.city || '-'}</span>
                        <span class="grid-tag"><i class="ri-graduation-cap-line"></i> ${i.edu || '不限'}</span>
                        <span class="grid-tag"><i class="ri-time-line"></i> ${i.exp || '不限'}</span>
                    </div>
                </td>`;
            }
            if (showSourceMeta) {
                h += `<td><div class="grid-source-info">${sourceBadge}<span class="grid-date">${i.pub_date || '-'}</span></div></td>`;
            }

            h += `<td style="text-align:right;">
                    <div class="grid-actions">
                        ${linkBtn}
                        <button type="button" class="btn btn-primary" style="padding:4px 10px; font-size:12px;" data-action="evaluate" data-job-id="${i.id}" title="查看详细评估报告"><i class="ri-radar-line"></i> 查看评估</button>
                        <button type="button" class="btn btn-default app-quick-action" style="padding:4px 10px; font-size:12px;" data-action="mark-applied" data-job-id="${i.id}" title="标记为已投递"><i class="ri-send-plane-line"></i> 标记投递</button>
                        <button class="grid-act-btn btn-view" onclick="viewDetail('${rowData}')" title="查看岗位详情"><i class="ri-file-list-3-line"></i></button>
                        <button class="grid-act-btn btn-note ${hasNote}" onclick="editNote(${i.id}, '${encodeURIComponent(i.note || '')}')" title="${i.note ? '查看/修改备注' : '添加备注'}"><i class="ri-edit-2-line"></i></button>
                        <button class="grid-act-btn btn-del" onclick="delData(${i.id})" title="删除岗位记录"><i class="ri-delete-bin-line"></i></button>
                    </div>
                </td>
            </tr>`;
        });
        h += `</tbody></table></div>`;
        tableBox.innerHTML = h;

        const tbody = tableBox.querySelector('.bento-table-premium tbody');
        if (tbody) {
            tbody.addEventListener('click', (ev) => {
                const btn = ev.target.closest('button[data-action]');
                if (!btn) return;
                const jobId = Number(btn.dataset.jobId || 0);
                if (!jobId) return;
                const action = String(btn.dataset.action || '');
                if (action === 'evaluate') {
                    if (typeof window.evaluateJobFromList === 'function') window.evaluateJobFromList(jobId);
                    else showToast('岗位评估模块未就绪，请刷新页面后重试', 'error');
                    return;
                }
                if (action === 'mark-applied') {
                    if (typeof window.quickMarkApplied === 'function') window.quickMarkApplied(jobId);
                    else showToast('投递标记模块未就绪，请刷新页面后重试', 'error');
                }
            });
        }

        hydrateDataRowActions(rows || []);
        if (typeof window.syncJobEvalPanelFromList === 'function') window.syncJobEvalPanelFromList(rows || []);
        document.getElementById('page-info').innerText = `共 ${d.total} 条岗位`;
        document.getElementById('btn-prev').disabled = p === 1;
        document.getElementById('btn-next').disabled = rows.length < DATA_PAGE_SIZE;
    } catch (e) {
        console.error(e);
        tableBox.innerHTML = '<div style="text-align:center;padding:40px;color:var(--error);"><i class="ri-alert-line" style="font-size:24px;"></i><br>数据总线通信失败，请重试</div>';
    }
}

function changePage(s) {
    if (currentPage + s > 0) loadData(currentPage + s);
}

function goToPage(page) {
    const pageCount = Math.max(1, Math.ceil((lastDataTotal || 0) / DATA_PAGE_SIZE));
    const target = Number(page) === -1 ? pageCount : Number(page || 1);
    loadData(Math.max(1, Math.min(pageCount, target)));
}

// 🔥🔥 核心修改：viewDetail 函数 (显示完整 raw_desc)

// ====== 高级 Confirm 弹窗系统 ======
let confirmCallback = null;

function showConfirm(title, desc, confirmText, type, callback) {
    document.getElementById('confirm-title').innerText = title;
    document.getElementById('confirm-desc').innerText = desc;

    const icon = document.getElementById('confirm-icon');
    const iconBox = document.getElementById('confirm-icon-box');
    const btnOk = document.getElementById('btn-confirm-ok');

    btnOk.innerText = confirmText;

    if (type === 'danger') {
        icon.className = 'ri-error-warning-fill';
        iconBox.style.background = '#fee2e2';
        iconBox.style.color = '#ef4444';
        btnOk.style.background = '#ef4444';
        btnOk.style.borderColor = '#ef4444';
        btnOk.style.boxShadow = '0 4px 12px rgba(239, 68, 68, 0.3)';
    } else {
        icon.className = 'ri-question-fill';
        iconBox.style.background = '#e0e7ff';
        iconBox.style.color = '#4f46e5';
        btnOk.style.background = '#4f46e5';
        btnOk.style.borderColor = '#4f46e5';
        btnOk.style.boxShadow = '0 4px 12px rgba(79, 70, 229, 0.3)';
    }

    confirmCallback = callback;
    document.getElementById('confirm-modal').style.display = 'flex';
}

function closeConfirm() {
    document.getElementById('confirm-modal').style.display = 'none';
    confirmCallback = null;
}

function execConfirm() {
    if (confirmCallback) confirmCallback();
    closeConfirm();
}

function clearData() {
    showConfirm('清空数据资产', '⚠️ 确定要清空所有已采集的数据吗？此操作不可恢复！', '确认清空', 'danger', () => {
        fetch('/api/data/clean', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        })
            .then(r => r.json())
            .then(d => {
                if (d.success) {
                    showToast(d.msg, 'success');
                    loadData(1);
                } else {
                    showToast('清空失败: ' + d.msg, 'error');
                }
            })
            .catch(e => showToast('请求出错', 'error'));
    });
}

function delData(id) {
    showConfirm('删除单条资产', '确定剔除此职位记录吗？删除后不再统计。', '确认删除', 'danger', () => {
        // Assume API /api/data/delete exists or fallback to dummy log (Will need to make sure API exists later or add it)
        fetch(`/api/data/delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: [id] })
        })
            .then(r => r.json())
            .then(d => {
                if (d.success) {
                    showToast(`删除成功（${d.deleted || 1} 条）`, 'success');
                    loadData(currentPage);
                } else {
                    showToast('删除失败: ' + d.msg, 'error');
                }
            })
            .catch(e => {
                console.error('删除接口请求失败', e);
                showToast('删除失败：接口不可用或网络异常', 'error');
            });
    });
}

function viewDetail(dataStr) {
    const data = JSON.parse(decodeURIComponent(dataStr));
    window.currentDetailJob = data || null;
    window.currentDetailJobId = data && data.id ? Number(data.id) : 0;
    const modal = document.getElementById('detail-modal');
    document.getElementById('d-title').innerText = data.job_name;
    document.getElementById('d-company').innerText = data.company;
    document.getElementById('d-salary').innerText = data.salary_text || data.salary_avg;
    document.getElementById('d-city').innerText = data.city;
    // 优先显示完整描述 (爬虫抓的)
    const desc = data.raw_desc || data.skills || '暂无详细描述';
    document.getElementById('d-desc').innerText = desc;
    const matchSection = document.getElementById('detail-match-section');
    if (matchSection) matchSection.style.display = 'block';
    const matchSkills = document.getElementById('detail-match-skills');
    if (matchSkills) {
        const skillText = (data.skills || '').split(',').filter(Boolean).slice(0, 6).join('、');
        matchSkills.innerHTML = `<div style="font-size:13px;color:#334155;">岗位技能：${skillText || '待补充'}</div>`;
    }
    const matchExp = document.getElementById('detail-match-exp');
    if (matchExp) matchExp.innerHTML = `<span style="color:#64748b;">经验要求：</span>${data.exp || '不限'}`;
    const matchAdvice = document.getElementById('detail-match-advice');
    if (matchAdvice) matchAdvice.innerText = '点击“岗位评估”可生成匹配结论，并可直接标记到投递看板。';
    modal.style.display = 'flex';
    syncDetailApplyButtons(window.currentDetailJobId);
}

// === 收藏与备注相关函数 ===

function toggleFavorite(id, icon, refreshAi = false) {
    fetch(`/api/job/${id}/favorite`, { method: 'POST' })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                if (icon && icon.classList) {
                    const ic = icon.querySelector('i') || icon;
                    if (d.is_favorite) {
                        ic.className = 'ri-star-fill';
                        ic.style.color = '#faad14';
                    } else {
                        ic.className = 'ri-star-line';
                        ic.style.color = '#8c8c8c';
                    }
                }
                if (refreshAi) refreshRecommendations();
            } else {
                showToast('操作失败: ' + (d.msg || '未知错误'), 'error');
            }
        })
        .catch(() => showToast('收藏操作失败', 'error'));
}

function toggleIgnore(id) {
    fetch(`/api/job/${id}/ignore`, { method: 'POST' })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                showToast(d.is_ignored ? '已忽略该岗位' : '已取消忽略', 'success');
                refreshRecommendations();
                loadData(currentPage);
                loadDataQuality();
            } else {
                showToast('忽略操作失败: ' + (d.msg || '未知错误'), 'error');
            }
        })
        .catch(() => showToast('忽略操作失败', 'error'));
}

function quickNote(id, noteEncoded) {
    const current = decodeURIComponent(noteEncoded || '');
    const note = prompt('请输入岗位备注（用于后续投递决策）', current);
    if (note === null) return;
    fetch(`/api/job/${id}/note`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ note: note })
    })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                showToast('备注已保存', 'success');
                refreshRecommendations();
                loadData(currentPage);
            } else {
                showToast('保存失败: ' + (d.msg || '未知错误'), 'error');
            }
        });
}

function refreshRecommendations() {
    const kw = (document.getElementById('kw') || {}).value || '';
    if (!kw) return;
    if (window.isRecComparison) window.isRecComparison = false;
    quickSearch();
}

function editNote(id, noteEncoded) {
    const note = decodeURIComponent(noteEncoded);
    document.getElementById('note-job-id').value = id;
    document.getElementById('note-input').value = note;
    document.getElementById('note-modal').style.display = 'flex';
}

function saveNote() {
    const id = document.getElementById('note-job-id').value;
    const note = document.getElementById('note-input').value;

    fetch(`/api/job/${id}/note`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ note: note })
    })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                closeModal('note-modal');
                loadData(currentPage); // 刷新列表以更新备注图标颜色
            } else {
                alert('保存失败: ' + (d.msg || '未知错误'));
            }
        });
}

// === 爬虫配置相关函数 ===

let currentConfig = {
    city_scope: [],
    max_pages: 5,
    frequency: 'manual'
};

function openConfigModal() {
    // 1. Load available cities
    fetch('/api/config/cities')
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                const sel = document.getElementById('cfg-city-select');
                // Keep "全国" and clear others 
                sel.innerHTML = '<option value="全国">全国</option>';
                d.data.forEach(c => {
                    if (c !== '全国') {
                        sel.innerHTML += `<option value="${c}">${c}</option>`;
                    }
                });
            }
        });

    // 2. Load current config
    fetch('/api/config/spider')
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                currentConfig = d.data;
                renderCfgCities();
                document.getElementById('cfg-max-pages').value = currentConfig.max_pages || 5;
                document.getElementById('cfg-schedule').checked = (currentConfig.frequency === 'daily');
                document.getElementById('config-modal').style.display = 'flex';
            } else {
                alert('加载配置失败');
            }
        });
}

function renderCfgCities() {
    const box = document.getElementById('cfg-city-tags');
    if (!currentConfig.city_scope || currentConfig.city_scope.length === 0) {
        currentConfig.city_scope = ['全国'];
    }

    let h = '';
    currentConfig.city_scope.forEach(c => {
        h += `<span class="tag">${c} <i class="ri-close-line" onclick="removeCfgCity('${c}')" style="cursor:pointer; margin-left:4px;"></i></span>`;
    });
    box.innerHTML = h;
}

function addCfgCity() {
    const val = document.getElementById('cfg-city-select').value;
    if (!currentConfig.city_scope.includes(val)) {
        currentConfig.city_scope.push(val);
        renderCfgCities();
    }
}

function removeCfgCity(city) {
    currentConfig.city_scope = currentConfig.city_scope.filter(c => c !== city);
    if (currentConfig.city_scope.length === 0) {
        currentConfig.city_scope = ['全国'];
    }
    renderCfgCities();
}

function saveSpiderConfig() {
    const newCfg = {
        city_scope: currentConfig.city_scope,
        max_pages: parseInt(document.getElementById('cfg-max-pages').value),
        frequency: document.getElementById('cfg-schedule').checked ? 'daily' : 'manual'
    };

    fetch('/api/config/spider', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCfg)
    })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                alert('配置已保存 (即时生效)');
                document.getElementById('config-modal').style.display = 'none';
            } else {
                alert('保存失败');
            }
        });
}

function getSuggestions(v) {
    if (v.length < 1) return;
    const optionsEl = document.getElementById('job-options');
    if (!optionsEl) return;
    fetch(`/api/suggest?kw=${v}`).then(r => r.json()).then(d => optionsEl.innerHTML = d.map(i => `<option value="${i}">`).join(''));
}

function exportCurrentFilteredData() {
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val || '';
    };
    setVal('exp-city', (document.getElementById('filter-city') || {}).value || '');
    setVal('exp-kw', (document.getElementById('search-kw') || {}).value || '');
    setVal('exp-salary', (document.getElementById('filter-min') || {}).value || '');
    setVal('exp-date', '');
    const modal = document.getElementById('export-modal');
    if (modal) modal.style.display = 'flex';
}

function closeChartHelp() {
    const modal = document.getElementById('chart-help-modal');
    if (modal) modal.style.display = 'none';
}

function togglePassword(inputId, triggerBtn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const toText = input.type === 'password';
    input.type = toText ? 'text' : 'password';
    if (triggerBtn) {
        const icon = triggerBtn.querySelector('i');
        if (icon) icon.className = toText ? 'ri-eye-off-line' : 'ri-eye-line';
    }
}

function initRecommendWeightConfig() {
    const config = JSON.parse(localStorage.getItem('recommend_weight_config') || '{}');
    const defaults = { skill: 35, salary: 30, threshold: 20, trend: 15 };
    const keys = ['skill', 'salary', 'threshold', 'trend'];
    keys.forEach(k => {
        const slider = document.getElementById(`weight-${k}`);
        const label = document.getElementById(`weight-${k}-val`);
        if (!slider || !label) return;
        const val = Number(config[k] || defaults[k]);
        slider.value = String(val);
        label.innerText = `${val}%`;
        slider.oninput = () => { label.innerText = `${slider.value}%`; };
    });
}

function saveRecommendWeights() {
    const read = (k, fallback) => {
        const el = document.getElementById(`weight-${k}`);
        return el ? Number(el.value || fallback) : fallback;
    };
    const config = {
        skill: read('skill', 35),
        salary: read('salary', 30),
        threshold: read('threshold', 20),
        trend: read('trend', 15)
    };
    localStorage.setItem('recommend_weight_config', JSON.stringify(config));
    const statusEl = document.getElementById('weight-config-status');
    if (statusEl) statusEl.innerText = '推荐权重已保存（前端排序即时生效）。';
    showToast('推荐权重已保存');
}

function resetRecommendWeights() {
    localStorage.removeItem('recommend_weight_config');
    initRecommendWeightConfig();
    const statusEl = document.getElementById('weight-config-status');
    if (statusEl) statusEl.innerText = '已恢复默认权重：技能35%，薪资30%，门槛20%，趋势15%。';
    showToast('已恢复默认权重');
}

// =========================================================
