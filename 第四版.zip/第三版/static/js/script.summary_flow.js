﻿// 8. 系统概览 (tab-summary) 数据联调与渲?
// =========================================================
const MATCH_SCORE_MAIN = 80;
const MATCH_SCORE_SPRINT = 65;
let latestJobEvalPanelSnapshot = null;
let latestApplicationDashboard = null;
let latestWeeklyPlanMeta = { week_key: '', completed_map: {} };

function renderJobEvalPanel(snapshot = {}) {
    const badgeEl = document.getElementById('job-eval-status-badge');
    const scoreEl = document.getElementById('job-eval-kpi-score');
    const investEl = document.getElementById('job-eval-kpi-invest');
    const riskEl = document.getElementById('job-eval-kpi-risk');
    const bucketEl = document.getElementById('job-eval-kpi-bucket');
    const actionsEl = document.getElementById('job-eval-next-actions');
    const conclusionEl = document.getElementById('job-decision-conclusion');
    const reasonEl = document.getElementById('job-decision-reason');
    const suggestionEl = document.getElementById('job-decision-suggestion');
    const focusEl = document.getElementById('job-decision-focus');
    const decisionActionsEl = document.getElementById('job-decision-actions');
    if (!scoreEl || !investEl || !riskEl || !bucketEl || !actionsEl) return;

    const score = Number(snapshot.score || 0);
    const invest = Number(snapshot.investIndex || 0);
    const risk = String(snapshot.riskLevel || '--');
    const bucket = String(snapshot.bucket || '--');
    const stateText = String(snapshot.stateText || '待评估');
    const title = String(snapshot.jobTitle || '');
    const nextActions = Array.isArray(snapshot.nextActions) ? snapshot.nextActions.filter(Boolean) : [];
    const reason = String(snapshot.reason || '');
    const sampleSize = Array.isArray(window.latestDataRows) ? window.latestDataRows.length : 0;

    scoreEl.innerText = score > 0 ? `${score}` : '--';
    investEl.innerText = invest > 0 ? `${invest}` : '--';
    riskEl.innerText = risk;
    bucketEl.innerText = bucket;

    if (badgeEl) {
        badgeEl.innerText = stateText;
        if (stateText.includes('已评估') || stateText.includes('可投') || stateText.includes('完成')) {
            badgeEl.style.background = '#ecfdf5';
            badgeEl.style.borderColor = '#86efac';
            badgeEl.style.color = '#166534';
        } else if (stateText.includes('谨慎') || stateText.includes('待补')) {
            badgeEl.style.background = '#fffbeb';
            badgeEl.style.borderColor = '#fcd34d';
            badgeEl.style.color = '#92400e';
        } else {
            badgeEl.style.background = '#f8fafc';
            badgeEl.style.borderColor = '#e2e8f0';
            badgeEl.style.color = '#64748b';
        }
    }

    let conclusionText = '先确认这一轮是否存在可投岗位';
    let suggestionText = nextActions[0] || '建议先完成一次批量预评估，再查看单岗位决策结果。';
    let focusText = sampleSize > 0
        ? `当前筛选结果共 ${sampleSize} 个岗位，先从最高匹配岗位开始判断是否进入主申、冲刺或保底池。`
        : '当前还没有形成候选岗位，先放宽条件或补充数据。';
    if (score >= MATCH_SCORE_MAIN) {
        conclusionText = `当前已形成主申级候选：${title || '目标岗位'}`;
        suggestionText = nextActions[0] || '建议先把该岗位纳入主申池，并尽快进入投递执行。';
        focusText = `${title || '该岗位'} 当前匹配分 ${score}，推荐分层 ${bucket}，可以作为这一轮优先动作。`;
    } else if (score >= MATCH_SCORE_SPRINT) {
        conclusionText = `当前存在可投递候选，但建议先补强后优先`;
        suggestionText = nextActions[0] || '建议先按冲刺策略投递，并同步补齐关键短板。';
        focusText = `${title || '该岗位'} 当前匹配分 ${score}，适合列为冲刺岗位并保留跟进。`;
    } else if (score > 0) {
        conclusionText = '当前筛选结果整体偏弱，建议谨慎进入投递';
        suggestionText = nextActions[0] || '先补齐短板或调整筛选，再重新生成岗位决策。';
        focusText = `${title || '当前岗位'} 当前匹配分 ${score}，风险 ${risk}，更适合作为观察或保底候选。`;
    }

    if (conclusionEl) conclusionEl.innerText = conclusionText;
    if (reasonEl) reasonEl.innerText = reason || `当前列表已完成预评估，系统会持续输出匹配分、风险和推荐分层。`;
    if (suggestionEl) suggestionEl.innerText = suggestionText;
    if (focusEl) focusEl.innerText = focusText;
    if (decisionActionsEl) {
        const primaryBtn = score >= MATCH_SCORE_SPRINT
            ? `<button class="btn btn-primary" onclick="switchTab('applications')"><i class="ri-send-plane-line"></i> 去投递执行</button>`
            : `<button class="btn btn-primary" onclick="evaluateTopJobs()"><i class="ri-flashlight-line"></i> 批量预评估</button>`;
        const secondaryBtn = score > 0
            ? `<button class="btn btn-default" onclick="switchTab('ai')"><i class="ri-focus-3-line"></i> 看推荐计划</button>`
            : `<button class="btn btn-default" onclick="switchTab('profile')"><i class="ri-user-settings-line"></i> 完善个人画像</button>`;
        const thirdBtn = `<button class="btn btn-default" onclick="switchTab('profile')"><i class="ri-bubble-chart-line"></i> 看短板分析</button>`;
        decisionActionsEl.innerHTML = `${primaryBtn}${secondaryBtn}${thirdBtn}`;
    }

    if (!nextActions.length) {
        actionsEl.innerHTML = '<div class="text-hint">评估后将自动生成“下一步行动清单”。</div>';
        return;
    }
    actionsEl.innerHTML = `
        <div style="font-size:12px; color:#1e293b; margin-bottom:6px;"><b>${title || '当前评估'}：</b>${reason || '已生成评估建议'}</div>
        <ul>${nextActions.slice(0, 3).map(x => `<li>${x}</li>`).join('')}</ul>
    `;
}

function syncJobEvalPanelFromList(rows = []) {
    const list = Array.isArray(rows) ? rows : [];
    if (!list.length) {
        renderJobEvalPanel({
            stateText: '待评估',
            score: 0,
            investIndex: 0,
            riskLevel: '--',
            bucket: '--',
            reason: '当前筛选结果为空，请先调整条件或采集数据。',
            nextActions: ['先在“数据准备”补充样本，或放宽筛选条件。', '从列表中选择岗位后点击“岗位决策”。']
        });
        return;
    }
    if (latestJobEvalPanelSnapshot && Number(latestJobEvalPanelSnapshot.score || 0) > 0) {
        renderJobEvalPanel(latestJobEvalPanelSnapshot);
        return;
    }
    const evalFn = typeof window.computeRuleEvaluation === 'function'
        ? window.computeRuleEvaluation
        : ((row) => ({ score: Number(row._quick_match || 0), riskLevel: '--', bucket: '--', reason: '规则评估未就绪', suggestion: '' }));
    const enriched = list.map(row => ({ row, eval: evalFn(row) }));
    enriched.sort((a, b) => Number(b.eval.score || 0) - Number(a.eval.score || 0));
    const top = enriched[0] || { row: {}, eval: {} };
    const topTitle = top.row.job_name || '当前列表岗位';
    const topSalaryVal = Number(top.row.salary_avg || 0);
    renderJobEvalPanel({
        stateText: '预评估完成',
        score: Number(top.eval.score || 0),
        investIndex: Number(top.eval.investIndex || 0),
        riskLevel: String(top.eval.riskLevel || '--'),
        bucket: String(top.eval.bucket || '--'),
        jobTitle: topTitle,
        reason: `当前列表共 ${list.length} 个岗位，已完成规则预评估。`,
        nextActions: [
            `优先处理：${topTitle}${topSalaryVal > 0 ? `（约 ¥${topSalaryVal.toLocaleString()}）` : ''}。`,
            `当前最高匹配 ${Number(top.eval.score || 0)} 分，建议先查看详细岗位决策报告。`,
            '再按主申/冲刺/保底分层进入投递看板。'
        ]
    });
}

function applyJobEvalPanelSnapshot(snapshot = {}) {
    latestJobEvalPanelSnapshot = {
        ...snapshot,
        updatedAt: Date.now()
    };
    renderJobEvalPanel(latestJobEvalPanelSnapshot);
}

window.syncJobEvalPanelFromList = syncJobEvalPanelFromList;

async function loadSummaryDashboard() {
    if (document.body.classList.contains('app-auth-locked')) return;
    const summaryOverlay = document.getElementById('auth-overlay');
    if (summaryOverlay && summaryOverlay.style.display !== 'none') return;
    try {
        const toFiniteList = (arr) => (Array.isArray(arr) ? arr.map(x => Number(x)).filter(v => Number.isFinite(v)) : []);
        const ids = ['home-c1', 'home-c2', 'home-c3', 'home-c4'];
        const getHomeChart = (id) => {
            const inst = charts[id];
            return inst && typeof inst.setOption === 'function' ? inst : null;
        };
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                if (!charts[id]) charts[id] = echarts.init(el);
                charts[id].showLoading({ text: '数据雷达同步中...', color: '#4f46e5' });
            }
        });

        const r = await fetch('/api/summary/charts');
        const d = await r.json();

        Object.keys(charts).forEach(k => {
            if (k.startsWith('home-c') && charts[k] && typeof charts[k].hideLoading === 'function') {
                charts[k].hideLoading();
            }
        });

        const gridDiv = document.querySelector('#tab-summary .summary-chart-grid');
        const emptyDiv = document.getElementById('home-empty-state');
        if (!d.success || d.empty) {
            if (gridDiv) gridDiv.style.display = 'none';
            if (emptyDiv) emptyDiv.style.display = 'flex';
            return;
        } else {
            if (gridDiv) gridDiv.style.display = 'grid';
            if (emptyDiv) emptyDiv.style.display = 'none';
        }

        const commonGrid = { top: 40, right: 30, bottom: 40, left: 60, containLabel: true };

        if (d.city && d.city.labels && d.city.avg) {
            const cityTop = d.city.labels[0] || '未知城市';
            const citySalary = Number(d.city.avg[0] || 0);
            const c1Note = document.getElementById('home-c1-note');
            if (c1Note) c1Note.innerText = `结论：${cityTop} 当前均薪较高（约 ¥${citySalary.toLocaleString()}），可优先纳入投递城市清单。`;
            const c1Chart = getHomeChart('home-c1');
            if (c1Chart) c1Chart.setOption({
                tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
                grid: commonGrid,
                xAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { type: 'dashed', color: '#e5e7eb' } } },
                yAxis: { type: 'category', data: [...d.city.labels].reverse(), axisTick: { show: false }, axisLine: { lineStyle: { color: '#9ca3af' } } },
                series: [{
                    name: '平均薪资(元)',
                    type: 'bar',
                    data: [...d.city.avg].reverse(),
                    itemStyle: {
                        color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                            { offset: 0, color: '#60a5fa' },
                            { offset: 1, color: '#2563eb' }
                        ]),
                        borderRadius: [0, 6, 6, 0]
                    },
                        label: { show: true, position: 'right', color: '#4b5563', formatter: '{c}' }
                }]
            });
        }

        if (d.cloud && d.cloud.length > 0) {
            const topSkill = d.cloud[0] && d.cloud[0].name ? d.cloud[0].name : '核心技能';
            const c2Note = document.getElementById('home-c2-note');
            if (c2Note) c2Note.innerText = `结论：${topSkill} 是高频需求项，建议优先补齐并在简历中突出相关项目。`;
            const c2Chart = getHomeChart('home-c2');
            if (c2Chart) {
                try {
                    c2Chart.setOption({
                        tooltip: { show: true },
                        series: [{
                            type: 'wordCloud',
                            shape: 'circle',
                            left: 'center',
                            top: 'center',
                            width: '90%',
                            height: '90%',
                            sizeRange: [14, 46],
                            rotationRange: [-45, 45],
                            gridSize: 12,
                            textStyle: { fontFamily: 'sans-serif', fontWeight: '600', color: () => getBrandColor(Math.floor(Math.random() * 8)) },
                            data: d.cloud
                        }]
                    });
                } catch (err) {
                    const topSkills = d.cloud.slice(0, 8);
                    c2Chart.setOption({
                        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
                        grid: commonGrid,
                        xAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { type: 'dashed', color: '#e5e7eb' } } },
                        yAxis: { type: 'category', data: topSkills.map(x => x.name).reverse(), axisTick: { show: false }, axisLine: { lineStyle: { color: '#9ca3af' } } },
                        series: [{
                            name: '需求频次',
                            type: 'bar',
                            data: topSkills.map(x => Number(x.value || 0)).reverse(),
                            itemStyle: {
                                color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                                    { offset: 0, color: '#34d399' },
                                    { offset: 1, color: '#059669' }
                                ]),
                                borderRadius: [0, 6, 6, 0]
                            },
                            label: { show: true, position: 'right', color: '#4b5563', formatter: '{c}' }
                        }]
                    });
                    console.warn('wordCloud 不可用，已降级为条形图', err);
                }
            }
        }

        const salaryExpLabels =
            (d.salary && d.salary.exp_trend && d.salary.exp_trend.labels) ||
            (d.salary && d.salary.dist && d.salary.dist.labels) ||
            (d.salary && d.salary.range_dist && d.salary.range_dist.labels) ||
            [];
        const salaryExpValues =
            (d.salary && d.salary.exp_trend && (d.salary.exp_trend.values || d.salary.exp_trend.avg)) ||
            (d.salary && d.salary.dist && d.salary.dist.values) ||
            (d.salary && d.salary.range_dist && d.salary.range_dist.values) ||
            [];
        const salaryExpNums = toFiniteList(salaryExpValues);
        if (salaryExpLabels.length > 0 && salaryExpNums.length > 0) {
            const c3Note = document.getElementById('home-c3-note');
            if (c3Note) {
                const nums = salaryExpNums.filter(v => v > 0);
                const maxVal = nums.length ? Math.max(...nums) : 0;
                c3Note.innerText = maxVal > 0
                    ? `结论：经验提升与薪资增长呈正相关，当前最高层级约 ¥${maxVal.toLocaleString()}。`
                    : '结论：当前样本中的经验薪资数据不足，建议先扩充样本再判断趋势。';
            }
            const c3Chart = getHomeChart('home-c3');
            if (c3Chart) c3Chart.setOption({
                tooltip: { trigger: 'axis', backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 12, borderRadius: 8, textStyle: { color: '#333' }, formatter: (p) => `<div style="font-weight:bold;margin-bottom:6px;">${p[0].name}</div><div style="display:flex;align-items:center;gap:8px;"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${p[0].color}"></span>均薪：¥${p[0].value.toLocaleString()}</div>` },
                grid: { top: 30, right: 30, bottom: 30, left: 60, containLabel: true },
                xAxis: { type: 'category', data: salaryExpLabels, axisLine: { lineStyle: { color: '#e2e8f0' } }, axisLabel: { color: '#64748b' }, axisTick: { show: false } },
                yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { type: 'dashed', color: '#f1f5f9' } }, axisLabel: { color: '#64748b' } },
                series: [{
                    type: 'line', smooth: true, symbol: 'circle', symbolSize: 6,
                    data: salaryExpNums,
                    itemStyle: { color: '#6366f1', borderWidth: 2, borderColor: '#fff' },
                    lineStyle: { width: 3, shadowColor: 'rgba(99,102,241,0.3)', shadowBlur: 10, shadowOffsetY: 5 },
                    areaStyle: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                            { offset: 0, color: 'rgba(99,102,241,0.5)' },
                            { offset: 1, color: 'rgba(99,102,241,0.05)' }
                        ])
                    }
                }]
            });
        } else if (getHomeChart('home-c3')) {
            const c3Note = document.getElementById('home-c3-note');
            const rangeLabels = (((d.salary || {}).range_dist || {}).labels) || [];
            const rangeValues = toFiniteList((((d.salary || {}).range_dist || {}).values) || []);
            const c3Chart = getHomeChart('home-c3');
            if (rangeLabels.length > 0 && rangeValues.length > 0) {
                if (c3Note) c3Note.innerText = '说明：经验字段不足，已自动切换为薪资区间分布作为参考。';
                c3Chart && c3Chart.setOption({
                    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
                    grid: { top: 30, right: 20, bottom: 30, left: 50, containLabel: true },
                    xAxis: { type: 'category', data: rangeLabels, axisLine: { lineStyle: { color: '#e2e8f0' } }, axisLabel: { color: '#64748b' }, axisTick: { show: false } },
                    yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { type: 'dashed', color: '#f1f5f9' } }, axisLabel: { color: '#64748b' } },
                    series: [{
                        type: 'bar',
                        data: rangeValues,
                        itemStyle: { color: '#6366f1', borderRadius: [6, 6, 0, 0] }
                    }]
                }, true);
            } else {
                if (c3Note) c3Note.innerText = '结论：暂无可用的经验分层数据，请先采集或导入更多岗位样本。';
                c3Chart && c3Chart.setOption({
                    xAxis: { show: false },
                    yAxis: { show: false },
                    series: [],
                    graphic: [{
                        type: 'text',
                        left: 'center',
                        top: 'middle',
                        style: { text: '暂无经验薪资数据', fill: '#94a3b8', fontSize: 13 }
                    }]
                }, true);
            }
        }

        if (d.edu && d.edu.labels && (d.edu.values || d.edu.avg || d.edu.counts || d.edu.count)) {
            let petalData = [];
            for (let i = 0; i < d.edu.labels.length; i++) {
                const eduSalaryVal = d.edu.values && d.edu.values[i] > 0 ? d.edu.values[i] : (d.edu.avg && d.edu.avg[i] > 0 ? d.edu.avg[i] : 0);
                const eduCountVal = d.edu.counts && d.edu.counts[i] > 0 ? d.edu.counts[i] : (d.edu.count && d.edu.count[i] > 0 ? d.edu.count[i] : 0);
                if (eduSalaryVal > 0) {
                    petalData.push({ name: d.edu.labels[i], value: eduSalaryVal });
                } else if (eduCountVal > 0) {
                    petalData.push({ name: d.edu.labels[i], value: eduCountVal });
                }
            }
            if (petalData.length > 0) {
                const sortedPetalData = [...petalData].sort((a, b) => Number(b.value || 0) - Number(a.value || 0));
                const c4Note = document.getElementById('home-c4-note');
                if (c4Note) {
                    const topEdu = sortedPetalData[0] || { name: '未知', value: 0 };
                    c4Note.innerText = `结论：${topEdu.name} 对应薪资更高（约 ¥${Number(topEdu.value || 0).toLocaleString()}），可作为长期提升方向参考。`;
                }
                const c4Chart = getHomeChart('home-c4');
                c4Chart && c4Chart.setOption({
                    tooltip: { trigger: 'item', formatter: '{b} <br/> 均薪: ¥{c} ({d}%)' },
                    legend: { bottom: '0%', left: 'center', itemWidth: 10, itemHeight: 10, textStyle: { color: '#64748b' }, icon: 'circle' },
                    color: ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#06b6d4'],
                    series: [{
                        name: '学历薪资分析', type: 'pie', radius: ['15%', '70%'], center: ['50%', '45%'],
                        roseType: 'area', itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
                        label: { show: true, formatter: '{b}\n{d}%', fontSize: 11, color: '#475569' },
                        data: sortedPetalData
                    }]
                }, true); // Use true to prevent leftover bar chart grid lines if any
            } else if ((d.edu.counts || d.edu.count || []).length > 0) {
                const eduCounts = d.edu.counts || d.edu.count;
                const labels = d.edu.labels || [];
                const vals = toFiniteList(eduCounts);
                const c4Note = document.getElementById('home-c4-note');
                if (c4Note) c4Note.innerText = '说明：薪资字段不足，已切换为学历样本占比参考。';
                const c4Chart = getHomeChart('home-c4');
                c4Chart && c4Chart.setOption({
                    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
                    grid: { top: 20, right: 20, bottom: 30, left: 50, containLabel: true },
                    xAxis: { type: 'category', data: labels, axisLine: { lineStyle: { color: '#e2e8f0' } }, axisTick: { show: false }, axisLabel: { color: '#64748b' } },
                    yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { type: 'dashed', color: '#f1f5f9' } }, axisLabel: { color: '#64748b' } },
                    series: [{ type: 'bar', data: vals, itemStyle: { color: '#8b5cf6', borderRadius: [6, 6, 0, 0] } }]
                }, true);
            }
        } else if (getHomeChart('home-c4')) {
            const c4Note = document.getElementById('home-c4-note');
            if (c4Note) c4Note.innerText = '结论：暂无可用的学历薪资数据，请先补充学历字段后再分析。';
            const c4Chart = getHomeChart('home-c4');
            c4Chart && c4Chart.setOption({
                series: [],
                legend: { show: false },
                graphic: [{
                    type: 'text',
                    left: 'center',
                    top: 'middle',
                    style: { text: '暂无学历薪资数据', fill: '#94a3b8', fontSize: 13 }
                }]
            }, true);
        }
        // 延迟调整图表尺寸，确保容器布局已完成
        setTimeout(() => {
            ['home-c1', 'home-c2', 'home-c3', 'home-c4'].forEach(id => {
                if (charts[id]) charts[id].resize();
            });
        }, 150);
    } catch (e) {
        console.error("Home Charts Error", e);
    }
}

function quickEntry(action) {
    const map = {
        crawl: 'spider',
        dashboard: 'dashboard',
        recommend: 'ai'
    };
    const id = map[action] || 'summary';
    const menu = document.querySelector(`.menu-item[onclick*="switchTab('${id}'"]`);
    if (menu) switchTab(id, menu);
    else switchTab(id);
}

function dismissProfileBanner() {
    localStorage.setItem('profile_banner_dismissed_at', new Date().toISOString());
    const banner = document.getElementById('profile-banner');
    if (banner) banner.style.display = 'none';
}

function gotoProfileFromBanner() {
    const menu = document.querySelector(`.menu-item[onclick*="switchTab('profile'"]`);
    if (menu) switchTab('profile', menu);
    else switchTab('profile');
}

function toggleSummaryAdvancedView(forceOpen = null) {
    const btn = document.getElementById('summary-toggle-advanced');
    const current = document.body.classList.contains('summary-advanced-open');
    const next = (typeof forceOpen === 'boolean') ? forceOpen : !current;
    document.body.classList.toggle('summary-advanced-open', next);
    if (btn) {
        btn.innerHTML = next
            ? '<i class="ri-layout-grid-line"></i> 收起市场洞察'
            : '<i class="ri-layout-grid-line"></i> 展开市场洞察';
    }
    localStorage.setItem('summary_advanced_open', next ? '1' : '0');
}

function initSummaryProgressiveView() {
    const saved = localStorage.getItem('summary_advanced_open');
    toggleSummaryAdvancedView(saved === '1');
}

// =========================================================
// 9. 求职决策闭环补丁（画像 -> 评估 -> 投递 -> 跟踪）
// =========================================================
const APP_STATUS_COLUMNS = [
    { key: 'favorite', label: '已收藏' },
    { key: 'applied', label: '已投递' },
    { key: 'interview', label: '面试邀约' },
    { key: 'offer', label: 'Offer' }
];

let appIdByJobId = {};
let appCacheRows = [];
let appAllRows = [];
let aiAdviceCache = {};
let latestSkillGapList = [];
let aiRuntimeStatusCache = { ts: 0, data: null };
const APP_PANEL_TIMEOUT_MS = 3000;
const APP_MARKET_BASELINE = {
    interviewRate: 22,
    offerRate: 8
};
const PROFILE_LEARNING_SKILLS_KEY = 'profile_learning_skills';
const PROFILE_TIMELINE_KEY = 'profile_timeline_events';

function getLearningSkillSet() {
    try {
        const raw = localStorage.getItem(PROFILE_LEARNING_SKILLS_KEY) || '[]';
        const arr = JSON.parse(raw);
        if (!Array.isArray(arr)) return new Set();
        return new Set(arr.map(x => String(x || '').trim().toLowerCase()).filter(Boolean));
    } catch (_) {
        return new Set();
    }
}

function saveLearningSkillSet(setObj) {
    const arr = Array.from(setObj || []);
    localStorage.setItem(PROFILE_LEARNING_SKILLS_KEY, JSON.stringify(arr));
}

function appendLearningSkillToProfileInput(skill) {
    const input = document.getElementById('p-skills');
    if (!input) return;
    const s = String(skill || '').trim();
    if (!s) return;
    const raw = String(input.value || '').split(/[，,、]/).map(x => x.trim()).filter(Boolean);
    const normalized = raw.map(x => x.toLowerCase());
    const plain = s.toLowerCase();
    const marked = `${s}(学习中)`;
    if (!normalized.includes(plain) && !normalized.includes(marked.toLowerCase())) {
        raw.push(marked);
        input.value = raw.join(', ');
        if (typeof syncProfileSkillTagsFromHidden === 'function') syncProfileSkillTagsFromHidden(true);
        markProfileFormDirty(true);
    }
}

function pushProfileTimelineEvent(title, desc) {
    try {
        const oldRaw = localStorage.getItem(PROFILE_TIMELINE_KEY) || '[]';
        const arr = JSON.parse(oldRaw);
        const list = Array.isArray(arr) ? arr : [];
        list.unshift({
            ts: Date.now(),
            tone: 'favorite',
            title: String(title || '学习事件'),
            desc: String(desc || '')
        });
        localStorage.setItem(PROFILE_TIMELINE_KEY, JSON.stringify(list.slice(0, 20)));
    } catch (_) { }
}

function isLearningSkill(skill) {
    const key = String(skill || '').trim().toLowerCase();
    if (!key) return false;
    return getLearningSkillSet().has(key);
}

function toggleLearningSkill(skill) {
    const s = String(skill || '').trim();
    if (!s) return;
    const key = s.toLowerCase();
    const setObj = getLearningSkillSet();
    if (setObj.has(key)) {
        setObj.delete(key);
        showToast(`已取消学习标记：${s}`);
    } else {
        setObj.add(key);
        appendLearningSkillToProfileInput(s);
        pushProfileTimelineEvent('开始学习技能', `${s} 已加入学习计划`);
        showToast(`已加入学习计划：${s}`);
    }
    saveLearningSkillSet(setObj);
    if (typeof updateCard === 'function') updateCard();
    if (typeof loadSkillGap === 'function') loadSkillGap();
}

window.toggleLearningSkill = toggleLearningSkill;

async function getAiRuntimeStatus(force = false) {
    const now = Date.now();
    if (!force && aiRuntimeStatusCache.data && (now - aiRuntimeStatusCache.ts) < 30000) {
        return aiRuntimeStatusCache.data;
    }
    const ruleFallback = {
        mode: 'rule',
        ai_available: false,
        message: '系统增强服务暂不可用，已自动切换规则模式',
        tips: '核心结论与行动建议可正常使用'
    };
    try {
        let body = null;
        if (typeof fetchJsonWithTimeout === 'function') {
            const res = await fetchJsonWithTimeout('/api/ai/status', {}, 6000);
            if (res && res.ok && res.body && res.body.success) body = res.body.data || null;
        } else {
            const r = await fetch('/api/ai/status');
            const d = await r.json();
            if (r.ok && d && d.success) body = d.data || null;
        }
        if (body && typeof body === 'object') {
            aiRuntimeStatusCache = { ts: now, data: body };
            return body;
        }
    } catch (e) {
        // 忽略状态接口异常，统一按规则模式兜底
    }
    aiRuntimeStatusCache = { ts: now, data: ruleFallback };
    return ruleFallback;
}

function getAiRuntimeHint(status) {
    const s = status || {};
    const mode = String(s.mode || 'rule');
    if (s.ai_available) {
        if (mode === 'ollama') return '系统增强模式：本地模型可用，支持深度解读';
        if (mode === 'cloud') return '系统增强模式：云端回退可用，支持智能解读';
        return '系统增强模式：可用';
    }
    return '规则模式：系统增强服务不可用时自动降级，主流程不受影响';
}

function normalizeAppStatusKey(raw) {
    const s = String(raw || '').toLowerCase();
    if (!s) return 'favorite';
    if (s.includes('offer')) return 'offer';
    if (s.includes('reject') || s.includes('拒')) return 'applied';
    if (s.includes('interview') || s.includes('面试')) return 'interview';
    if (s.includes('screen') || s.includes('筛')) return 'applied';
    if (s.includes('applied') || s.includes('投递') || s.includes('姇')) return 'applied';
    if (s.includes('favorite') || s.includes('favourite') || s.includes('收藏') || s.includes('敹')) return 'favorite';
    return 'favorite';
}

function statusKeyToApiValue(key) {
    if (key === 'applied') return 'applied';
    if (key === 'interview') return 'interview';
    if (key === 'offer') return 'offer';
    return 'favorite';
}

function getStepperConfig() {
    return [
        { key: 'profile', title: '完善个人画像', icon: 'ri-user-settings-line' },
        { key: 'evaluate', title: '岗位决策', icon: 'ri-radar-line' },
        { key: 'compet', title: '画像深度分析', icon: 'ri-bar-chart-grouped-line' },
        { key: 'apply', title: '投递执行', icon: 'ri-send-plane-line' },
        { key: 'interview', title: '面试准备', icon: 'ri-discuss-line' },
        { key: 'improve', title: '持续提升', icon: 'ri-rocket-line' }
    ];
}

function renderJobStepper(progressState = null) {
    const box = document.getElementById('job-stepper');
    if (!box) return;
    const steps = getStepperConfig();
    box.innerHTML = steps.map((s, idx) => {
        const stateObj = Array.isArray(progressState) ? (progressState[idx] || {}) : {};
        const state = stateObj.state || (idx === 0 ? 'doing' : 'todo');
        const toneText = stateObj.text || (state === 'done' ? '已完成' : (state === 'doing' ? '进行中' : '待开始'));
        const stateClass = state === 'done' ? 'is-active' : (state === 'doing' ? 'is-doing' : 'is-pending');
        return `
            <div class="job-step-item ${stateClass}">
                <div class="job-step-line"></div>
                <div class="job-step-dot"><i class="${s.icon}"></i></div>
                <div class="job-step-main">
                    <div class="job-step-title">${idx + 1}. ${s.title}</div>
                    <div class="job-step-state">${toneText}</div>
                </div>
            </div>
        `;
    }).join('');
}

function getJobFlowStep() {
    const val = parseInt(localStorage.getItem('job_flow_step') || '0', 10);
    return Number.isFinite(val) ? Math.max(0, Math.min(5, val)) : 0;
}

function setJobFlowStep(step) {
    const safe = Math.max(0, Math.min(5, parseInt(step || 0, 10)));
    localStorage.setItem('job_flow_step', String(safe));
    renderJobStepper();
}

function buildSummaryProgressState(ctx) {
    const profileScore = Number(ctx.profileScore || 0);
    const recCount = Number(ctx.recCount || 0);
    const competitDone = Boolean(ctx.competitDone);
    const shortlistCount = Number(ctx.shortlistCount || 0);
    const appliedCount = Number(ctx.appliedCount || 0);
    const interviewCount = Number(ctx.interviewCount || 0);
    const offerCount = Number(ctx.offerCount || 0);
    const improveDone = Boolean(ctx.improveDone);

    const step1 = profileScore >= 80 ? { state: 'done', text: '已完成' } : (profileScore >= 40 ? { state: 'doing', text: '进行中' } : { state: 'todo', text: '待开始' });
    const step2 = shortlistCount > 0 ? { state: 'done', text: '已完成' } : (recCount > 0 ? { state: 'doing', text: '进行中' } : { state: 'todo', text: '待开始' });
    const step3 = (competitDone && step2.state !== 'todo') ? { state: 'done', text: '已完成' } : (step2.state !== 'todo' ? { state: 'doing', text: '进行中' } : { state: 'todo', text: '待开始' });
    const step4 = appliedCount > 0 ? { state: 'done', text: '已完成' } : (recCount > 0 ? { state: 'doing', text: '进行中' } : { state: 'todo', text: '待开始' });
    const step5 = (interviewCount + offerCount) > 0 ? { state: 'done', text: '已完成' } : (appliedCount > 0 ? { state: 'doing', text: '进行中' } : { state: 'todo', text: '待开始' });
    const step6 = (improveDone && step5.state !== 'todo') ? { state: 'done', text: '已完成' } : ((step5.state === 'done' || step5.state === 'doing') ? { state: 'doing', text: '进行中' } : { state: 'todo', text: '待开始' });
    return [step1, step2, step3, step4, step5, step6];
}

function renderWeeklyMissionBoard(ctx = {}) {
    const box = document.getElementById('summary-mission-board');
    if (!box) return;
    const profileScore = Number(ctx.profileScore || 0);
    const recCount = Number(ctx.recCount || 0);
    const shortlistCount = Number(ctx.shortlistCount || 0);
    const appliedCount = Number(ctx.appliedCount || 0);
    const interviewCount = Number(ctx.interviewCount || 0);
    const topMissing = Array.isArray(ctx.topMissing) ? ctx.topMissing.filter(Boolean) : [];

    const missions = [];
    if (profileScore < 60) {
        missions.push({
            title: '完善画像关键字段',
            detail: `当前画像 ${profileScore} 分，先补齐目标岗位、技能、经验和薪资区间。`,
            priority: 'high',
            eta: '约 10 分钟',
            impact: '提高评估可信度',
            actionId: 'profile'
        });
    }
    if (profileScore >= 60 && recCount <= 0) {
        missions.push({
            title: '重新生成岗位决策结果',
            detail: '当前高匹配岗位为 0，建议放宽城市或关键词后再次评估。',
            priority: 'high',
            eta: '约 8 分钟',
            impact: '产出可投候选池',
            actionId: 'data'
        });
    }
    if (recCount > 0 && shortlistCount <= 0) {
        missions.push({
            title: '把高匹配岗位加入候选池',
            detail: `已识别 ${recCount} 个高匹配岗位，先筛出主申/冲刺各 1-2 个。`,
            priority: 'high',
            eta: '约 12 分钟',
            impact: '明确投递优先级',
            actionId: 'data'
        });
    }
    if (shortlistCount > 0 && appliedCount <= 0) {
        missions.push({
            title: '执行首轮投递验证',
            detail: `当前候选 ${shortlistCount} 个，建议先投递 2-3 个主申岗位。`,
            priority: 'high',
            eta: '约 20 分钟',
            impact: '启动转化闭环',
            actionId: 'applications'
        });
    }
    if (appliedCount > 0 && interviewCount <= 0) {
        missions.push({
            title: '安排投递跟进与转化',
            detail: `已投递 ${appliedCount} 个岗位，建议 48 小时内更新一次状态并跟进。`,
            priority: 'mid',
            eta: '约 10 分钟',
            impact: '提升面试转化率',
            actionId: 'applications'
        });
    }
    if (topMissing.length) {
        missions.push({
            title: '补齐关键技能短板',
            detail: `优先补齐：${topMissing.slice(0, 2).join('、')}。`,
            priority: 'mid',
            eta: '约 2-3 天',
            impact: '提升匹配分与面试通过率',
            actionId: 'compet'
        });
    }

    const finalMissions = missions.length ? missions.slice(0, 3) : [{
        title: '保持投递节奏并持续复盘',
        detail: '当前流程推进稳定，建议继续跟进在途岗位并更新画像。',
        priority: 'low',
        eta: '每日 10 分钟',
        impact: '稳定提升转化',
        actionId: 'applications'
    }];

    box.innerHTML = finalMissions.map((m, idx) => {
        const pri = String(m.priority || 'mid').toLowerCase();
        const priText = pri === 'high' ? '高优先级' : (pri === 'low' ? '低优先级' : '中优先级');
        return `
            <div class="summary-mission-item">
                <div class="summary-mission-head">
                    <div class="summary-mission-title">${idx + 1}. ${m.title || '执行行动'}</div>
                    <span class="summary-mission-priority ${pri}">${priText}</span>
                </div>
                <div class="summary-mission-desc">${m.detail || ''}</div>
                <div class="summary-mission-meta">
                    <span>预估耗时：${m.eta || '--'}</span>
                    <span>预期收益：${m.impact || '--'}</span>
                </div>
                <div>
                    <button class="btn btn-default" onclick="runSummaryAction('${m.actionId || ''}')">${getSummaryActionButtonText(m.actionId)}</button>
                </div>
            </div>
        `;
    }).join('');
}

let profileFormDirty = false;
let profileSavedFingerprint = '';
let profileDirtyWatchersBound = false;

function updateProfileDirtyUI() {
    const btn = document.getElementById('btn-save-profile');
    const txt = document.getElementById('btn-save-profile-text');
    if (!btn || !txt) return;
    if (hasUnsavedProfileChanges()) {
        btn.classList.add('is-dirty');
        txt.innerText = '● 有未保存更改';
    } else {
        btn.classList.remove('is-dirty');
        txt.innerText = '保存画像';
    }
}

function markProfileFormDirty(force = true) {
    if (force) {
        profileFormDirty = true;
        updateProfileDirtyUI();
        return;
    }
    profileFormDirty = buildProfileFingerprint() !== profileSavedFingerprint;
    updateProfileDirtyUI();
}

function resetProfileFormDirty() {
    profileSavedFingerprint = buildProfileFingerprint();
    profileFormDirty = false;
    updateProfileDirtyUI();
}

function hasUnsavedProfileChanges() {
    if (profileFormDirty) return true;
    return buildProfileFingerprint() !== profileSavedFingerprint;
}

window.markProfileFormDirty = markProfileFormDirty;

function bindProfileFormDirtyWatchers() {
    if (profileDirtyWatchersBound) return;
    profileDirtyWatchersBound = true;
    ['p-job', 'p-city', 'p-edu', 'p-exp', 'p-salary-min', 'p-salary-max'].forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('input', () => markProfileFormDirty(false));
        el.addEventListener('change', () => markProfileFormDirty(false));
    });
}

async function ensureProfileCityOptions() {
    const datalist = document.getElementById('profile-city-options');
    if (!datalist) return;
    if (datalist.getAttribute('data-loaded') === '1') return;
    try {
        const r = await fetch('/api/config/cities');
        const d = await r.json();
        if (d && d.success && Array.isArray(d.data)) {
            const existing = new Set(Array.from(datalist.querySelectorAll('option')).map(x => String(x.value || '').trim()));
            d.data.forEach(city => {
                const c = String(city || '').trim();
                if (!c || existing.has(c)) return;
                const opt = document.createElement('option');
                opt.value = c;
                datalist.appendChild(opt);
            });
            datalist.setAttribute('data-loaded', '1');
        }
    } catch (_) { }
}

async function switchProfileSubTab(subtab) {
    const activeBtn = document.querySelector('.profile-subtab-btn.active');
    const currentSubtab = activeBtn ? activeBtn.getAttribute('data-subtab') : 'basic';
    if (currentSubtab === 'basic' && subtab !== 'basic' && hasUnsavedProfileChanges()) {
        const saveFirst = window.confirm('检测到“我的画像”有未保存修改。\n点击“确定”先保存再切换。');
        if (saveFirst) {
            const ok = await saveProfile(true);
            if (!ok) return;
        } else {
            const discard = window.confirm('是否放弃当前修改并继续切换？');
            if (!discard) return;
            profileFormDirty = false;
            updateProfileDirtyUI();
        }
    }
    document.querySelectorAll('.profile-subtab-panel').forEach(el => { el.style.display = 'none'; });
    document.querySelectorAll('.profile-subtab-btn').forEach(btn => { btn.classList.remove('active'); });
    const panel = document.getElementById('profile-sub-' + subtab);
    if (panel) panel.style.display = 'block';
    const btn = document.querySelector(`.profile-subtab-btn[data-subtab="${subtab}"]`);
    if (btn) btn.classList.add('active');
    if (subtab === 'compet') setJobFlowStep(Math.max(getJobFlowStep(), 2));
}

function normalizeProfileExpValue(exp) {
    const value = String(exp || '').trim();
    if (!value) return '应届/实习';
    if (value === '应届生' || value === '应届') return '应届/实习';
    const expEl = document.getElementById('p-exp');
    if (!expEl) return value;
    const options = Array.from(expEl.options || []).map(o => o.value);
    return options.includes(value) ? value : '应届/实习';
}

function parseProfileExpYears(expText) {
    const s = String(expText || '').trim();
    if (!s) return 0;
    if (s.includes('应届') || s.includes('实习')) return 0;
    if (s.includes('不限')) return 1;
    if (s.includes('1年以内')) return 1;
    if (s.includes('1-3')) return 2;
    if (s.includes('3-5')) return 4;
    if (s.includes('5-10')) return 7;
    if (s.includes('10')) return 10;
    const m = s.match(/(\d+(\.\d+)?)/);
    return m ? Number(m[1]) : 0;
}

function buildProfileFingerprint(profileLike = null) {
    const p = profileLike || {};
    const job = String(p.target_job || p.job || (document.getElementById('p-job') || {}).value || '').trim().toLowerCase();
    const city = String(p.target_city || p.city || (document.getElementById('p-city') || {}).value || '').trim().toLowerCase();
    const edu = String(p.edu_level || p.edu || (document.getElementById('p-edu') || {}).value || '').trim().toLowerCase();
    const exp = String(p.exp_year || p.exp || (document.getElementById('p-exp') || {}).value || '').trim().toLowerCase();
    const salaryMin = String(p.expected_salary_min || p.salary_min || (document.getElementById('p-salary-min') || {}).value || '').trim();
    const salaryMax = String(p.expected_salary_max || p.salary_max || (document.getElementById('p-salary-max') || {}).value || '').trim();
    const skillsRaw = String(p.skills || (document.getElementById('p-skills') || {}).value || '');
    const skills = skillsRaw
        .split(/[，,、]/)
        .map(x => x.trim().toLowerCase())
        .filter(Boolean)
        .sort()
        .join(',');
    return `${job}|${city}|${edu}|${exp}|${salaryMin}|${salaryMax}|${skills}`;
}

function renderDecisionCardLite(title, conclusion, reason, suggestion, tone = 'mid') {
    const colorMap = {
        good: { bd: '#86efac', bg: '#ecfdf5', fg: '#166534' },
        mid: { bd: '#fcd34d', bg: '#fffbeb', fg: '#92400e' },
        risk: { bd: '#fecaca', bg: '#fef2f2', fg: '#991b1b' }
    };
    const t = colorMap[tone] || colorMap.mid;
    return `
        <div style="border:1px solid ${t.bd}; background:${t.bg}; border-radius:10px; padding:12px;">
            <div style="font-weight:700; color:${t.fg}; margin-bottom:8px;">${title}</div>
            <div style="margin-bottom:6px;"><b>结论：</b>${conclusion || '--'}</div>
            <div style="margin-bottom:6px; color:#334155;"><b>原因：</b>${reason || '--'}</div>
            <div style="color:#0f172a;"><b>建议：</b>${suggestion || '--'}</div>
        </div>
    `;
}

async function fetchProfilePayload() {
    if (document.body.classList.contains('app-auth-locked')) return {};
    const profileOverlay = document.getElementById('auth-overlay');
    if (profileOverlay && profileOverlay.style.display !== 'none') return {};
    try {
        const scoreRes = await fetch('/api/profile/score');
        const scoreJson = await scoreRes.json();
        if (scoreJson && scoreJson.success) return scoreJson.profile || {};
    } catch (e) {
        console.warn('读取画像接口失败，降级到兼容接口', e);
    }
    try {
        const r = await fetch('/api/user/profile');
        const d = await r.json();
        if (d && d.success && d.data) return d.data;
    } catch (e) {
        console.error('读取兼容画像接口失败', e);
    }
    return {};
}

async function loadProfile() {
    if (document.body.classList.contains('app-auth-locked')) return;
    const loadProfileOverlay = document.getElementById('auth-overlay');
    if (loadProfileOverlay && loadProfileOverlay.style.display !== 'none') return;
    try {
        await ensureProfileCityOptions();
        const profile = await fetchProfilePayload();
        const jobEl = document.getElementById('p-job');
        if (jobEl) jobEl.value = profile.target_job || '';
        const cityEl = document.getElementById('p-city');
        if (cityEl) {
            const city = profile.target_city || localStorage.getItem('profile_target_city') || cityEl.value || '北京';
            cityEl.value = city;
        }
        const eduEl = document.getElementById('p-edu');
        if (eduEl) eduEl.value = profile.edu_level || '本科';
        const expEl = document.getElementById('p-exp');
        if (expEl) expEl.value = normalizeProfileExpValue(profile.exp_year);
        const skillsEl = document.getElementById('p-skills');
        if (skillsEl) skillsEl.value = profile.skills || '';
        if (typeof initProfileSkillInput === 'function') await initProfileSkillInput();
        if (typeof syncProfileSkillTagsFromHidden === 'function') syncProfileSkillTagsFromHidden(false);
        if (document.getElementById('p-salary-min')) document.getElementById('p-salary-min').value = profile.expected_salary_min || '';
        if (document.getElementById('p-salary-max')) document.getElementById('p-salary-max').value = profile.expected_salary_max || '';
    } catch (e) {
        console.error(e);
    }
    bindProfileFormDirtyWatchers();
    resetProfileFormDirty();
    updateCard();
    refreshProfileScore();
}

function resetProfileForm() {
    const defaults = {
        job: 'Python 开发工程师',
        city: '北京',
        edu: '本科',
        exp: '应届/实习',
        skills: 'python',
        salaryMin: '12000',
        salaryMax: ''
    };

    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val;
    };

    setVal('p-job', defaults.job);
    setVal('p-city', defaults.city);
    setVal('p-edu', defaults.edu);
    setVal('p-exp', defaults.exp);
    setVal('p-skills', defaults.skills);
    setVal('p-salary-min', defaults.salaryMin);
    setVal('p-salary-max', defaults.salaryMax);

    // 画像重置后，历史分析状态失效，避免误判“已完成”
    localStorage.removeItem('competitiveness_done');
    localStorage.removeItem('improve_action_done');
    localStorage.removeItem('competitiveness_profile_fp');
    localStorage.removeItem('improve_profile_fp');
    if (typeof syncProfileSkillTagsFromHidden === 'function') syncProfileSkillTagsFromHidden(true);
    markProfileFormDirty(true);
    updateCard();
    showToast('已重置为默认画像，请点击“保存画像”生效');
}

async function saveProfile(silent = false) {
    const actionBtn = document.querySelector('#tab-profile button[onclick="saveProfile()"]');
    setButtonLoading(actionBtn, '保存中...');
    const expText = normalizeProfileExpValue((document.getElementById('p-exp') || {}).value || '');
    let salaryMin = parseInt((document.getElementById('p-salary-min') || {}).value || '0', 10) || 0;
    let salaryMax = parseInt((document.getElementById('p-salary-max') || {}).value || '0', 10) || 0;
    if (salaryMin > 0 && salaryMax > 0 && salaryMin > salaryMax) {
        const t = salaryMin;
        salaryMin = salaryMax;
        salaryMax = t;
    }
    const payload = {
        target_job: (document.getElementById('p-job') || {}).value || '',
        target_jobs: [((document.getElementById('p-job') || {}).value || '').trim()].filter(Boolean),
        edu_level: (document.getElementById('p-edu') || {}).value || '',
        exp_year: expText,
        exp_years_num: parseProfileExpYears(expText),
        skills: (document.getElementById('p-skills') || {}).value || '',
        target_city: (document.getElementById('p-city') || {}).value || '',
        expected_salary_min: salaryMin,
        expected_salary_max: salaryMax,
        expected_salary: salaryMax > 0 ? salaryMax : salaryMin
    };
    if (!payload.target_job && !payload.skills) {
        clearButtonLoading(actionBtn);
        showToast('请至少填写目标岗位或核心技能后再保存', 'error');
        return false;
    }
    try {
        const r = await fetch('/api/profile/update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const d = await r.json().catch(() => ({ success: false, msg: `画像保存接口异常(${r.status})` }));
        if (r.ok && d.success) {
            if (payload.target_city) localStorage.setItem('profile_target_city', payload.target_city);
            // 画像更新后，竞争力/提升状态应重新计算
            localStorage.removeItem('competitiveness_done');
            localStorage.removeItem('improve_action_done');
            localStorage.removeItem('competitiveness_profile_fp');
            localStorage.removeItem('improve_profile_fp');
            if (!silent) showToast('画像保存成功');
            setJobFlowStep(Math.max(getJobFlowStep(), 1));
            await refreshProfileScore();
            updateCard();
            await updateSummary();
            resetProfileFormDirty();
            return true;
        } else {
            if (r.status === 401) {
                showToast('登录状态已失效，请重新登录后再保存', 'error');
                return false;
            }
            const legacy = await fetch('/api/user/profile', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).then(async x => ({
                status: x.status,
                body: await x.json().catch(() => ({ success: false, msg: `兼容接口异常(${x.status})` }))
            })).catch(() => ({ status: 0, body: { success: false, msg: '兼容接口请求失败' } }));
            if (legacy.body.success) {
                if (payload.target_city) localStorage.setItem('profile_target_city', payload.target_city);
                localStorage.removeItem('competitiveness_done');
                localStorage.removeItem('improve_action_done');
                localStorage.removeItem('competitiveness_profile_fp');
                localStorage.removeItem('improve_profile_fp');
                if (!silent) showToast('画像保存成功');
                await refreshProfileScore();
                updateCard();
                await updateSummary();
                resetProfileFormDirty();
                return true;
            } else {
                const msg = d.msg || legacy.body.msg || '保存失败';
                showToast(`画像保存失败：${msg}`, 'error');
                return false;
            }
        }
    } catch (e) {
        console.error(e);
        showToast('保存失败，请稍后重试', 'error');
        return false;
    } finally {
        clearButtonLoading(actionBtn);
    }
}

async function refreshProfileScore() {
    if (document.body.classList.contains('app-auth-locked')) return;
    const scoreOverlay = document.getElementById('auth-overlay');
    if (scoreOverlay && scoreOverlay.style.display !== 'none') return;
    try {
        const r = await fetch('/api/profile/score');
        const d = await r.json();
        if (!d.success) return;
        const score = (d.data && d.data.score) ? Number(d.data.score) : 0;
        const textEl = document.getElementById('profile-score-text');
        const fillEl = document.getElementById('profile-score-fill');
        if (textEl) textEl.innerText = `${score}分`;
        if (fillEl) fillEl.style.width = `${Math.max(0, Math.min(100, score))}%`;
        updateSidebarBadges(score, null);
        renderProfileScoreInsights(d);
    } catch (e) {
        console.error(e);
    }
}

function renderProfileScoreInsights(payload = {}) {
    const scoreBox = document.getElementById('profile-score-breakdown');
    const actionBox = document.getElementById('profile-improve-actions');
    if (!scoreBox && !actionBox) return;

    const data = (payload && payload.data) || {};
    const backendDecision = data.decision || {};
    const details = Array.isArray(data.details) ? data.details : [];
    const missingFields = Array.isArray(data.missing_fields) ? data.missing_fields : [];
    const score = Number(data.score || 0);
    const profile = (payload && payload.profile) || {};
    const skillList = Array.isArray(profile.skill_list)
        ? profile.skill_list
        : String(profile.skills || '').split(/[，,、]/).map(x => x.trim()).filter(Boolean);

    const detailTips = {
        '目标岗位': '决定推荐和评估是否有方向',
        '技能标签': '技能越完整，匹配结果越准确',
        '学历信息': '影响岗位门槛匹配与薪资评估',
        '经验信息': '影响竞争力与岗位层级判断',
        '期望薪资': '影响投递可行性与谈薪建议',
        '更新时间': '定期更新可提高建议时效性'
    };

    if (scoreBox) {
        if (!details.length) {
            scoreBox.innerHTML = '<div class="text-hint">暂无评分拆解，请先保存画像。</div>';
        } else {
            scoreBox.innerHTML = `
                <div class="section-heading"><i class="ri-pie-chart-2-line"></i> 画像评分拆解（总分 ${score}）</div>
                <div class="profile-score-grid">
                    ${details.map(item => {
                const field = String(item.field || '字段');
                const sc = Number(item.score || 0);
                const mx = Number(item.max || 0);
                const tip = detailTips[field] || '该项会影响个性化建议质量';
                return `
                            <div class="profile-score-item">
                                <div class="profile-score-name">${field}</div>
                                <div class="profile-score-val">${sc}<span style="font-size:12px;color:#64748b;"> / ${mx}</span></div>
                                <div class="profile-score-tip">${tip}</div>
                            </div>
                        `;
            }).join('')}
                </div>
            `;
        }
    }

    if (actionBox) {
        const actions = Array.isArray(backendDecision.actions) && backendDecision.actions.length
            ? backendDecision.actions.map(x => x.desc || x.title).filter(Boolean)
            : (() => {
                const localActions = [];
                if (missingFields.includes('目标岗位')) {
                    localActions.push('先补齐“目标岗位”，否则系统无法给出稳定的岗位决策结论。');
                }
                if (skillList.length < 4 || missingFields.includes('技能标签')) {
                    localActions.push('核心技能建议至少填写 4 项（建议含技术栈 + 项目能力）。');
                }
                if (missingFields.includes('经验信息')) {
                    localActions.push('补充经验年限后，可显著提升竞争力判断准确度。');
                }
                if (missingFields.includes('期望薪资')) {
                    localActions.push('补齐薪资区间后，系统才能给出“值不值得投”的结论。');
                }
                if (localActions.length === 0 && score < 85) {
                    localActions.push('画像已可用，建议继续补充技能细分与目标城市，提高推荐精度。');
                }
                if (localActions.length === 0) {
                    localActions.push('画像质量较高，建议进入岗位决策并执行首轮投递。');
                }
                return localActions;
            })();
        const summaryHtml = backendDecision.conclusion
            ? `<div style="margin-bottom:10px;">${renderDecisionCardLite('画像决策摘要', backendDecision.conclusion, backendDecision.reason, backendDecision.suggestion, backendDecision.tone || 'mid')}</div>`
            : '';

        actionBox.innerHTML = `
            <div class="section-heading"><i class="ri-road-map-line"></i> 提分动作（按优先级）</div>
            ${summaryHtml}
            <ol class="profile-improve-list">
                ${actions.slice(0, 4).map(x => `<li>${x}</li>`).join('')}
            </ol>
            <div class="profile-improve-actions">
                <button class="btn btn-default" onclick="saveProfile()"><i class="ri-save-line"></i> 保存并刷新评分</button>
                <button class="btn btn-primary" onclick="switchProfileSubTab('compet')"><i class="ri-bar-chart-grouped-line"></i> 去竞争力分析</button>
            </div>
        `;
    }
}

function renderConclusionCard(title, conclusion, reason, suggestion, tone, aiGenerated = true) {
    const toneMap = {
        good: { bg: '#ecfdf5', bd: '#86efac', fg: '#166534' },
        mid: { bg: '#fffbeb', bd: '#fcd34d', fg: '#92400e' },
        risk: { bg: '#fef2f2', bd: '#fecaca', fg: '#991b1b' }
    };
    const t = toneMap[tone || 'mid'];
    const aiTag = aiGenerated === false
        ? `<span style="font-size:12px; font-weight:normal; background:#e2e8f0; color:#475569; padding:2px 6px; border-radius:4px; margin-left:8px;"><i class="ri-ruler-line"></i> 规则评估</span>`
        : `<span style="font-size:12px; font-weight:normal; background:#e0f2fe; color:#0284c7; padding:2px 6px; border-radius:4px; margin-left:8px;"><i class="ri-sparkling-fill"></i> 系统生成</span>`;
    return `<div class="card" style="padding:14px;border:1px solid ${t.bd};background:${t.bg};"><div style="font-weight:700;color:${t.fg};margin-bottom:8px; display:flex; align-items:center;">${title} ${aiTag}</div><div style="margin-bottom:6px;"><b>结论：</b>${conclusion || '--'}</div><div style="margin-bottom:6px;color:#334155;"><b>原因：</b>${reason || '--'}</div><div style="color:#0f172a;"><b>建议：</b>${suggestion || '--'}</div></div>`;
}

function renderAiStructCard(title, data, tone = 'mid') {
    const d = data || {};
    const cleanText = (x) => {
        const t = String(x || '').trim();
        if (!t) return '';
        const low = t.toLowerCase();
        if (low === 'undefined' || low === 'null' || t === '暂无') return '';
        return t;
    };
    const reason = Array.isArray(d.reason) ? d.reason.map(cleanText).filter(Boolean) : [];
    const suggest = Array.isArray(d.suggestion) ? d.suggestion.map(cleanText).filter(Boolean) : [];
    const risk = Array.isArray(d.risk) ? d.risk.map(cleanText).filter(Boolean) : [];
    const reasonText = reason.length ? reason.join('；') : '暂无';
    const suggestText = suggest.length ? suggest.join('；') : '暂无';
    const riskHtml = risk.length
        ? `<div style="margin-top:8px; font-size:12px; color:#92400e;"><b>风险：</b>${risk.join('；')}</div>`
        : '';
    return renderConclusionCard(title, d.conclusion || '暂无结论', reasonText, suggestText, tone, d.ai_generated !== false) + riskHtml;
}

function pickConclusionPart(raw) {
    if (!raw) return { conclusion: '', reason: '', suggestion: '' };
    if (typeof raw === 'string') return { conclusion: raw, reason: '', suggestion: '' };
    return {
        conclusion: raw.finding || raw.conclusion || raw.summary || '',
        reason: raw.reason || raw.explain || raw.evidence || '',
        suggestion: raw.suggestion || raw.recommendation || raw.action || ''
    };
}

async function ensureProfileReadyForAnalysis(minScore = 40) {
    try {
        const r = await fetch('/api/profile/score');
        const d = await r.json();
        const score = Number((((d || {}).data || {}).score) || 0);
        if (score < minScore) {
            showToast('请先完善画像（技能/经验/薪资）再进行深度分析', 'error');
            switchTab('profile');
            return false;
        }
        return true;
    } catch (e) {
        return true;
    }
}

function extractSkillWordsFromTexts(texts) {
    const stopWords = new Set([
        '建议', '优先', '补齐', '补充', '提升', '能力', '项目', '经验', '简历', '岗位', '投递', '当前', '可以', '以及', '并且',
        '和', '与', '再', '后', '先', '做', '把', '将', '的', '了', '在', '为', '及', '等', '方向', '短板', '关键'
    ]);
    const isCityLike = (w) => /(?:北京|上海|广州|深圳|杭州|南京|苏州|武汉|西安|成都|重庆|天津|朝阳区|海淀区|浦东|全国)/.test(w);
    const merged = (texts || []).filter(Boolean).join('、');
    const tokens = merged
        .split(/[，,。；;、\/\|\s]+/)
        .map(x => String(x || '').trim())
        .filter(Boolean)
        .filter(x => x.length >= 2 && x.length <= 20)
        .filter(x => !/^(\d+|\d+%|\d+\))$/.test(x))
        .filter(x => !/^[\(\)\[\]（）]+$/.test(x))
        .filter(x => !isCityLike(x))
        .filter(x => !stopWords.has(x));
    const uniq = [];
    tokens.forEach(t => {
        if (!uniq.includes(t)) uniq.push(t);
    });
    return uniq.slice(0, 8);
}

function cleanGapItems(rawList) {
    const src = Array.isArray(rawList) ? rawList : [];
    const stripPrefixes = (s) => String(s || '').replace(/^缺少\s*/g, '').replace(/^需补\s*/g, '').trim();
    const isNoise = (s) => {
        if (!s) return true;
        if (s.length < 2 || s.length > 24) return true;
        if (/undefined|null|暂无/i.test(s)) return true;
        if (/(北京|上海|广州|深圳|杭州|南京|苏州|武汉|西安|成都|重庆|天津|全国|朝阳区|海淀区)/.test(s)) return true;
        if (/^[\d\-\s%kKwW]+$/.test(s)) return true;
        return false;
    };
    const out = [];
    const seen = new Set();
    src.forEach(item => {
        const cleaned = stripPrefixes(item);
        const key = cleaned.toLowerCase();
        if (isNoise(cleaned) || seen.has(key)) return;
        seen.add(key);
        out.push(cleaned);
    });
    return out;
}

function cleanAdviceItems(rawList) {
    const src = Array.isArray(rawList) ? rawList : [];
    const out = [];
    const seen = new Set();
    src.forEach(item => {
        const t = String(item || '').trim();
        if (!t || /undefined|null|暂无/i.test(t)) return;
        const key = t.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        out.push(t);
    });
    return out;
}

function buildCompetActionPlan(score, gapList, skillFillList, cityRoleList, salaryAdjustList) {
    const gaps = cleanGapItems(gapList).slice(0, 2);
    const skills = cleanAdviceItems(skillFillList).slice(0, 2);
    const cityRole = cleanAdviceItems(cityRoleList).slice(0, 1);
    const salaryAdj = cleanAdviceItems(salaryAdjustList).slice(0, 1);

    const step1 = gaps.length
        ? `补齐关键短板：${gaps.join('、')}。`
        : (skills.length ? `先强化技能：${skills.join('、')}。` : '先完善一个可展示的项目案例并补齐关键技能。');
    const step2 = score >= MATCH_SCORE_SPRINT
        ? '回到岗位决策页筛选主申/冲刺岗位，先完成小批量投递验证。'
        : '先做岗位决策，优先观察匹配分变化，不建议立即密集投递。';
    const step3 = cityRole.length || salaryAdj.length
        ? `调整策略：${cityRole[0] || ''}${cityRole.length && salaryAdj.length ? '；' : ''}${salaryAdj[0] || ''}`
        : '进入投递执行看板，设置48小时跟进提醒并更新状态。';
    return [step1, step2, step3];
}

function buildSummaryDecisionPayload(ctx = {}) {
    const profileScore = Number(ctx.profileScore || 0);
    const recCount = Number(ctx.recCount || 0);
    const shortlistCount = Number(ctx.shortlistCount || 0);
    const appliedCount = Number(ctx.appliedCount || 0);
    const interviewCount = Number(ctx.interviewCount || 0);
    const offerCount = Number(ctx.offerCount || 0);
    const topMissing = Array.isArray(ctx.topMissing) ? ctx.topMissing.filter(Boolean) : [];

    let conclusion = '先完成岗位决策，形成首批候选';
    let reason = `画像完整度 ${profileScore} 分，高匹配岗位 ${recCount} 个，候选 ${shortlistCount} 个，已投递 ${appliedCount} 个。`;
    let suggestion = '进入“岗位决策”筛出 Top3 候选，再进入“投递执行”执行状态跟踪。';
    let tone = 'mid';
    let primaryAction = 'evaluate';

    if (profileScore < 60) {
        conclusion = '先完善画像，再开始投递';
        reason = `当前画像完整度 ${profileScore} 分，低于建议阈值 60 分。`;
        suggestion = `优先补齐技能、经验、期望薪资字段${topMissing.length ? `，并补强 ${topMissing.slice(0, 2).join('、')}` : ''}。`;
        tone = 'risk';
        primaryAction = 'profile';
    } else if (recCount <= 0) {
        conclusion = '画像已可用，但缺少可投候选岗位';
        reason = '当前高匹配岗位数量为 0，说明岗位筛选范围或关键词需要调整。';
        suggestion = '先去岗位决策页重新筛选关键词/城市，再生成候选岗位。';
        tone = 'mid';
        primaryAction = 'evaluate';
    } else if (shortlistCount <= 0) {
        conclusion = '已有可投岗位，先完成候选归类';
        reason = `识别到 ${recCount} 个高匹配岗位，但看板候选仍为空。`;
        suggestion = '先将 Top3 岗位收藏到看板，再进入投递执行排优先级。';
        tone = 'mid';
        primaryAction = 'evaluate';
    } else if (appliedCount <= 0) {
        conclusion = '候选已形成，进入首轮投递';
        reason = `候选岗位 ${shortlistCount} 个，但尚未形成投递记录。`;
        suggestion = '优先投递主申岗位 2-3 个，并设置 48 小时跟进提醒。';
        tone = 'good';
        primaryAction = 'applications';
    } else if ((interviewCount + offerCount) <= 0) {
        conclusion = '进入跟进阶段，提升面试转化';
        reason = `已投递 ${appliedCount} 个岗位，但面试/Offer 仍为 0。`;
        suggestion = `优先跟进已投递岗位，并补齐 ${topMissing[0] || '关键短板技能'} 提升转化率。`;
        tone = 'mid';
        primaryAction = 'applications';
    } else {
        conclusion = '流程推进良好，进入持续提升阶段';
        reason = `当前面试 ${interviewCount} 个，Offer ${offerCount} 个，已形成闭环。`;
        suggestion = '继续维护投递节奏，并根据反馈迭代画像与技能策略。';
        tone = 'good';
        primaryAction = 'compet';
    }

    return { conclusion, reason, suggestion, tone, primaryAction };
}

function goToSkillGapFromCompet() {
    switchProfileSubTab('gap');
    loadSkillGap();
}

function goToDataEvaluateFromCompet() {
    switchTab('data');
    setTimeout(() => {
        if (typeof evaluateTopJobs === 'function') evaluateTopJobs();
    }, 120);
}

function goToApplicationsFromCompet() {
    switchTab('applications');
    setTimeout(() => {
        if (typeof generateWeeklyPlan === 'function') generateWeeklyPlan();
    }, 120);
}

function setCompetProgressStep(step = 0) {
    const wrap = document.getElementById('compet-progress-steps');
    if (!wrap) return;
    wrap.style.display = step > 0 ? 'grid' : 'none';
    wrap.querySelectorAll('.compet-step').forEach(el => {
        const s = Number(el.getAttribute('data-step') || 0);
        el.classList.remove('active', 'done');
        if (s < step) el.classList.add('done');
        else if (s === step) el.classList.add('active');
    });
}

function toggleCompetDetail(force = null) {
    const box = document.getElementById('compet-detail-wrap');
    const btn = document.getElementById('compet-detail-toggle');
    if (!box) return;
    const next = (force === null) ? (box.style.display === 'none') : !!force;
    box.style.display = next ? 'block' : 'none';
    if (btn) {
        btn.innerHTML = next
            ? '<i class="ri-arrow-up-s-line"></i> 收起详细分析'
            : '<i class="ri-arrow-down-s-line"></i> 查看详细分析';
    }
}

window.toggleCompetDetail = toggleCompetDetail;

function applyCompetTopSkillToProfile() {
    const payload = latestCompetitivenessPayload || {};
    const improveObj = payload.improvement_suggestions || {};
    const skillFillList = cleanAdviceItems(Array.isArray(improveObj.skill_fill) ? improveObj.skill_fill : []);
    const gapList = cleanGapItems(Array.isArray((payload.decision_explain || {}).gap_analysis) ? (payload.decision_explain || {}).gap_analysis : []);
    const candidates = extractSkillWordsFromTexts([...skillFillList, ...gapList]);
    if (!candidates.length) {
        showToast('未识别到可应用的技能建议', 'error');
        return;
    }
    const input = document.getElementById('p-skills');
    if (!input) return;
    const existing = String(input.value || '')
        .split(/[，,、]/)
        .map(x => x.trim())
        .filter(Boolean);
    const existingLowerSet = new Set(existing.map(x => x.toLowerCase()));
    const merged = [...existing];
    candidates.slice(0, 2).forEach(s => {
        const key = String(s || '').toLowerCase();
        if (!existingLowerSet.has(key)) {
            merged.push(s);
            existingLowerSet.add(key);
        }
    });
    input.value = merged.join(', ');
    if (typeof syncProfileSkillTagsFromHidden === 'function') syncProfileSkillTagsFromHidden(true);
    markProfileFormDirty(true);
    updateCard();
    localStorage.setItem('improve_action_done', '1');
    localStorage.setItem('improve_profile_fp', buildProfileFingerprint());
    showToast(`已应用技能建议：${candidates.slice(0, 2).join('、')}`);
}

function getDeliverySkillHint() {
    if (Array.isArray(latestSkillGapList) && latestSkillGapList.length) {
        const names = latestSkillGapList.slice(0, 3).map(x => String(x.skill || '').trim()).filter(Boolean);
        if (names.length) return names.join('、');
    }
    const compPayload = latestCompetitivenessPayload || {};
    const improveObj = compPayload.improvement_suggestions || {};
    const fills = Array.isArray(improveObj.skill_fill) ? improveObj.skill_fill : [];
    if (fills.length) return fills.slice(0, 2).join('、');
    const statText = String((document.getElementById('stat-median-salary') || {}).innerText || '').trim();
    if (statText && statText !== '暂无') return statText;
    return 'SQL、数据可视化';
}

function splitDeliveryBuckets(actionableRows) {
    const sorted = [...(actionableRows || [])].sort((a, b) => Number(b.match_score || 0) - Number(a.match_score || 0));
    const primary = sorted.filter(x => Number(x.match_score || 0) >= MATCH_SCORE_MAIN).slice(0, 3);
    const sprint = sorted.filter(x => Number(x.match_score || 0) >= MATCH_SCORE_SPRINT && Number(x.match_score || 0) < MATCH_SCORE_MAIN).slice(0, 3);
    const backup = sorted.filter(x => Number(x.match_score || 0) < MATCH_SCORE_SPRINT).slice(0, 3);
    if (!primary.length && sorted.length) primary.push(...sorted.slice(0, 2));
    return { primary, sprint, backup, sorted };
}

function buildDeliveryRuleAdvice(baseRows, actionableRows) {
    const { primary, sprint, backup } = splitDeliveryBuckets(actionableRows);
    const appliedCount = (baseRows || []).filter(x => normalizeAppStatusKey(x.status) !== 'favorite').length;
    const interviewCount = (baseRows || []).filter(x => normalizeAppStatusKey(x.status) === 'interview').length;
    const offerCount = (baseRows || []).filter(x => normalizeAppStatusKey(x.status) === 'offer').length;
    const earliestFollow = [...(baseRows || [])]
        .map(x => computeNextFollowDate(x.updated_at || x.applied_at))
        .filter(Boolean)[0] || '今日';
    const skillGapHint = getDeliverySkillHint();

    const primaryNames = primary.map(x => (x.job || {}).job_name).filter(Boolean);
    const sprintNames = sprint.map(x => (x.job || {}).job_name).filter(Boolean);

    let conclusion = '建议本周优先推进主申岗位';
    let reason = `主申岗位 ${primary.length} 个，冲刺岗位 ${sprint.length} 个，保底岗位 ${backup.length} 个。`;
    let suggestion = `主申：${primaryNames.join('、') || '暂无'}；冲刺：${sprintNames.join('、') || '暂无'}；优先补技能：${skillGapHint}；最近跟进提醒：${earliestFollow}。`;
    let tone = 'good';

    if (appliedCount <= 0) {
        conclusion = '先完成首批投递，再建立跟进节奏';
        reason = `当前已有候选岗位 ${primary.length + sprint.length + backup.length} 个，但尚未形成投递记录。`;
        suggestion = `优先投递：${primaryNames.slice(0, 2).join('、') || 'Top2 候选岗位'}；投递后 48 小时内安排首次跟进。`;
        tone = 'mid';
    } else if ((interviewCount + offerCount) > 0) {
        conclusion = '进入面试/Offer推进阶段，重心转向转化率';
        reason = `当前面试 ${interviewCount} 个，Offer ${offerCount} 个，投递总量 ${appliedCount} 个。`;
        suggestion = `优先处理在途流程：准备面试复盘与Offer比对；并继续维护主申岗位跟进频率。`;
        tone = 'good';
    }

    return { conclusion, reason, suggestion, tone };
}

function applySkillGapTopSkills() {
    if (!Array.isArray(latestSkillGapList) || !latestSkillGapList.length) {
        showToast('暂无可应用的技能差距建议', 'error');
        return;
    }
    const input = document.getElementById('p-skills');
    if (!input) return;
    const existingRaw = String(input.value || '')
        .split(/[，,、]/)
        .map(x => x.trim())
        .filter(Boolean);
    const existingLowerSet = new Set(existingRaw.map(x => x.toLowerCase()));
    const topSkills = latestSkillGapList.slice(0, 2).map(x => String(x.skill || '').trim()).filter(Boolean);
    const merged = [...existingRaw];
    topSkills.forEach(s => {
        const normalized = s.toLowerCase();
        if (!existingLowerSet.has(normalized)) {
            merged.push(s);
            existingLowerSet.add(normalized);
        }
    });
    input.value = merged.join(', ');
    if (typeof syncProfileSkillTagsFromHidden === 'function') syncProfileSkillTagsFromHidden(true);
    markProfileFormDirty(true);
    updateCard();
    localStorage.setItem('improve_action_done', '1');
    localStorage.setItem('improve_profile_fp', buildProfileFingerprint());
    showToast(`已应用技能建议：${topSkills.join('、')}`);
    switchProfileSubTab('basic');
}

async function syncGapSkillsToProfileAndReEval() {
    if (!Array.isArray(latestSkillGapList) || !latestSkillGapList.length) {
        showToast('暂无可同步的技能差距', 'error');
        return;
    }
    const input = document.getElementById('p-skills');
    if (!input) return;
    const raw = String(input.value || '').split(/[，,、]/).map(x => x.trim()).filter(Boolean);
    const low = new Set(raw.map(x => x.toLowerCase()));
    const picked = latestSkillGapList.slice(0, 3).map(x => String(x.skill || '').trim()).filter(Boolean);
    picked.forEach(s => {
        const marked = `${s}(学习中)`;
        if (!low.has(s.toLowerCase()) && !low.has(marked.toLowerCase())) {
            raw.push(marked);
            low.add(marked.toLowerCase());
        }
        const learnSet = getLearningSkillSet();
        learnSet.add(s.toLowerCase());
        saveLearningSkillSet(learnSet);
        pushProfileTimelineEvent('开始学习技能', `${s} 已加入学习计划`);
    });
    input.value = raw.join(', ');
    if (typeof syncProfileSkillTagsFromHidden === 'function') syncProfileSkillTagsFromHidden(true);
    markProfileFormDirty(true);
    switchProfileSubTab('basic');
    updateCard();
    const saved = await saveProfile(true);
    if (!saved) return;
    try {
        const city = (document.getElementById('p-city') || {}).value || '';
        const edu = (document.getElementById('p-edu') || {}).value || '';
        const exp = (document.getElementById('p-exp') || {}).value || '';
        const skills = (document.getElementById('p-skills') || {}).value || '';
        const r = await fetch('/api/competitiveness', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ city, edu, exp, skills })
        });
        const d = await r.json();
        if (d && d.success) {
            showToast(`已同步并重评：预估竞争力 ${d.total_score} 分（分位 ${d.percentile}%）`);
        } else {
            showToast(`已同步技能：${picked.join('、')}`);
        }
    } catch (_) {
        showToast(`已同步技能：${picked.join('、')}`);
    }
}

window.syncGapSkillsToProfileAndReEval = syncGapSkillsToProfileAndReEval;

async function evaluateCompetitiveness() {
    const ready = await ensureProfileReadyForAnalysis(40);
    if (!ready) return;
    const city = (document.getElementById('p-city') || {}).value || '';
    const edu = (document.getElementById('p-edu') || {}).value || '';
    const exp = (document.getElementById('p-exp') || {}).value || '';
    const skills = (document.getElementById('p-skills') || {}).value || '';
    const actionBtn = document.querySelector('#tab-profile button[onclick="evaluateCompetitiveness()"]');
    toggleCompetDetail(false);
    setCompetProgressStep(1);
    setButtonLoading(actionBtn, '分析中...');
    try {
        const r = await fetch('/api/competitiveness', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ city, edu, exp, skills })
        });
        setCompetProgressStep(2);
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '分析失败');
        setCompetProgressStep(3);
        latestCompetitivenessPayload = d;
        const score = Number(d.total_score || d.score || 0);
        const percentile = Number(d.percentile || 0);
        const explainObj = d.decision_explain || {};
        const improveObj = d.improvement_suggestions || {};
        const gapList = cleanGapItems(Array.isArray(explainObj.gap_analysis) ? explainObj.gap_analysis : []);
        const skillFillList = cleanAdviceItems(Array.isArray(improveObj.skill_fill) ? improveObj.skill_fill : []);
        const cityRoleList = cleanAdviceItems(Array.isArray(improveObj.city_or_role_adjust) ? improveObj.city_or_role_adjust : []);
        const salaryAdjustList = cleanAdviceItems(Array.isArray(improveObj.salary_expectation_adjust) ? improveObj.salary_expectation_adjust : []);
        const tone = score >= MATCH_SCORE_MAIN ? 'good' : (score >= MATCH_SCORE_SPRINT ? 'mid' : 'risk');
        const conc = d.conclusion || (score >= MATCH_SCORE_MAIN ? '竞争力较强，可进入重点投递阶段' : (score >= MATCH_SCORE_SPRINT ? '竞争力中等，建议补关键短板后投递' : '竞争力偏弱，建议先补技能与项目经历'));
        const reason = d.reason || (gapList.length
            ? `当前竞争力指数 ${score}，市场分位约 ${percentile}%，主要短板：${gapList.slice(0, 2).join('、')}`
            : `当前竞争力指数 ${score}，市场分位约 ${percentile}%`);
        const suggest = d.suggestion || skillFillList[0] || cityRoleList[0] || salaryAdjustList[0] || d.advice || '优先补齐高频缺失技能，并强化项目成果表达。';
        const core = document.getElementById('compet-core-summary');
        if (core) {
            core.style.display = 'block';
            core.innerHTML = `
                <div class="compet-core-grid">
                    <div class="compet-core-item">
                        <div class="compet-core-label">竞争力指数</div>
                        <div class="compet-core-value">${score}</div>
                        <div class="compet-core-note">${score >= MATCH_SCORE_MAIN ? '处于可投区间' : (score >= MATCH_SCORE_SPRINT ? '补强后可投' : '建议先提升')}</div>
                    </div>
                    <div class="compet-core-item">
                        <div class="compet-core-label">市场分位</div>
                        <div class="compet-core-value">${percentile}%</div>
                        <div class="compet-core-note">超过同类求职者约 ${percentile}%</div>
                    </div>
                    <div class="compet-core-item">
                        <div class="compet-core-label">可投岗位数</div>
                        <div class="compet-core-value">${Number(d.match_count || 0)}</div>
                        <div class="compet-core-note">按当前画像估算的候选池容量</div>
                    </div>
                </div>
                <div class="compet-core-brief ${tone}">
                    <div class="compet-core-brief-title">核心判断</div>
                    <div class="compet-core-brief-main">${conc}</div>
                    <div class="compet-core-brief-sub">${reason}</div>
                    <div class="compet-core-brief-sub"><b>建议：</b>${suggest}</div>
                </div>
            `;
        }
        const jobfit = document.getElementById('comp-jobfit-summary');
        if (jobfit) {
            // 避免重复展示同类结论，主面板已覆盖投递可行性判断。
            jobfit.style.display = 'none';
            jobfit.innerHTML = '';
        }
        const explain = document.getElementById('comp-decision-explain-box');
        if (explain) {
            explain.style.display = 'block';
            const signals = [
                `竞争力指数：${score}（市场分位 ${percentile}%）`,
                gapList.length ? `关键差距：${gapList.slice(0, 2).join('、')}` : '关键差距：暂无明显硬性短板',
                `投递判断：${score >= MATCH_SCORE_MAIN ? '可进入主申投递' : (score >= MATCH_SCORE_SPRINT ? '补强后小批量投递' : '先补短板再投递')}`
            ];
            explain.innerHTML = `
                <div class="compet-detail-card">
                    <div class="compet-detail-title">关键依据</div>
                    <div class="compet-detail-list">${signals.map(x => `• ${x}`).join('<br>')}</div>
                </div>
            `;
        }
        const improve = document.getElementById('comp-improvement-box');
        if (improve) {
            const actions = buildCompetActionPlan(score, gapList, skillFillList, cityRoleList, salaryAdjustList);
            improve.style.display = 'block';
            const ranked = actions.map((x, i) => {
                const p = i === 0 ? 'P1' : (i === 1 ? 'P2' : 'P3');
                const impact = i === 0 ? '+8~12分' : (i === 1 ? '面试率约 +10%~15%' : '稳定提升');
                return `<li><b>${p}</b>：${x} <span class="compet-impact">（预期效果：${impact}）</span></li>`;
            }).join('');
            improve.innerHTML = `
                <div class="compet-detail-card">
                    <div class="compet-detail-title">改进优先级（先后顺序）</div>
                    <div class="text-hint mb-8">建议先补技能（影响最大），再调整薪资与投递结构。</div>
                    <ol class="compet-priority-list">${ranked}</ol>
                </div>
            `;
        }
        loadCompetAiInterpret(d, score);
        const actionBox = document.getElementById('comp-action-box');
        if (actionBox) {
            actionBox.style.display = 'block';
            const quickSkills = extractSkillWordsFromTexts([...skillFillList, ...gapList]).slice(0, 3);
            const nextAction = score >= MATCH_SCORE_MAIN
                ? '你已具备较强竞争力，建议立即进入岗位决策并完成首轮投递。'
                : (score >= MATCH_SCORE_SPRINT ? '先补齐1-2项关键技能，再进行岗位决策与小批量投递。' : '先执行技能补齐与项目强化，再进入岗位决策。');
            actionBox.innerHTML = `
                <div class="compet-action-card">
                    <div class="compet-action-title"><i class="ri-play-circle-line"></i> 下一步行动</div>
                    <div class="compet-action-desc">${nextAction}</div>
                    <div class="compet-action-skill">建议优先技能：${quickSkills.length ? quickSkills.join('、') : 'SQL、数据可视化'}</div>
                    <div class="compet-action-buttons">
                        <button class="btn btn-default" onclick="applyCompetTopSkillToProfile()"><i class="ri-magic-line"></i> 应用技能建议到画像</button>
                        <button class="btn btn-primary" onclick="goToDataEvaluateFromCompet()"><i class="ri-radar-line"></i> 去岗位决策</button>
                        <button class="btn btn-default" onclick="goToApplicationsFromCompet()"><i class="ri-send-plane-line"></i> 进入投递执行</button>
                    </div>
                </div>
            `;
        }
        if (Array.isArray(d.growth_paths) && d.growth_paths.length) {
            renderGrowthPath(d.growth_paths);
        }
        setCompetProgressStep(4);
        localStorage.setItem('competitiveness_done', '1');
        localStorage.setItem('competitiveness_profile_fp', buildProfileFingerprint());
        setJobFlowStep(Math.max(getJobFlowStep(), score >= MATCH_SCORE_MAIN ? 3 : 2));
    } catch (e) {
        console.error(e);
        showToast('竞争力分析失败', 'error');
    } finally {
        setTimeout(() => setCompetProgressStep(0), 900);
        clearButtonLoading(actionBtn);
    }
}

async function loadCompetAiInterpret(payload, score = 0) {
    const box = document.getElementById('comp-ai-interpret-box');
    if (!box) return;
    // 作为补充层，默认收起以减少重复感。
    box.style.display = 'none';
    box.innerHTML = '';
    try {
        const res = await fetchJsonWithTimeout('/api/competitiveness/ai-interpret', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload || {})
        }, 70000);
        const d = res.body || {};
        if (!d.success || !d.data) throw new Error(d.msg || '解读失败');
        const tone = Number(score || 0) >= MATCH_SCORE_MAIN ? 'good' : (Number(score || 0) >= MATCH_SCORE_SPRINT ? 'mid' : 'risk');
        const aiData = d.data || {};
        const scoreNum = Number(score || 0);
        const fallbackConclusion = scoreNum >= MATCH_SCORE_MAIN
            ? '竞争力较强，可进入重点投递阶段'
            : (scoreNum >= MATCH_SCORE_SPRINT ? '竞争力中等，建议补关键短板后投递' : '竞争力偏弱，建议先提升再投递');
        if (!aiData.conclusion || typeof aiData.conclusion !== 'string') aiData.conclusion = fallbackConclusion;
        if (!Array.isArray(aiData.reason) || !aiData.reason.length) {
            aiData.reason = [`当前竞争力指数 ${scoreNum}，建议结合下方“关键差距”先执行补强。`];
        }
        if (!Array.isArray(aiData.suggestion) || !aiData.suggestion.length) {
            aiData.suggestion = ['先补齐1-2项高频缺口技能，再进入岗位决策与投递执行。'];
        }
        const reasonText = (Array.isArray(aiData.reason) ? aiData.reason : []).filter(Boolean)[0] || `当前竞争力指数 ${scoreNum}，建议先执行上方三步行动。`;
        const suggestText = (Array.isArray(aiData.suggestion) ? aiData.suggestion : []).filter(Boolean)[0] || '优先补齐关键短板后再扩大投递。';
        box.style.display = 'block';
        box.innerHTML = `<div class="compet-detail-card" style="border-style:dashed; background:#f8fafc;">
            <div class="compet-detail-title">系统补充解读（可选）</div>
            <div style="font-size:12px; color:#475569;"><b>一句话：</b>${aiData.conclusion || '已生成补充解读。'}</div>
            <div style="font-size:12px; color:#64748b; margin-top:4px;"><b>原因：</b>${reasonText}</div>
            <div style="font-size:12px; color:#334155; margin-top:4px;"><b>建议：</b>${suggestText}</div>
        </div>`;
    } catch (e) {
        box.style.display = 'none';
    }
}

async function loadSkillGap() {
    const ready = await ensureProfileReadyForAnalysis(30);
    if (!ready) return;
    const box = document.getElementById('skill-gap-box');
    const gapSummary = document.getElementById('gap-decision-summary');
    if (!box) return;
    box.style.display = 'block';
    box.innerHTML = '技能差距分析中...';
    try {
        const r = await fetch('/api/skill-gap');
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '加载失败');
        const data = d.data || {};
        const missing = Array.isArray(data.missing_skills) ? data.missing_skills : [];
        const userSkills = Array.isArray(data.user_skills) ? data.user_skills.map(x => String(x || '').trim()).filter(Boolean) : [];
        const userSkillLow = userSkills.map(x => x.toLowerCase());
        const gapCandidates = missing.map(item => {
            const skillName = String(item.skill || '').trim();
            const low = skillName.toLowerCase();
            const fuzzy = userSkillLow.some(us => us.includes(low) || low.includes(us));
            const learning = isLearningSkill(skillName);
            const status = learning || fuzzy ? 'learning' : 'miss';
            return { ...item, skill: skillName, status };
        });
        const top = gapCandidates.filter(x => x.status !== 'owned').slice(0, 8);
        latestSkillGapList = top;
        const topNames = top.slice(0, 3).map(x => x.skill).filter(Boolean);
        const reason = top.length ? `当前样本 ${data.sample_size || 0} 条，缺口主要集中在：${topNames.join('、')}` : `当前样本 ${data.sample_size || 0} 条中未检测到明显技能差距。`;
        const suggest = top.length ? `建议两周内优先补齐：${topNames.join('、')}` : '若岗位匹配分仍偏低，建议重点检查简历表达与项目深度。';
        if (gapSummary) {
            const tone = top.length >= 3 ? 'risk' : (top.length > 0 ? 'mid' : 'good');
            const gapConclusion = top.length
                ? `存在 ${top.length} 项关键差距，补齐后可提升岗位匹配与面试通过率`
                : '当前样本未见明显硬技能差距（需结合岗位逐条评估）';
            const gapReason = top.length
                ? `高频缺口集中在：${topNames.join('、')}，对目标岗位影响较大。`
                : `本次分析样本 ${data.sample_size || 0} 条，可能存在样本不足导致的假阴性。`;
            const gapSuggestion = top.length
                ? `优先补齐 ${topNames.slice(0, 2).join('、')}，完成后回到岗位决策观察分数变化。`
                : '继续投递并根据面试反馈微调技能方向。';
            gapSummary.style.display = 'block';
            gapSummary.innerHTML = renderDecisionCardLite('技能差距决策摘要', gapConclusion, gapReason, gapSuggestion, tone);
        }
        const topRate = top.length ? Math.max(...top.map(x => Number(x.demand_rate || 0))) : 0;
        const skillRows = top.length ? top.map(x => {
            const skillName = String(x.skill || '-');
            const rate = Math.max(0, Number(x.demand_rate || 0));
            const width = topRate > 0 ? Math.max(8, Math.round(rate / topRate * 100)) : 0;
            const premium = Number(x.salary_premium || 0);
            const premiumText = premium >= 0 ? `+¥${premium}` : `-¥${Math.abs(premium)}`;
            const learning = String(x.status) === 'learning' || isLearningSkill(skillName);
            const statusHtml = learning
                ? '<span class="gap-skill-status learning">🟡 了解中</span>'
                : '<span class="gap-skill-status miss">🔴 未掌握</span>';
            return `
                <div class="gap-skill-row">
                    <div class="gap-skill-name">${skillName}<div style="margin-top:4px;">${statusHtml}</div></div>
                    <div class="gap-skill-track"><div class="gap-skill-fill" style="width:${width}%;"></div></div>
                    <div class="gap-skill-premium" title="该技能相关岗位相对样本均值的薪资溢价">${premiumText}</div>
                    <button class="gap-skill-btn ${learning ? 'learning' : ''}" onclick="toggleLearningSkill('${skillName.replace(/'/g, "\\'")}')">
                        ${learning ? '学习中' : '加入学习计划'}
                    </button>
                    <div class="gap-skill-rate" style="grid-column:2 / span 2;">需求率 ${rate}% · ${x.priority || '中频加分'}</div>
                </div>
            `;
        }).join('') : '<div style="font-size:12px; color:#64748b;">暂无明显技能差距，可继续提升项目深度与表达能力。</div>';

        const planList = top.length ? `
            <li>第1-3天：学习 <b>${top[0] ? top[0].skill : 'SQL'}</b> 基础（建议关键词：${top[0] ? top[0].skill : 'SQL'} 入门 + 面试题）。</li>
            <li>第4-7天：基于你的项目做一次 <b>${top[0] ? top[0].skill : '该技能'}</b> 实操，并沉淀可展示结果。</li>
            <li>第8-10天：继续补齐 <b>${top[1] ? top[1].skill : '第二短板技能'}</b>，形成对比案例。</li>
            <li>第11-14天：把学习成果写入简历，回到岗位决策页验证匹配分变化。</li>
        ` : `
            <li>保持每周 1 个小项目复盘。</li>
            <li>持续优化简历中的项目量化结果。</li>
            <li>定期在岗位决策页复查匹配变化。</li>
        `;
        const strengthsHtml = userSkills.length
            ? `<div class="gap-strengths"><div class="text-hint">你的优势技能</div>${userSkills.slice(0, 8).map(s => `<span class="gap-strength-tag">${s}</span>`).join('')}</div>`
            : '';

        box.innerHTML = `
            ${renderConclusionCard('技能差距诊断', top.length ? '存在可补齐的高频技能差距' : '技能覆盖较好', reason, suggest, top.length ? 'mid' : 'good')}
            <div class="skill-gap-layout">
                <div class="gap-skill-card">
                    <div class="gap-card-title"><i class="ri-bar-chart-horizontal-line"></i> 缺口技能优先级</div>
                    <div class="gap-skill-list">${skillRows}</div>
                    ${strengthsHtml}
                </div>
                <div class="gap-plan-card">
                    <div class="gap-card-title"><i class="ri-calendar-check-line"></i> 两周补齐计划</div>
                    <ol class="gap-plan-list">${planList}</ol>
                    <div class="gap-plan-actions">
                        <button class="btn btn-default" onclick="applySkillGapTopSkills()"><i class="ri-magic-line"></i> 一键应用到画像</button>
                        <button class="btn btn-primary" onclick="switchTab('data')"><i class="ri-radar-line"></i> 去岗位决策</button>
                    </div>
                </div>
            </div>
        `;
        setJobFlowStep(Math.max(getJobFlowStep(), 5));
    } catch (e) {
        console.error(e);
        box.innerHTML = '<span style="color:#ef4444;">技能差距加载失败</span>';
    }
}

function renderSummarySystemPanels(metricsPayload, weeklyPayload, qualityPayload) {
    const sysEl = document.getElementById('summary-system-interpretation');
    const weeklyEl = document.getElementById('overview-weekly-list');
    const reasonsEl = document.getElementById('overview-health-reasons');

    if (sysEl) {
        const lines = [];
        const interp = metricsPayload && metricsPayload.system_interpretation;
        if (Array.isArray(interp) && interp.length) {
            interp.slice(0, 3).forEach(x => lines.push(`• ${x}`));
        } else if (interp && typeof interp === 'string') {
            lines.push(`• ${interp}`);
        } else {
            lines.push('• 当前系统已进入求职决策模式，可围绕画像、评估与投递闭环使用。');
        }
        sysEl.innerHTML = lines.join('<br>');
    }

    if (weeklyEl) {
        const arr = ((((weeklyPayload || {}).data || {}).summary) || []);
        weeklyEl.innerHTML = arr.length ? arr.slice(0, 3).map(x => `• ${x}`).join('<br>') : '暂无本周动态，请先采集或导入近7天数据。';
    }

    if (reasonsEl) {
        const reasons = ((((qualityPayload || {}).data || {}).health_reasons) || []);
        reasonsEl.innerHTML = reasons.length
            ? reasons.slice(0, 3).map(x => `<div style="margin-top:6px;"><b>${x.title || '质量项'}：</b>${x.summary || '--'}</div>`).join('')
            : '<div style="margin-top:6px;">暂无质量风险明细。</div>';
    }
}

function runSummaryAction(actionId) {
    const id = String(actionId || '').toLowerCase();
    if (id === 'profile') return switchTab('profile');
    if (id === 'data' || id === 'evaluate') return switchTab('data');
    if (id === 'applications') return switchTab('applications');
    if (id === 'dashboard') return switchTab('dashboard');
    if (id === 'ai') return switchTab('ai');
    if (id === 'compet') return goToCompetitiveness();
    return switchTab('data');
}

function getSummaryActionButtonText(actionId) {
    const id = String(actionId || '').toLowerCase();
    if (id === 'profile') return '去个人画像';
    if (id === 'data' || id === 'evaluate') return '去岗位决策';
    if (id === 'applications') return '去投递执行';
    if (id === 'dashboard') return '去市场分析';
    if (id === 'ai') return '去推荐计划';
    if (id === 'compet') return '去竞争力分析';
    return '立即执行';
}

function renderSummaryPersonalActions(ctx = {}) {
    const backendDecision = ctx.__decision || null;
    const actionHint = document.getElementById('summary-action-hint');
    const confidenceEl = document.getElementById('summary-action-confidence');
    const conclusionEl = document.getElementById('summary-brief-conclusion');
    const reasonEl = document.getElementById('summary-brief-reason');
    const suggestionEl = document.getElementById('summary-brief-suggestion');
    const listEl = document.getElementById('summary-action-list');
    const matchBtn = document.getElementById('summary-action-match');
    const profileBtn = document.getElementById('summary-action-profile');
    const competBtn = document.getElementById('summary-action-compet');
    if (!listEl) return;

    const decision = backendDecision || ((typeof buildPersonalActionBrief === 'function')
        ? buildPersonalActionBrief(ctx)
        : { conclusion: '请先完善画像后再执行岗位决策。', reason: '未加载行动建议引擎。', suggestion: '先完善画像。', actions: [], confidence: { score: 50, level: '中' }, primaryAction: 'profile' });
    const conf = decision.confidence || { score: 50, level: '中', tone: 'mid' };

    if (actionHint) actionHint.innerText = decision.conclusion || '已生成今日行动建议。';
    if (confidenceEl) {
        const badge = conf.level === '高' ? '较高可信' : (conf.level === '中' ? '中等可信' : '建议谨慎');
        confidenceEl.innerText = `建议置信度：${conf.score}（${conf.level}）｜${badge}`;
        confidenceEl.style.color = conf.level === '高' ? '#166534' : (conf.level === '中' ? '#92400e' : '#991b1b');
    }
    if (conclusionEl) conclusionEl.innerText = decision.conclusion || '--';
    if (reasonEl) reasonEl.innerText = decision.reason || '--';
    if (suggestionEl) suggestionEl.innerText = decision.suggestion || '--';

    const items = Array.isArray(decision.actions) ? decision.actions.slice(0, 3) : [];
    if (!items.length) {
        listEl.innerHTML = '<div class="summary-placeholder">暂无行动建议，请先完善画像并刷新。</div>';
    } else {
        listEl.innerHTML = items.map((item, idx) => {
            const pri = String(item.priority || 'mid').toLowerCase();
            const priText = pri === 'high' ? '高优先级' : (pri === 'low' ? '低优先级' : '中优先级');
            const btnText = getSummaryActionButtonText(item.actionId);
            return `
                <div class="summary-action-item">
                    <div class="summary-action-item-head">
                        <div class="summary-action-item-title">${idx + 1}. ${item.title || '执行行动'}</div>
                        <span class="summary-action-priority ${pri}">${priText}</span>
                    </div>
                    <div class="summary-action-item-desc">${item.desc || ''}</div>
                    <button class="btn btn-default summary-action-item-btn" onclick="runSummaryAction('${item.actionId || ''}')">${btnText}</button>
                </div>
            `;
        }).join('');
    }

    if (matchBtn && profileBtn && competBtn) {
        const resetBtn = (btn, primary) => {
            btn.classList.remove('btn-primary', 'btn-default');
            btn.classList.add(primary ? 'btn-primary' : 'btn-default');
        };
        resetBtn(matchBtn, false);
        resetBtn(profileBtn, false);
        resetBtn(competBtn, false);
        if (decision.primaryAction === 'profile') {
            resetBtn(profileBtn, true);
        } else if (decision.primaryAction === 'compet') {
            resetBtn(competBtn, true);
        } else {
            resetBtn(matchBtn, true);
        }
    }
}

async function fetchWorkbenchDecision(ctx = {}) {
    try {
        const r = await fetch('/api/workbench/decision', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(ctx || {})
        });
        const d = await r.json();
        if (r.ok && d.success && d.data) return d.data;
    } catch (e) {
        console.warn('读取工作台决策失败，使用前端兜底', e);
    }
    return (typeof buildPersonalActionBrief === 'function')
        ? buildPersonalActionBrief(ctx)
        : { conclusion: '请先完善画像后再执行岗位决策。', reason: '未加载行动建议引擎。', suggestion: '先完善画像。', actions: [], confidence: { score: 50, level: '中' }, primaryAction: 'profile' };
}

window.runSummaryAction = runSummaryAction;

async function updateSummary() {
    if (document.body.classList.contains('app-auth-locked')) return;
    const updateSummaryOverlay = document.getElementById('auth-overlay');
    if (updateSummaryOverlay && updateSummaryOverlay.style.display !== 'none') return;
    const setText = (id, v) => {
        const el = document.getElementById(id);
        if (el) el.innerText = v;
    };
    const now = new Date();
    setText('stat-last-update', `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`);
    initSummaryProgressiveView();
    const dqBody = document.getElementById('dq-body');
    const dqBtn = document.getElementById('dq-toggle-btn');
    if (dqBody && dqBtn && !dqBody.dataset.initCollapsed) {
        dqBody.style.display = 'none';
        dqBtn.innerHTML = '<i class="ri-arrow-down-s-line"></i> 展开';
        dqBody.dataset.initCollapsed = '1';
    }
    const userEl = document.getElementById('display-username');
    const welcomeEl = document.getElementById('welcome-msg');
    if (welcomeEl) {
        const hour = now.getHours();
        const greet = hour < 12 ? '早上好' : (hour < 18 ? '下午好' : '晚上好');
        const rawName = (userEl && userEl.innerText) ? userEl.innerText.trim() : '';
        const userName = (rawName && rawName !== 'Guest' && rawName !== '游客') ? rawName : '同学';
        welcomeEl.innerText = `${greet}，${userName}`;
    }

    try {
        const [profileRes, appRes, qualityRes, summaryRes, metricsRes, weeklyRes] = await Promise.all([
            fetch('/api/profile/score').catch(() => null),
            fetch('/api/applications').catch(() => null),
            fetch('/api/data/quality').catch(() => null),
            fetch('/api/stats/summary').catch(() => null),
            fetch('/api/system/metrics').catch(() => null),
            fetch('/api/system/weekly-trends').catch(() => null)
        ]);

        let profileScore = 0;
        let profilePayload = null;
        if (profileRes && profileRes.ok) {
            const p = await profileRes.json();
            profilePayload = p;
            profileScore = Number((((p || {}).data || {}).score) || 0);
        }

        let recCount = 0;
        let topMissing = [];
        let marketSample = 0;
        let dataQualityScoreForAction = 55;
        const profileObj = ((profilePayload || {}).profile) || ((profilePayload || {}).data || {}).profile || {};
        const currentProfileFp = buildProfileFingerprint(profileObj);
        const summaryKeyword = String(
            profileObj.target_job
            || profileObj.target_jobs
            || profileObj.skills
            || (document.getElementById('p-job') || {}).value
            || ''
        ).split(/[，,]/)[0].trim();
        if (summaryKeyword && profileScore >= 40) {
            const recRes = await fetch('/api/recommend', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ keyword: summaryKeyword })
            }).catch(() => null);
            if (recRes && recRes.ok) {
                const rr = await recRes.json();
                const list = rr.recommendations || [];
                recCount = list.filter(x => Number(x.score || 0) >= MATCH_SCORE_MAIN).length;
                topMissing = (((rr.summary || {}).top_missing_skills) || []).slice(0, 3).map(x => x.name || x.skill);
            }
        }

        let appliedCount = 0;
        let interviewCount = 0;
        let offerCount = 0;
        let appItems = [];
        if (appRes && appRes.ok) {
            const ap = await appRes.json();
            appItems = ap.data || [];
            appliedCount = appItems.filter(x => normalizeAppStatusKey(x.status) !== 'favorite').length;
            interviewCount = appItems.filter(x => normalizeAppStatusKey(x.status) === 'interview').length;
            offerCount = appItems.filter(x => normalizeAppStatusKey(x.status) === 'offer').length;
        }
        updateSidebarBadges(profileScore, appItems);

        setText('stat-market-avg', String(recCount));
        setText('stat-total-jobs', '--');
        setText('stat-median-salary', topMissing.length ? topMissing.join(' / ') : '暂无');
        setText('stat-city-cov', String(appliedCount));

        const matchBtn = document.getElementById('summary-action-match');
        const profileBtn = document.getElementById('summary-action-profile');
        const competBtn = document.getElementById('summary-action-compet');
        if (matchBtn && profileScore < 40) {
            matchBtn.disabled = true;
            matchBtn.title = '请先完善画像';
        } else if (matchBtn) {
            matchBtn.disabled = false;
            matchBtn.title = '';
        }
        if (profileBtn && profileScore >= 80) {
            profileBtn.classList.add('btn-default');
        }
        if (competBtn) {
            competBtn.onclick = () => goToCompetitiveness();
        }

        const competitFlag = localStorage.getItem('competitiveness_done') === '1';
        const competitFp = localStorage.getItem('competitiveness_profile_fp') || '';
        const competDone = !!(
            (window.latestCompetitivenessPayload && Number(window.latestCompetitivenessPayload.total_score || window.latestCompetitivenessPayload.score || 0) > 0)
            || (competitFlag && competitFp && competitFp === currentProfileFp)
        );
        const shortlistCount = appItems.filter(x => normalizeAppStatusKey(x.status) === 'favorite').length;
        const improveFlag = localStorage.getItem('improve_action_done') === '1';
        const improveFp = localStorage.getItem('improve_profile_fp') || '';
        const improveDone = improveFlag && improveFp && improveFp === currentProfileFp;
        renderWeeklyMissionBoard({
            profileScore,
            recCount,
            shortlistCount,
            appliedCount,
            interviewCount,
            topMissing
        });

        if (summaryRes && summaryRes.ok) {
            const s = await summaryRes.json();
            marketSample = Number(s.total || 0);
            setText('stat-total-jobs', `${s.total || 0}`);
            setText('summary-hot-jobs', `${s.total || 0} 个岗位样本`);
            setText('summary-hot-cities', `${s.city_count || 0} 个城市`);
            setText('summary-salary-overview', `均薪 ¥${(s.avg_salary || 0).toLocaleString()}`);
            refreshOverviewWorkbench(s.total || 0);
        } else {
            setText('stat-total-jobs', '0');
            refreshOverviewWorkbench(0);
        }

        const actionHint = document.getElementById('summary-action-hint');
        const onboardingText = document.getElementById('summary-onboarding-text');
        const closureEl = document.getElementById('summary-closure-rate');
        const nextStepEl = document.getElementById('summary-next-step');
        const firstUseGuideEl = document.getElementById('first-use-guide');
        const firstGuideDismissed = localStorage.getItem('first_use_guide_dismissed') === '1';
        const closureFlags = [
            profileScore >= 60,
            shortlistCount > 0,
            appliedCount > 0,
            (interviewCount + offerCount) > 0
        ];
        const closureDone = closureFlags.filter(Boolean).length;
        const closureRate = Math.round((closureDone / closureFlags.length) * 100);
        if (closureEl) closureEl.innerText = `${closureRate}%（${closureDone}/${closureFlags.length}）`;
        let nextStep = '先在岗位决策生成可投候选岗位';
        if (profileScore < 60) {
            nextStep = '先完善个人画像';
        } else if (recCount <= 0) {
            nextStep = '进入岗位决策，先完成首轮评估';
        } else if (shortlistCount <= 0) {
            nextStep = '从推荐结果中筛选候选岗位并加入看板';
        } else if (appliedCount <= 0) {
            nextStep = '从高匹配岗位中先投递 3 个';
        } else if ((interviewCount + offerCount) <= 0) {
            nextStep = '在投递看板安排跟进并更新状态';
        } else {
            nextStep = '进入持续提升，复盘反馈补短板';
        }
        if (nextStepEl) nextStepEl.innerText = nextStep;
        if (firstUseGuideEl) {
            const shouldShowGuide = !firstGuideDismissed && closureDone <= 1;
            firstUseGuideEl.style.display = shouldShowGuide ? 'block' : 'none';
        }
        if (actionHint) {
            if (profileScore < 60) {
                actionHint.innerText = '你的画像未完善，建议先补全技能、经验和薪资预期。';
                setJobFlowStep(Math.max(getJobFlowStep(), 0));
                if (onboardingText) onboardingText.innerHTML = '第 1 步：先到“个人画像”补齐目标岗位、技能、经验、期望薪资；<br>第 2 步：到“岗位决策”点击评估按钮查看结论；<br>第 3 步：将可投岗位标记到“投递执行”看板并持续跟进。';
            } else if (recCount > 0 && shortlistCount <= 0) {
                actionHint.innerText = `已识别 ${recCount} 个高匹配岗位，建议先筛选候选并加入看板。`;
                setJobFlowStep(Math.max(getJobFlowStep(), 1));
                if (onboardingText) onboardingText.innerHTML = '你已具备画像基础：先在岗位决策中筛选候选岗位，再进入投递执行。';
            } else if (shortlistCount > 0 && appliedCount === 0) {
                actionHint.innerText = `你已筛选 ${shortlistCount} 个候选岗位，建议先完成第一批投递。`;
                setJobFlowStep(Math.max(getJobFlowStep(), 2));
                if (onboardingText) onboardingText.innerHTML = '下一步：从候选岗位中优先投递主申岗位，并在看板中持续跟进。';
            } else if (appliedCount > 0) {
                actionHint.innerText = `你已投递 ${appliedCount} 个岗位，建议进入看板跟进面试进度。`;
                setJobFlowStep(Math.max(getJobFlowStep(), 3));
                if (onboardingText) onboardingText.innerHTML = '当前重点：在“投递执行”中更新状态、查看下次跟进提醒，并回到“个人画像-深度分析”持续补短板。';
            } else {
                actionHint.innerText = '建议先到岗位决策页查看匹配结论，再进入投递执行。';
                if (onboardingText) onboardingText.innerHTML = '建议路径：岗位决策（看结论）→ 个人画像深度分析（看短板）→ 投递执行（看行动顺序）。';
            }
        }

        const setCardState = (stateId, descId, btnId, stateText, descText, btnText, btnType = 'default') => {
            const sEl = document.getElementById(stateId);
            const dEl = document.getElementById(descId);
            const bEl = document.getElementById(btnId);
            if (sEl) sEl.innerText = stateText;
            if (dEl) dEl.innerText = descText;
            if (bEl) {
                const iconEl = bEl.querySelector('i');
                const iconHtml = iconEl ? `${iconEl.outerHTML} ` : '';
                bEl.innerHTML = `${iconHtml}${btnText}`;
                bEl.classList.remove('btn-primary', 'btn-default');
                bEl.classList.add(btnType === 'primary' ? 'btn-primary' : 'btn-default');
            }
            if (sEl) {
                if (stateText.indexOf('已') >= 0) {
                    sEl.style.background = '#ecfdf5';
                    sEl.style.color = '#166534';
                    sEl.style.borderColor = '#86efac';
                } else if (stateText.indexOf('进行') >= 0) {
                    sEl.style.background = '#fffbeb';
                    sEl.style.color = '#92400e';
                    sEl.style.borderColor = '#fcd34d';
                } else {
                    sEl.style.background = '#eef2ff';
                    sEl.style.color = '#4338ca';
                    sEl.style.borderColor = '#c7d2fe';
                }
            }
        };

        if (profileScore >= 80) {
            setCardState('summary-card-profile-state', 'summary-card-profile-desc', 'summary-card-profile-btn', '已完善', '画像完整度较高，可直接进入岗位决策与投递执行。', '查看画像', 'default');
        } else if (profileScore > 0) {
            setCardState('summary-card-profile-state', 'summary-card-profile-desc', 'summary-card-profile-btn', '进行中', '还需补齐部分字段，完善后匹配与建议会更准确。', '继续完善', 'primary');
        } else {
            setCardState('summary-card-profile-state', 'summary-card-profile-desc', 'summary-card-profile-btn', '待开始', '先补齐目标岗位、技能、经验与薪资区间。', '立即完善', 'primary');
        }

        if (shortlistCount > 0) {
            setCardState('summary-card-eval-state', 'summary-card-eval-desc', 'summary-card-eval-btn', '已完成', `已形成 ${shortlistCount} 个候选岗位，可继续细化评估后投递。`, '继续评估', 'default');
        } else if (recCount > 0) {
            setCardState('summary-card-eval-state', 'summary-card-eval-desc', 'summary-card-eval-btn', '进行中', `已识别 ${recCount} 个高匹配岗位，建议先挑选并加入候选看板。`, '去筛选候选', 'primary');
        } else if (profileScore >= 60) {
            setCardState('summary-card-eval-state', 'summary-card-eval-desc', 'summary-card-eval-btn', '待开始', '画像已就绪，建议开始岗位决策并产出首批候选。', '开始评估', 'primary');
        } else {
            setCardState('summary-card-eval-state', 'summary-card-eval-desc', 'summary-card-eval-btn', '待开始', '完成画像后可查看岗位匹配度、竞争强度与投递建议。', '去岗位决策', 'default');
        }

        if (competDone) {
            setCardState('summary-card-compet-state', 'summary-card-compet-desc', 'summary-card-compet-btn', '已完成', '深度分析结果已生成，建议按短板清单持续提升。', '查看分析', 'default');
        } else if (profileScore >= 60) {
            setCardState('summary-card-compet-state', 'summary-card-compet-desc', 'summary-card-compet-btn', '待开始', '画像可用于深度分析，建议生成竞争力、薪资与技能差距结果。', '去分析', 'primary');
        } else {
            setCardState('summary-card-compet-state', 'summary-card-compet-desc', 'summary-card-compet-btn', '待开始', '完善画像后可进行竞争力分析、薪资诊断与技能差距分析。', '去分析', 'default');
        }

        const phaseNameEl = document.getElementById('summary-phase-name');
        const phaseBlockerEl = document.getElementById('summary-phase-blocker');
        const phaseNextEl = document.getElementById('summary-phase-next');
        if (phaseNameEl && phaseBlockerEl && phaseNextEl) {
            if (profileScore < 60) {
                phaseNameEl.innerText = '画像完善阶段';
                phaseBlockerEl.innerText = '关键字段未补齐，评估结果可信度不足。';
                phaseNextEl.innerText = '先补技能、经验与薪资，再进入岗位决策。';
            } else if (recCount <= 0) {
                phaseNameEl.innerText = '岗位决策阶段';
                phaseBlockerEl.innerText = '尚未形成可投递候选岗位。';
                phaseNextEl.innerText = '先在岗位决策页产出首批高匹配岗位。';
            } else if (shortlistCount <= 0) {
                phaseNameEl.innerText = '候选筛选阶段';
                phaseBlockerEl.innerText = '已生成推荐结果，但尚未确认主申/冲刺候选。';
                phaseNextEl.innerText = '先把高匹配岗位加入看板，再进入投递执行。';
            } else if (appliedCount <= 0) {
                phaseNameEl.innerText = '投递准备阶段';
                phaseBlockerEl.innerText = '候选岗位已形成，但未进入投递。';
                phaseNextEl.innerText = '优先投递 3 个高匹配岗位并建立看板跟踪。';
            } else {
                phaseNameEl.innerText = '投递跟进阶段';
                phaseBlockerEl.innerText = interviewCount + offerCount > 0 ? '流程推进中，需持续复盘。' : '投递后缺少跟进节奏与状态更新。';
                phaseNextEl.innerText = interviewCount + offerCount > 0 ? '复盘反馈并持续提升技能短板。' : '在投递执行看板中安排下一次跟进提醒。';
            }
        }

        let qualityPayload = null;
        if (qualityRes && qualityRes.ok) {
            const q = await qualityRes.json();
            qualityPayload = q;
            const qd = q.data || {};
            const score = Math.max(0, Math.min(100, Math.round((qd.valid_salary_rate || 0) * 0.4 + (100 - (qd.duplicate_rate || 0)) * 0.2 + (100 - (qd.abnormal_salary_rate || 0)) * 0.2 + (100 - (qd.missing_city_rate || 0)) * 0.1 + (100 - (qd.missing_company_rate || 0)) * 0.1)));
            dataQualityScoreForAction = score;
            const hint = document.getElementById('overview-reliability-hint');
            if (hint) hint.innerText = score >= 80 ? '当前数据质量较高，结论可信度较好。' : '当前数据质量一般，建议先补齐数据后再做关键决策。';
            if (score >= 70) {
                initSummaryProgressiveView();
            }
        }

        const metricsPayload = (metricsRes && metricsRes.ok) ? await metricsRes.json() : null;
        const weeklyPayload = (weeklyRes && weeklyRes.ok) ? await weeklyRes.json() : null;
        renderSummarySystemPanels(metricsPayload, weeklyPayload, qualityPayload);
        const summaryDecisionCtx = {
            profileScore,
            recCount,
            shortlistCount,
            appliedCount,
            interviewCount,
            offerCount,
            topMissing,
            dataQualityScore: dataQualityScoreForAction,
            marketSample
        };
        const workbenchDecision = await fetchWorkbenchDecision(summaryDecisionCtx);
        renderSummaryPersonalActions({
            ...summaryDecisionCtx,
            __decision: workbenchDecision
        });

        const aiStatus = await getAiRuntimeStatus();
        const aiBox = document.getElementById('summary-ai-advice');
        if (aiBox) {
            const decision = workbenchDecision || buildSummaryDecisionPayload(summaryDecisionCtx);
            let actionBtn = `<button class="btn btn-primary" onclick="switchTab('data')"><i class="ri-radar-line"></i> 去岗位决策</button>`;
            if (decision.primaryAction === 'profile') {
                actionBtn = `<button class="btn btn-primary" onclick="switchTab('profile')"><i class="ri-user-settings-line"></i> 去完善画像</button>`;
            } else if (decision.primaryAction === 'applications') {
                actionBtn = `<button class="btn btn-primary" onclick="switchTab('applications')"><i class="ri-send-plane-line"></i> 去投递执行</button>`;
            } else if (decision.primaryAction === 'compet') {
                actionBtn = `<button class="btn btn-primary" onclick="goToCompetitiveness()"><i class="ri-bar-chart-grouped-line"></i> 去竞争力分析</button>`;
            }
            const aiHint = getAiRuntimeHint(aiStatus);
            const aiHintClass = aiStatus && aiStatus.ai_available ? 'good' : 'warn';
            aiBox.innerHTML = `
                <div class="section-heading"><i class="ri-robot-2-line"></i> 今日决策建议</div>
                <div class="summary-ai-runtime-note ${aiHintClass}">${aiHint}</div>
                ${renderConclusionCard('系统决策输出', decision.conclusion, decision.reason, decision.suggestion, decision.tone)}
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
                    ${actionBtn}
                    <button class="btn btn-default" onclick="switchTab('ai')"><i class="ri-focus-3-line"></i> 查看系统推荐</button>
                    <button class="btn btn-default" onclick="switchTab('dashboard')"><i class="ri-line-chart-line"></i> 查看市场依据</button>
                </div>
            `;
        }

        const banner = document.getElementById('profile-banner');
        const bannerText = document.getElementById('profile-banner-text');
        const dismissed = localStorage.getItem('profile_banner_dismissed_at');
        const dismissTime = dismissed ? new Date(dismissed).getTime() : 0;
        const canShowBanner = !dismissTime || (Date.now() - dismissTime > 24 * 60 * 60 * 1000);
        if (banner) {
            if (profileScore < 60 && canShowBanner) {
                banner.style.display = 'block';
                if (bannerText) {
                    const miss = (((profilePayload || {}).data || {}).missing_fields) || [];
                    bannerText.innerText = miss.length ? `当前待完善：${miss.slice(0, 3).join('、')}` : '完善个人画像后可查看岗位匹配度、竞争力分析和技能差距。';
                }
            } else {
                banner.style.display = 'none';
            }
        }
    } catch (e) {
        console.error(e);
    }
    loadDataQuality();
}

function toggleSummaryQualityPanel() {
    const body = document.getElementById('dq-body');
    const btn = document.getElementById('dq-toggle-btn');
    if (!body || !btn) return;
    const collapsed = body.style.display === 'none';
    body.style.display = collapsed ? 'block' : 'none';
    btn.innerHTML = collapsed ? '<i class="ri-arrow-up-s-line"></i> 收起' : '<i class="ri-arrow-down-s-line"></i> 展开';
}

let jobEvalModalRadarChart = null;
let jobEvalModalGaugeChart = null;

function closeJobEvalModal() {
    const modal = document.getElementById('job-eval-modal');
    if (modal) modal.style.display = 'none';
}

function renderJobEvalModalCharts(radar = {}, investIndex = 0) {
    if (typeof echarts === 'undefined') return;
    const radarEl = document.getElementById('job-eval-modal-radar');
    const gaugeEl = document.getElementById('job-eval-modal-gauge');
    if (radarEl) {
        if (jobEvalModalRadarChart) {
            try { jobEvalModalRadarChart.dispose(); } catch (e) { }
        }
        jobEvalModalRadarChart = echarts.init(radarEl);
        jobEvalModalRadarChart.setOption({
            radar: {
                indicator: [
                    { name: '技能', max: 100 },
                    { name: '经验', max: 100 },
                    { name: '学历', max: 100 },
                    { name: '薪资', max: 100 }
                ],
                radius: '68%'
            },
            series: [{
                type: 'radar',
                data: [{
                    value: [
                        Number(radar.skill_match || 0),
                        Number(radar.exp_match || 0),
                        Number(radar.edu_match || 0),
                        Number(radar.salary_fit || 0)
                    ],
                    areaStyle: { color: 'rgba(37,99,235,0.30)' },
                    lineStyle: { color: '#2563eb', width: 2 }
                }]
            }]
        }, true);
    }
    if (gaugeEl) {
        if (jobEvalModalGaugeChart) {
            try { jobEvalModalGaugeChart.dispose(); } catch (e) { }
        }
        jobEvalModalGaugeChart = echarts.init(gaugeEl);
        jobEvalModalGaugeChart.setOption({
            series: [{
                type: 'gauge',
                radius: '86%',
                min: 0,
                max: 100,
                progress: { show: true, width: 12 },
                axisLine: { lineStyle: { width: 12 } },
                detail: { valueAnimation: true, formatter: '{value}', fontSize: 24, color: '#1e293b' },
                data: [{ value: Number(investIndex || 0), name: '可投指数' }]
            }]
        }, true);
    }
}

function showJobEvalModal(payload = {}) {
    const modal = document.getElementById('job-eval-modal');
    if (!modal) return;
    const setText = (id, text) => {
        const el = document.getElementById(id);
        if (el) el.innerText = String(text || '');
    };
    setText('job-eval-modal-title', payload.title || '岗位决策结果');
    setText('job-eval-modal-company', payload.company || '');
    setText('job-eval-modal-salary', payload.salary || '');
    setText('job-eval-modal-city', payload.city || '');
    const skillsEl = document.getElementById('job-eval-modal-skills');
    if (skillsEl) skillsEl.innerHTML = payload.skillsHtml || '';
    const adviceEl = document.getElementById('job-eval-modal-advice');
    if (adviceEl) adviceEl.innerHTML = payload.adviceHtml || '';
    const decisionEl = document.getElementById('job-eval-modal-decision');
    if (decisionEl) decisionEl.innerHTML = payload.decisionHtml || '';
    const actionsEl = document.getElementById('job-eval-modal-actions');
    if (actionsEl) actionsEl.innerHTML = payload.actionsHtml || '';
    modal.style.display = 'flex';
    setTimeout(() => renderJobEvalModalCharts(payload.radar || {}, payload.investIndex || 0), 80);
}

function getJobEvalRiskTone(level) {
    return level === '高' ? '#ef4444' : (level === '中' ? '#f59e0b' : '#10b981');
}

function renderJobEvalActions(jobId, score, actions = []) {
    const list = Array.isArray(actions) ? actions : [];
    if (!list.length) return '';
    return list.map(action => {
        const icon = action.icon ? `<i class="${action.icon}"></i> ` : '';
        const cls = action.style === 'primary' ? 'btn btn-primary' : 'btn btn-default';
        if (action.type === 'bucket') {
            return `<button class="${cls}" onclick="classifyJobForDelivery(${jobId}, ${score}, '${action.bucket || '主申'}')">${icon}${action.label || '归类'}</button>`;
        }
        if (action.type === 'applied') {
            return `<button class="${cls}" onclick="markJobAppliedById(${jobId}, ${score})">${icon}${action.label || '标记已投递'}</button>`;
        }
        return `<button class="${cls}" onclick="markJobAsFavorite(${jobId}, ${score})">${icon}${action.label || '收藏到看板'}</button>`;
    }).join('');
}

function buildJobEvalModalPayloadFromDecision(jobId, payload = {}, trustWarn = '') {
    const job = payload.job || {};
    const match = payload.match || {};
    const decision = payload.decision || {};
    const radar = match.radar || {};
    const matched = Array.isArray(decision.matched_skills) ? decision.matched_skills : [];
    const missing = Array.isArray(decision.missing_skills) ? decision.missing_skills : [];
    const risks = decision.risks || {};
    const score = Number(decision.score || match.score || 0);
    const riskLevel = decision.risk_level || '--';
    const riskColor = riskLevel === '高风险' ? '#ef4444' : (riskLevel === '中风险' ? '#f59e0b' : '#10b981');
    const skillRisk = (risks.skill || {}).level || '-';
    const salaryRisk = (risks.salary || {}).level || '-';
    const competitionRisk = (risks.competition || {}).level || '-';
    const matchedTags = matched.map(s => `<span class="skill-tag matched">✅ ${s}</span>`).join('');
    const missingTags = missing.map(s => `<span class="skill-tag missing">⚠ ${s}</span>`).join('');
    const nextActions = Array.isArray(decision.next_actions) ? decision.next_actions : [];
    const adviceHtml = nextActions.length
        ? `<b>三步行动：</b><br>${nextActions.map((item, idx) => `${idx + 1}. ${item}`).join('<br>')}`
        : `<b>建议：</b>${decision.suggestion || '建议先补齐短板后再投递。'}`;
    const decisionHtml = `
        <b>评估结论：</b>${decision.conclusion || '已完成评估'} ｜ <b>推荐分层：</b>${decision.bucket || '--'} ｜ <b>投递风险：</b><span style="color:${riskColor};">${riskLevel}</span><br>
        <b>三维风险：</b>
        <span style="color:${getJobEvalRiskTone(skillRisk)};">技能${skillRisk}</span> /
        <span style="color:${getJobEvalRiskTone(salaryRisk)};">薪资${salaryRisk}</span> /
        <span style="color:${getJobEvalRiskTone(competitionRisk)};">竞争${competitionRisk}</span><br>
        <b>原因：</b>${decision.reason || '规则评估已完成'}<br>
        <b>建议：</b>${decision.suggestion || '建议先补短板后再投递。'}
        ${trustWarn ? `<div style="margin-top:8px; color:#92400e;">${trustWarn}</div>` : ''}
    `;
    return {
        title: `${job.job_name || '岗位'} · 岗位决策结果`,
        company: job.company ? `🏢 ${job.company}` : '',
        salary: (job.salary_text || job.salary_avg) ? `💰 ${job.salary_text || job.salary_avg}` : '',
        city: job.city ? `📍 ${job.city}` : '',
        skillsHtml: (matchedTags + missingTags) || '<span style="color:#999;font-size:12px;">暂无技能数据</span>',
        adviceHtml,
        decisionHtml,
        actionsHtml: renderJobEvalActions(jobId, score, decision.actions || []),
        radar,
        investIndex: Number(decision.invest_index || score || 0),
        panelSnapshot: {
            stateText: decision.state_text || '已评估',
            jobTitle: job.job_name || '岗位',
            score,
            investIndex: Number(decision.invest_index || score || 0),
            riskLevel: `${riskLevel}（${decision.risk_summary || '--'}）`,
            bucket: decision.bucket || '--',
            reason: decision.reason || '规则评估已完成',
            nextActions: nextActions.length ? nextActions : [decision.suggestion || '建议先补齐短板后再投递。']
        }
    };
}

async function evaluateJobFromList(jobId) {
    const fallbackWithRules = (errMsg = '') => {
        const rows = Array.isArray(window.latestDataRows) ? window.latestDataRows : [];
        const row = rows.find(x => Number(x.id) === Number(jobId));
        if (!row || typeof window.computeRuleEvaluation !== 'function') {
            showToast(`岗位决策失败：${errMsg || '无法获取岗位数据'}`, 'error');
            return;
        }
        const ev = window.computeRuleEvaluation(row);
        const score = Number(ev.score || 0);
        const bucket = ev.bucket || '保底';
        const investIndex = Number(ev.investIndex || score);
        const risks = ev.risks || {};
        const riskText = `技能${(risks.skill || {}).level || '-'} / 薪资${(risks.salary || {}).level || '-'} / 竞争${(risks.competition || {}).level || '-'}`;
        const decisionHtml = `
            <b>评估结论：</b>${score >= MATCH_SCORE_MAIN ? '适合投递' : (score >= MATCH_SCORE_SPRINT ? '可投递，建议补强后优先' : '暂缓投递，先补短板')} ｜ 
            <b>推荐分层：</b>${bucket} ｜ <b>投递风险：</b>${ev.riskLevel || '--'}<br>
            <b>三维风险：</b>
            <span style="color:${getJobEvalRiskTone((risks.skill || {}).level)};">技能${(risks.skill || {}).level || '-'}</span> /
            <span style="color:${getJobEvalRiskTone((risks.salary || {}).level)};">薪资${(risks.salary || {}).level || '-'}</span> /
            <span style="color:${getJobEvalRiskTone((risks.competition || {}).level)};">竞争${(risks.competition || {}).level || '-'}</span><br>
            <b>原因：</b>${ev.reason || '规则评估已完成'}<br>
            <b>建议：</b>${ev.suggestion || '建议先补短板后再投递'}
            ${errMsg ? `<div style="margin-top:8px; color:#92400e;">系统增强服务/接口不可用，已切换规则评估：${errMsg}</div>` : ''}
        `;
        applyJobEvalPanelSnapshot({
            stateText: '已评估（规则兜底）',
            jobTitle: row.job_name || '岗位',
            score,
            investIndex,
            riskLevel: `${ev.riskLevel || '--'}（${riskText}）`,
            bucket,
            reason: ev.reason || '规则评估已完成',
            nextActions: [
                `先按“${bucket}”分层处理，避免盲目投递。`,
                `风险重点：${riskText}。`,
                ev.suggestion || '建议先补技能再投递。'
            ]
        });
        showJobEvalModal({
        title: `${row.job_name || '岗位'} · 岗位决策结果`,
            company: row.company ? `🏢 ${row.company}` : '',
            salary: row.salary_text ? `💰 ${row.salary_text}` : '',
            city: row.city ? `📍 ${row.city}` : '',
            skillsHtml: `<span class="skill-tag matched">✅ 规则评分 ${score}</span>`,
            adviceHtml: `<b>规则评估建议：</b>${ev.suggestion || '建议先补短板后投递。'}`,
            decisionHtml,
            actionsHtml: renderJobEvalActions(jobId, score, [
                { type: 'bucket', bucket: '主申', label: '归类主申', style: 'default', icon: 'ri-medal-line' },
                { type: 'bucket', bucket: '冲刺', label: '归类冲刺', style: 'default', icon: 'ri-rocket-line' },
                { type: 'bucket', bucket: '保底', label: '归类保底', style: 'default', icon: 'ri-shield-line' },
                { type: 'favorite', label: '收藏到看板', style: 'default', icon: 'ri-star-line' },
                { type: 'applied', label: '标记已投递', style: 'primary', icon: 'ri-send-plane-line' }
            ]),
            radar: {
                skill_match: Math.max(0, Math.min(100, Number(row._quick_match || 58))),
                exp_match: Math.max(0, Math.min(100, Math.round(score * 0.9))),
                edu_match: Math.max(0, Math.min(100, Math.round(score * 0.95))),
                salary_fit: Math.max(0, Math.min(100, Math.round(score * 0.92)))
            },
            investIndex
        });
        showToast(`岗位决策完成（规则兜底）：匹配分 ${score}，推荐分层 ${bucket}`);
    };

    showToast('正在评估岗位，请稍候...');
    try {
        const r = await fetch(`/api/job/${jobId}/decision`, { method: 'POST' });
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '评估失败');
        const trustWarn = (latestDataQualityScore !== null && Number(latestDataQualityScore) < 60)
            ? `当前数据可信度 ${latestDataQualityScore} 分，建议将本次结论作为参考并结合岗位原文人工复核。`
            : '';
        const modalPayload = buildJobEvalModalPayloadFromDecision(jobId, d.data || {}, trustWarn);
        applyJobEvalPanelSnapshot(modalPayload.panelSnapshot || {});
        showJobEvalModal(modalPayload);
        setJobFlowStep(Math.max(getJobFlowStep(), 1));
        const decision = ((d.data || {}).decision) || {};
        showToast(`岗位决策完成：匹配分 ${Number(decision.score || 0)}，推荐分层 ${decision.bucket || '--'}`);
    } catch (e) {
        fallbackWithRules(String((e && e.message) || '未知错误'));
    }
}

async function loadJobAiSummary(jobId, score = 0) {
    const box = document.getElementById('job-ai-summary-box');
    const content = document.getElementById('job-ai-summary-content');
    if (!box || !content || !jobId) return;
    box.style.display = 'block';
    content.innerHTML = '系统评估结论生成中...';
    try {
        const res = await fetchJsonWithTimeout(`/api/job/${jobId}/ai-summary`, { method: 'POST' }, 70000);
        const d = res.body || {};
        if (!d.success || !d.data) throw new Error(d.msg || '失败');
        const tone = Number(score || 0) >= MATCH_SCORE_MAIN ? 'good' : (Number(score || 0) >= MATCH_SCORE_SPRINT ? 'mid' : 'risk');
        content.innerHTML = renderAiStructCard('系统评估结论', d.data, tone);
    } catch (e) {
        content.innerHTML = '<span style="color:#ef4444;">系统评估结论暂不可用（超时或服务离线），已展示规则评估结果。</span>';
    }
}

async function evaluateTopJobs() {
    const rows = Array.isArray(window.latestDataRows) ? window.latestDataRows : [];
    if (!rows.length) {
        showToast('请先筛选并加载岗位列表', 'error');
        return;
    }
    const evalFn = typeof window.computeRuleEvaluation === 'function'
        ? window.computeRuleEvaluation
        : ((row) => ({ score: Number(row._quick_match || 0), bucket: '保底', riskLevel: '--', suggestion: '规则引擎未就绪' }));
    const ranked = rows
        .filter(x => x && x.id)
        .map(row => ({ row, ev: evalFn(row) }))
        .sort((a, b) => Number(b.ev.score || 0) - Number(a.ev.score || 0));
    if (!ranked.length) {
        showToast('当前筛选结果不足，无法评估', 'error');
        return;
    }
    const top = ranked[0];
    const top3 = ranked.slice(0, 3);
    const conc = Number(top.ev.score || 0) >= MATCH_SCORE_MAIN
        ? '当前筛选结果中存在可优先投递岗位'
        : (Number(top.ev.score || 0) >= MATCH_SCORE_SPRINT ? '当前筛选结果可投递，但建议先补强' : '当前筛选结果整体匹配度偏低');
    const reason = `已完成 ${ranked.length} 个岗位规则预评估，最高匹配 ${top.ev.score}（${top.row.job_name || '未知岗位'}）`;
    const suggestion = `主推岗位：${top3.map(x => x.row.job_name || '未知岗位').join('、')}。建议：${top.ev.suggestion || '先补短板再投递。'}`;
    const listHtml = ranked.slice(0, 8).map((x, i) => {
        const rv = x.ev.riskLevel || '--';
        return `<div style="display:flex;justify-content:space-between;gap:8px;font-size:12px;padding:6px 0;border-bottom:${i === 7 || i === ranked.length - 1 ? 'none' : '1px dashed #e2e8f0'};">
            <span>${i + 1}. ${x.row.job_name || '未知岗位'} · ${x.row.company || '-'}</span>
            <b>${x.ev.score}</b>
            <span style="color:${rv === '高风险' ? '#ef4444' : (rv === '中风险' ? '#f59e0b' : '#10b981')};">${rv}</span>
        </div>`;
    }).join('');
    applyJobEvalPanelSnapshot({
        stateText: '批量预评估完成',
        jobTitle: top.row.job_name || '岗位',
        score: Number(top.ev.score || 0),
        investIndex: Number(top.ev.investIndex || top.ev.score || 0),
        riskLevel: top.ev.riskLevel || '--',
        bucket: top.ev.bucket || '--',
        reason,
        nextActions: [
            `优先处理最高分岗位：${top.row.job_name || '未知岗位'}（${top.ev.score}分）。`,
            `先投主申岗位，再补投冲刺岗位；当前 Top3：${top3.map(x => x.row.job_name || '未知岗位').join('、')}。`,
            '进入投递执行页执行今日行动清单并跟进反馈。'
        ]
    });
    showJobEvalModal({
        title: '批量预评估结果（当前筛选）',
        company: `🏢 已评估 ${ranked.length} 个岗位`,
        salary: `💰 最高匹配 ${top.ev.score}`,
        city: '',
        skillsHtml: '<span class="skill-tag matched">✅ 已完成当前筛选岗位预评估</span>',
        adviceHtml: `<b>结论：</b>${conc}<br><b>原因：</b>${reason}<br><b>建议：</b>${suggestion}`,
        decisionHtml: `<div style="font-weight:700; margin-bottom:6px;">预评估清单（Top8）</div>${listHtml}`,
        actionsHtml: `<button class="btn btn-primary" onclick="evaluateJobFromList(${top.row.id})"><i class="ri-radar-line"></i> 打开最高分岗位决策</button>`,
        radar: { skill_match: top.ev.score, exp_match: top.ev.score, edu_match: top.ev.score, salary_fit: top.ev.score },
        investIndex: Number(top.ev.investIndex || top.ev.score || 0)
    });
    showToast('当前筛选岗位已完成批量预评估');
}

function renderJobEvalEvidenceChart(radar, matched, missing, score) {
    const el = document.getElementById('job-eval-evidence-chart');
    const textEl = document.getElementById('job-eval-evidence-text');
    if (!el || typeof echarts === 'undefined') return;
    if (jobEvalEvidenceChart) {
        try { jobEvalEvidenceChart.dispose(); } catch (e) { }
    }
    jobEvalEvidenceChart = echarts.init(el);
    const dims = ['技能匹配', '经验匹配', '学历匹配', '薪资匹配'];
    const vals = [
        Number((radar || {}).skill_match || 0),
        Number((radar || {}).exp_match || 0),
        Number((radar || {}).edu_match || 0),
        Number((radar || {}).salary_fit || 0),
    ];
    jobEvalEvidenceChart.setOption({
        grid: { left: 90, right: 20, top: 20, bottom: 20 },
        xAxis: { type: 'value', max: 100, axisLabel: { color: '#64748b' } },
        yAxis: { type: 'category', data: dims, axisLabel: { color: '#334155' } },
        series: [{
            type: 'bar',
            data: vals,
            label: { show: true, position: 'right', formatter: '{c}' },
            itemStyle: {
                borderRadius: [0, 6, 6, 0],
                color: function (p) {
                    if (p.value >= 80) return '#10b981';
                    if (p.value >= 60) return '#f59e0b';
                    return '#ef4444';
                }
            },
            barWidth: 14
        }]
    }, true);
    if (textEl) {
        textEl.innerHTML = `结论依据：综合得分 <b>${score}</b>；已匹配技能 <b>${(matched || []).length}</b> 项，缺失技能 <b>${(missing || []).length}</b> 项。图中维度用于解释“为什么适合/不适合投递”。`;
    }
}

async function markJobAsFavorite(jobId, score = 0) {
    const safeScore = Number(score || 0);
    const autoBucket = safeScore >= MATCH_SCORE_MAIN ? '主申' : (safeScore >= MATCH_SCORE_SPRINT ? '冲刺' : '保底');
    const bucketTag = `[${autoBucket}候选]`;
    try {
        const payload = { job_id: jobId, status: 'favorite', bucket: autoBucket, notes: bucketTag };
        if (safeScore > 0) payload.match_score = safeScore;
        const r = await fetch('/api/applications', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const d = await r.json();
        if (!d.success) {
            const listRes = await fetch('/api/applications');
            const listData = await listRes.json();
            if (!listData.success) throw new Error(d.msg || '失败');
            const hit = (listData.data || []).find(x => Number(x.job_id) === Number(jobId));
            if (!hit) throw new Error(d.msg || '失败');
            const oldNotes = String(hit.notes || '').trim();
            const mergedNotes = oldNotes
                ? (oldNotes.includes(bucketTag) ? oldNotes : `${bucketTag} ${oldNotes}`)
                : bucketTag;
            const patchPayload = { status: 'favorite', bucket: autoBucket, notes: mergedNotes };
            if (safeScore > 0) patchPayload.match_score = safeScore;
            const p = await fetch(`/api/applications/${hit.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(patchPayload)
            });
            const pd = await p.json();
            if (!pd.success) throw new Error(pd.msg || d.msg || '失败');
            appIdByJobId[jobId] = hit.id;
        }
        showToast(`已收藏到看板（${autoBucket}候选）`);
        loadApplicationBoard();
        syncDetailApplyButtons(jobId);
    } catch (e) {
        showToast('收藏失败', 'error');
    }
}

async function markJobAppliedById(jobId, score = 0) {
    try {
        const safeScore = Number(score || 0);
        const autoBucket = safeScore >= MATCH_SCORE_MAIN ? '主申' : (safeScore >= MATCH_SCORE_SPRINT ? '冲刺' : '保底');
        let appId = appIdByJobId[jobId];
        if (!appId) {
            const createPayload = { job_id: jobId, status: 'applied', bucket: autoBucket };
            if (safeScore > 0) createPayload.match_score = safeScore;
            const c = await fetch('/api/applications', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(createPayload)
            });
            const cd = await c.json();
            if (!cd.success) throw new Error(cd.msg || '创建失败');
            appId = ((cd.data || {}).id) || 0;
            if (appId) appIdByJobId[jobId] = appId;
        } else {
            const updatePayload = { status: 'applied', bucket: autoBucket };
            if (safeScore > 0) updatePayload.match_score = safeScore;
            const u = await fetch(`/api/applications/${appId}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatePayload)
            });
            const ud = await u.json();
            if (!ud.success) throw new Error(ud.msg || '更新失败');
        }
        showToast('已标记为已投递');
        setJobFlowStep(Math.max(getJobFlowStep(), 3));
        loadApplicationBoard();
        syncDetailApplyButtons(jobId);
        hydrateDataRowActions();
    } catch (e) {
        showToast('标记失败', 'error');
    }
}

function quickMarkApplied(jobId) {
    return markJobAppliedById(jobId, 0);
}

function buildExecutionSeedJobs(limit = 12) {
    const maxCount = Math.max(1, Math.min(Number(limit || 12), 16));
    const fromRecommend = Array.isArray(window.currentAiData) ? window.currentAiData : [];
    if (fromRecommend.length) {
        return fromRecommend
            .map(item => ({
                job_id: Number(item.id || item.job_id || 0),
                match_score: Number(item.score || item.match_score || 0),
                job_name: item.job_name || '',
                company: item.company || ''
            }))
            .filter(item => item.job_id > 0)
            .sort((a, b) => Number(b.match_score || 0) - Number(a.match_score || 0))
            .slice(0, maxCount);
    }
    const fromList = Array.isArray(window.latestDataRows) ? window.latestDataRows : [];
    return fromList
        .map(row => ({
            job_id: Number(row.id || row.job_id || 0),
            match_score: Number(row._quick_match || row.match_score || row.score || 0),
            job_name: row.job_name || '',
            company: row.company || ''
        }))
        .filter(item => item.job_id > 0 && Number(item.match_score || 0) > 0)
        .sort((a, b) => Number(b.match_score || 0) - Number(a.match_score || 0))
        .slice(0, maxCount);
}

async function autoBuildExecutionPool() {
    const seedJobs = buildExecutionSeedJobs(12);
    if (!seedJobs.length) {
        showToast('当前没有可用于生成执行池的推荐结果，请先完成岗位决策或推荐计划', 'error');
        return;
    }
    try {
        showToast('正在生成执行池，请稍候...');
        const r = await fetch('/api/applications/auto-plan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ jobs: seedJobs, limit: 9 })
        });
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '生成失败');
        const summary = ((d.data || {}).summary) || {};
        showToast(`已生成执行池：主申 ${summary.主申 || 0}，冲刺 ${summary.冲刺 || 0}，保底 ${summary.保底 || 0}`);
        setJobFlowStep(Math.max(getJobFlowStep(), 2));
        loadApplicationBoard();
        if (typeof syncRecommendApplicationMap === 'function') {
            try { await syncRecommendApplicationMap(); } catch (_) { }
        }
        hydrateDataRowActions();
    } catch (e) {
        showToast(`生成执行池失败：${String((e && e.message) || '未知错误')}`, 'error');
    }
}

async function autoOrganizeExecutionPool() {
    try {
        showToast('正在整理执行池优先级...');
        const r = await fetch('/api/applications/auto-organize', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '整理失败');
        const summary = ((d.data || {}).summary) || {};
        showToast(`执行池已整理：主申 ${summary.主申 || 0}，冲刺 ${summary.冲刺 || 0}，保底 ${summary.保底 || 0}`);
        loadApplicationBoard();
    } catch (e) {
        showToast(`整理执行池失败：${String((e && e.message) || '未知错误')}`, 'error');
    }
}

async function hydrateDataRowActions(rows) {
    try {
        if (Array.isArray(rows)) window.latestDataRows = rows;
        const r = await fetch('/api/applications');
        const d = await r.json();
        if (!d.success) return;
        appIdByJobId = {};
        (d.data || []).forEach(item => { if (item.job_id) appIdByJobId[item.job_id] = item.id; });
        document.querySelectorAll('.app-quick-action').forEach(btn => {
            const jobId = Number(btn.getAttribute('data-job-id') || '0');
            const appId = appIdByJobId[jobId];
            if (appId) {
                btn.title = '已在看板中，点击更新为已投递';
                btn.innerHTML = '<i class="ri-check-line"></i> 已在看板';
                btn.style.color = '#16a34a';
            } else {
                btn.title = '标记已投递';
                btn.innerHTML = '<i class="ri-send-plane-line"></i> 标记投递';
                btn.style.color = '';
            }
        });
    } catch (e) {
        console.error(e);
    }
}

async function syncDetailApplyButtons(jobId) {
    const root = document.getElementById('detail-apply-actions');
    if (!root || !jobId) return;
    try {
        const r = await fetch('/api/applications');
        const d = await r.json();
        if (!d.success) return;
        const found = (d.data || []).find(x => Number(x.job_id) === Number(jobId));
        if (!found) {
            root.innerHTML = `<button class="btn btn-default" onclick="addDetailToBoard()"><i class="ri-star-line"></i> 收藏到看板</button><button class="btn btn-primary" onclick="markDetailApplied()"><i class="ri-send-plane-2-line"></i> 标记已投递</button>`;
            return;
        }
        const currentKey = normalizeAppStatusKey(found.status);
        root.innerHTML = `<span class="tag" style="background:#ecfdf5;color:#166534;">已在看板中</span><select class="select" style="width:160px;" onchange="updateApplicationStatus(${found.id}, this.value)">${APP_STATUS_COLUMNS.map(x => `<option value="${x.key}" ${x.key === currentKey ? 'selected' : ''}>${x.label}</option>`).join('')}</select>`;
    } catch (e) {
        console.error(e);
    }
}

function addDetailToBoard() {
    if (!window.currentDetailJobId) return showToast('未识别岗位ID', 'error');
    return markJobAsFavorite(window.currentDetailJobId, 0);
}

function markDetailApplied() {
    if (!window.currentDetailJobId) return showToast('未识别岗位ID', 'error');
    return markJobAppliedById(window.currentDetailJobId, 0);
}

async function loadApplicationBoard() {
    const board = document.getElementById('application-board');
    const summary = document.getElementById('application-summary');
    if (!board || !summary) return;
    board.innerHTML = '看板加载中...';
    let timedOut = false;
    const timeoutHandle = setTimeout(() => {
        timedOut = true;
        const fallbackRows = (Array.isArray(appAllRows) && appAllRows.length)
            ? appAllRows
            : (Array.isArray(appCacheRows) ? appCacheRows : []);
        if (fallbackRows.length) {
            renderApplicationBoardColumns(board, fallbackRows);
            renderDecisionCockpitPanel(fallbackRows);
            renderDecisionTodoPanel(fallbackRows);
            renderPriorityPool(fallbackRows);
            renderDecisionReviewPanel(fallbackRows);
            renderDecisionTimelinePanel(fallbackRows);
            summary.innerHTML = `
                <div class="flex-between">
                    <div class="fw-700"><i class="ri-dashboard-3-line"></i> 投递总览与转化分析（缓存兜底）</div>
                    <span class="text-hint">接口响应较慢，已先展示最近缓存数据</span>
                </div>
            `;
        } else {
            const cockpit = document.getElementById('decision-cockpit-panel');
            const todoBox = document.getElementById('decision-todo-panel');
            const poolBox = document.getElementById('decision-priority-pool');
            const reviewBox = document.getElementById('decision-review-panel');
            const timelineBox = document.getElementById('decision-timeline-panel');
            if (cockpit) cockpit.innerHTML = '<div class="fw-700"><i class="ri-compass-3-line"></i> 执行驾驶舱</div><div class="text-hint mt-8">接口响应较慢，先按规则模式展示。请稍后刷新看板。</div>';
            if (todoBox) todoBox.innerHTML = '<div class="text-hint">暂无可执行动作，请先在岗位决策页加入候选岗位。</div>';
            if (poolBox) poolBox.innerHTML = '<div class="text-hint">优先投递池暂未生成，等待数据返回。</div>';
            if (reviewBox) reviewBox.innerHTML = '<div class="text-hint">周转化复盘暂不可用，等待数据返回。</div>';
            if (timelineBox) timelineBox.innerHTML = '<div class="text-hint">关键事件时间线暂不可用，等待数据返回。</div>';
        }
        const timing = document.getElementById('application-timing');
        if (timing && String(timing.innerHTML || '').includes('加载中')) {
            timing.innerHTML = '<div class="text-hint">投递时机分析加载较慢，正在尝试规则兜底...</div>';
        }
    }, APP_PANEL_TIMEOUT_MS);
    try {
        const filter = (document.getElementById('app-status-filter') || {}).value || '';
        const selectedKey = normalizeAppStatusKey(filter);
        let d = null;
        let dashboardPayload = null;
        try {
            const dashboardResp = await fetch('/api/applications/dashboard');
            const dashboardJson = await dashboardResp.json();
            if (dashboardJson && dashboardJson.success) {
                dashboardPayload = dashboardJson.data || {};
                latestApplicationDashboard = dashboardPayload;
                latestWeeklyPlanMeta = {
                    week_key: (((dashboardPayload || {}).weekly_plan || {}).week_key) || '',
                    completed_map: ((((dashboardPayload || {}).weekly_plan || {}).completed_map) || {})
                };
                d = {
                    success: true,
                    data: dashboardPayload.items || [],
                    metrics: {
                        response_rate: Number((dashboardPayload.overview || {}).response_rate || 0),
                        interview_rate: Number((dashboardPayload.overview || {}).interview_rate || 0),
                        offer_rate: Number((dashboardPayload.overview || {}).offer_rate || 0)
                    }
                };
            }
        } catch (e) {}
        if (!d) {
            latestApplicationDashboard = null;
            latestWeeklyPlanMeta = { week_key: '', completed_map: {} };
            const r = await fetch('/api/applications');
            d = await r.json();
        }
        if (!d.success) throw new Error(d.msg || '加载失败');
        const rawList = d.data || [];
        appAllRows = rawList;
        const list = filter ? rawList.filter(x => normalizeAppStatusKey(x.status) === selectedKey) : rawList;
        appCacheRows = list;
        updateSidebarBadges(null, rawList);
        appIdByJobId = {};
        rawList.forEach(x => { if (x.job_id) appIdByJobId[x.job_id] = x.id; });

        const appliedCount = rawList.filter(x => normalizeAppStatusKey(x.status) !== 'favorite').length;
        const interviewCount = rawList.filter(x => normalizeAppStatusKey(x.status) === 'interview').length;
        const offerCount = rawList.filter(x => normalizeAppStatusKey(x.status) === 'offer').length;
        const filteredHint = filter ? `当前筛选 ${list.length} / 总记录 ${rawList.length}` : `总记录 ${rawList.length}`;
        const metrics = d.metrics || { response_rate: 0, interview_rate: 0, offer_rate: 0 };
        const executionFeedback = (dashboardPayload || {}).execution_feedback || {};
        const executionMetrics = executionFeedback.metrics || {};
        summary.innerHTML = `
            <div class="flex-between" style="margin-bottom:8px;">
                <div class="fw-700"><i class="ri-dashboard-3-line"></i> 投递总览与转化分析</div>
                <span class="text-hint">${filteredHint}</span>
            </div>
            <div style="display:grid; grid-template-columns:repeat(4, minmax(120px, 1fr)); gap:8px; margin-bottom:12px;">
                <div style="border:1px solid #dbeafe; background:#eff6ff; border-radius:10px; padding:10px;">
                    <div class="text-hint">已投递</div>
                    <div style="font-size:22px; font-weight:800; color:#1d4ed8;">${appliedCount}</div>
                </div>
                <div style="border:1px solid #fde68a; background:#fffbeb; border-radius:10px; padding:10px;">
                    <div class="text-hint">面试邀约</div>
                    <div style="font-size:22px; font-weight:800; color:#92400e;">${interviewCount}</div>
                </div>
                <div style="border:1px solid #bbf7d0; background:#f0fdf4; border-radius:10px; padding:10px;">
                    <div class="text-hint">Offer</div>
                    <div style="font-size:22px; font-weight:800; color:#166534;">${offerCount}</div>
                </div>
                <div style="border:1px solid #e9d5ff; background:#faf5ff; border-radius:10px; padding:10px;">
                    <div class="text-hint">收藏池</div>
                    <div style="font-size:22px; font-weight:800; color:#6d28d9;">${rawList.length - appliedCount}</div>
                </div>
            </div>
            <div style="display:flex; gap:12px; background:#f8fafc; border-radius:8px; padding:10px; border:1px solid #e2e8f0;">
                <div style="flex:1; text-align:center;">
                    <div style="font-size:11px; color:#64748b; margin-bottom:2px;">初筛回复率 (非已投递占比)</div>
                    <div style="font-size:16px; font-weight:700; color:#0ea5e9;">${metrics.response_rate}%</div>
                </div>
                <div style="width:1px; background:#cbd5e1;"></div>
                <div style="flex:1; text-align:center;">
                    <div style="font-size:11px; color:#64748b; margin-bottom:2px;">面试面邀率 (总面邀占比)</div>
                    <div style="font-size:16px; font-weight:700; color:#f59e0b;">${metrics.interview_rate}%</div>
                </div>
                <div style="width:1px; background:#cbd5e1;"></div>
                <div style="flex:1; text-align:center;">
                    <div style="font-size:11px; color:#64748b; margin-bottom:2px;">Offer获取率 (面试到最终)</div>
                    <div style="font-size:16px; font-weight:700; color:#10b981;">${metrics.offer_rate}%</div>
                </div>
            </div>
            <div style="display:grid; grid-template-columns:repeat(3, minmax(120px, 1fr)); gap:8px; margin-top:12px;">
                <div style="border:1px solid #dbeafe; background:#f8fbff; border-radius:10px; padding:10px;">
                    <div class="text-hint">周计划完成率</div>
                    <div style="font-size:18px; font-weight:800; color:#1d4ed8;">${Number(executionMetrics.completion_rate || 0)}%</div>
                </div>
                <div style="border:1px solid #fcd34d; background:#fffbeb; border-radius:10px; padding:10px;">
                    <div class="text-hint">主申执行率</div>
                    <div style="font-size:18px; font-weight:800; color:#92400e;">${Number(executionMetrics.main_execution_rate || 0)}%</div>
                </div>
                <div style="border:1px solid #fecaca; background:#fff7f7; border-radius:10px; padding:10px;">
                    <div class="text-hint">逾期待跟进</div>
                    <div style="font-size:18px; font-weight:800; color:#b91c1c;">${Number(executionMetrics.overdue_tasks || 0)}</div>
                </div>
            </div>
            ${executionFeedback.conclusion ? `
            <div style="margin-top:12px; border:1px solid #e2e8f0; background:#f8fafc; border-radius:10px; padding:10px; font-size:13px; line-height:1.7;">
                <b>执行反馈：</b>${executionFeedback.conclusion}<br>
                <span style="color:#475569;">${executionFeedback.reason || ''}</span>
            </div>` : ''}
        `;
        renderDecisionCockpitPanel(rawList, dashboardPayload);

        renderApplicationBoardColumns(board, list);
        renderDecisionTodoPanel(rawList, dashboardPayload);
        renderPriorityPool(rawList, dashboardPayload);
        renderDecisionReviewPanel(rawList, dashboardPayload);
        renderDecisionTimelinePanel(rawList, dashboardPayload);
        loadApplicationTiming();
        hydrateDataRowActions();
        loadDeliveryDecisionPanel(dashboardPayload);
        generateWeeklyPlan(dashboardPayload);
        // 避免看板批量触发系统增强服务导致本地模型排队超时：
        // 保留卡片本地规则建议，核心增强能力聚焦在三大结果页。
    } catch (e) {
        const fallbackRows = (Array.isArray(appAllRows) && appAllRows.length)
            ? appAllRows
            : (Array.isArray(appCacheRows) ? appCacheRows : []);
        if (fallbackRows.length) {
            renderApplicationBoardColumns(board, fallbackRows);
            renderDecisionCockpitPanel(fallbackRows);
            renderDecisionTodoPanel(fallbackRows);
            renderPriorityPool(fallbackRows);
            renderDecisionReviewPanel(fallbackRows);
            renderDecisionTimelinePanel(fallbackRows);
            loadApplicationTiming();
            summary.innerHTML = '<div class="text-hint">接口加载失败，已切换到本地缓存数据。</div>';
        } else {
            board.innerHTML = '<div style="color:#ef4444;">看板加载失败</div>';
            const cockpit = document.getElementById('decision-cockpit-panel');
            if (cockpit) cockpit.innerHTML = '<div style="color:#ef4444;">执行驾驶舱加载失败</div>';
            const todoBox = document.getElementById('decision-todo-panel');
            const poolBox = document.getElementById('decision-priority-pool');
            const reviewBox = document.getElementById('decision-review-panel');
            const timelineBox = document.getElementById('decision-timeline-panel');
            if (todoBox) todoBox.innerHTML = '<div style="color:#ef4444;">今日行动加载失败</div>';
            if (poolBox) poolBox.innerHTML = '<div style="color:#ef4444;">优先投递池加载失败</div>';
            if (reviewBox) reviewBox.innerHTML = '<div style="color:#ef4444;">周转化复盘加载失败</div>';
            if (timelineBox) timelineBox.innerHTML = '<div style="color:#ef4444;">关键事件时间线加载失败</div>';
        }
        if (!timedOut) showToast('看板接口异常，已尝试规则兜底', 'warning');
    } finally {
        clearTimeout(timeoutHandle);
    }
}

function scrollDecisionPanel(panelId) {
    const el = document.getElementById(panelId);
    if (!el) return;
    try {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) {
        el.scrollIntoView();
    }
}

window.scrollDecisionPanel = scrollDecisionPanel;

function renderApplicationBoardColumns(board, rows) {
    if (!board) return;
    const list = Array.isArray(rows) ? rows : [];
    const colMap = { favorite: [], applied: [], interview: [], offer: [] };
    list.forEach(item => {
        const key = normalizeAppStatusKey(item.status);
        if (!colMap[key]) colMap[key] = [];
        colMap[key].push(item);
    });
    const columnsHtml = APP_STATUS_COLUMNS.map(col => {
        const cards = (colMap[col.key] || []).map(item => renderApplicationCard(item)).join('');
        return `<div class="card" style="padding:10px;min-width:260px;"><div style="font-weight:700;margin-bottom:8px;">${col.label} (${(colMap[col.key] || []).length})</div><div style="display:grid;gap:8px;">${cards || '<div style="font-size:12px;color:#94a3b8;">暂无岗位</div>'}</div></div>`;
    }).join('');
    board.innerHTML = `
        <div class="flex-between" style="margin-bottom:12px;gap:12px;flex-wrap:wrap;">
            <div>
                <div class="fw-700" style="font-size:16px;">执行看板</div>
                <div class="text-hint" style="margin-top:4px;">先生成执行池，再按卡片建议完成投递、跟进和状态推进。</div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button class="btn btn-primary" onclick="autoBuildExecutionPool()"><i class="ri-magic-line"></i> 一键生成执行池</button>
                <button class="btn btn-default" onclick="autoOrganizeExecutionPool()"><i class="ri-stack-line"></i> 整理优先级</button>
            </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(4, minmax(260px, 1fr));gap:12px;align-items:start;">
            ${columnsHtml}
        </div>
    `;
}

function renderDecisionCockpitPanel(rows, dashboardPayload = null) {
    const box = document.getElementById('decision-cockpit-panel');
    if (!box) return;
    const list = Array.isArray(rows) ? rows : [];
    if (!list.length) {
        box.innerHTML = '<div class="fw-700"><i class="ri-compass-3-line"></i> 执行驾驶舱</div><div class="text-hint mt-8">暂无投递数据，先在岗位决策中添加候选并标记投递状态。</div>';
        return;
    }

    const tasks = buildTodayActions(list);
    const highCount = tasks.filter(t => t.level === 'high').length;
    const applied = list.filter(x => normalizeAppStatusKey(x.status) !== 'favorite');
    const interview = list.filter(x => normalizeAppStatusKey(x.status) === 'interview');
    const offer = list.filter(x => normalizeAppStatusKey(x.status) === 'offer');
    const now = new Date();
    const last7 = new Date(now);
    last7.setDate(last7.getDate() - 7);
    const recentApplied = applied.filter(x => {
        const dt = new Date(x.applied_at || x.updated_at || '');
        return !Number.isNaN(dt.getTime()) && dt.getTime() >= last7.getTime();
    }).length;
    const interviewRate = applied.length ? Math.round((interview.length / applied.length) * 100) : 0;
    const offerRate = interview.length ? Math.round((offer.length / interview.length) * 100) : 0;

    const cockpit = (dashboardPayload || {}).cockpit || {};
    const deliveryDecision = (dashboardPayload || {}).delivery_decision || {};
    const executionFeedback = (dashboardPayload || {}).execution_feedback || {};
    const executionMetrics = executionFeedback.metrics || {};
    let suggestion = deliveryDecision.suggestion || cockpit.suggestion || '保持主申优先投递，并在每次投递后 48 小时内完成首次跟进。';
    if (executionFeedback.suggestion) suggestion = executionFeedback.suggestion;
    const todayTasks = Number((cockpit || {}).today_tasks || tasks.length || 0);
    const todayHighCount = Number((cockpit || {}).high_priority_tasks || highCount || 0);
    const todayRecentApplied = Number((cockpit || {}).recent_applied || recentApplied || 0);
    const todayInterviewRate = Number(executionMetrics.interview_rate || (cockpit || {}).interview_rate || interviewRate || 0);
    const todayOfferRate = Number((cockpit || {}).offer_rate || offerRate || 0);
    const todayCompletionRate = Number(executionMetrics.completion_rate || 0);

    box.innerHTML = `
        <div class="flex-between">
            <div class="fw-700"><i class="ri-compass-3-line"></i> 执行驾驶舱（今日重点）</div>
            <span class="text-hint">把结果转成可执行动作</span>
        </div>
        <div class="decision-cockpit-grid">
            <div class="decision-cockpit-item">
                <div class="decision-cockpit-label">今日待办</div>
                <div class="decision-cockpit-value">${todayTasks}</div>
            </div>
            <div class="decision-cockpit-item">
                <div class="decision-cockpit-label">高优先任务</div>
                <div class="decision-cockpit-value">${todayHighCount}</div>
            </div>
            <div class="decision-cockpit-item">
                <div class="decision-cockpit-label">近7日投递</div>
                <div class="decision-cockpit-value">${todayRecentApplied}</div>
            </div>
            <div class="decision-cockpit-item">
                <div class="decision-cockpit-label">转化率（面试/Offer）</div>
                <div class="decision-cockpit-value">${todayInterviewRate}% / ${todayOfferRate}%</div>
            </div>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap; margin:10px 0 0;">
            <span class="tag" style="background:#eff6ff;color:#1d4ed8;">周计划完成率 ${todayCompletionRate}%</span>
            <span class="tag" style="background:#fff7ed;color:#9a3412;">逾期待跟进 ${Number(executionMetrics.overdue_tasks || 0)}</span>
        </div>
        <div class="decision-cockpit-suggest">${suggestion}</div>
        <div class="decision-cockpit-actions">
            <button class="btn btn-primary" onclick="scrollDecisionPanel('decision-todo-panel')"><i class="ri-checkbox-circle-line"></i> 处理今日待办</button>
            <button class="btn btn-default" onclick="autoBuildExecutionPool()"><i class="ri-magic-line"></i> 一键生成执行池</button>
            <button class="btn btn-default" onclick="autoOrganizeExecutionPool()"><i class="ri-stack-line"></i> 整理优先级</button>
            <button class="btn btn-default" onclick="scrollDecisionPanel('decision-priority-pool')"><i class="ri-medal-line"></i> 查看优先投递池</button>
            <button class="btn btn-default" onclick="switchTab('data')"><i class="ri-radar-line"></i> 回到岗位决策</button>
        </div>
    `;
}

async function loadAiAdviceForApplications(list) {
    const top = (list || []).slice(0, 6);
    const aiStatus = await getAiRuntimeStatus();
    const allowAi = !!(aiStatus && aiStatus.ai_available);
    if (allowAi) {
        for (const item of top) {
            const jobId = Number(item.job_id || 0);
            if (!jobId || aiAdviceCache[jobId]) continue;
            try {
                const r = await fetch(`/api/job/${jobId}/ai-advice`, { method: 'POST' });
                const d = await r.json();
                if (d.success && d.advice) {
                    aiAdviceCache[jobId] = String(d.advice).slice(0, 80);
                }
            } catch (e) {
                // 忽略系统增强接口异常，使用本地建议兜底
            }
        }
    }
    const board = document.getElementById('application-board');
    if (board && appCacheRows.length) {
        const snapshot = [...appCacheRows];
        renderApplicationBoardColumns(board, snapshot);
    }
}

function getFallbackAiAdvice(item) {
    const score = Number(item.match_score || 0);
    const key = normalizeAppStatusKey(item.status);
    if (key === 'offer') return '优先确认薪资结构与入职时间。';
    if (key === 'interview') return '优先准备项目复盘与技术问答。';
    if (score >= MATCH_SCORE_MAIN) return '优先跟进，突出项目成果与业务价值。';
    if (score >= MATCH_SCORE_SPRINT) return '建议补一项关键技能后继续跟进。';
    return '建议作为备选岗位，先补关键能力再推进。';
}

function getApplicationDecisionReason(item, key, score, followInfo) {
    if (key === 'offer') return '已进入最终阶段，重点核对薪资结构、入职时间与试用期条款。';
    if (key === 'interview') {
        return followInfo.overdue
            ? '面试阶段已到跟进节点，建议今天确认进度并准备下一轮材料。'
            : '面试阶段建议聚焦项目复盘与岗位高频问题。';
    }
    if (key === 'applied') {
        return followInfo.overdue
            ? '投递后已超过建议跟进窗口，建议尽快补一次跟进。'
            : '已投递待反馈，保持简历与项目亮点可快速发送。';
    }
    if (score >= MATCH_SCORE_MAIN) return '高匹配候选，建议优先进入投递或保持高频跟进。';
    if (score >= MATCH_SCORE_SPRINT) return '中等匹配候选，建议补齐1项短板后推进。';
    return '当前匹配偏弱，建议作为保底候选并先补核心能力。';
}

function renderApplicationCard(item) {
    const job = item.job || {};
    const jobId = Number(item.job_id || job.id || 0);
    const key = normalizeAppStatusKey(item.status);
    const score = Number(item.match_score || 0);
    const bucket = getApplicationBucket(item);
    const followInfo = computeNextFollowInfo(item.updated_at || item.applied_at);
    const nextDate = item.next_follow_date || followInfo.text;
    const salary = String(job.salary || job.salary_text || job.salary_range || '-');
    const elapsed = getApplicationElapsedHint(item, key);
    const followTag = (key === 'offer')
        ? '<span class="tag" style="background:#ecfdf5;color:#166534;">重点确认Offer条款</span>'
        : '<span class="tag" style="background:#eff6ff;color:#1d4ed8;">建议在提醒日前完成跟进</span>';
    const aiAdvice = aiAdviceCache[item.job_id] || getFallbackAiAdvice(item);
    const decisionReason = item.recommended_action || getApplicationDecisionReason(item, key, score, followInfo);
    const followOverdue = Boolean(item.follow_up_overdue || followInfo.overdue);
    const bucketButtons = ['主申', '冲刺', '保底'].map(name => {
        const active = bucket === name;
        return `<button class="btn ${active ? 'btn-primary' : 'btn-default'}" style="padding:6px 10px;min-height:auto;" onclick="classifyJobForDelivery(${jobId}, ${score}, '${name}')">${name}</button>`;
    }).join('');
    const nextStatusMap = { applied: 'interview', interview: 'offer' };
    const primaryAction = key === 'favorite'
        ? `<button class="btn btn-primary" onclick="markJobAppliedById(${jobId}, ${score})"><i class="ri-send-plane-line"></i> 今天投递</button>`
        : ((key === 'applied' || key === 'interview') && followOverdue
            ? `<button class="btn btn-primary" onclick="markApplicationFollowed(${item.id})"><i class="ri-check-line"></i> 记录已跟进</button>`
            : (nextStatusMap[key]
                ? `<button class="btn btn-default" onclick="updateApplicationStatus(${item.id}, '${nextStatusMap[key]}')"><i class="ri-refresh-line"></i> 推进到下一阶段</button>`
                : `<button class="btn btn-default" onclick="markApplicationFollowed(${item.id})"><i class="ri-time-line"></i> 更新进展记录</button>`));
    const inspectAction = jobId
        ? `<button class="btn btn-default" onclick="evaluateJobFromList(${jobId})"><i class="ri-radar-line"></i> 查看岗位决策</button>`
        : '';
    return `
        <div style="border:1px solid #dbe6f4;border-radius:14px;padding:12px;background:linear-gradient(180deg,#ffffff 0%,#f8fbff 100%);box-shadow:0 14px 30px rgba(148,163,184,.10);">
            <div style="display:flex;justify-content:space-between;gap:8px;">
                <div style="font-weight:700;font-size:13px;line-height:1.5;">${job.job_name || '未知岗位'}</div>
                <div style="display:flex;align-items:center;gap:6px;">
                    <span style="font-size:11px;color:#64748b;">更新状态</span>
                    <select class="select" style="width:110px;height:30px;padding:2px 8px;" onchange="updateApplicationStatus(${item.id}, this.value)">
                        ${APP_STATUS_COLUMNS.map(x => `<option value="${x.key}" ${x.key === key ? 'selected' : ''}>${x.label}</option>`).join('')}
                    </select>
                </div>
            </div>
            <div style="margin-top:4px;font-size:12px;color:#64748b;">${job.company || '-'} · ${job.city || '-'}</div>
            <div style="margin-top:4px;font-size:12px;color:#334155;">薪资：<b>${salary}</b></div>
            <div style="margin-top:6px;font-size:12px;">匹配度：<b>${score}</b> | 分层：<b>${bucket}</b> | 下次跟进：<b>${nextDate}</b>${followOverdue ? ' <span style="color:#b45309;">（已逾期）</span>' : ''}</div>
            <div style="margin-top:6px;">${followTag}</div>
            <div style="margin-top:8px;padding:8px 10px;border-radius:10px;background:#f8fafc;font-size:12px;color:#334155;"><i class="ri-lightbulb-line"></i> ${decisionReason}</div>
            <div style="margin-top:6px;font-size:12px;color:#334155;"><i class="ri-robot-2-line"></i> ${aiAdvice}</div>
            <div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:8px;">
                ${primaryAction}
                ${inspectAction}
            </div>
            <div style="margin-top:10px;padding-top:10px;border-top:1px dashed #dbe6f4;">
                <div style="font-size:11px;color:#64748b;margin-bottom:6px;">快速调整执行分层</div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">${bucketButtons}</div>
            </div>
            <div style="margin-top:10px;display:inline-flex;align-items:center;border:1px solid #e2e8f0;border-radius:999px;padding:2px 8px;font-size:11px;color:#475569;background:#f8fafc;">${elapsed}</div>
        </div>
    `;
}

function getCurrentWeekAnchor() {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    const weekDay = (d.getDay() + 6) % 7; // 周一=0
    d.setDate(d.getDate() - weekDay);
    return d;
}

function getWeeklyPlanStorageKey() {
    const anchor = getCurrentWeekAnchor();
    const y = anchor.getFullYear();
    const m = String(anchor.getMonth() + 1).padStart(2, '0');
    const d = String(anchor.getDate()).padStart(2, '0');
    return `${WEEKLY_PLAN_STORAGE_PREFIX}${y}${m}${d}`;
}

function loadWeeklyPlanChecks() {
    const map = (latestWeeklyPlanMeta && latestWeeklyPlanMeta.completed_map) || {};
    if (map && typeof map === 'object' && Object.keys(map).length) return map;
    try {
        const raw = localStorage.getItem(getWeeklyPlanStorageKey());
        const parsed = raw ? JSON.parse(raw) : {};
        return (parsed && typeof parsed === 'object') ? parsed : {};
    } catch (e) {
        return {};
    }
}

function saveWeeklyPlanChecks(map) {
    latestWeeklyPlanMeta = {
        ...(latestWeeklyPlanMeta || {}),
        completed_map: (map && typeof map === 'object') ? map : {}
    };
    try {
        localStorage.setItem(getWeeklyPlanStorageKey(), JSON.stringify(map || {}));
    } catch (e) {
        console.warn('保存周计划状态失败', e);
    }
}

function computeNextFollowInfo(last) {
    const base = last ? new Date(last) : new Date();
    const safe = Number.isNaN(base.getTime()) ? new Date() : base;
    safe.setHours(0, 0, 0, 0);
    const next = new Date(safe);
    next.setDate(next.getDate() + 3);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
        date: next,
        text: `${next.getMonth() + 1}/${next.getDate()}`,
        overdue: next.getTime() < today.getTime()
    };
}

function computeNextFollowDate(last) {
    return computeNextFollowInfo(last).text;
}

function getApplicationElapsedHint(item, key) {
    const now = Date.now();
    const ts = new Date(
        (key === 'favorite')
            ? (item.updated_at || item.applied_at || Date.now())
            : (item.applied_at || item.updated_at || Date.now())
    ).getTime();
    if (Number.isNaN(ts)) return key === 'favorite' ? '距上次更新 -- 天' : '投递后 -- 天';
    const days = Math.max(0, Math.floor((now - ts) / (24 * 3600 * 1000)));
    if (key === 'favorite') return `距上次更新 ${days} 天`;
    return `投递后 ${days} 天`;
}

function formatYmd(date) {
    const d = date instanceof Date ? date : new Date(date || Date.now());
    if (Number.isNaN(d.getTime())) return '';
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
}

function getApplicationBucket(item) {
    if (item && item.bucket) return String(item.bucket);
    const notes = String((item && item.notes) || '');
    if (notes.includes('[主申候选]')) return '主申';
    if (notes.includes('[冲刺候选]')) return '冲刺';
    if (notes.includes('[保底候选]')) return '保底';
    const score = Number((item && item.match_score) || 0);
    if (score >= MATCH_SCORE_MAIN) return '主申';
    if (score >= MATCH_SCORE_SPRINT) return '冲刺';
    return '保底';
}

function buildTodayActions(rows) {
    const deferMap = loadTodayTodoDeferMap();
    const tasks = [];
    const sorted = [...(rows || [])].sort((a, b) => Number(b.match_score || 0) - Number(a.match_score || 0));
    sorted.forEach(item => {
        const job = item.job || {};
        const key = normalizeAppStatusKey(item.status);
        const score = Number(item.match_score || 0);
        const follow = computeNextFollowInfo(item.updated_at || item.applied_at);
        const title = `${job.job_name || '未知岗位'} · ${job.company || '-'}`;
        if (key === 'applied' && (follow.overdue || item.follow_up_overdue)) {
            tasks.push({
                type: 'follow',
                level: 'high',
                appId: item.id,
                jobId: item.job_id,
                title,
                desc: `已投递超过 3 天未跟进（匹配分 ${score}）`,
                actionText: '完成跟进'
            });
        }
        if (key === 'interview' && (follow.overdue || item.follow_up_overdue)) {
            tasks.push({
                type: 'follow',
                level: 'high',
                appId: item.id,
                jobId: item.job_id,
                title,
                desc: '面试阶段超时未更新，建议今天完成面试准备与确认',
                actionText: '完成跟进'
            });
        }
        if (key === 'favorite' && (score >= MATCH_SCORE_MAIN || String(item.priority || '').toLowerCase() === 'high')) {
            tasks.push({
                type: 'apply',
                level: 'mid',
                appId: item.id,
                jobId: item.job_id,
                title,
                desc: `高匹配候选仍未投递（匹配分 ${score}）`,
                actionText: '标记已投递'
            });
        }
    });
    return tasks
        .filter(t => !deferMap[`${t.type}_${t.appId || t.jobId}`])
        .slice(0, 6);
}

function getTodayTodoStorageKey() {
    return `job_todo_defer_${formatYmd(new Date())}`;
}

function loadTodayTodoDeferMap() {
    try {
        const raw = localStorage.getItem(getTodayTodoStorageKey());
        const parsed = raw ? JSON.parse(raw) : {};
        return (parsed && typeof parsed === 'object') ? parsed : {};
    } catch (e) {
        return {};
    }
}

function saveTodayTodoDeferMap(map) {
    try {
        localStorage.setItem(getTodayTodoStorageKey(), JSON.stringify(map || {}));
    } catch (e) {
        console.warn('保存今日待办状态失败', e);
    }
}

function deferTodayAction(taskKey) {
    if (!taskKey) return;
    const map = loadTodayTodoDeferMap();
    map[taskKey] = true;
    saveTodayTodoDeferMap(map);
    renderDecisionTodoPanel((Array.isArray(appAllRows) && appAllRows.length) ? appAllRows : appCacheRows, latestApplicationDashboard);
}

async function markApplicationFollowed(appId) {
    try {
        const hit = (appAllRows || []).find(x => Number(x.id) === Number(appId));
        const oldNotes = String((hit && hit.notes) || '').trim();
        const tag = `[已跟进 ${formatYmd(new Date())}]`;
        const notes = oldNotes ? (oldNotes.includes(tag) ? oldNotes : `${tag} ${oldNotes}`) : tag;
        const r = await fetch(`/api/applications/${appId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ notes })
        });
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '更新失败');
        showToast('已记录跟进行为');
        loadApplicationBoard();
    } catch (e) {
        showToast('记录跟进失败', 'error');
    }
}

function renderDecisionTodoPanel(rows, dashboardPayload = null) {
    const box = document.getElementById('decision-todo-panel');
    if (!box) return;
    const deferMap = loadTodayTodoDeferMap();
    const backendTodos = Array.isArray((dashboardPayload || {}).todos) ? dashboardPayload.todos : [];
    const tasks = backendTodos.length
        ? backendTodos.map(t => ({
            type: String((t.status || '')).toLowerCase().includes('投递') ? 'follow' : (String(t.title || '').includes('投递') ? 'apply' : 'follow'),
            level: t.level || 'medium',
            appId: t.id,
            jobId: t.job_id || 0,
            title: t.title || '处理待办',
            desc: t.desc || '',
            actionText: String(t.title || '').includes('投递') ? '标记已投递' : '完成跟进'
        }))
        : buildTodayActions(rows);
    const visibleTasks = tasks.filter(t => !deferMap[`${t.type}_${t.appId || t.jobId}`]);
    if (!visibleTasks.length) {
        box.innerHTML = `
            <div class="flex-between" style="margin-bottom:8px;">
                <div class="fw-700"><i class="ri-calendar-check-line"></i> 今日行动清单</div>
                <span class="badge" style="background:#ecfdf5; border-color:#86efac; color:#166534;">0 条待办</span>
            </div>
            <div class="text-hint">今天暂无高优先动作，建议回到岗位决策新增候选，或在看板保持状态更新。</div>
        `;
        return;
    }
    const highCount = visibleTasks.filter(t => t.level === 'high').length;
    box.innerHTML = `
        <div class="flex-between" style="margin-bottom:10px;">
            <div class="fw-700"><i class="ri-calendar-check-line"></i> 今日行动清单</div>
            <span class="badge" style="background:${highCount ? '#fef2f2' : '#ecfdf5'}; border-color:${highCount ? '#fecaca' : '#86efac'}; color:${highCount ? '#991b1b' : '#166534'};">
                ${visibleTasks.length} 条待办 · 高优先 ${highCount}
            </span>
        </div>
        <div style="margin-bottom:8px; font-size:12px; color:#64748b;">红色任务建议今天优先完成；黄色任务可在今天内安排处理。</div>
        <div style="display:grid; gap:8px;">
            ${visibleTasks.map(t => `
                <div style="border:1px solid #e2e8f0; border-radius:10px; padding:10px; background:#fff;">
                    <div class="flex-between" style="gap:8px;">
                        <div style="font-weight:700; font-size:13px;">${t.title}</div>
                        <span class="badge" style="background:${t.level === 'high' ? '#fef2f2' : '#fffbeb'}; border-color:${t.level === 'high' ? '#fecaca' : '#fcd34d'}; color:${t.level === 'high' ? '#991b1b' : '#92400e'};">
                            ${t.level === 'high' ? '高优先' : '中优先'}
                        </span>
                    </div>
                    <div style="margin-top:4px; font-size:12px; color:#475569;">${t.desc}</div>
                    <div style="margin-top:8px; display:flex; gap:8px; flex-wrap:wrap;">
                        ${t.type === 'follow'
            ? `<button class="btn btn-primary" onclick="markApplicationFollowed(${t.appId})"><i class="ri-check-line"></i> ${t.actionText}</button>`
            : `<button class="btn btn-primary" onclick="markJobAppliedById(${t.jobId}, 0)"><i class="ri-send-plane-line"></i> ${t.actionText}</button>`
        }
                        <button class="btn btn-default" onclick="deferTodayAction('${t.type}_${t.appId || t.jobId}')"><i class="ri-time-line"></i> 稍后处理</button>
                        <button class="btn btn-default" onclick="switchTab('applications')"><i class="ri-kanban-view-2-line"></i> 查看看板</button>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

function renderPriorityPool(rows, dashboardPayload = null) {
    const box = document.getElementById('decision-priority-pool');
    if (!box) return;
    const backendPools = (dashboardPayload || {}).priority_pool || null;
    const actionable = (rows || []).filter(x => {
        const key = normalizeAppStatusKey(x.status);
        return key === 'favorite' || key === 'applied' || key === 'interview';
    });
    const pools = backendPools && typeof backendPools === 'object'
        ? { 主申: backendPools.主申 || [], 冲刺: backendPools.冲刺 || [], 保底: backendPools.保底 || [] }
        : (() => {
            const result = { 主申: [], 冲刺: [], 保底: [] };
            actionable.forEach(item => {
                result[getApplicationBucket(item)].push(item);
            });
            return result;
        })();
    const renderPoolCard = (label, list) => {
        const top = [...list].sort((a, b) => Number(b.match_score || 0) - Number(a.match_score || 0)).slice(0, 6);
        const tone = label.includes('主申')
            ? { bg: '#eff6ff', bd: '#bfdbfe', tx: '#1d4ed8', hint: '优先投递，主力岗位' }
            : (label.includes('冲刺')
                ? { bg: '#fffbeb', bd: '#fde68a', tx: '#92400e', hint: '控制数量，重点突破' }
                : { bg: '#f8fafc', bd: '#e2e8f0', tx: '#475569', hint: '保留底线，避免断档' });
        return `
            <div class="card" style="padding:10px; min-width:260px; border:1px solid ${tone.bd}; background:${tone.bg};">
                <div class="flex-between" style="margin-bottom:4px;">
                    <div style="font-weight:700; color:${tone.tx};">${label}</div>
                    <span class="badge">${top.length}</span>
                </div>
                <div style="font-size:12px; color:${tone.tx}; margin-bottom:8px;">${tone.hint}</div>
                <div style="display:grid; gap:8px;">
                    ${top.length ? top.map(item => {
            const job = item.job || {};
            const key = normalizeAppStatusKey(item.status);
            const follow = computeNextFollowInfo(item.updated_at || item.applied_at);
            const statusText = (APP_STATUS_COLUMNS.find(x => x.key === key) || {}).label || key;
            return `
                            <div style="border:1px solid #e2e8f0; border-radius:8px; padding:8px;">
                                <div style="font-size:13px; font-weight:700;">${job.job_name || '未知岗位'}</div>
                                <div style="font-size:12px; color:#64748b;">${job.company || '-'} · ${job.city || '-'}</div>
                                <div style="margin-top:4px; font-size:12px;">匹配分 <b>${Number(item.match_score || 0)}</b> ｜ 状态 <b>${statusText}</b></div>
                                <div style="margin-top:4px; font-size:12px; color:${follow.overdue ? '#b45309' : '#475569'};">下次跟进：${follow.text}${follow.overdue ? '（已逾期）' : ''}</div>
                            </div>
                        `;
        }).join('') : '<div style="font-size:12px;color:#94a3b8;">暂无岗位</div>'}
                </div>
            </div>
        `;
    };
    box.innerHTML = `
        <div class="flex-between" style="margin-bottom:10px;">
            <div class="fw-700"><i class="ri-medal-line"></i> 优先投递池（主申 / 冲刺 / 保底）</div>
            <span class="text-hint">用于每日投递顺序与资源分配</span>
        </div>
        <div style="display:grid; grid-template-columns:repeat(3, minmax(260px, 1fr)); gap:10px; overflow-x:auto;">
            ${renderPoolCard('主申岗位', pools.主申)}
            ${renderPoolCard('冲刺岗位', pools.冲刺)}
            ${renderPoolCard('保底岗位', pools.保底)}
        </div>
    `;
}

function renderDecisionReviewPanel(rows, dashboardPayload = null) {
    const box = document.getElementById('decision-review-panel');
    if (!box) return;
    const list = Array.isArray(rows) ? rows : [];
    if (!list.length) {
        box.innerHTML = '<div class="fw-700"><i class="ri-line-chart-line"></i> 周转化复盘</div><div class="text-hint mt-8">暂无投递数据，先完成首批投递再进行复盘。</div>';
        return;
    }
    const now = new Date();
    const weekStart = new Date(now);
    const wd = (weekStart.getDay() + 6) % 7;
    weekStart.setDate(weekStart.getDate() - wd);
    weekStart.setHours(0, 0, 0, 0);
    const inWeek = (dt) => {
        const d = new Date(dt || '');
        return !Number.isNaN(d.getTime()) && d.getTime() >= weekStart.getTime();
    };
    const allApplied = list.filter(x => normalizeAppStatusKey(x.status) !== 'favorite');
    const allInterview = list.filter(x => normalizeAppStatusKey(x.status) === 'interview');
    const allOffer = list.filter(x => normalizeAppStatusKey(x.status) === 'offer');
    const weekApplied = allApplied.filter(x => inWeek(x.applied_at || x.updated_at));
    const weekInterview = allInterview.filter(x => inWeek(x.updated_at || x.applied_at));
    const weekOffer = allOffer.filter(x => inWeek(x.updated_at || x.applied_at));
    const bucketBase = list.filter(x => {
        const key = normalizeAppStatusKey(x.status);
        return key === 'favorite' || key === 'applied' || key === 'interview';
    });
    const bucketCount = { 主申: 0, 冲刺: 0, 保底: 0 };
    bucketBase.forEach(x => {
        const b = getApplicationBucket(x);
        if (bucketCount[b] !== undefined) bucketCount[b] += 1;
    });
    const weeklyReview = (dashboardPayload || {}).weekly_review || {};
    const executionFeedback = (dashboardPayload || {}).execution_feedback || {};
    const executionMetrics = executionFeedback.metrics || {};
    const bucketTotal = Math.max(1, bucketBase.length);
    const primaryRate = Number(weeklyReview.primary_rate || Math.round((bucketCount.主申 / bucketTotal) * 100));
    const sprintRate = Number(weeklyReview.sprint_rate || Math.round((bucketCount.冲刺 / bucketTotal) * 100));
    const backupRate = Number(weeklyReview.backup_rate || Math.round((bucketCount.保底 / bucketTotal) * 100));

    const interviewRate = weekApplied.length ? Math.round((weekInterview.length / weekApplied.length) * 100) : 0;
    const offerRate = weekInterview.length ? Math.round((weekOffer.length / weekInterview.length) * 100) : 0;
    const interviewGap = interviewRate - APP_MARKET_BASELINE.interviewRate;
    const offerGap = offerRate - APP_MARKET_BASELINE.offerRate;

    let conclusion = weeklyReview.conclusion || '本周投递节奏稳定，建议继续执行当前策略';
    let reason = `本周投递 ${weekApplied.length}，面试 ${weekInterview.length}，Offer ${weekOffer.length}。`;
    let suggestion = weeklyReview.suggestion || '保持主申岗位优先，确保每次投递后 48 小时内完成首次跟进。';
    let toneBg = '#ecfdf5';
    let toneBd = '#86efac';
    let toneTx = '#166534';
    if (weekApplied.length === 0) {
        conclusion = '本周尚未形成有效投递，先完成首批投递动作';
        reason = '当前周内无已投递记录，无法计算转化率。';
        suggestion = '从主申岗位中先投递 2-3 个，并在看板中记录状态更新。';
        toneBg = '#fffbeb'; toneBd = '#fcd34d'; toneTx = '#92400e';
    } else if (interviewRate < 20) {
        conclusion = '投递量有了，但面试转化偏低';
        reason = `本周投递 ${weekApplied.length}，仅转化面试 ${weekInterview.length}（面试率 ${interviewRate}%）。`;
        suggestion = '提高主申岗位占比，投递前强化简历项目成果与关键词匹配。';
        toneBg = '#fef2f2'; toneBd = '#fecaca'; toneTx = '#991b1b';
    } else if (weekInterview.length > 0 && offerRate < 30) {
        conclusion = '面试推进中，Offer转化仍有提升空间';
        reason = `本周面试 ${weekInterview.length}，Offer ${weekOffer.length}（Offer率 ${offerRate}%）。`;
        suggestion = '加强面试复盘与岗位对齐，优先推进已进入面试的高匹配岗位。';
        toneBg = '#fffbeb'; toneBd = '#fcd34d'; toneTx = '#92400e';
    }

    let biasLevel = '正常';
    let biasText = '当前主申/冲刺/保底结构相对均衡，可继续按当前节奏执行。';
    let biasBg = '#ecfdf5';
    let biasBd = '#86efac';
    let biasTx = '#166534';
    if (primaryRate < 40) {
        biasLevel = '偏差';
        biasText = `主申占比仅 ${primaryRate}%，偏低。建议提升到 50%-65%，减少低转化投递。`;
        biasBg = '#fef2f2'; biasBd = '#fecaca'; biasTx = '#991b1b';
    } else if (sprintRate > 40) {
        biasLevel = '偏差';
        biasText = `冲刺占比 ${sprintRate}%，偏高。建议控制在 20%-35%，避免分散精力。`;
        biasBg = '#fffbeb'; biasBd = '#fcd34d'; biasTx = '#92400e';
    } else if (backupRate > 35) {
        biasLevel = '偏差';
        biasText = `保底占比 ${backupRate}%，偏高。建议把更多精力转向主申岗位。`;
        biasBg = '#fffbeb'; biasBd = '#fcd34d'; biasTx = '#92400e';
    }

    const executionSummary = executionFeedback.conclusion ? `
        <div style="margin-top:10px; border:1px solid #e2e8f0; background:#f8fafc; border-radius:10px; padding:10px; font-size:13px; line-height:1.8;">
            <b>执行反馈：</b>${executionFeedback.conclusion}<br>
            <b>原因：</b>${executionFeedback.reason || '--'}<br>
            <b>下一步：</b>${executionFeedback.next_focus || executionFeedback.suggestion || '--'}
        </div>
    ` : '';
    box.innerHTML = `
        <div class="flex-between" style="margin-bottom:10px;">
            <div class="fw-700"><i class="ri-line-chart-line"></i> 周转化复盘</div>
            <span class="text-hint">统计窗口：本周</span>
        </div>
        <div style="display:grid; grid-template-columns:repeat(4, minmax(120px, 1fr)); gap:8px; margin-bottom:10px;">
            <div style="border:1px solid #e2e8f0;border-radius:10px;padding:10px;background:#fff;"><div class="text-hint">本周投递</div><div style="font-size:22px;font-weight:700;">${weekApplied.length}</div></div>
            <div style="border:1px solid #e2e8f0;border-radius:10px;padding:10px;background:#fff;"><div class="text-hint">本周面试</div><div style="font-size:22px;font-weight:700;">${weekInterview.length}</div></div>
            <div style="border:1px solid #e2e8f0;border-radius:10px;padding:10px;background:#fff;"><div class="text-hint">面试率</div><div style="font-size:22px;font-weight:700;">${interviewRate}%</div></div>
            <div style="border:1px solid #e2e8f0;border-radius:10px;padding:10px;background:#fff;"><div class="text-hint">Offer率</div><div style="font-size:22px;font-weight:700;">${offerRate}%</div></div>
        </div>
        <div style="display:grid; grid-template-columns:repeat(3, minmax(120px, 1fr)); gap:8px; margin-bottom:10px;">
            <div style="border:1px solid #dbeafe;border-radius:10px;padding:10px;background:#f8fbff;"><div class="text-hint">计划完成率</div><div style="font-size:18px;font-weight:700;color:#1d4ed8;">${Number(executionMetrics.completion_rate || 0)}%</div></div>
            <div style="border:1px solid #fcd34d;border-radius:10px;padding:10px;background:#fffbeb;"><div class="text-hint">主申执行率</div><div style="font-size:18px;font-weight:700;color:#92400e;">${Number(executionMetrics.main_execution_rate || 0)}%</div></div>
            <div style="border:1px solid #fecaca;border-radius:10px;padding:10px;background:#fff7f7;"><div class="text-hint">逾期待跟进</div><div style="font-size:18px;font-weight:700;color:#b91c1c;">${Number(executionMetrics.overdue_tasks || 0)}</div></div>
        </div>
        <div style="margin-bottom:10px; border:1px solid #e2e8f0; background:#fff; border-radius:10px; padding:10px; font-size:13px; color:#334155; line-height:1.8;">
            <b>市场基准对比：</b>
            面试率 ${interviewRate}%（基准 ${APP_MARKET_BASELINE.interviewRate}%，${interviewGap >= 0 ? `高 ${interviewGap}%` : `低 ${Math.abs(interviewGap)}%`}）；
            Offer率 ${offerRate}%（基准 ${APP_MARKET_BASELINE.offerRate}%，${offerGap >= 0 ? `高 ${offerGap}%` : `低 ${Math.abs(offerGap)}%`}）。
        </div>
        <div style="border:1px solid ${toneBd}; background:${toneBg}; color:${toneTx}; border-radius:10px; padding:10px; font-size:13px; line-height:1.8;">
            <b>结论：</b>${conclusion}<br>
            <b>建议：</b>${suggestion}
        </div>
        <div style="margin-top:10px; border:1px solid ${biasBd}; background:${biasBg}; color:${biasTx}; border-radius:10px; padding:10px; font-size:13px; line-height:1.8;">
            <b>结构提醒：</b>${biasText}
        </div>
        ${executionSummary}
    `;
}

function renderDecisionTimelinePanel(rows, dashboardPayload = null) {
    const box = document.getElementById('decision-timeline-panel');
    if (!box) return;
    const list = Array.isArray(rows) ? rows : [];
    const events = [];
    const backendTimeline = Array.isArray((dashboardPayload || {}).timeline) ? dashboardPayload.timeline : [];
    if (backendTimeline.length) {
        backendTimeline.forEach(item => {
            const ts = new Date(item.time || Date.now());
            if (Number.isNaN(ts.getTime())) return;
            const dateText = `${ts.getMonth() + 1}/${ts.getDate()} ${String(ts.getHours()).padStart(2, '0')}:${String(ts.getMinutes()).padStart(2, '0')}`;
            events.push({
                ts: ts.getTime(),
                tone: normalizeAppStatusKey(item.status),
                title: item.title || '状态更新',
                dateText,
                desc: item.company ? `${item.title || '岗位'} · ${item.company}` : (item.title || '状态更新')
            });
        });
    } else {
        list.forEach(item => {
            const job = item.job || {};
            const key = normalizeAppStatusKey(item.status);
            const ts = new Date(item.updated_at || item.applied_at || Date.now());
            if (Number.isNaN(ts.getTime())) return;
            const dateText = `${ts.getMonth() + 1}/${ts.getDate()} ${String(ts.getHours()).padStart(2, '0')}:${String(ts.getMinutes()).padStart(2, '0')}`;
            const titleMap = { offer: '收到 Offer', interview: '进入面试阶段', applied: '已投递', favorite: '加入候选池' };
            events.push({
                ts: ts.getTime(),
                tone: key,
                title: titleMap[key] || '状态更新',
                dateText,
                desc: `${job.job_name || '未知岗位'} · ${job.company || '-'}`
            });
            if (key === 'applied') {
                const baseTs = new Date(item.applied_at || item.updated_at || Date.now()).getTime();
                const passedDays = Number.isNaN(baseTs) ? 0 : Math.floor((Date.now() - baseTs) / (24 * 3600 * 1000));
                if (passedDays >= 5) {
                    const remindTs = baseTs + (5 * 24 * 3600 * 1000);
                    const remindDate = new Date(remindTs);
                    const remindDateText = `${remindDate.getMonth() + 1}/${remindDate.getDate()} ${String(remindDate.getHours()).padStart(2, '0')}:${String(remindDate.getMinutes()).padStart(2, '0')}`;
                    events.push({
                        ts: Date.now() - 1,
                        tone: 'alert',
                        title: '跟进提醒',
                        dateText: remindDateText,
                        desc: `${job.job_name || '该岗位'} 已投递超 ${passedDays} 天无回音，建议今天发送一次跟进邮件。`
                    });
                }
            }
        });
    }
    try {
        const extraRaw = localStorage.getItem(PROFILE_TIMELINE_KEY) || '[]';
        const extra = JSON.parse(extraRaw);
        if (Array.isArray(extra)) {
            extra.forEach(ev => {
                const ts = Number(ev.ts || 0);
                if (!ts) return;
                const dt = new Date(ts);
                const dateText = `${dt.getMonth() + 1}/${dt.getDate()} ${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
                events.push({
                    ts,
                    tone: String(ev.tone || 'favorite'),
                    title: String(ev.title || '学习事件'),
                    dateText,
                    desc: String(ev.desc || '')
                });
            });
        }
    } catch (_) { }
    if (!events.length) {
        box.innerHTML = '<div class="fw-700"><i class="ri-time-line"></i> 关键事件时间线</div><div class="text-hint mt-8">暂无投递记录，先在岗位决策中将岗位加入看板并标记状态。</div>';
        return;
    }
    events.sort((a, b) => b.ts - a.ts);
    const toneMap = {
        offer: { dot: '#16a34a', bg: '#ecfdf5', fg: '#166534' },
        interview: { dot: '#2563eb', bg: '#eff6ff', fg: '#1d4ed8' },
        applied: { dot: '#d97706', bg: '#fffbeb', fg: '#92400e' },
        favorite: { dot: '#7c3aed', bg: '#f5f3ff', fg: '#6d28d9' },
        alert: { dot: '#ef4444', bg: '#fef2f2', fg: '#991b1b' }
    };
    box.innerHTML = `
        <div class="flex-between" style="margin-bottom:10px;">
            <div class="fw-700"><i class="ri-time-line"></i> 关键事件时间线</div>
            <span class="text-hint">最近 ${Math.min(12, events.length)} 条</span>
        </div>
        <div class="decision-timeline-list">
            ${events.slice(0, 12).map(ev => {
        const tone = toneMap[ev.tone] || toneMap.favorite;
        return `
                    <div class="decision-timeline-item">
                        <div class="decision-timeline-dot" style="background:${tone.dot};"></div>
                        <div class="decision-timeline-main">
                            <div class="decision-timeline-head">
                                <span class="decision-timeline-title">${ev.title}</span>
                                <span class="decision-timeline-time">${ev.dateText}</span>
                            </div>
                            <div class="decision-timeline-desc" style="background:${tone.bg}; color:${tone.fg};">${ev.desc}</div>
                        </div>
                    </div>
                `;
    }).join('')}
        </div>
    `;
}

async function toggleWeeklyPlanTask(taskId) {
    if (!taskId) return;
    const checks = { ...loadWeeklyPlanChecks() };
    const nextVal = !checks[taskId];
    checks[taskId] = nextVal;
    saveWeeklyPlanChecks(checks);
    generateWeeklyPlan(latestApplicationDashboard);
    try {
        const weekKey = (latestWeeklyPlanMeta && latestWeeklyPlanMeta.week_key) || getWeeklyPlanStorageKey().replace(WEEKLY_PLAN_STORAGE_PREFIX, '');
        const r = await fetch('/api/applications/weekly-plan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ task_id: taskId, completed: nextVal, week_key: weekKey })
        });
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '保存失败');
        latestWeeklyPlanMeta = {
            ...(latestWeeklyPlanMeta || {}),
            week_key: weekKey,
            completed_map: checks
        };
        if (latestApplicationDashboard && latestApplicationDashboard.weekly_plan) {
            latestApplicationDashboard.weekly_plan.completed_map = checks;
        }
    } catch (e) {
        showToast('周计划状态保存失败', 'error');
    }
}

function normalizeTextForMatch(text) {
    return String(text || '')
        .toLowerCase()
        .replace(/\s+/g, '')
        .replace(/[【】\[\]（）()\-·,.，。\/\\|]/g, '');
}

function findJobForImport(jobs, jobName, company) {
    const targetJob = normalizeTextForMatch(jobName);
    const targetCompany = normalizeTextForMatch(company);
    if (!targetJob) return null;
    const best = jobs.find(j => {
        const jn = normalizeTextForMatch(j.job_name || '');
        const cp = normalizeTextForMatch(j.company || '');
        if (!jn) return false;
        if (targetCompany) {
            return (jn.includes(targetJob) || targetJob.includes(jn)) && (cp.includes(targetCompany) || targetCompany.includes(cp));
        }
        return jn.includes(targetJob) || targetJob.includes(jn);
    });
    if (best) return best;
    return jobs.find(j => normalizeTextForMatch(j.job_name || '').includes(targetJob)) || null;
}

async function updateApplicationStatus(appId, statusKey) {
    try {
        const r = await fetch(`/api/applications/${appId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: statusKeyToApiValue(statusKey) })
        });
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '更新失败');
        showToast('状态已更新');
        loadApplicationBoard();
        if (statusKey === 'interview' || statusKey === 'offer') setJobFlowStep(Math.max(getJobFlowStep(), 4));
    } catch (e) {
        showToast('状态更新失败', 'error');
    }
}

async function loadDeliveryDecisionPanel(dashboardPayload = null) {
    const box = document.getElementById('delivery-decision-panel');
    if (!box) return;
    const baseRows = Array.isArray(appAllRows) && appAllRows.length ? appAllRows : appCacheRows;
    if (!baseRows.length) {
        const recList = Array.isArray(window.currentAiData) ? window.currentAiData : [];
        if (recList.length > 0) {
            const top = recList
                .filter(x => Number(x.score || 0) > 0)
                .sort((a, b) => Number(b.score || 0) - Number(a.score || 0))
                .slice(0, 3);
            box.innerHTML = `
                <div class="fw-700"><i class="ri-compass-discover-line"></i> 投递执行建议</div>
                <div style="margin-top:8px; font-size:13px; color:#334155; line-height:1.75;">
                    当前暂无看板记录，建议先把推荐结果中的高分岗位加入候选池，再执行主申/冲刺分层投递。
                </div>
                <div style="margin-top:8px; font-size:12px; color:#475569;">
                    优先候选：${top.map(x => x.job_name).filter(Boolean).join('、') || '推荐结果 Top3'}
                </div>
                <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap;">
                    <button class="btn btn-primary" onclick="autoBuildExecutionPool()"><i class="ri-magic-line"></i> 一键生成执行池</button>
                    <button class="btn btn-default" onclick="switchTab('ai')"><i class="ri-focus-3-line"></i> 回到推荐计划</button>
                </div>
            `;
        } else {
            box.innerHTML = '暂无投递记录，先在岗位决策或详情页标记“已投递”。';
        }
        generateWeeklyPlan();
        return;
    }
    const actionable = baseRows.filter(x => {
        const key = normalizeAppStatusKey(x.status);
        return key === 'favorite' || key === 'applied';
    });
    const adv = (dashboardPayload && dashboardPayload.delivery_decision)
        ? dashboardPayload.delivery_decision
        : buildDeliveryRuleAdvice(baseRows, actionable);
    const toneMap = {
        good: { bg: '#ecfdf5', bd: '#86efac', tx: '#166534' },
        mid: { bg: '#fffbeb', bd: '#fcd34d', tx: '#92400e' },
        risk: { bg: '#fef2f2', bd: '#fecaca', tx: '#991b1b' }
    };
    const tone = toneMap[adv.tone] || toneMap.mid;
    const focusJobs = Array.isArray(adv.focus_jobs) ? adv.focus_jobs : [];
    const structure = adv.structure || {};
    const focusHtml = focusJobs.length
        ? `<div style="margin-top:8px; font-size:12px; color:#475569; line-height:1.7;"><b>今日优先：</b>${focusJobs.map(x => `${x.job_name}（${x.bucket}）`).join('、')}</div>`
        : '';
    box.innerHTML = `
        <div class="fw-700"><i class="ri-compass-discover-line"></i> 投递执行建议</div>
        <div style="margin-top:8px; border:1px solid ${tone.bd}; background:${tone.bg}; color:${tone.tx}; border-radius:10px; padding:10px; font-size:13px; line-height:1.7;">
            <b>结论：</b>${adv.conclusion}
        </div>
        <div style="margin-top:8px; font-size:12px; color:#475569; line-height:1.7;">
            <div><b>原因：</b>${adv.reason}</div>
            <div><b>动作：</b>${adv.suggestion}</div>
        </div>
        <div style="margin-top:8px; display:flex; gap:8px; flex-wrap:wrap;">
            <span class="tag" style="background:#eff6ff;color:#1d4ed8;">主申 ${Number(structure.primary || 0)}</span>
            <span class="tag" style="background:#fffbeb;color:#92400e;">冲刺 ${Number(structure.sprint || 0)}</span>
            <span class="tag" style="background:#f8fafc;color:#475569;">保底 ${Number(structure.backup || 0)}</span>
        </div>
        ${focusHtml}
        <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap;">
            <button class="btn btn-primary" onclick="autoBuildExecutionPool()"><i class="ri-magic-line"></i> 一键补齐执行池</button>
            <button class="btn btn-default" onclick="autoOrganizeExecutionPool()"><i class="ri-stack-line"></i> 整理优先级</button>
            <button class="btn btn-default" onclick="generateWeeklyPlan()"><i class="ri-calendar-check-line"></i> 刷新周计划</button>
            <button class="btn btn-primary" onclick="switchTab('applications')"><i class="ri-send-plane-line"></i> 去投递看板执行</button>
        </div>
    `;
    generateWeeklyPlan();
    loadDeliveryAiAdvice();
}

async function classifyJobForDelivery(jobId, score = 0, bucket = '主申') {
    const safeBucket = ['主申', '冲刺', '保底'].includes(bucket) ? bucket : '主申';
    try {
        let appId = appIdByJobId[jobId];
        const noteTag = `[${safeBucket}候选]`;
        if (!appId) {
            const createPayload = {
                job_id: jobId,
                status: 'favorite',
                bucket: safeBucket,
                notes: noteTag
            };
            if (Number(score) > 0) createPayload.match_score = Number(score);
            const c = await fetch('/api/applications', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(createPayload)
            });
            const cd = await c.json();
            if (!cd.success) throw new Error(cd.msg || '创建失败');
            appId = ((cd.data || {}).id) || 0;
            if (appId) appIdByJobId[jobId] = appId;
        } else {
            const current = await fetch('/api/applications').then(x => x.json()).catch(() => ({ success: false }));
            let mergedNotes = noteTag;
            if (current.success) {
                const hit = (current.data || []).find(x => Number(x.job_id) === Number(jobId));
                const oldNotes = String((hit && hit.notes) || '').trim();
                mergedNotes = oldNotes ? (oldNotes.includes(noteTag) ? oldNotes : `${noteTag} ${oldNotes}`) : noteTag;
            }
            const updatePayload = {
                status: 'favorite',
                bucket: safeBucket,
                notes: mergedNotes
            };
            if (Number(score) > 0) updatePayload.match_score = Number(score);
            const u = await fetch(`/api/applications/${appId}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatePayload)
            });
            const ud = await u.json();
            if (!ud.success) throw new Error(ud.msg || '更新失败');
        }
        showToast(`已归类到${safeBucket}候选`);
        setJobFlowStep(Math.max(getJobFlowStep(), 2));
        loadApplicationBoard();
        hydrateDataRowActions();
    } catch (e) {
        showToast(`归类失败：${String((e && e.message) || '未知错误')}`, 'error');
    }
}

async function loadDeliveryAiAdvice() {
    const box = document.getElementById('delivery-ai-advice');
    if (!box) return;
    box.style.display = 'block';
    box.innerHTML = '<div class="card" style="padding:12px;">系统行动建议生成中...</div>';
    try {
        const res = await fetchJsonWithTimeout('/api/applications/ai-action', {}, 70000);
        const d = res.body || {};
        if (!d.success || !d.data) throw new Error(d.msg || '失败');
        box.innerHTML = renderAiStructCard('系统行动建议', d.data, 'good');
    } catch (e) {
        const baseRows = (Array.isArray(appAllRows) && appAllRows.length) ? appAllRows : appCacheRows;
        const actionable = (baseRows || []).filter(x => {
            const key = normalizeAppStatusKey(x.status);
            return key === 'favorite' || key === 'applied';
        });
        const fallback = (latestApplicationDashboard && latestApplicationDashboard.delivery_decision)
            ? latestApplicationDashboard.delivery_decision
            : buildDeliveryRuleAdvice(baseRows || [], actionable);
        box.innerHTML = renderAiStructCard('系统行动建议（规则兜底）', {
            conclusion: fallback.conclusion,
            reason: [fallback.reason],
            suggestion: [fallback.suggestion],
            risk: ['当前系统增强服务不可用，建议先按规则方案执行并持续更新看板状态。']
        }, fallback.tone === 'good' ? 'good' : 'mid');
    }
}

function generateWeeklyPlan(dashboardPayload = null) {
    const box = document.getElementById('weekly-plan-box');
    const progressEl = document.getElementById('weekly-plan-progress');
    if (!box) return;
    const dashboard = dashboardPayload || latestApplicationDashboard || {};
    const rows = (Array.isArray(appAllRows) && appAllRows.length) ? appAllRows : (Array.isArray(appCacheRows) ? appCacheRows : []);
    if (!rows.length) {
        box.innerHTML = '暂无投递记录，先在岗位决策页将岗位加入看板。';
        if (progressEl) progressEl.innerText = '完成率：-- ｜ 跟进提醒：--';
        return;
    }
    const actionable = rows.filter(x => {
        const key = normalizeAppStatusKey(x.status);
        return key === 'favorite' || key === 'applied';
    });
    if (!actionable.length) {
        box.innerHTML = '当前都在面试/Offer阶段，建议重点跟进沟通与复盘。';
        if (progressEl) progressEl.innerText = '完成率：100% ｜ 跟进提醒：暂无待办';
        return;
    }
    const backendWeeklyPlan = Array.isArray(((dashboard || {}).weekly_plan || {}).tasks)
        ? ((dashboard || {}).weekly_plan || {}).tasks
        : [];
    const backendWeeklyPlanMeta = ((dashboard || {}).weekly_plan) || {};
    const backendFocusJobs = Array.isArray(((dashboard || {}).delivery_decision || {}).focus_jobs)
        ? ((dashboard || {}).delivery_decision || {}).focus_jobs
        : [];
    let planTasks = [];
    if (backendWeeklyPlan.length) {
        planTasks = backendWeeklyPlan.map((task, idx) => {
            const matched = actionable.find(x => Number(x.job_id || 0) === Number(task.job_id || 0));
            return {
                role: task.role || '主申',
                item: matched
                    ? {
                        ...matched,
                        task_id: task.task_id || `${task.role || '主申'}-${task.job_id || idx}`,
                        completed: !!task.completed,
                        _weekly_action: task.action || '',
                        updated_at: matched.updated_at || task.follow_date || '',
                        applied_at: matched.applied_at || task.follow_date || '',
                    }
                    : {
                        id: task.task_id || idx,
                        task_id: task.task_id || `${task.role || '主申'}-${task.job_id || idx}`,
                        completed: !!task.completed,
                        job_id: task.job_id || 0,
                        updated_at: task.follow_date || '',
                        applied_at: task.follow_date || '',
                        job: {
                            job_name: task.title || '未知岗位',
                            company: task.company || '-'
                        },
                        _weekly_action: task.action || ''
                    }
            };
        });
    } else if (backendFocusJobs.length) {
        planTasks = backendFocusJobs.map((focus, idx) => {
            const matched = actionable.find(x => Number(x.job_id || 0) === Number(focus.job_id || 0));
            return {
                role: focus.bucket || '主申',
                item: matched
                    ? {
                        ...matched,
                        task_id: `${focus.bucket || '主申'}-${focus.id || focus.job_id || idx}`,
                    }
                    : {
                        id: focus.id || focus.job_id || idx,
                        task_id: `${focus.bucket || '主申'}-${focus.id || focus.job_id || idx}`,
                        job_id: focus.job_id || 0,
                        updated_at: '',
                        applied_at: '',
                        job: {
                            job_name: focus.job_name || '未知岗位',
                            company: focus.company || '-'
                        }
                    }
            };
        });
    } else {
        const sorted = [...actionable].sort((a, b) => Number(b.match_score || 0) - Number(a.match_score || 0));
        const main = sorted.slice(0, 3);
        const sprint = sorted.slice(3, 5);
        const backup = sorted.slice(5, 8);
        planTasks = [
            ...main.map(x => ({ role: '主申', item: x })),
            ...sprint.map(x => ({ role: '冲刺', item: x })),
            ...backup.map(x => ({ role: '保底', item: x }))
        ];
    }
    const checks = {
        ...(((backendWeeklyPlanMeta || {}).completed_map) || {}),
        ...loadWeeklyPlanChecks()
    };
    let doneCount = 0;
    let overdueCount = 0;
    const taskHtml = planTasks.map((task, idx) => {
        const item = task.item || {};
        const job = item.job || {};
        const taskId = String(item.task_id || `${task.role}-${item.id || idx}`);
        const checked = typeof item.completed === 'boolean' ? item.completed : !!checks[taskId];
        if (checked) doneCount += 1;
        const follow = computeNextFollowInfo(item.updated_at || item.applied_at);
        if (!checked && follow.overdue) overdueCount += 1;
        const overdueTag = (!checked && follow.overdue)
            ? '<span style="font-size:11px;color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;border-radius:999px;padding:1px 6px;">已逾期</span>'
            : '';
        return `
            <label style="display:flex;align-items:flex-start;gap:8px;padding:8px;border:1px solid #e2e8f0;border-radius:8px;background:#fff;">
                <input type="checkbox" ${checked ? 'checked' : ''} onchange="toggleWeeklyPlanTask('${taskId}')">
                <div style="font-size:12px;line-height:1.5;">
                    <div><b>${task.role}</b>：${job.job_name || '未知岗位'}</div>
                    <div style="color:#64748b;">${job.company || '-'} · 跟进截止 ${follow.text} ${overdueTag}</div>
                    ${item._weekly_action ? `<div style="color:#334155; margin-top:2px;">${item._weekly_action}</div>` : ''}
                </div>
            </label>
        `;
    }).join('');
    const total = planTasks.length;
    const backendProgress = (backendWeeklyPlanMeta || {}).progress || {};
    const rate = total > 0 ? Math.round((doneCount / total) * 100) : Number(backendProgress.completion_rate || 0);
    const reviewSuggestion = (((dashboard || {}).weekly_plan || {}).summary) || (((dashboard || {}).weekly_review || {}).suggestion) || '执行节奏：周一~周三完成主申投递，周四补冲刺，周五统一跟进状态。';
    box.innerHTML = `
        <div style="padding:10px; border:1px solid #e2e8f0; border-radius:10px; background:#f8fafc;">
            <div style="margin-bottom:8px; font-weight:700;">本周执行清单</div>
            <div style="display:grid; gap:8px;">${taskHtml}</div>
            <div style="font-size:12px; color:#64748b;">${reviewSuggestion}</div>
        </div>
    `;
    if (progressEl) {
        progressEl.innerText = `完成率：${rate}%（${doneCount}/${total}） ｜ 跟进提醒：${overdueCount > 0 ? `${overdueCount} 条逾期待跟进` : '暂无逾期'}`;
    }
}

async function loadApplicationTiming() {
    const box = document.getElementById('application-timing');
    if (!box) return;
    box.innerHTML = '分析中...';
    try {
        const r = await fetch('/api/applications/timing');
        const d = await r.json();
        if (!d.success) throw new Error(d.msg || '加载失败');
        const t = d.data || {};
        const best = (t.best_windows || []).slice(0, 2).map(x => x.window).join('、') || '暂无';
        const conv = t.conversion || {};
        const windows = (t.best_windows || []).slice(0, 2);
        const firstWin = windows[0] && windows[0].window ? windows[0].window : '周二至周四上午 10:00-12:00';
        const firstLift = windows[0] && Number.isFinite(Number(windows[0].lift))
            ? `${Number(windows[0].lift) >= 0 ? '+' : ''}${Math.round(Number(windows[0].lift))}%`
            : '+20%';
        const interviewRate = Number(conv.interview_rate || 0);
        const offerRate = Number(conv.offer_rate || 0);
        const timingConclusion = `根据历史数据，建议优先在 ${firstWin} 投递，预期回复率提升约 ${firstLift}。`;
        box.innerHTML = `<div style="font-weight:700;margin-bottom:8px;"><i class="ri-time-line"></i> 投递时机分析</div><div style="font-size:13px;line-height:1.7;">最佳时段：<b>${best}</b><br>投递->面试转化率：<b>${interviewRate}%</b>，投递->Offer转化率：<b>${offerRate}%</b></div><div style="margin-top:8px; font-size:12px; color:#1e3a8a; background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:8px 10px;">${timingConclusion}</div>`;
    } catch (e) {
        box.innerHTML = '<span style="color:#ef4444;">投递时机分析加载失败</span>';
    }
}

async function importApplicationRecords() {
    const fileInput = document.getElementById('app-import-file');
    const statusEl = document.getElementById('app-import-status');
    if (!fileInput || !fileInput.files || !fileInput.files[0]) return showToast('请先选择导入文件', 'error');
    const file = fileInput.files[0];
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (!['csv', 'txt'].includes(ext)) {
        return showToast('暂仅支持 CSV/TXT，请将 Excel 另存为 CSV 后导入', 'error');
    }
    let text = '';
    try {
        const buf = await file.arrayBuffer();
        try {
            text = new TextDecoder('utf-8', { fatal: true }).decode(buf);
        } catch (e) {
            text = new TextDecoder('gbk').decode(buf);
        }
    } catch (e) {
        text = await file.text();
    }
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (lines.length < 2) return showToast('文件内容为空', 'error');
    const splitLine = (line) => {
        const sep = line.includes('\t') ? '\t' : ',';
        return line.split(sep).map(s => s.trim().replace(/^"|"$/g, ''));
    };
    const header = splitLine(lines[0]);
    const idxJob = header.findIndex(h => /岗位|job/i.test(h));
    const idxCompany = header.findIndex(h => /公司|company/i.test(h));
    const idxStatus = header.findIndex(h => /状态|status/i.test(h));
    const idxScore = header.findIndex(h => /匹配|score/i.test(h));
    const idxNote = header.findIndex(h => /备注|note/i.test(h));
    const idxAppliedAt = header.findIndex(h => /投递日期|日期|applied_at|date/i.test(h));
    if (idxJob < 0) return showToast('缺少岗位名称字段', 'error');
    if (statusEl) statusEl.innerText = '正在匹配岗位并导入...';

    const jobs = [];
    const pageSize = 200;
    for (let page = 1; page <= 10; page++) {
        const search = await fetch('/api/data/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ page, page_size: pageSize, keyword: '' })
        });
        const sData = await search.json();
        const rows = sData.rows || [];
        jobs.push(...rows);
        if (rows.length < pageSize) break;
    }

    let ok = 0;
    let fail = 0;
    for (let i = 1; i < lines.length; i++) {
        const cols = splitLine(lines[i]);
        const jobName = (cols[idxJob] || '').trim();
        const company = idxCompany >= 0 ? (cols[idxCompany] || '').trim() : '';
        if (!jobName) continue;
        const found = findJobForImport(jobs, jobName, company);
        if (!found) { fail++; continue; }
        const rawStatus = idxStatus >= 0 ? (cols[idxStatus] || '').trim() : 'favorite';
        const statusKey = normalizeAppStatusKey(rawStatus);
        const scoreVal = idxScore >= 0 ? parseInt(cols[idxScore] || '0', 10) : 0;
        const noteVal = idxNote >= 0 ? String(cols[idxNote] || '').trim() : '';
        const appliedAtVal = idxAppliedAt >= 0 ? String(cols[idxAppliedAt] || '').trim() : '';
        try {
            const resp = await fetch('/api/applications', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    job_id: found.id,
                    status: statusKeyToApiValue(statusKey),
                    match_score: scoreVal || 0,
                    notes: noteVal,
                    applied_at: appliedAtVal
                })
            });
            const rd = await resp.json();
            if (rd.success) ok++; else fail++;
        } catch (e) {
            fail++;
        }
    }
    if (statusEl) statusEl.innerText = `导入完成：成功 ${ok}，失败 ${fail}`;
    showToast(`导入完成：成功 ${ok}，失败 ${fail}`);
    loadApplicationBoard();
    updateSummary();
}

function downloadAppImportTemplate() {
    const header = ['岗位名称', '公司名称', '状态', '匹配分', '备注', '投递日期'];
    const demo = ['Java开发工程师', '示例科技', '已投递', '78', '首轮投递', '2026-03-03'];
    const csv = [header.join(','), demo.join(',')].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '投递记录导入模板.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}

window.evaluateJobFromList = evaluateJobFromList;
window.quickMarkApplied = quickMarkApplied;
window.classifyJobForDelivery = classifyJobForDelivery;
window.autoBuildExecutionPool = autoBuildExecutionPool;
window.autoOrganizeExecutionPool = autoOrganizeExecutionPool;
window.evaluateTopJobs = evaluateTopJobs;
window.closeJobEvalModal = closeJobEvalModal;
window.markApplicationFollowed = markApplicationFollowed;
window.deferTodayAction = deferTodayAction;
