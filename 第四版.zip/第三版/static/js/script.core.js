﻿// =========================================================
// 1. 全局变量定义 (保留原样)
// =========================================================
let isRegister = false;
let charts = {};
let currentAiData = [];
// 品牌色板 (与 CSS 变量对应)
const BRAND_COLORS = [
    '#2563eb', // Blue
    '#7c3aed', // Purple
    '#059669', // Emerald
    '#d97706', // Amber
    '#db2777', // Pink
    '#0891b2', // Cyan
    '#4f46e5', // Indigo
    '#ea580c'  // Orange
];
const getBrandColor = (i) => BRAND_COLORS[i % BRAND_COLORS.length];
let cityDataCache = { labels: [], values: [] };
let currentCityChartType = 'bar';
let currSalaryType = 'rose';
let currEduType = 'bar';
let currentPage = 1;
let currentSortField = 'match';
let currentSortOrder = 'desc';

function changeSort(field) {
    currentSortField = field;
    if (typeof loadData === 'function') {
        loadData(1);
    }
}
let spiderTimer = null; // 新增爬虫定时器
let currentExportType = 'xlsx';
let lastDataTotal = 0;
const DATA_PAGE_SIZE = 10;
let jobEvalEvidenceChart = null;
let latestDataQualityScore = null;
const WEEKLY_PLAN_STORAGE_PREFIX = 'weekly_plan_checks_';
let latestCompetitivenessPayload = null;

console.log("Script.js loaded successfully");

document.addEventListener('DOMContentLoaded', function () {
    console.log("DOM Content Loaded");
    // Ensure handleAuth is available
    window.handleAuth = handleAuth;
    window.logout = handleLogout;
    window.toggleSidebar = toggleSidebar;
    window.closeSidebar = closeSidebar;

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeSidebar();
    });
    window.addEventListener('resize', () => {
        Object.values(charts).forEach(c => c && c.resize && c.resize());
        Object.values(dashCharts).forEach(c => c && c.resize && c.resize());
    });
    initRecommendWeightConfig();
});

// =========================================================
// 2. 通用工具函数 (保留原样)
// =========================================================
function animateValue(obj, start, end, duration) {
    if (!obj) return;
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        obj.innerHTML = (progress * (end - start) + start).toFixed(1);
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

function showToast(msg, type = 'success') {
    const c = document.getElementById('toast-container');
    const d = document.createElement('div');
    d.className = `toast ${type}`;
    d.innerHTML = `<span>${type === 'success' ? '✅' : '❌'}</span> ${msg}`;
    c.appendChild(d);
    setTimeout(() => {
        d.style.opacity = '0';
        setTimeout(() => d.remove(), 300)
    }, 3000);
}

function setButtonLoading(btn, loadingText = '处理中...') {
    if (!btn) return;
    if (!btn.dataset.originHtml) btn.dataset.originHtml = btn.innerHTML;
    btn.disabled = true;
    btn.classList.add('is-loading');
    btn.innerHTML = `<i class="ri-loader-4-line"></i> ${loadingText}`;
}

function clearButtonLoading(btn) {
    if (!btn) return;
    btn.disabled = false;
    btn.classList.remove('is-loading');
    if (btn.dataset.originHtml) btn.innerHTML = btn.dataset.originHtml;
}

const __dqCache = {
    ts: 0,
    data: null,
    pending: null
};

async function fetchDataQualityCached(force = false, ttlMs = 15000) {
    const now = Date.now();
    if (!force && __dqCache.data && (now - __dqCache.ts) < ttlMs) return __dqCache.data;
    if (!force && __dqCache.pending) return __dqCache.pending;

    __dqCache.pending = (async () => {
        const r = await fetch('/api/data/quality');
        const d = await r.json();
        if (!d || !d.success) throw new Error((d && d.msg) || 'quality failed');
        __dqCache.data = d;
        __dqCache.ts = Date.now();
        return d;
    })();

    try {
        return await __dqCache.pending;
    } finally {
        __dqCache.pending = null;
    }
}

function gotoTabById(id) {
    const menu = document.querySelector(`.menu-item[onclick*="${id}"]`);
    if (!menu) return;
    switchTab(id, menu);
}

async function refreshOverviewWorkbench(totalJobs = 0) {
    const healthEl = document.getElementById('overview-health-score');
    const priEl = document.getElementById('overview-priority');
    const actionEl = document.getElementById('overview-action-list');
    if (!healthEl || !priEl || !actionEl) return;

    if (!totalJobs || totalJobs <= 0) {
        healthEl.innerText = '--';
        priEl.innerText = '先导入或采集数据';
        actionEl.innerHTML = '建议：先在“数据采集”启动任务，或上传 CSV 文件补充岗位数据。';
        return;
    }

    try {
        const d = await fetchDataQualityCached(false);
        if (!d.success || !d.data) throw new Error('quality unavailable');

        const q = d.data;
        const penalty = (q.duplicate_rate || 0) * 0.35 + (q.abnormal_salary_rate || 0) * 0.35 + (q.missing_city_rate || 0) * 0.15 + (q.missing_company_rate || 0) * 0.15;
        const score = Math.max(0, Math.min(100, Math.round(100 - penalty)));

        healthEl.innerText = `${score}分`;
        healthEl.style.color = score >= 80 ? '#059669' : (score >= 60 ? '#d97706' : '#dc2626');

        let priority = '继续扩充数据样本';
        if ((q.duplicate_rate || 0) >= 10) priority = '优先去重，降低重复记录';
        else if ((q.abnormal_salary_rate || 0) >= 8) priority = '优先清洗异常薪资';
        else if ((q.missing_city_rate || 0) >= 12) priority = '优先补齐城市字段';
        priEl.innerText = priority;

        const acts = [];
        if ((q.valid_salary_rate || 0) < 70) acts.push('补充含薪资字段的数据源');
        if ((q.duplicate_rate || 0) > 10) acts.push('按岗位+公司+城市去重');
        if ((q.abnormal_salary_rate || 0) > 8) acts.push('按区间过滤异常薪资');
        if ((q.missing_city_rate || 0) > 12) acts.push('补齐城市字段，提升区域对比可靠性');
        if ((q.missing_company_rate || 0) > 12) acts.push('修复公司字段，提升来源可追溯性');
        const healthReasons = Array.isArray(q.health_reasons) ? q.health_reasons : [];
        if (healthReasons.length) {
            const reasonLines = healthReasons
                .slice(0, 2)
                .map(x => `${x.title || '质量项'}（${x.summary || '--'}）`)
                .join('；');
            acts.unshift(`诊断依据：${reasonLines}`);
        }
        if (acts.length === 0) acts.push('数据质量良好，建议直接进入推荐与投递决策');
        actionEl.innerHTML = acts.slice(0, 2).map(a => `• ${a}`).join('<br>');
    } catch (e) {
        healthEl.innerText = '--';
        priEl.innerText = '质量接口暂不可用';
        actionEl.innerHTML = '建议：先完成数据上传并刷新概览。';
    }
}

function __clampNum(v, min, max) {
    return Math.max(min, Math.min(max, v));
}

function __toNum(v, d = 0) {
    const n = Number(v);
    return Number.isFinite(n) ? n : d;
}

function __sampleToScore(sample) {
    const n = __toNum(sample, 0);
    if (n >= 1500) return 100;
    if (n >= 800) return 90;
    if (n >= 300) return 75;
    if (n >= 100) return 60;
    if (n >= 30) return 45;
    return 35;
}

function buildDecisionConfidence(ctx = {}) {
    const profileScore = __clampNum(__toNum(ctx.profileScore, 0), 0, 100);
    const dataQualityScore = __clampNum(__toNum(ctx.dataQualityScore, 55), 0, 100);
    const marketSample = __toNum(ctx.marketSample, 0);
    const sampleScore = __sampleToScore(marketSample);
    const score = Math.round(profileScore * 0.45 + dataQualityScore * 0.35 + sampleScore * 0.20);
    const level = score >= 75 ? '高' : (score >= 58 ? '中' : '低');
    const tone = score >= 75 ? 'good' : (score >= 58 ? 'mid' : 'risk');
    const reasons = [
        `画像完整度 ${profileScore} 分`,
        `数据质量 ${dataQualityScore} 分`,
        `样本规模 ${marketSample || 0} 条`
    ];
    return { score, level, tone, reasons };
}

function buildPersonalActionBrief(ctx = {}) {
    const profileScore = __toNum(ctx.profileScore, 0);
    const recCount = __toNum(ctx.recCount, 0);
    const shortlistCount = __toNum(ctx.shortlistCount, 0);
    const appliedCount = __toNum(ctx.appliedCount, 0);
    const interviewCount = __toNum(ctx.interviewCount, 0);
    const offerCount = __toNum(ctx.offerCount, 0);
    const topMissing = Array.isArray(ctx.topMissing) ? ctx.topMissing.filter(Boolean) : [];

    let conclusion = '先完成岗位评估，生成第一批候选岗位。';
    let reason = `当前高匹配岗位 ${recCount} 个，候选岗位 ${shortlistCount} 个，已投递 ${appliedCount} 个。`;
    let suggestion = '先从岗位评估筛选 Top3，再进入投递决策做状态跟进。';
    let primaryAction = 'data';
    let actions = [];

    if (profileScore < 60) {
        conclusion = '先完善画像，再进行投递动作。';
        reason = `画像完整度仅 ${profileScore} 分，评估与推荐可信度不足。`;
        suggestion = '优先补齐目标岗位、技能、经验、薪资区间，再开始岗位评估。';
        primaryAction = 'profile';
        actions = [
            { title: '补齐画像关键字段', desc: '至少补齐目标岗位、核心技能、经验和期望薪资。', priority: 'high', actionId: 'profile' },
            { title: '补齐高频缺失技能', desc: topMissing.length ? `建议先补：${topMissing.slice(0, 2).join('、')}。` : '先补 1-2 项岗位高频技能，提高匹配度。', priority: 'high', actionId: 'profile' },
            { title: '完成一次竞争力分析', desc: '生成“竞争力+技能差距”后再决定投递节奏。', priority: 'mid', actionId: 'compet' }
        ];
    } else if (recCount <= 0) {
        conclusion = '画像可用，但尚未形成可投岗位。';
        reason = '当前高匹配岗位为 0，关键词或筛选条件与市场不匹配。';
        suggestion = '先扩大岗位关键词与城市范围，再重新评估。';
        primaryAction = 'data';
        actions = [
            { title: '调整筛选条件并重评', desc: '先放宽城市/经验条件，重新执行岗位评估。', priority: 'high', actionId: 'data' },
            { title: '查看市场参考校准方向', desc: '确认当前岗位在目标城市是否有足够样本。', priority: 'mid', actionId: 'dashboard' },
            { title: '更新画像目标岗位', desc: '若方向过窄，补充 1-2 个相邻岗位方向。', priority: 'mid', actionId: 'profile' }
        ];
    } else if (shortlistCount <= 0) {
        conclusion = '已有高匹配岗位，先完成候选归类。';
        reason = `已识别 ${recCount} 个高匹配岗位，但未形成候选池。`;
        suggestion = '先把主申/冲刺岗位加入看板，再安排投递顺序。';
        primaryAction = 'data';
        actions = [
            { title: '从评估结果中选出 Top3', desc: '将高匹配岗位分别标记为主申/冲刺。', priority: 'high', actionId: 'data' },
            { title: '收藏到投递看板', desc: '把候选岗位加入看板，避免重复评估。', priority: 'high', actionId: 'applications' },
            { title: '补齐关键短板技能', desc: topMissing.length ? `优先补：${topMissing[0]}。` : '继续补齐岗位高频技能。', priority: 'mid', actionId: 'profile' }
        ];
    } else if (appliedCount <= 0) {
        conclusion = '候选已形成，进入首轮投递验证。';
        reason = `当前候选 ${shortlistCount} 个，但投递记录为 0。`;
        suggestion = '建议今日先投递 2-3 个主申岗位并建立跟进提醒。';
        primaryAction = 'applications';
        actions = [
            { title: '首批投递 2-3 个岗位', desc: '优先主申岗位，冲刺岗位控制在少量。', priority: 'high', actionId: 'applications' },
            { title: '设置 48 小时跟进提醒', desc: '每次投递后记录时间与下一步跟进节点。', priority: 'high', actionId: 'applications' },
            { title: '准备投递话术与项目亮点', desc: '围绕岗位要求改写简历的项目成果表达。', priority: 'mid', actionId: 'profile' }
        ];
    } else if ((interviewCount + offerCount) <= 0) {
        conclusion = '进入跟进优化阶段，提升面试转化。';
        reason = `已投递 ${appliedCount} 个岗位，但面试/Offer 仍为 0。`;
        suggestion = '优先跟进最近投递岗位，并根据反馈补齐关键短板。';
        primaryAction = 'applications';
        actions = [
            { title: '更新投递状态与跟进结果', desc: '把“已投递/沟通中/面试邀约”状态及时更新。', priority: 'high', actionId: 'applications' },
            { title: '对未回复岗位进行一次跟进', desc: '投递后 48-72 小时未回复可发送简短跟进。', priority: 'mid', actionId: 'applications' },
            { title: '补齐转化关键技能', desc: topMissing.length ? `优先补：${topMissing.slice(0, 2).join('、')}。` : '根据面试反馈补齐高频硬技能。', priority: 'mid', actionId: 'profile' }
        ];
    } else {
        conclusion = '流程推进良好，进入持续提升与复盘。';
        reason = `当前面试 ${interviewCount} 个，Offer ${offerCount} 个，已形成正向反馈。`;
        suggestion = '继续保持投递节奏，并基于反馈迭代画像与岗位策略。';
        primaryAction = 'compet';
        actions = [
            { title: '复盘面试反馈并更新画像', desc: '把面试反馈同步到技能与项目经历中。', priority: 'mid', actionId: 'profile' },
            { title: '动态调整主申/冲刺比例', desc: '根据近两周结果优化投递结构。', priority: 'mid', actionId: 'applications' },
            { title: '每周补齐 1 项高频技能', desc: '持续提升竞争力，抬升薪资与岗位上限。', priority: 'low', actionId: 'compet' }
        ];
    }

    const confidence = buildDecisionConfidence(ctx);
    return { conclusion, reason, suggestion, primaryAction, actions, confidence };
}

window.buildDecisionConfidence = buildDecisionConfidence;
window.buildPersonalActionBrief = buildPersonalActionBrief;


