﻿// =========================================================
// 7. 全景分析仪表盘逻辑 (New Dashboard)
// =========================================================

let dashboardState = { city: '', edu: '', exp: '' };
let dashCharts = {}; // 存储仪表盘图表实例
let dashboardRefreshing = false;
let dashboardFallbackToastTs = 0;
let dashboardProfileCache = null;
let dashboardRunMode = 'advanced';
let dashboardFallbackNotified = false;
let dashboardAutoRefreshBound = false;
let dashboardAutoRefreshTimer = null;

function showDashboardFallbackToast(msg) {
    const statusEl = document.getElementById('dash-runtime-badge') || document.getElementById('dash-market-temp');
    if (statusEl) {
        statusEl.innerText = msg || '基础分析模式';
        statusEl.style.background = '#fff7ed';
        statusEl.style.color = '#9a3412';
        statusEl.style.border = '1px solid #fed7aa';
    }
    if (dashboardFallbackNotified) return;
    const now = Date.now();
    if (now - dashboardFallbackToastTs < 5000) return;
    dashboardFallbackToastTs = now;
    dashboardFallbackNotified = true;
}

function setDashboardRunMode(mode, message) {
    if (dashboardRunMode === mode) return;
    dashboardRunMode = mode;
    if (!message) return;
    if (mode === 'fallback') {
        showDashboardFallbackToast(message);
    } else {
        dashboardFallbackNotified = false;
        showToast(message, 'success');
    }
}

function normalizeDashboardData(raw) {
    const data = raw && typeof raw === 'object' ? raw : {};
    const metaRaw = data.meta && typeof data.meta === 'object' ? data.meta : {};
    const statsRaw = metaRaw.stats && typeof metaRaw.stats === 'object' ? metaRaw.stats : {};
    const insightsRaw = data.insights && typeof data.insights === 'object' ? data.insights : {};
    const chartsRaw = data.charts && typeof data.charts === 'object' ? data.charts : {};
    const safeNum = (v, d = 0) => {
        const n = Number(v);
        return Number.isFinite(n) ? n : d;
    };
    const asArray = (v) => (Array.isArray(v) ? v : []);
    const asObject = (v, d = {}) => (v && typeof v === 'object' ? v : d);
    const salaryRaw = asObject(chartsRaw.salary);
    const companyRaw = asObject(chartsRaw.company);
    const timeRaw = asObject(chartsRaw.time_trend);
    const cityRaw = asObject(chartsRaw.city);
    const eduRaw = asObject(chartsRaw.edu);
    const demandRaw = asObject(insightsRaw.demand_index);
    const qualityGateRaw = asObject(data.quality_gate || insightsRaw.quality_gate);
    return {
        meta: {
            diagnosis: String(metaRaw.diagnosis || ''),
            stats: {
                count: safeNum(statsRaw.count, 0),
                avg_salary: safeNum(statsRaw.avg_salary, 0),
                max_salary: safeNum(statsRaw.max_salary, 0)
            }
        },
        insights: {
            market: {
                score: safeNum(((insightsRaw.market || {}).score), 0),
                level: String(((insightsRaw.market || {}).level) || '待评估')
            },
            factors: asArray(insightsRaw.factors),
            skills: {
                high_value: asArray((insightsRaw.skills || {}).high_value),
                common: asArray((insightsRaw.skills || {}).common)
            },
            conclusions: asObject(insightsRaw.conclusions),
            action_plan: asArray(insightsRaw.action_plan),
            advices: asArray(insightsRaw.advices),
            competitiveness: asObject(insightsRaw.competitiveness, null),
            demand_index: {
                categories: asArray(demandRaw.categories)
            }
        },
        charts: {
            salary: {
                range_dist: {
                    labels: asArray((salaryRaw.range_dist || {}).labels),
                    values: asArray((salaryRaw.range_dist || {}).values).map(v => safeNum(v, 0))
                },
                exp_trend: {
                    labels: asArray((salaryRaw.exp_trend || {}).labels),
                    values: asArray((salaryRaw.exp_trend || {}).values).map(v => safeNum(v, 0))
                }
            },
            cloud: asArray(chartsRaw.cloud),
            city: {
                labels: asArray(cityRaw.labels),
                avg: asArray(cityRaw.avg).map(v => safeNum(v, 0)),
                count: asArray(cityRaw.count).map(v => safeNum(v, 0))
            },
            edu: {
                labels: asArray(eduRaw.labels),
                values: asArray(eduRaw.values).map(v => safeNum(v, 0)),
                counts: asArray(eduRaw.counts).map(v => safeNum(v, 0))
            },
            heatmap: asObject(chartsRaw.heatmap, null),
            time_trend: {
                labels: asArray(timeRaw.labels),
                job_counts: asArray(timeRaw.job_counts).map(v => safeNum(v, 0)),
                salary_trend: asArray(timeRaw.salary_trend).map(v => safeNum(v, 0))
            },
            company: {
                salary_rank: asArray(companyRaw.salary_rank),
                size_dist: asArray(companyRaw.size_dist),
                size_salary: asObject(companyRaw.size_salary, { labels: [], values: [] })
            }
        },
        quality_gate: qualityGateRaw
    };
}

async function loadDashboardProfileSnapshot() {
    try {
        const r = await fetch('/api/profile/score');
        const d = await r.json();
        if (d && d.success) {
            const data = d.data || {};
            const profile = d.profile || data.profile || {};
            return {
                score: Number(data.score || 0),
                profile
            };
        }
    } catch (e) {
        console.warn('读取画像快照失败', e);
    }
    return { score: 0, profile: {} };
}

function getDashboardProfileInfo(profileSnapshot = null) {
    const snap = profileSnapshot || dashboardProfileCache || {};
    const profile = (snap && snap.profile) || {};
    const targetJob = String(profile.target_job || profile.target_jobs || '').trim() || '目标岗位';
    const exp = String(profile.exp_year || profile.exp || '').trim() || '经验不限';
    const expectedMin = Number(profile.expected_salary_min || 0);
    const expectedMax = Number(profile.expected_salary_max || 0);
    const expected = expectedMax || expectedMin || 0;
    const expectedText = expected
        ? `期望薪资 ¥${expectedMin > 0 ? expectedMin.toLocaleString() : 0}${expectedMax > 0 ? `-${expectedMax.toLocaleString()}` : '+'}`
        : '期望薪资未填写';
    return { targetJob, exp, expectedMin, expectedMax, expected, expectedText, profile };
}

function setupDashboardAutoRefresh() {
    if (dashboardAutoRefreshBound) return;
    dashboardAutoRefreshBound = true;
    const ids = ['dash-city', 'dash-source', 'dash-edu', 'dash-exp', 'dash-date-range'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('change', () => {
            if (dashboardAutoRefreshTimer) clearTimeout(dashboardAutoRefreshTimer);
            dashboardAutoRefreshTimer = setTimeout(() => {
                refreshDashboard();
            }, 280);
        });
    });
}

function renderDashboardPersonalDecision(meta, insights, profileSnapshot, qualityGate = {}) {
    const box = document.getElementById('dash-personal-insight');
    const actionBox = document.getElementById('dash-next-actions');
    if (!box || !actionBox) return;

    const pScore = Number((profileSnapshot || {}).score || 0);
    const info = getDashboardProfileInfo(profileSnapshot);
    const profile = info.profile || {};
    const targetJob = info.targetJob;
    const expectedText = info.expectedText;
    const expText = info.exp;
    const skillsRaw = String(profile.skills || '').trim();
    const userSkills = skillsRaw ? skillsRaw.split(/[，,、]/).map(x => x.trim()).filter(Boolean) : [];
    const highSkills = (insights && insights.skills && Array.isArray(insights.skills.high_value))
        ? insights.skills.high_value.map(x => (typeof x === 'object' ? x.name : x)).filter(Boolean)
        : [];
    const commonSkills = (insights && insights.skills && Array.isArray(insights.skills.common))
        ? insights.skills.common.map(x => (typeof x === 'object' ? x.name : x)).filter(Boolean)
        : [];
    const marketSkillPool = [...highSkills, ...commonSkills].filter(Boolean);
    const missing = marketSkillPool.filter(s => !userSkills.some(us => us.toLowerCase() === String(s).toLowerCase()));
    const keyGap = missing.slice(0, 2);
    const avgSalary = Number(((meta || {}).stats || {}).avg_salary || 0);
    const expectedMin = Number(profile.expected_salary_min || 0);
    const expectedMax = Number(profile.expected_salary_max || 0);
    const expected = expectedMax || expectedMin;
    const salaryGap = expected > 0 && avgSalary > 0 ? (expected - avgSalary) : 0;

    let conclusion = '你已具备进入岗位决策阶段的条件';
    let reason = `画像完整度 ${pScore} 分，市场均薪约 ¥${avgSalary.toLocaleString()}。`;
    let suggestion = '先在岗位决策中筛出主申岗位，再进入投递执行建立跟进节奏。';
    let tone = 'mid';

    if (qualityGate && qualityGate.blocking) {
        conclusion = '当前更适合先修复数据，再参考市场分析结论';
        reason = qualityGate.summary || '当前样本质量未达到市场分析准入门槛。';
        suggestion = ((qualityGate.actions || [])[0]) || '先补齐数据质量，再回到市场分析。';
        tone = 'risk';
    } else if (pScore < 60) {
        conclusion = '当前更适合先补齐画像，再做投递判断';
        reason = `画像完整度 ${pScore} 分，低于建议阈值 60 分。`;
        suggestion = `优先补齐目标岗位、经验与技能字段${keyGap.length ? `，并补 ${keyGap.join('、')}` : ''}。`;
        tone = 'risk';
    } else if (keyGap.length >= 2) {
        conclusion = `你可投递 ${targetJob}，但建议先补关键技能`;
        reason = `画像分 ${pScore}，识别到关键差距：${keyGap.join('、')}。`;
        suggestion = `先补齐 ${keyGap.join('、')}，预期可提升岗位匹配与面试通过率。`;
        tone = 'mid';
    } else if (salaryGap > 2500) {
        conclusion = '你的薪资预期偏高，建议分层投递';
        reason = `期望薪资约 ¥${expected.toLocaleString()}，高于市场均值约 ¥${salaryGap.toLocaleString()}。`;
        suggestion = '主申岗位按市场中高位投递，冲刺岗位控制数量并突出项目成果。';
        tone = 'mid';
    } else if (pScore >= 80) {
        conclusion = `你当前可优先投递 ${targetJob}`;
        reason = `画像分 ${pScore}，技能差距较小，市场信号 ${((insights || {}).market || {}).level || '正常'}。`;
        suggestion = '先投递 2-3 个主申岗位，48 小时内完成首次跟进。';
        tone = 'good';
    }

    box.innerHTML = renderConclusionCard(`个人化决策洞见（针对你：${targetJob} / ${expText} / ${expectedText}）`, conclusion, reason, suggestion, tone);

    const actions = [];
    if (qualityGate && qualityGate.blocking) {
        actions.push({ label: '去数据管理', fn: "switchTab('data')", icon: 'ri-database-2-line', primary: true });
        actions.push({ label: '看质量面板', fn: "switchTab('summary')", icon: 'ri-shield-check-line' });
    } else if (pScore < 60) {
        actions.push({ label: '完善画像', fn: "switchTab('profile')", icon: 'ri-user-settings-line', primary: true });
        actions.push({ label: '查看技能差距', fn: "switchTab('profile'); setTimeout(()=>switchProfileSubTab&&switchProfileSubTab('gap'),120)", icon: 'ri-bubble-chart-line' });
    } else if (keyGap.length) {
        actions.push({ label: '去技能差距', fn: "switchTab('profile'); setTimeout(()=>switchProfileSubTab&&switchProfileSubTab('gap'),120)", icon: 'ri-bubble-chart-line', primary: true });
        actions.push({ label: '去岗位决策', fn: "switchTab('data')", icon: 'ri-radar-line' });
    } else {
        actions.push({ label: '去岗位决策', fn: "switchTab('data')", icon: 'ri-radar-line', primary: true });
        actions.push({ label: '去投递执行', fn: "switchTab('applications')", icon: 'ri-send-plane-line' });
    }
    actions.push({ label: '查看系统推荐', fn: "switchTab('ai')", icon: 'ri-focus-3-line' });

    actionBox.innerHTML = `
        <div style="font-weight:700; margin-bottom:6px;">下一步行动（按优先级）</div>
        <div style="font-size:12px; color:#64748b; margin-bottom:8px;">面向 ${targetJob} · ${expText} · ${expectedText}</div>
        <div style="display:flex; flex-wrap:wrap; gap:8px;">
            ${actions.map(a => `<button class="btn ${a.primary ? 'btn-primary' : 'btn-default'}" onclick="${a.fn}"><i class="${a.icon}"></i> ${a.label}</button>`).join('')}
        </div>
        <div style="margin-top:8px; font-size:12px; color:#64748b;">说明：行动建议基于你的画像、市场薪资与技能缺口自动生成。</div>
    `;
}

function renderDashboardCommandDeck(meta, insights, profileSnapshot, qualityGate = {}) {
    const qualityEl = document.getElementById('dash-quality-gate');
    const conclusionEl = document.getElementById('dash-market-conclusion');
    const actionsEl = document.getElementById('dash-market-actions');
    if (!qualityEl || !conclusionEl || !actionsEl) return;

    const stats = (meta || {}).stats || {};
    const market = (insights || {}).market || {};
    const actionPlan = Array.isArray((insights || {}).action_plan) ? insights.action_plan : [];
    const salaryConclusion = pickConclusionPart(((insights || {}).conclusions || {}).salary);
    const cityConclusion = pickConclusionPart(((insights || {}).conclusions || {}).city);
    const sampleCount = Number(stats.count || 0);
    const profileInfo = getDashboardProfileInfo(profileSnapshot);

    if (qualityGate && qualityGate.blocking) {
        const blockers = Array.isArray(qualityGate.blockers) ? qualityGate.blockers : [];
        qualityEl.innerHTML = `
            <div style="font-weight:700; color:#b45309;">当前不建议直接参考市场结论</div>
            <div style="margin-top:6px; font-size:12px; color:#92400e;">${qualityGate.summary || '当前数据质量未达到分析准入门槛。'}</div>
            <div style="margin-top:8px; font-size:12px; color:#92400e;">${blockers.slice(0, 2).map(x => `• ${x}`).join('<br>') || '• 先补齐数据后再重新分析。'}</div>
        `;
    } else {
        const warnings = Array.isArray(qualityGate.warnings) ? qualityGate.warnings : [];
        qualityEl.innerHTML = `
            <div style="font-weight:700; color:#166534;">分析准入已通过</div>
            <div style="margin-top:6px; font-size:12px; color:#475569;">${qualityGate.summary || `当前样本 ${sampleCount} 条，可用于市场分析。`}</div>
            <div style="margin-top:8px; font-size:12px; color:#475569;">${warnings.length ? warnings.slice(0, 2).map(x => `• ${x}`).join('<br>') : '• 当前可以继续查看市场证据，并转入岗位决策。'}</div>
        `;
    }

    conclusionEl.innerHTML = `
        <div style="font-weight:700; color:#0f172a;">${salaryConclusion.conclusion || `当前市场信号为 ${market.level || '待评估'}`}</div>
        <div style="margin-top:6px; font-size:12px; color:#475569;">${salaryConclusion.reason || `当前样本 ${sampleCount} 条，目标方向 ${profileInfo.targetJob}，平均薪资约 ¥${Number(stats.avg_salary || 0).toLocaleString() || 0}。`}</div>
        <div style="margin-top:8px; font-size:12px; color:#0f172a;">${cityConclusion.conclusion || salaryConclusion.suggestion || '先从目标城市和经验范围中筛出可投岗位。'}</div>
    `;

    const nextLines = [];
    actionPlan.slice(0, 3).forEach((item, idx) => {
        if (!item) return;
        const title = item.title || `动作 ${idx + 1}`;
        const detail = item.desc || item.text || '';
        nextLines.push(`• ${title}${detail ? `：${detail}` : ''}`);
    });
    if (!nextLines.length) {
        nextLines.push(qualityGate && qualityGate.blocking
            ? '• 先去数据准备页处理样本质量，再回来看市场分析。'
            : '• 先去岗位决策页筛出主申和冲刺岗位，再进入投递执行。');
    }

    const primaryAction = (qualityGate && qualityGate.blocking)
        ? `<button class="btn btn-primary" onclick="switchTab('settings')"><i class="ri-database-2-line"></i> 去数据准备</button>`
        : `<button class="btn btn-primary" onclick="switchTab('data')"><i class="ri-radar-line"></i> 去岗位决策</button>`;
    const secondaryAction = `<button class="btn btn-default" onclick="switchTab('ai')"><i class="ri-focus-3-line"></i> 看推荐计划</button>`;
    const tertiaryAction = `<button class="btn btn-default" onclick="switchTab('applications')"><i class="ri-send-plane-line"></i> 去投递执行</button>`;

    actionsEl.innerHTML = `
        <div style="font-size:12px; color:#334155;">${nextLines.join('<br>')}</div>
        <div style="margin-top:10px; display:flex; flex-wrap:wrap; gap:8px;">
            ${primaryAction}
            ${secondaryAction}
            ${tertiaryAction}
        </div>
    `;
}

function renderDashboardStoryline(meta, insights, profileSnapshot, charts = null) {
    const wrap = document.getElementById('dash-storyline-steps');
    if (!wrap) return;

    const info = getDashboardProfileInfo(profileSnapshot);
    const pScore = Number((profileSnapshot || {}).score || 0);
    const demandCats = Array.isArray(((insights || {}).demand_index || {}).categories)
        ? insights.demand_index.categories
        : [];
    const topDemand = demandCats[0] || {};
    const actionPlan = Array.isArray((insights || {}).action_plan) ? insights.action_plan : [];
    const topAction = actionPlan[0] || {};
    const highSkills = Array.isArray(((insights || {}).skills || {}).high_value) ? insights.skills.high_value : [];
    const keySkill = highSkills[0];
    const avgSalary = Number(((meta || {}).stats || {}).avg_salary || 0);
    const count = Number(((meta || {}).stats || {}).count || 0);
    const trend = (charts && charts.time_trend) ? charts.time_trend : {};
    const jobCounts = Array.isArray(trend.job_counts) ? trend.job_counts : [];
    const salaryTrend = Array.isArray(trend.salary_trend) ? trend.salary_trend : [];
    const firstJobs = Number(jobCounts[0] || 0);
    const lastJobs = Number(jobCounts[jobCounts.length - 1] || 0);
    const jobsGrowth = firstJobs > 0 ? Math.round(((lastJobs - firstJobs) / firstJobs) * 100) : 0;
    const firstSalary = Number(salaryTrend[0] || 0);
    const lastSalary = Number(salaryTrend[salaryTrend.length - 1] || 0);
    const salaryGrowth = firstSalary > 0 ? Math.round(((lastSalary - firstSalary) / firstSalary) * 100) : 0;
    const topDemandHeat = Number(topDemand.heat_index || 0);

    const steps = [
        {
            title: '1. 市场现状',
            text: `当前样本 ${count} 条，市场信号 ${((insights || {}).market || {}).level || '待评估'}，均薪约 ¥${avgSalary.toLocaleString() || 0}。`,
            dataPoint: `关键数据：岗位量${jobsGrowth >= 0 ? '上升' : '回落'} ${Math.abs(jobsGrowth)}%，薪资趋势${salaryGrowth >= 0 ? '上行' : '回调'} ${Math.abs(salaryGrowth)}%`,
            action: '<button class="btn btn-default btn-sm" onclick="(function(){var el=document.getElementById(\'chart-salary-dist\');if(el){el.scrollIntoView({behavior:\'smooth\',block:\'center\'});}})()">查看薪资依据</button>'
        },
        {
            title: '2. 对你影响',
            text: pScore > 0
                ? `你的画像分 ${pScore}。${keySkill ? `当前高价值技能信号：${typeof keySkill === 'object' ? keySkill.name : keySkill}。` : '建议继续补齐高频技能。'}`
                : '尚未读取到画像评分，建议先完善画像后再看市场分析结果。',
            dataPoint: `关键数据：目标=${info.targetJob}，${info.expectedText}，经验=${info.exp}`,
            action: '<button class="btn btn-default btn-sm" onclick="switchTab(\'profile\')">去完善画像</button>'
        },
        {
            title: '3. 机会窗口',
            text: topDemand.name
                ? `当前需求热度最高方向是「${topDemand.name}」，热度指数 ${Number(topDemand.heat_index || 0)}。`
                : '暂未识别出明显的需求热点，可先按目标岗位关键词筛选。',
            dataPoint: `关键数据：热度指数 ${topDemandHeat || 0}，建议优先关注高热度且薪资高于期望的岗位`,
            action: '<button class="btn btn-default btn-sm" onclick="switchTab(\'data\')">去岗位决策</button>'
        },
        {
            title: '4. 下一步行动',
            text: topAction.title
                ? `${topAction.title}：${topAction.desc || '按建议推进执行。'}`
                : '先完成岗位决策，再进入投递执行建立跟进节奏。',
            dataPoint: '关键数据：先主申后冲刺，先做高命中动作再扩大投递范围',
            action: '<button class="btn btn-primary btn-sm" onclick="switchTab(\'applications\')">去投递执行</button>'
        }
    ];

    wrap.innerHTML = steps.map(step => `
        <div class="dashboard-storyline-step">
            <div class="dashboard-storyline-step-title">${step.title}</div>
            <div class="dashboard-storyline-step-text">${step.text}</div>
            <div class="dashboard-storyline-step-data">${step.dataPoint || ''}</div>
            <div class="dashboard-storyline-step-action">${step.action}</div>
        </div>
    `).join('');
}

async function loadDashboardFallback(city = '', edu = '', exp = '') {
    if (document.body.classList.contains('app-auth-locked')) return;
    const fallbackOverlay = document.getElementById('auth-overlay');
    if (fallbackOverlay && fallbackOverlay.style.display !== 'none') return;
    const countEl = document.getElementById('dash-count');
    const txtEl = document.getElementById('dash-diagnosis-text');
    try {
        const r = await fetch('/api/stats/summary');
        const d = await r.json();
        const total = Number(d.total || 0);
        const avg = Number(d.avg_salary || 0);
        const max = Number(d.max_salary || 0);
        if (countEl) countEl.innerText = String(total);
        const avgEl = document.getElementById('dash-avg-salary');
        const maxEl = document.getElementById('dash-max-salary');
        if (avgEl) avgEl.innerText = avg > 0 ? `¥ ${avg.toLocaleString()}` : '--';
        if (maxEl) maxEl.innerText = max > 0 ? `¥ ${max.toLocaleString()}` : '--';
        if (txtEl) {
            txtEl.innerHTML = `当前使用降级分析结果。已加载样本 <b>${total}</b> 条。建议先检查筛选条件（城市=${city || '全部'}，学历=${edu || '全部'}，经验=${exp || '全部'}）后重试高级分析。`;
        }
        const advicesEl = document.getElementById('dash-advices');
        if (advicesEl) {
            advicesEl.innerHTML = `<div class="advice-item"><div class="advice-icon"><i class="ri-lightbulb-line"></i></div><div class="advice-content"><div class="advice-title">降级模式建议</div><div class="advice-text">先切换到“岗位决策”完成候选筛选，再回到市场分析刷新高级模型。</div></div></div>`;
        }
        renderDashboardCommandDeck({ stats: { count: total, avg_salary: avg, max_salary: max } }, { market: { level: '基础分析', score: 0 }, conclusions: {} }, dashboardProfileCache || { score: 0, profile: {} }, { blocking: false, summary: '当前显示的是基础分析结果，可先参考趋势后再返回高级分析。', warnings: ['当前为降级模式，结论可信度低于高级分析。'] });
        setDashboardRunMode('fallback', '已切换为基础分析模式');
    } catch (e) {
        if (txtEl) txtEl.innerHTML = '<span style="color:red"><i class="ri-error-warning-line"></i> 市场分析暂不可用，请稍后再试。</span>';
    }
}

async function initAnalysisDashboard() {
    if (document.body.classList.contains('app-auth-locked')) return;
    const initDashOverlay = document.getElementById('auth-overlay');
    if (initDashOverlay && initDashOverlay.style.display !== 'none') return;
    // 1. 初始化下拉框 (只做一次)
    const citySel = document.getElementById('dash-city');
    if (citySel && citySel.options.length <= 1) {
        try {
            const r = await fetch('/api/config/cities');
            const d = await r.json();
            if (d.success) {
                d.data.forEach(c => {
                    const opt = document.createElement('option');
                    opt.value = c;
                    opt.innerText = c;
                    citySel.appendChild(opt);
                });
            }
        } catch (e) {
            console.error("加载城市失败", e);
        }
    }
    setupDashboardAutoRefresh();

    // 2. 初始化图表实例
    const ids = ['chart-factors', 'chart-salary-dist', 'chart-cloud-dash', 'chart-city-dash', 'chart-edu-dash', 'chart-heatmap-edu', 'chart-radar', 'chart-time-trend', 'chart-company', 'chart-demand'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el && !dashCharts[id]) {
            dashCharts[id] = echarts.init(el);
        }
    });

    // 3. 延迟resize确保图表容器尺寸正确
    setTimeout(() => {
        Object.values(dashCharts).forEach(c => c && c.resize && c.resize());
    }, 100);

    // 4. 刷新数据
    refreshDashboard();
}

async function refreshDashboard() {
    if (document.body.classList.contains('app-auth-locked')) return;
    const refreshDashOverlay = document.getElementById('auth-overlay');
    if (refreshDashOverlay && refreshDashOverlay.style.display !== 'none') return;
    if (dashboardRefreshing) return;
    dashboardRefreshing = true;
    // 获取筛选值
    const keyword = (document.getElementById('dash-keyword') || {}).value || '';
    const city = (document.getElementById('dash-city') || {}).value || '';
    const source = (document.getElementById('dash-source') || {}).value || '';
    const edu = (document.getElementById('dash-edu') || {}).value || '';
    const exp = (document.getElementById('dash-exp') || {}).value || '';
    const date_range = (document.getElementById('dash-date-range') || {}).value || '';

    // 显示 Loading
    Object.values(dashCharts).forEach(c => {
        if (c && c.showLoading) c.showLoading({ text: '分析中...', color: '#2563eb', maskColor: 'rgba(255,255,255,0.6)' });
    });
    const diagnosisEl = document.getElementById('dash-diagnosis-text');
    if (diagnosisEl) diagnosisEl.innerHTML = '<i class="ri-loader-4-line ri-spin"></i> 正在运算市场模型...';

    try {
        // 增加超时控制（30秒）
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000);
        dashboardProfileCache = await loadDashboardProfileSnapshot();

        const r = await fetch('/api/analysis/dashboard', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ keyword, city, source, edu, exp, date_range }),
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        const res = await r.json();

        Object.values(dashCharts).forEach(c => { if (c && c.hideLoading) c.hideLoading(); });

        if (res.success) {
            setDashboardRunMode('advanced', '已恢复高级分析模式');
            updateDashboardUI(normalizeDashboardData(res.data), dashboardProfileCache);
            // 延迟调整仪表盘图表尺寸
            setTimeout(() => {
                Object.values(dashCharts).forEach(c => c && c.resize && c.resize());
            }, 200);
        } else {
            setDashboardRunMode('fallback', res.msg || '加载失败，已切换基础分析');
            await loadDashboardFallback(city, edu, exp);
        }
    } catch (e) {
        console.error('仪表盘加载错误:', e);
        Object.values(dashCharts).forEach(c => { if (c && c.hideLoading) c.hideLoading(); });
        let errText = '数据加载失败';
        if (e.name === 'AbortError') errText = '请求超时，数据量较大请稍后重试';
        else if (e.message && e.message.includes('JSON')) errText = '服务器响应异常';
        setDashboardRunMode('fallback', errText + '，已尝试基础分析');
        await loadDashboardFallback(city, edu, exp);
    } finally {
        dashboardRefreshing = false;
    }
}

function resetDashboardFilters() {
    const kw = document.getElementById('dash-keyword');
    const src = document.getElementById('dash-source');
    const dr = document.getElementById('dash-date-range');
    if (kw) kw.value = "";
    document.getElementById('dash-city').value = "";
    if (src) src.value = "";
    document.getElementById('dash-edu').value = "";
    document.getElementById('dash-exp').value = "";
    if (dr) dr.value = "";
    refreshDashboard();
}



function updateDashboardUI(data, profileSnapshot = null) {
    const { meta, insights, charts } = data;
    const safeMoney = (v) => {
        const n = Number(v);
        return Number.isFinite(n) && n > 0 ? `¥ ${Math.round(n).toLocaleString()}` : '--';
    };

    // Empty State Check
    const emptyEl = document.getElementById('dash-empty-state');
    const diagEl = document.querySelector('#tab-dashboard .diagnosis-panel');
    const chartGrid = document.querySelector('#tab-dashboard .chart-dashboard-grid');

    if (meta.stats.count === 0) {
        if (emptyEl) emptyEl.style.display = 'flex';
        if (diagEl) diagEl.style.display = 'none';
        if (chartGrid) chartGrid.style.display = 'none';
        const commandDeck = document.getElementById('dash-command-deck');
        if (commandDeck) commandDeck.style.display = 'none';
        const storyEl = document.getElementById('dash-storyline-steps');
        if (storyEl) {
            storyEl.innerHTML = '<div class="dashboard-storyline-empty">暂无样本，暂无法生成分析链路。请先放宽筛选条件或补充数据。</div>';
        }

        // Update stats to 0
        animateValue(document.getElementById('dash-count'), 0, 0, 500);
        document.getElementById('dash-avg-salary').innerText = '--';
        document.getElementById('dash-max-salary').innerText = '--';
        return;
    } else {
        if (emptyEl) emptyEl.style.display = 'none';
        if (diagEl) diagEl.style.display = 'block';
        if (chartGrid) chartGrid.style.display = 'grid';
        const commandDeck = document.getElementById('dash-command-deck');
        if (commandDeck) commandDeck.style.display = 'grid';
    }

    // 1. 更新顶部 KPI & 诊断
    animateValue(document.getElementById('dash-count'), 0, meta.stats.count, 500);
    const avgEl = document.getElementById('dash-avg-salary');
    const maxEl = document.getElementById('dash-max-salary');
    if (avgEl) avgEl.innerText = safeMoney(meta.stats.avg_salary);
    if (maxEl) maxEl.innerText = safeMoney(meta.stats.max_salary);

    const trendEl = document.getElementById('dash-market-temp');
    if (trendEl) {
        trendEl.innerText = insights.market.level + ' (' + insights.market.score + ')';
        trendEl.style.color = insights.market.score > 60 ? '#ef4444' : '#f59e0b';
        trendEl.style.background = insights.market.score > 60 ? '#fff1f0' : '#fff7e6';
    }

    // 补充计算新增的三个指标: 市场决策信号、机会窗口、样本稳定性
    const totalJobs = meta.stats.count || 0;

    // 市场决策信号: 结合偏好、打分和薪资差进行展示
    const signalEl = document.getElementById('dash-kpi-signal');
    if (signalEl) {
        if (insights.market.score > 70) {
            signalEl.innerHTML = '<span style="color: #ef4444; font-weight: bold;">红海 (竞争激烈)</span>';
        } else if (insights.market.score > 40) {
            signalEl.innerHTML = '<span style="color: #f59e0b; font-weight: bold;">温和 (正常竞争)</span>';
        } else {
            signalEl.innerHTML = '<span style="color: #10b981; font-weight: bold;">蓝海 (机会广阔)</span>';
        }
    }

    // 机会窗口指数: 综合活跃度和岗位数量基数模拟
    const windowEl = document.getElementById('dash-kpi-window');
    if (windowEl) {
        let windowIndex = 50 + (meta.stats.avg_salary / 1000) * 0.5 + (totalJobs / 10) * 0.5;
        windowIndex = Math.min(99, Math.max(10, windowIndex)).toFixed(1);
        windowEl.innerHTML = `<span style="font-weight: 700; color: #8b5cf6;">${windowIndex}/100</span>`;
    }

    // 样本稳定性: 数据越充足稳定性越高
    const stableEl = document.getElementById('dash-kpi-stable');
    if (stableEl) {
        let stability = "低"; let sColor = "#ef4444";
        if (totalJobs > 500) { stability = "极高 (A+)"; sColor = "#10b981"; }
        else if (totalJobs > 200) { stability = "高 (A)"; sColor = "#3b82f6"; }
        else if (totalJobs > 50) { stability = "良 (B)"; sColor = "#f59e0b"; }

        stableEl.innerHTML = `<span style="color: ${sColor}; font-weight: bold;">${stability}</span>`;
    }

    // 自动诊断打字机效果 (简化) - 修复 Markdown 渲染
    const rawDiagnosis = meta.diagnosis || '';
    const diagnosisTextEl = document.getElementById('dash-diagnosis-text');
    if (diagnosisTextEl) {
        diagnosisTextEl.innerHTML = typeof marked !== 'undefined'
            ? marked.parse(rawDiagnosis)
            : rawDiagnosis;
    }

    // 首要因子
    const topFactor = insights.factors[0] ? insights.factors[0].name : '--';
    const topFactorEl = document.getElementById('dash-top-factor');
    if (topFactorEl) topFactorEl.innerText = topFactor;

    // 1.1 市场参考结论层：统一“结论-原因-建议”
    const marketSummaryEl = document.getElementById('insight-summary');
    if (marketSummaryEl) {
        const salaryC = pickConclusionPart((insights.conclusions || {}).salary);
        const marketTone = (insights.market && Number(insights.market.score || 0) >= 70) ? 'risk'
            : ((insights.market && Number(insights.market.score || 0) >= 40) ? 'mid' : 'good');
        const conc = salaryC.conclusion || `当前市场信号为${insights.market.level || '待评估'}`;
        const reason = salaryC.reason || `样本量 ${meta.stats.count || 0}，平均薪资 ¥${(meta.stats.avg_salary || 0).toLocaleString()}，关键因子 ${topFactor}。`;
        const suggestion = salaryC.suggestion || '先按目标城市和经验筛选岗位，再结合岗位决策页输出做投递优先级决策。';
        marketSummaryEl.innerHTML = renderConclusionCard('市场参考结论', conc, reason, suggestion, marketTone);
    }
    renderDashboardCommandDeck(meta, insights, profileSnapshot || dashboardProfileCache || { score: 0, profile: {} }, data.quality_gate || {});
    renderDashboardPersonalDecision(meta, insights, profileSnapshot || dashboardProfileCache || { score: 0, profile: {} }, data.quality_gate || {});
    renderDashboardStoryline(meta, insights, profileSnapshot || dashboardProfileCache || { score: 0, profile: {} }, charts || {});

    // 1.2 系统解读与依据：图表降级为证据，不再独立撑页面
    const sysInterpEl = document.getElementById('dash-system-interpretation');
    if (sysInterpEl) {
        const lines = [];
        lines.push(`• 结论：市场信号 ${insights.market.level || '待评估'}，样本规模 ${meta.stats.count || 0}。`);
        if (data.quality_gate && data.quality_gate.summary) lines.push(`• 准入：${data.quality_gate.summary}`);
        if (meta.diagnosis) lines.push(`• 解释：${String(meta.diagnosis).replace(/\s+/g, ' ')}`);
        lines.push('• 建议：结合“岗位决策”页逐个验证目标岗位，再进入“投递执行”推进。');
        sysInterpEl.innerHTML = lines.join('<br>');
    }
    const evidenceEl = document.getElementById('dash-analysis-evidence');
    if (evidenceEl) {
        const cSalary = pickConclusionPart((insights.conclusions || {}).salary);
        const cCity = pickConclusionPart((insights.conclusions || {}).city);
        const cEdu = pickConclusionPart((insights.conclusions || {}).edu);
        const cCloud = pickConclusionPart((insights.conclusions || {}).cloud);
        const evidenceRows = [
            { title: '薪资分布图', text: cSalary.reason || cSalary.conclusion || '用于验证薪资判断与分位变化。' },
            { title: '城市分布图', text: cCity.reason || cCity.conclusion || '用于验证目标城市岗位供给与竞争强度。' },
            { title: '学历分布图', text: cEdu.reason || cEdu.conclusion || '用于验证学历门槛与投递可行性。' },
            { title: '技能词云图', text: cCloud.reason || cCloud.conclusion || '用于验证高频技能与能力缺口。' },
        ];
        evidenceEl.innerHTML = evidenceRows.map((x, i) =>
            `<div style="padding:10px 12px; border:1px solid #e2e8f0; border-radius:10px; margin-bottom:8px; background:${i % 2 === 0 ? '#fff' : '#f8fafc'};"><b>${x.title}</b><div style="margin-top:4px; color:#64748b; font-size:12px;">${x.text}</div></div>`
        ).join('');
    }

    // 2. 更新因子图表 (横向柱状)
    if (dashCharts['chart-factors']) {
        const factorOpt = {
            grid: { top: 0, bottom: 0, left: 0, right: 30, containLabel: true },
            xAxis: { show: false, type: 'value' },
            yAxis: {
                type: 'category',
                data: insights.factors.map(f => f.name),
                axisLine: { show: false }, tickLine: { show: false }
            },
            series: [{
                type: 'bar',
                data: insights.factors.map(f => f.value),
                label: { show: true, position: 'right', formatter: '{c}%' },
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [{ offset: 0, color: '#2563eb' }, { offset: 1, color: '#60a5fa' }]),
                    borderRadius: [0, 4, 4, 0]
                },
                barWidth: 10
            }]
        };
        dashCharts['chart-factors'].setOption(factorOpt);
    }

    // 3. 更新技能标签
    const highSkillsEl = document.getElementById('dash-high-skills');
    if (highSkillsEl) {
        highSkillsEl.innerHTML = (insights.skills.high_value || []).map(s => {
            const name = typeof s === 'object' ? s.name : s;
            const premium = typeof s === 'object' && s.premium ? ` +${s.premium}%` : '';
            return `<span class="tag-pill highlight" style="color:#7c3aed; background:#f9f0ff; border-color:#d3adf7">✨ ${name}${premium}</span>`;
        }).join('') || '<span style="color:#ccc; font-size:12px">暂无高溢价技能数据</span>';
    }

    const commonSkillsEl = document.getElementById('dash-common-skills');
    if (commonSkillsEl) {
        commonSkillsEl.innerHTML = (insights.skills.common || []).map(s => {
            const name = typeof s === 'object' ? s.name : s;
            return `<span class="tag-pill" style="background:#f5f5f5; color:#666">${name}</span>`;
        }).join('') || '<span style="color:#ccc; font-size:12px">暂无通用技能数据</span>';
    }

    // 4. 更新详细图表与洞察（三段式结论）
    if (insights.conclusions) {
        const map = {
            'salary': 'insight-salary',
            'cloud': 'insight-cloud',
            'city': 'insight-city',
            'edu': 'insight-edu',
            'heatmap': 'insight-heatmap',
            'trend': 'insight-trend',
            'company': 'insight-company',
            'demand': 'insight-demand',
            'radar': 'insight-radar'
        };
        for (let [key, id] of Object.entries(map)) {
            const el = document.getElementById(id);
            if (el && insights.conclusions[key]) {
                const c = insights.conclusions[key];
                // 仅抽离核心结论注入到悬浮气泡中，舍弃以往破坏定宽排版的繁琐 Div
                const shortText = typeof c === 'object' && c.finding ? c.finding : String(c);
                el.innerHTML = `<i class="ri-lightbulb-flash-line"></i> ${shortText.replace(/<\/?[^>]+(>|$)/g, "")}`;
            } else if (el) {
                el.style.display = '';
                el.textContent = '分析中...';
            }
        }
    }

    // 5. 渲染决策建议面板 (使用 action_plan)
    dashboardAdviceContext = {
        meta: meta || { stats: {} },
        insights: insights || { market: {}, skills: {} },
        profile: profileSnapshot || dashboardProfileCache || { score: 0, profile: {} }
    };
    if (insights.action_plan) {
        renderDecisionBoard(insights.action_plan);
    } else if (insights.advices && insights.advices.length > 0) {
        // Fallback to old advices if action_plan is missing
        const advicesEl = document.getElementById('dash-advices');
        if (advicesEl) {
            advicesEl.innerHTML = insights.advices.map(a => `
                <div class="advice-item">
                    <div class="advice-icon"><i class="${a.icon}"></i></div>
                    <div class="advice-content">
                        <div class="advice-title">${a.title}</div>
                        <div class="advice-text">${a.text}</div>
                    </div>
                </div>
            `).join('');
        }
    }

    const safeRender = (fn, name, ...args) => {
        try {
            fn(...args);
        } catch (e) {
            console.error(`[Dashboard] 图表渲染失败: ${name}`, e);
        }
    };

    safeRender(renderChart_SalaryDist, 'salary', charts.salary);
    safeRender(renderChart_Cloud, 'cloud', charts.cloud, insights.skills);
    safeRender(renderChart_City, 'city', charts.city);
    safeRender(renderChart_Edu, 'edu', charts.edu);

    // 6. 新增图表
    if (charts.heatmap) safeRender(renderChart_Heatmap, 'heatmap', charts.heatmap);
    if (insights.competitiveness) safeRender(renderChart_Radar, 'radar', insights.competitiveness);

    // 7. 新增高级分析图表
    if (charts.time_trend) safeRender(renderChart_TimeTrend, 'time_trend', charts.time_trend);
    if (charts.company) safeRender(renderChart_Company, 'company', charts.company);
    if (insights.demand_index) safeRender(renderChart_DemandIndex, 'demand', insights.demand_index);
    renderDashboardChartConclusions(meta, insights, charts, profileSnapshot || dashboardProfileCache || { score: 0, profile: {} });
}

function setDashboardInsightText(id, text) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = text || '暂无可解释结论';
}

function renderDashboardChartConclusions(meta, insights, charts, profileSnapshot) {
    const salaryRange = ((charts || {}).salary || {}).range_dist || {};
    const salaryLabels = Array.isArray(salaryRange.labels) ? salaryRange.labels : [];
    const salaryValues = Array.isArray(salaryRange.values) ? salaryRange.values : [];
    if (salaryLabels.length && salaryValues.length) {
        const idx = salaryValues.indexOf(Math.max(...salaryValues));
        const mainRange = salaryLabels[idx] || '主流区间';
        setDashboardInsightText('insight-salary', `薪资分布：${mainRange} 区间岗位占比最高，建议优先匹配该薪资带的岗位。`);
    } else {
        setDashboardInsightText('insight-salary', '薪资分布：暂无有效样本，建议放宽条件后重试。');
    }

    const radarVals = Array.isArray(((insights || {}).competitiveness || {}).values) ? insights.competitiveness.values : [];
    if (radarVals.length) {
        const avgRadar = Math.round(radarVals.reduce((a, b) => a + Number(b || 0), 0) / radarVals.length);
        const level = avgRadar >= 70 ? '较强' : (avgRadar >= 55 ? '中等' : '偏弱');
        setDashboardInsightText('insight-radar', `能力雷达：综合能力 ${avgRadar}/100（${level}），建议优先补齐最低维度。`);
    } else {
        setDashboardInsightText('insight-radar', '能力雷达：暂无可计算的画像维度。');
    }

    const city = (charts || {}).city || {};
    const cityLabels = Array.isArray(city.labels) ? city.labels : [];
    const cityAvg = Array.isArray(city.avg) ? city.avg : [];
    if (cityLabels.length && cityAvg.length) {
        const pairs = cityLabels.map((name, i) => ({ name, avg: Number(cityAvg[i] || 0) })).filter(x => x.avg > 0).sort((a, b) => b.avg - a.avg);
        const best = pairs[0];
        const info = getDashboardProfileInfo(profileSnapshot);
        if (best) {
            if (info.expected > 0) {
                const diff = best.avg - info.expected;
                const diffTxt = diff >= 0 ? `高于你的期望约 ¥${Math.abs(diff).toLocaleString()}` : `低于你的期望约 ¥${Math.abs(diff).toLocaleString()}`;
                setDashboardInsightText('insight-city', `城市薪资：${best.name} 均薪最高（¥${best.avg.toLocaleString()}），${diffTxt}。`);
            } else {
                setDashboardInsightText('insight-city', `城市薪资：${best.name} 均薪最高（¥${best.avg.toLocaleString()}），建议与目标城市一起比较。`);
            }
        }
    } else {
        setDashboardInsightText('insight-city', '城市薪资：暂无城市样本。');
    }

    const edu = (charts || {}).edu || {};
    const eduLabels = Array.isArray(edu.labels) ? edu.labels : [];
    const eduValues = Array.isArray(edu.values) ? edu.values : [];
    if (eduLabels.length && eduValues.length) {
        const ePairs = eduLabels.map((name, i) => ({ name, avg: Number(eduValues[i] || 0) })).filter(x => x.avg > 0).sort((a, b) => b.avg - a.avg);
        const bestEdu = ePairs[0];
        setDashboardInsightText('insight-edu', `学历薪资：${bestEdu ? bestEdu.name : '该维度'} 对应均薪领先，作为学习投入回报参考。`);
    } else {
        setDashboardInsightText('insight-edu', '学历薪资：暂无可用数据。');
    }

    const heat = (charts || {}).heatmap || {};
    const heatCityEdu = heat.city_edu || {};
    const heatData = Array.isArray(heatCityEdu.data) ? heatCityEdu.data : [];
    if (heatData.length) {
        const top = heatData.slice().sort((a, b) => Number(b[2] || 0) - Number(a[2] || 0))[0];
        const cities = Array.isArray(heatCityEdu.cities) ? heatCityEdu.cities : [];
        const edus = Array.isArray(heatCityEdu.edus) ? heatCityEdu.edus : [];
        const cName = cities[Number(top[0] || 0)] || '未知城市';
        const eName = edus[Number(top[1] || 0)] || '未知学历';
        setDashboardInsightText('insight-heatmap', `交叉热力：${cName} × ${eName} 组合薪资较高，建议优先匹配相关岗位。`);
    } else {
        setDashboardInsightText('insight-heatmap', '交叉热力：暂无足够样本生成有效结论。');
    }

    const highSkills = Array.isArray(((insights || {}).skills || {}).high_value) ? insights.skills.high_value : [];
    if (highSkills.length) {
        const star = highSkills.slice().sort((a, b) => Number((b.avg_salary || 0)) - Number((a.avg_salary || 0)))[0];
        setDashboardInsightText('insight-cloud', `技能价值：${star.name || '核心技能'} 在“频率-薪资”矩阵中价值突出，建议优先补齐。`);
    } else {
        setDashboardInsightText('insight-cloud', '技能价值：暂无技能溢价数据。');
    }

    const time = (charts || {}).time_trend || {};
    const tLabels = Array.isArray(time.labels) ? time.labels : [];
    const tCount = Array.isArray(time.job_counts) ? time.job_counts : [];
    const tSalary = Array.isArray(time.salary_trend) ? time.salary_trend : [];
    if (tLabels.length && tCount.length) {
        const cStart = Number(tCount[0] || 0);
        const cEnd = Number(tCount[tCount.length - 1] || 0);
        const sStart = Number(tSalary[0] || 0);
        const sEnd = Number(tSalary[tSalary.length - 1] || 0);
        const cPct = cStart > 0 ? Math.round(((cEnd - cStart) / cStart) * 100) : 0;
        const sPct = sStart > 0 ? Math.round(((sEnd - sStart) / sStart) * 100) : 0;
        setDashboardInsightText('insight-trend', `趋势联动：岗位量${cPct >= 0 ? '↑' : '↓'}${Math.abs(cPct)}%，均薪${sPct >= 0 ? '↑' : '↓'}${Math.abs(sPct)}%，可据此调整投递时机。`);
    } else {
        setDashboardInsightText('insight-trend', '趋势联动：暂无时序数据。');
    }

    const comp = (charts || {}).company || {};
    const rank = Array.isArray(comp.salary_rank) ? comp.salary_rank : [];
    if (rank.length) {
        const topComp = rank[0] || {};
        setDashboardInsightText('insight-company', `企业薪资：${topComp.name || '头部企业'}均薪约 ¥${Number(topComp.avg || 0).toLocaleString()}，可优先关注。`);
    } else {
        setDashboardInsightText('insight-company', '企业薪资：暂无可比较样本。');
    }

    const cats = Array.isArray(((insights || {}).demand_index || {}).categories) ? insights.demand_index.categories : [];
    if (cats.length) {
        const cat = cats[0] || {};
        setDashboardInsightText('insight-demand', `需求热度：${cat.name || '热门方向'} 热度指数 ${Number(cat.heat_index || 0)}，建议纳入主申池。`);
    } else {
        setDashboardInsightText('insight-demand', '需求热度：暂无岗位类别热度数据。');
    }
}

function renderChart_SalaryDist(data) {
    const chart = dashCharts['chart-salary-dist'];
    if (!chart) return;
    const expLabels = Array.isArray((data || {}).exp_trend?.labels) ? data.exp_trend.labels : [];
    const expValues = Array.isArray((data || {}).exp_trend?.values) ? data.exp_trend.values : [];
    const rangeLabels = Array.isArray((data || {}).range_dist?.labels) ? data.range_dist.labels : [];
    const rangeValues = Array.isArray((data || {}).range_dist?.values) ? data.range_dist.values : [];
    const hasExp = expLabels.length > 0 && expValues.some(v => Number(v || 0) > 0);
    const hasRange = rangeLabels.length > 0 && rangeValues.some(v => Number(v || 0) > 0);
    const insightEl = document.getElementById('insight-salary');

    if (hasExp) {
        if (insightEl) insightEl.textContent = '按经验分层：用于判断你的经验区间薪资位置。';
        chart.setOption({
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                borderColor: 'rgba(16, 185, 129, 0.2)',
                textStyle: { color: '#1f2937' },
                extraCssText: 'box-shadow: 0 4px 15px rgba(0,0,0,0.08); border-radius: 8px;'
            },
            legend: { bottom: 0 },
            grid: { left: '3%', right: '4%', bottom: '10%', containLabel: true },
            xAxis: { type: 'category', data: expLabels, axisLine: { lineStyle: { color: '#ddd' } } },
            yAxis: [{ type: 'value', name: '平均薪资', splitLine: { lineStyle: { type: 'dashed', color: '#f0f0f0' } } }],
            series: [{
                name: '经验薪资趋势',
                type: 'line',
                smooth: true,
                data: expValues,
                itemStyle: { color: '#10b981' },
                lineStyle: { width: 4, shadowColor: 'rgba(16,185,129,0.3)', shadowBlur: 10, shadowOffsetY: 5 },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(16, 185, 129, 0.6)' }, { offset: 1, color: 'rgba(16, 185, 129, 0.02)' }])
                },
                markPoint: { data: [{ type: 'max', name: '最高峰' }, { type: 'min', name: '起步点' }], itemStyle: { color: '#059669' } }
            }]
        }, true);
        return;
    }

    if (hasRange) {
        if (insightEl) insightEl.textContent = '按薪资区间分布：用于判断主流薪资档位。';
        chart.setOption({
            tooltip: { trigger: 'axis' },
            grid: { left: '3%', right: '4%', bottom: '10%', containLabel: true },
            xAxis: { type: 'category', data: rangeLabels, axisLabel: { rotate: rangeLabels.length > 6 ? 25 : 0 } },
            yAxis: [{ type: 'value', name: '岗位数量' }],
            series: [{
                name: '区间岗位数',
                type: 'bar',
                data: rangeValues,
                barWidth: '55%',
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: '#3b82f6' }, { offset: 1, color: '#93c5fd' }]),
                    borderRadius: [6, 6, 0, 0]
                }
            }]
        }, true);
        return;
    }

    if (insightEl) insightEl.textContent = '暂无薪资数据，请放宽筛选或先采集/导入数据。';
    chart.setOption({
        title: { text: '暂无薪资趋势数据', left: 'center', top: 'center', textStyle: { color: '#ccc', fontSize: 14 } },
        xAxis: { show: false }, yAxis: { show: false }, series: []
    }, true);
}

let dashboardCurrentActions = [];
let dashboardActionRuntimeMap = {};
let dashboardAdviceContext = {
    meta: { stats: {} },
    insights: { market: {}, skills: {} },
    profile: { score: 0, profile: {} }
};

function _dashboardActionStateStore() {
    const key = 'dashboard_action_states_v1';
    try {
        const raw = localStorage.getItem(key);
        const parsed = raw ? JSON.parse(raw) : {};
        if (parsed && typeof parsed === 'object') return parsed;
    } catch (e) {
        console.warn('读取行动状态失败', e);
    }
    return {};
}

function _saveDashboardActionStateStore(store) {
    try {
        localStorage.setItem('dashboard_action_states_v1', JSON.stringify(store || {}));
    } catch (e) {
        console.warn('保存行动状态失败', e);
    }
}

function _hashText(text) {
    let hash = 0;
    const s = String(text || '');
    for (let i = 0; i < s.length; i++) {
        hash = ((hash << 5) - hash + s.charCodeAt(i)) >>> 0;
    }
    return hash.toString(16);
}

function _buildDashboardActionId(action, idx) {
    return `a_${idx}_${_hashText(`${action?.type || ''}|${action?.title || ''}|${action?.desc || ''}`)}`;
}

function _normalizePriority(raw) {
    const v = String(raw || '').toLowerCase();
    if (v.includes('high') || v.includes('高')) return 'high';
    if (v.includes('low') || v.includes('低')) return 'low';
    return 'medium';
}

function _priorityMeta(level) {
    if (level === 'high') {
        return { label: '高优先', color: '#ef4444', bg: '#fff1f0', border: '#fecaca' };
    }
    if (level === 'low') {
        return { label: '低优先', color: '#2563eb', bg: '#f0f7ff', border: '#bfdbfe' };
    }
    return { label: '中优先', color: '#f59e0b', bg: '#fff7e6', border: '#fde68a' };
}

function _dashboardActionDueText(action, level) {
    const now = new Date();
    const due = new Date(now);
    const t = String(action?.type || '');
    if (t === 'timing' || level === 'high') due.setDate(now.getDate() + 1);
    else if (t === 'market') due.setDate(now.getDate() + 3);
    else if (t === 'skill') due.setDate(now.getDate() + 7);
    else due.setDate(now.getDate() + 5);
    return `建议完成：${due.getMonth() + 1}/${due.getDate()}`;
}

function _dashboardActionQuickAction(action) {
    const t = String(action?.type || '');
    if (t === 'skill') {
        return {
            label: '去补齐画像',
            run: () => {
                switchTab('profile');
                setTimeout(() => {
                    if (typeof switchProfileSubTab === 'function') switchProfileSubTab('gap');
                }, 120);
            }
        };
    }
    if (t === 'market') {
        return {
            label: '去岗位决策',
            run: () => switchTab('data')
        };
    }
    if (t === 'timing') {
        return {
            label: '去数据采集',
            run: () => switchTab('spider')
        };
    }
    return {
        label: '去投递执行',
        run: () => switchTab('applications')
    };
}

function _dashboardConfidenceText(sampleSize, marketScore) {
    if (sampleSize >= 800 && marketScore >= 40) return '高';
    if (sampleSize >= 300) return '中';
    return '低';
}

function _estimateActionImpact(action, ctx) {
    const meta = (ctx || {}).meta || {};
    const insights = (ctx || {}).insights || {};
    const profile = (ctx || {}).profile || {};
    const sampleSize = Number((meta.stats || {}).count || 0);
    const marketScore = Number((insights.market || {}).score || 0);
    const profileScore = Number(profile.score || 0);
    const skillCount = Array.isArray((insights.skills || {}).high_value) ? insights.skills.high_value.length : 0;
    const t = String(action?.type || '');

    if (t === 'skill') {
        const gain = Math.max(4, Math.min(16, Math.round(6 + skillCount * 0.8 + (70 - profileScore) / 12)));
        return {
            gainText: `预计收益：岗位匹配度 +${gain} 分`,
            reasonText: '依据：技能缺口与高价值技能重合度',
            confidence: _dashboardConfidenceText(sampleSize, marketScore)
        };
    }
    if (t === 'market') {
        const gain = Math.max(6, Math.min(22, Math.round(8 + sampleSize / 180)));
        return {
            gainText: `预计收益：有效投递命中率 +${gain}%`,
            reasonText: '依据：热点方向岗位供给与热度指数',
            confidence: _dashboardConfidenceText(sampleSize, marketScore)
        };
    }
    if (t === 'timing') {
        const gain = Math.max(80, Math.min(400, Math.round(120 + sampleSize * 0.25)));
        return {
            gainText: `预计收益：可分析样本 +${gain} 条`,
            reasonText: '依据：当前样本规模与采集补齐建议',
            confidence: sampleSize >= 300 ? '中' : '高'
        };
    }
    const gain = Math.max(5, Math.min(18, Math.round(7 + (marketScore / 18))));
    return {
        gainText: `预计收益：决策确定性 +${gain}%`,
        reasonText: '依据：市场稳定度与画像完成度',
        confidence: _dashboardConfidenceText(sampleSize, marketScore)
    };
}

function runDashboardAction(actionId) {
    const runtime = dashboardActionRuntimeMap[actionId];
    if (!runtime) return;
    const qa = _dashboardActionQuickAction(runtime.action);
    qa.run();
}

function setDashboardActionStatus(actionId, status) {
    const runtime = dashboardActionRuntimeMap[actionId];
    if (!runtime) return;
    const store = _dashboardActionStateStore();
    const prev = store[actionId] || {};
    store[actionId] = {
        status: status || 'todo',
        createdAt: prev.createdAt || Date.now(),
        updatedAt: Date.now(),
        title: runtime.action?.title || ''
    };
    _saveDashboardActionStateStore(store);
    renderDecisionBoard(dashboardCurrentActions);
}

function renderDecisionBoard(actions) {
    const container = document.getElementById('dash-advices');
    if (!container) return;

    if (!actions || actions.length === 0) {
        container.innerHTML = '<div class="advice-placeholder">暂无个性化建议，请完善画像或补充数据后重试。</div>';
        return;
    }

    dashboardCurrentActions = Array.isArray(actions) ? actions : [];
    dashboardActionRuntimeMap = {};
    const store = _dashboardActionStateStore();
    const parseFn = typeof marked !== 'undefined' ? marked.parseInline : (t => t);

    const ranked = dashboardCurrentActions
        .map((a, idx) => ({ ...a, _idx: idx, _level: _normalizePriority(a.priority) }))
        .sort((a, b) => {
            const rank = { high: 3, medium: 2, low: 1 };
            return (rank[b._level] || 0) - (rank[a._level] || 0);
        });
    const profileInfo = getDashboardProfileInfo((dashboardAdviceContext || {}).profile);

    let doneCount = 0;
    const cards = ranked.map((act, i) => {
        const actionId = _buildDashboardActionId(act, i);
        const st = store[actionId]?.status || 'todo';
        if (st === 'done') doneCount += 1;
        const meta = _priorityMeta(act._level);
        const qa = _dashboardActionQuickAction(act);
        const impact = _estimateActionImpact(act, dashboardAdviceContext);
        const icon = act.type === 'timing'
            ? 'ri-calendar-event-line'
            : (act.type === 'skill' ? 'ri-vip-diamond-line' : 'ri-radar-line');
        const statusLabel = st === 'done' ? '已完成' : (st === 'doing' ? '进行中' : '待执行');
        const statusClass = st === 'done' ? 'is-done' : (st === 'doing' ? 'is-doing' : 'is-todo');
        dashboardActionRuntimeMap[actionId] = { action: act };

        return `
        <div class="dash-action-card ${statusClass}" style="border-left-color:${meta.color}; background:${meta.bg}; border-color:${meta.border};">
            <div class="dash-action-head">
                <div class="dash-action-title-wrap">
                    <i class="${icon}" style="color:${meta.color};"></i>
                    <div class="dash-action-title">${act.title || '行动建议'}</div>
                </div>
                <div class="dash-action-badges">
                    <span class="dash-action-priority" style="background:${meta.color};">${meta.label}</span>
                    <span class="dash-action-status">${statusLabel}</span>
                </div>
            </div>
            <div class="dash-action-desc">${parseFn(act.desc || '')}</div>
            <div class="dash-action-impact">
                <span class="dash-impact-gain">${impact.gainText}</span>
                <span class="dash-impact-confidence">置信度：${impact.confidence}</span>
                <span class="dash-impact-reason">${impact.reasonText}</span>
            </div>
            <div class="dash-action-foot">
                <span class="dash-action-due">${_dashboardActionDueText(act, act._level)}</span>
                <div class="dash-action-ops">
                    <button class="btn btn-default btn-sm" onclick="setDashboardActionStatus('${actionId}','doing')">开始执行</button>
                    <button class="btn btn-primary btn-sm" onclick="runDashboardAction('${actionId}')">${qa.label}</button>
                    <button class="btn btn-default btn-sm" onclick="setDashboardActionStatus('${actionId}','done')">标记完成</button>
                </div>
            </div>
        </div>`;
    }).join('');

    container.innerHTML = `
        <div class="dash-action-summary">
            <span>执行进度：${doneCount}/${ranked.length}</span>
            <span>针对你：${profileInfo.targetJob} · ${profileInfo.exp} · ${profileInfo.expectedText}</span>
        </div>
        <div style="margin:-4px 0 10px; font-size:12px; color:#64748b;">说明：建议来自市场数据与画像匹配结果，按优先级从高到低排序。</div>
        ${cards}
    `;
}

async function renderSalaryChart() {
    if (!charts.c3) return;
    try {
        const r = await fetch('/api/stats/advanced', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dashboardState)
        });
        const d = await r.json();

        // Empty State Check
        if (d.salary_dist.labels.length === 0) {
            [charts.c3, charts['c3-trend']].forEach(c => {
                c && c.setOption({
                    backgroundColor: '#fff',
                    title: { text: '暂无薪资数据', left: 'center', top: 'center', textStyle: { color: '#999' } },
                    series: [], xAxis: { show: false }, yAxis: { show: false }
                }, true);
            });
            return;
        }

        const option = {
            tooltip: { trigger: 'item' },
            legend: { top: '5%', left: 'center' },
            series: [{
                name: '薪资分布',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
                label: { show: false, position: 'center' },
                emphasis: { label: { show: true, fontSize: 40, fontWeight: 'bold' } },
                data: d.salary_dist.labels.map((l, i) => ({ value: d.salary_dist.values[i], name: l }))
            }]
        };
        charts.c3.setOption(option);
        bindChartClick(charts.c3, 'switch-sync-c3', '同步薪资');

        if (charts['c3-trend']) {
            const opt2 = {
                tooltip: { trigger: 'axis' },
                grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
                xAxis: { type: 'category', data: d.exp_salary.labels },
                yAxis: { type: 'value', name: '平均月薪(元)' },
                series: [{
                    data: d.exp_salary.values,
                    type: 'line',
                    smooth: true,
                    areaStyle: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(37, 99, 235, 0.8)' }, { offset: 1, color: 'rgba(37, 99, 235, 0.05)' }])
                    }
                }]
            };
            charts['c3-trend'].setOption(opt2);
        }

    } catch (e) { console.error(e); }
}
// ========== 新增：时间趋势图（双轴折线） ==========
function renderChart_TimeTrend(data) {
    const chart = dashCharts['chart-time-trend'];
    if (!chart) return;

    const labels = Array.isArray((data || {}).labels) ? data.labels : [];
    const jobCounts = Array.isArray((data || {}).job_counts) ? data.job_counts.map(v => Number(v || 0)) : [];
    const salaryTrend = Array.isArray((data || {}).salary_trend) ? data.salary_trend.map(v => Number(v || 0)) : [];

    if (!labels.length || !jobCounts.length) {
        chart.setOption({
            title: { text: '暂无时间趋势数据', left: 'center', top: 'center', textStyle: { color: '#ccc', fontSize: 14 } },
            xAxis: { show: false }, yAxis: { show: false }, series: []
        }, true);
        setDashboardInsightText('insight-trend', '趋势联动：暂无发布时间数据，请先采集或导入含日期的岗位。');
        return;
    }

    const totalJobs = jobCounts.reduce((a, b) => a + Number(b || 0), 0);
    const avgPerPeriod = labels.length ? Math.round(totalJobs / labels.length) : 0;
    const firstJobs = Number(jobCounts[0] || 0);
    const lastJobs = Number(jobCounts[jobCounts.length - 1] || 0);
    const jobsChange = firstJobs > 0 ? Math.round(((lastJobs - firstJobs) / firstJobs) * 100) : 0;
    const firstSalary = Number(salaryTrend[0] || 0);
    const lastSalary = Number(salaryTrend[salaryTrend.length - 1] || 0);
    const salaryChange = firstSalary > 0 ? Math.round(((lastSalary - firstSalary) / firstSalary) * 100) : 0;
    setDashboardInsightText('insight-trend', `趋势联动：场均发布 ${avgPerPeriod} 岗，岗位量${jobsChange >= 0 ? '上升' : '回落'}${Math.abs(jobsChange)}%，薪资${salaryChange >= 0 ? '上行' : '回调'}${Math.abs(salaryChange)}%。`);

    chart.setOption({
        tooltip: { trigger: 'axis', axisPointer: { type: 'cross' } },
        legend: { data: ['岗位发布量', '平均薪资'], bottom: 0, textStyle: { fontSize: 11 } },
        grid: { left: '3%', right: '4%', bottom: '15%', top: '8%', containLabel: true },
        xAxis: { type: 'category', data: labels, axisLabel: { fontSize: 10, rotate: labels.length > 10 ? 30 : 0 } },
        yAxis: [
            { type: 'value', name: '岗位数', splitLine: { lineStyle: { type: 'dashed' } } },
            { type: 'value', name: '薪资(元)', splitLine: { show: false } }
        ],
        series: [
            {
                name: '岗位发布量', type: 'bar', data: jobCounts,
                itemStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: '#93c5fd' }, { offset: 1, color: '#3b82f6' }]), borderRadius: [4, 4, 0, 0] },
                barWidth: '40%'
            },
            {
                name: '平均薪资', type: 'line', yAxisIndex: 1, data: salaryTrend,
                smooth: true, symbol: 'circle', symbolSize: 6,
                itemStyle: { color: '#ef4444' },
                lineStyle: { width: 2 },
                areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(239,68,68,0.2)' }, { offset: 1, color: 'rgba(239,68,68,0)' }]) }
            }
        ]
    }, true);
}

// ========== 新增：企业维度分析图 ==========
function renderChart_Company(data) {
    const chart = dashCharts['chart-company'];
    if (!chart) return;
    const salaryRank = Array.isArray((data || {}).salary_rank) ? data.salary_rank : [];
    const sizeDist = Array.isArray((data || {}).size_dist) ? data.size_dist : [];

    if (!salaryRank.length && !sizeDist.length) {
        chart.setOption({
            title: { text: '暂无企业维度数据', left: 'center', top: 'center', textStyle: { color: '#ccc', fontSize: 14 } },
            xAxis: { show: false }, yAxis: { show: false }, series: []
        }, true);
        const el = document.getElementById('insight-company');
        if (el) el.textContent = '暂无企业数据';
        return;
    }

    // 更新洞察文案
    const el = document.getElementById('insight-company');
    if (el && salaryRank.length > 0) {
        const top = salaryRank[0];
        const topAvg = Number(top.avg || 0);
        const topCount = Number(top.count || 0);
        el.textContent = `薪资领先企业：${top.name || '未知企业'}（均薪 ¥${topAvg.toLocaleString()}，${topCount}个岗位）`;
    }

    // 优先展示企业薪资排行（更有决策价值）
    if (salaryRank.length > 0) {
        const names = salaryRank.map(r => r.name).reverse();
        const values = salaryRank.map(r => Number(r.avg || 0)).reverse();
        const counts = salaryRank.map(r => Number(r.count || 0)).reverse();

        chart.setOption({
            tooltip: { trigger: 'axis', formatter: function (p) { return `${p[0].name}<br/>均薪: ¥${p[0].value.toLocaleString()}<br/>岗位数: ${counts[p[0].dataIndex]}`; } },
            grid: { left: '3%', right: '10%', bottom: '3%', top: '3%', containLabel: true },
            xAxis: { type: 'value', show: false },
            yAxis: { type: 'category', data: names, axisLabel: { fontSize: 10, width: 80, overflow: 'truncate' } },
            series: [{
                type: 'bar', data: values,
                label: { show: true, position: 'right', formatter: '¥{c}', fontSize: 10 },
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [{ offset: 0, color: '#8b5cf6' }, { offset: 1, color: '#c4b5fd' }]),
                    borderRadius: [0, 4, 4, 0]
                },
                barWidth: 12
            }]
        }, true);
    } else if (sizeDist.length > 0) {
        // 若无薪资排行则展示规模分布
        chart.setOption({
            tooltip: { trigger: 'item', formatter: '{b}: {c}个岗位 ({d}%)' },
            series: [{
                type: 'pie', radius: ['30%', '65%'],
                data: sizeDist,
                itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
                label: { formatter: '{b}\n{d}%', fontSize: 11 },
                emphasis: { label: { fontSize: 14, fontWeight: 'bold' } }
            }]
        }, true);
    }
}

// ========== 新增：供需热度指数图 ==========
function renderChart_DemandIndex(data) {
    const chart = dashCharts['chart-demand'];
    if (!chart) return;

    const categories = Array.isArray((data || {}).categories) ? data.categories : [];
    if (!categories.length) {
        chart.setOption({
            title: { text: '暂无供需数据', left: 'center', top: 'center', textStyle: { color: '#ccc', fontSize: 14 } },
            xAxis: { show: false }, yAxis: { show: false }, series: []
        }, true);
        const el = document.getElementById('insight-demand');
        if (el) el.textContent = '暂无岗位类别数据';
        return;
    }

    const totalCount = categories.reduce((sum, c) => sum + Number(c.count || 0), 0);
    const cats = categories.slice(0, 10).map(c => {
        const heat = Number(c.heat_index || 0);
        const count = Number(c.count || 0);
        const percent = c.percent !== undefined ? Number(c.percent) : (totalCount > 0 ? (count / totalCount * 100) : 0);
        const competition = c.competition || (heat >= 75 ? '激烈' : (heat >= 50 ? '适中' : '可投'));
        return {
            ...c,
            heat_index: heat,
            count,
            percent: Number.isFinite(percent) ? percent.toFixed(1) : '0.0',
            competition,
            avg_salary: Number(c.avg_salary || 0)
        };
    });

    // 更新洞察文案
    const el = document.getElementById('insight-demand');
    if (el) {
        const hottest = cats[0];
        el.textContent = hottest
            ? `最热岗位「${hottest.name}」热度指数 ${hottest.heat_index}，竞争度：${hottest.competition}`
            : '暂无岗位类别数据';
    }

    const names = cats.map(c => c.name).reverse();
    const heatValues = cats.map(c => c.heat_index).reverse();
    const colors = cats.map(c => {
        if (c.competition === '激烈') return '#ef4444';
        if (c.competition === '适中') return '#f59e0b';
        return '#10b981';
    }).reverse();

    chart.setOption({
        tooltip: {
            trigger: 'axis',
            formatter: function (p) {
                const idx = cats.length - 1 - p[0].dataIndex;
                const c = cats[idx];
                return `<b>${c.name}</b><br/>热度指数: ${c.heat_index}<br/>岗位数: ${c.count}（占比${c.percent}%）<br/>均薪: ¥${c.avg_salary.toLocaleString()}<br/>竞争度: ${c.competition}`;
            }
        },
        grid: { left: '3%', right: '12%', bottom: '3%', top: '3%', containLabel: true },
        xAxis: { type: 'value', name: '热度指数', max: 100, splitLine: { lineStyle: { type: 'dashed' } } },
        yAxis: { type: 'category', data: names, axisLabel: { fontSize: 10, width: 70, overflow: 'truncate' } },
        series: [{
            type: 'bar', data: heatValues.map((v, i) => ({ value: v, itemStyle: { color: colors[i] } })),
            label: { show: true, position: 'right', formatter: '{c}', fontSize: 10, color: '#666' },
            barWidth: 14,
            itemStyle: { borderRadius: [0, 6, 6, 0] }
        }]
    }, true);
}

function renderChart_Cloud(data, skillInsights) {
    const chart = dashCharts['chart-cloud-dash'];
    if (!chart) return;

    const cloudList = Array.isArray(data) ? data : [];
    const highValue = Array.isArray(skillInsights?.high_value) ? skillInsights.high_value : [];
    const cloudFreqMap = new Map();
    cloudList.forEach(x => {
        const name = String((x || {}).name || '').trim();
        const value = Number((x || {}).value || 0);
        if (!name || value <= 0) return;
        cloudFreqMap.set(name, value);
    });

    const rows = highValue.map(s => {
        const name = String((s || {}).name || '').trim();
        const count = Number((s || {}).count || cloudFreqMap.get(name) || 0);
        const avgSalary = Number((s || {}).avg_salary || 0);
        const premium = Number((s || {}).premium || 0);
        if (!name || count <= 0 || avgSalary <= 0) return null;
        return { name, count, avgSalary, premium };
    }).filter(Boolean);

    if (!rows.length) {
        chart.setOption({
            title: { text: '暂无技能价值数据', left: 'center', top: 'center', textStyle: { color: '#ccc', fontSize: 14 } },
            xAxis: { show: false }, yAxis: { show: false }, series: []
        }, true);
        setDashboardInsightText('insight-cloud', '技能价值：暂无数据，无法构建频率-薪资矩阵。');
        return;
    }

    const avgCount = rows.reduce((sum, s) => sum + s.count, 0) / rows.length;
    const avgSalary = rows.reduce((sum, s) => sum + s.avgSalary, 0) / rows.length;
    const sortedByCount = rows.slice().sort((a, b) => b.count - a.count);
    const maxCount = sortedByCount[0] ? sortedByCount[0].count : 1;

    const seriesData = rows.map(s => {
        let color = '#94a3b8';
        if (s.count >= avgCount && s.avgSalary >= avgSalary) color = '#ef4444';   // 热门高价值
        else if (s.count >= avgCount) color = '#3b82f6';                           // 高频基础
        else if (s.avgSalary >= avgSalary) color = '#f59e0b';                      // 低频高薪
        return { name: s.name, value: [s.count, s.avgSalary, s.premium], itemStyle: { color } };
    });

    const option = {
        tooltip: {
            trigger: 'item',
            formatter: function (p) {
                const d = p.data;
                return `<b>${d.name}</b><br/>出现频次: ${d.value[0]} 次<br/>平均薪资: ¥${Number(d.value[1] || 0).toLocaleString()}<br/>薪资溢价: ${Number(d.value[2] || 0)}%`;
            }
        },
        grid: { left: '3%', right: '10%', bottom: '8%', top: '8%', containLabel: true },
        xAxis: {
            type: 'value', name: '出现频次（需求）', nameLocation: 'middle', nameGap: 25,
            splitLine: { lineStyle: { type: 'dashed', color: '#e2e8f0' } },
            axisLabel: { fontSize: 10, color: '#64748b' }
        },
        yAxis: {
            type: 'value', name: '对应岗位平均薪资（元）', nameLocation: 'middle', nameGap: 42,
            splitLine: { lineStyle: { type: 'dashed', color: '#e2e8f0' } },
            axisLabel: { fontSize: 10, color: '#64748b', formatter: (v) => `${Math.round(Number(v || 0) / 1000)}k` }
        },
        series: [{
            type: 'scatter',
            data: seriesData,
            symbolSize: function (point) {
                const freq = Number(point[0] || 0);
                const ratio = maxCount > 0 ? (freq / maxCount) : 0;
                return Math.max(12, Math.min(34, 12 + ratio * 22));
            },
            label: {
                show: true, formatter: '{b}', position: 'top',
                fontSize: 10, color: '#334155'
            },
            emphasis: { focus: 'series', label: { show: true, fontSize: 13, fontWeight: 'bold' } },
            markLine: {
                silent: true,
                symbol: ['none', 'none'],
                label: { show: false },
                lineStyle: { type: 'solid', color: '#cbd5e1', width: 1 },
                data: [
                    { xAxis: avgCount },
                    { yAxis: avgSalary }
                ]
            }
        }]
    };
    chart.setOption(option, true);

    const hot = rows
        .filter(s => s.count >= avgCount && s.avgSalary >= avgSalary)
        .sort((a, b) => (b.avgSalary - a.avgSalary) || (b.count - a.count))[0];
    const fallback = sortedByCount[0];
    if (hot) {
        setDashboardInsightText('insight-cloud', `技能价值：${hot.name} 同时具备高频与高薪特征（频次 ${hot.count}，均薪 ¥${hot.avgSalary.toLocaleString()}）。`);
    } else if (fallback) {
        setDashboardInsightText('insight-cloud', `技能价值：${fallback.name} 需求最强（频次 ${fallback.count}），建议作为优先补齐项。`);
    }
}

function renderChart_City(data) {
    const chart = dashCharts['chart-city-dash'];
    if (!chart) return;

    if (!data || !data.labels || data.labels.length === 0) {
        chart.setOption({
            title: { text: '暂无城市数据', left: 'center', top: 'center', textStyle: { color: '#ccc', fontSize: 14 } },
            xAxis: { show: false }, yAxis: { show: false }, series: []
        }, true);
        setDashboardInsightText('insight-city', '城市薪资：暂无可比较样本。');
        return;
    }

    const info = getDashboardProfileInfo();
    const expectedSalary = Number(info.expected || 0);
    const rows = (data.labels || []).map((name, idx) => ({
        name: String(name || ''),
        avg: Number((data.avg || [])[idx] || 0),
        count: Number((data.count || [])[idx] || 0)
    })).filter(x => x.name && x.avg > 0);
    rows.sort((a, b) => b.avg - a.avg);
    const top = rows.slice(0, 10);
    const labels = top.map(x => x.name);
    const values = top.map(x => x.avg);

    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: function (params) {
                const p = params && params[0];
                if (!p) return '';
                const idx = Number(p.dataIndex || 0);
                const row = top[idx] || {};
                const avg = Number(row.avg || 0);
                const gap = expectedSalary > 0 ? (avg - expectedSalary) : 0;
                const gapText = expectedSalary > 0
                    ? (gap >= 0 ? `高于期望 ¥${Math.abs(gap).toLocaleString()}` : `低于期望 ¥${Math.abs(gap).toLocaleString()}`)
                    : '未设置期望薪资';
                return `${row.name}<br/>城市均薪：¥${avg.toLocaleString()}<br/>岗位数：${Number(row.count || 0)}<br/>与你的期望：${gapText}`;
            }
        },
        grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
        xAxis: { type: 'value' },
        yAxis: { type: 'category', data: labels, inverse: true },
        series: [{
            type: 'bar',
            data: values.map(v => ({ value: v })),
            itemStyle: {
                color: new echarts.graphic.LinearGradient(1, 0, 0, 0, [{ offset: 0, color: '#2563eb' }, { offset: 1, color: '#60a5fa' }]),
                borderRadius: [0, 6, 6, 0]
            },
            emphasis: { itemStyle: { shadowBlur: 10, shadowColor: 'rgba(37,99,235,0.4)', shadowOffsetX: 2 } },
            label: {
                show: true,
                position: 'right',
                formatter: function (p) {
                    const row = top[Number(p.dataIndex || 0)] || {};
                    const avg = Number(row.avg || 0);
                    if (expectedSalary > 0) {
                        const diff = avg - expectedSalary;
                        const sign = diff >= 0 ? '+' : '-';
                        return `¥${avg.toLocaleString()}  (${sign}${Math.round(Math.abs(diff) / 1000)}k)`;
                    }
                    return `¥${avg.toLocaleString()}`;
                },
                color: '#2563eb',
                fontWeight: 'bold'
            }
        }]
    };
    chart.setOption(option, true);

    if (top.length) {
        const best = top[0];
        if (expectedSalary > 0) {
            const diff = best.avg - expectedSalary;
            const diffText = diff >= 0 ? `高于期望约 ¥${Math.abs(diff).toLocaleString()}` : `低于期望约 ¥${Math.abs(diff).toLocaleString()}`;
            setDashboardInsightText('insight-city', `城市薪资：${best.name} 均薪最高（¥${best.avg.toLocaleString()}），${diffText}。`);
        } else {
            setDashboardInsightText('insight-city', `城市薪资：${best.name} 均薪最高（¥${best.avg.toLocaleString()}），可作为重点城市参考。`);
        }
    }
}

function renderChart_Edu(data) {
    const chart = dashCharts['chart-edu-dash'];
    if (!chart) return;

    const rawLabels = Array.isArray((data || {}).labels) ? data.labels : [];
    const rawValues = Array.isArray((data || {}).values) && data.values.length ? data.values : (Array.isArray((data || {}).counts) ? data.counts : []);
    const pairs = rawLabels.map((label, idx) => ({
        label: String(label || '').trim(),
        value: Number(rawValues[idx])
    })).filter(x => x.label && Number.isFinite(x.value) && x.value > 0);

    if (!pairs.length) {
        chart.clear();
        chart.setOption({
            title: { text: '暂无学历分析数据', left: 'center', top: 'center', textStyle: { color: '#ccc', fontSize: 14 } },
            xAxis: { show: false },
            yAxis: { show: false },
            series: []
        }, true);
        return;
    }

    // 学历分层过少时降级柱图，避免雷达图在单维/双维数据下异常
    if (pairs.length < 3) {
        chart.clear();
        chart.setOption({
            tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
            grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
            xAxis: { type: 'category', data: pairs.map(p => p.label), axisTick: { show: false } },
            yAxis: { type: 'value', splitLine: { lineStyle: { type: 'dashed', color: '#f1f5f9' } } },
            series: [{
                type: 'bar',
                data: pairs.map(p => p.value),
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: '#a78bfa' },
                        { offset: 1, color: '#7c3aed' }
                    ]),
                    borderRadius: [6, 6, 0, 0]
                },
                label: { show: true, position: 'top', color: '#4c1d95', fontSize: 11 }
            }]
        }, true);
        return;
    }

    const values = pairs.map(p => p.value);
    const labels = pairs.map(p => p.label);
    const maxVal = Math.max(...values, 1);
    chart.clear();
    chart.setOption({
        tooltip: { trigger: 'item' },
        radar: {
            indicator: labels.map(l => ({ name: l, max: maxVal * 1.2 })),
            radius: '65%',
            splitNumber: 4,
            splitArea: { areaStyle: { color: ['rgba(250,250,250,0.3)', 'rgba(245,245,245,0.3)'] } },
            axisLine: { lineStyle: { color: '#eee' } },
            splitLine: { lineStyle: { color: '#eee' } }
        },
        series: [{
            type: 'radar',
            data: [{
                value: values,
                name: '学历维度',
                areaStyle: {
                    color: new echarts.graphic.RadialGradient(0.5, 0.5, 0.5, [
                        { offset: 0, color: 'rgba(124, 58, 237, 0.8)' },
                        { offset: 1, color: 'rgba(124, 58, 237, 0.2)' }
                    ])
                },
                lineStyle: { color: '#7c3aed', width: 2, shadowColor: 'rgba(124,58,237,0.5)', shadowBlur: 10 },
                itemStyle: { color: '#7c3aed', borderColor: '#fff', borderWidth: 2 },
                symbol: 'circle',
                symbolSize: 6
            }]
        }]
    }, true);
}

// ========== 新增：热力图渲染 ==========
function renderChart_Heatmap(heatmapData) {
    const container = document.getElementById('chart-heatmap-edu');
    if (!container || !heatmapData || !heatmapData.city_edu) return;

    const ce = heatmapData.city_edu;
    if (!ce.data || ce.data.length === 0) {
        container.innerHTML = '<div style="color:#ccc; text-align:center; padding:60px;">数据不足，无法生成热力图</div>';
        return;
    }

    if (!dashCharts['chart-heatmap-edu']) {
        dashCharts['chart-heatmap-edu'] = echarts.init(container);
    }
    const chart = dashCharts['chart-heatmap-edu'];

    // 计算数据范围
    const values = ce.data.map(d => d[2]);
    const minVal = Math.min(...values);
    const maxVal = Math.max(...values);

    // 兼容后端两种索引顺序: [cityIdx, eduIdx, val] 或 [eduIdx, cityIdx, val]
    const rawData = (ce.data || []).map(row => [Number(row[0]), Number(row[1]), Number(row[2])]);
    const max0 = Math.max(...rawData.map(r => r[0]));
    const max1 = Math.max(...rawData.map(r => r[1]));

    // 判断数组维度的位置以便调换，由于后端给的数据常常不对齐
    const assumedCitiesCount = ce.cities.length;
    const assumedEdusCount = ce.edus.length;

    // 我们强制将[x, y]映射成[cityIdx, eduIdx]
    let mapDataFixed = [];
    if (max0 < assumedEdusCount && max1 < assumedCitiesCount) {
        // 如果第一位索引(0维) 的最大值符合学历数量，第二位(1维)符合城市数量，说明顺序是 [eduIdx, cityIdx, val]
        mapDataFixed = rawData.map(r => [r[1], r[0], r[2]]);
    } else {
        // 否则默认为 [cityIdx, eduIdx, val]
        mapDataFixed = rawData;
    }

    // 城市过多时会挤成细条，保留热度最高的 Top 15 城市提升可读性
    const cityAgg = new Map();
    mapDataFixed.forEach(([cityIdx, eduIdx, val]) => {
        cityAgg.set(cityIdx, (cityAgg.get(cityIdx) || 0) + val);
    });

    // 取最高的前15个或全部
    const topCityIdx = [...cityAgg.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, Math.min(15, ce.cities.length))
        .map(([idx]) => idx);

    const citySet = new Set(topCityIdx);
    const cityLabel = topCityIdx.map(idx => ce.cities[idx]);
    const cityPos = new Map(topCityIdx.map((idx, i) => [idx, i]));

    // 根据新位置组装过滤后的最终网格数据
    const filteredData = mapDataFixed
        .filter(([cityIdx]) => citySet.has(cityIdx))
        .map(([cityIdx, eduIdx, val]) => [cityPos.get(cityIdx), eduIdx, val]);

    const option = {
        tooltip: {
            position: 'top',
            formatter: function (params) {
                const city = cityLabel[params.value[0]];
                const edu = ce.edus[params.value[1]];
                return `${city} · ${edu}<br/>平均薪资: <b>¥${params.value[2].toLocaleString()}</b>`;
            }
        },
        grid: { top: 30, bottom: 80, left: 80, right: 30, containLabel: false },
        xAxis: {
            type: 'category',
            data: cityLabel,
            splitArea: { show: true },
            axisLabel: {
                fontSize: 11,
                interval: 0,
                rotate: cityLabel.length > 7 ? 26 : 0
            }
        },
        yAxis: {
            type: 'category',
            data: ce.edus,
            splitArea: { show: true },
            axisLabel: { fontSize: 12 },
            inverse: true
        },
        visualMap: {
            min: minVal,
            max: maxVal,
            calculable: false,
            orient: 'horizontal',
            left: 'center',
            bottom: 8,
            inRange: {
                color: ['#e0f2fe', '#7dd3fc', '#38bdf8', '#0284c7', '#075985']
            },
            textStyle: { fontSize: 10 },
            itemWidth: 200,
            itemHeight: 12,
            formatter: function (val) { return '¥' + Math.round(val / 1000) + 'k'; }
        },
        series: [{
            type: 'heatmap',
            data: filteredData.filter(d => d[2] > 0),
            label: {
                show: true,
                formatter: function (p) { return Math.round(p.value[2] / 1000) + 'k'; },
                fontSize: 10,
                fontWeight: 600,
                color: '#ffffff'
            },
            itemStyle: { borderColor: '#fff', borderWidth: 2, borderRadius: 4 },
            emphasis: {
                itemStyle: { shadowBlur: 10, shadowColor: 'rgba(0, 0, 0, 0.3)' }
            }
        }]
    };
    chart.setOption(option);
}

// ========== 新增：竞争力雷达图 ==========
function renderChart_Radar(compData) {
    const container = document.getElementById('chart-radar');
    if (!container || !compData || !compData.dimensions || compData.dimensions.length === 0) {
        if (container) container.innerHTML = '<div style="color:#ccc; text-align:center; padding:60px;">数据不足</div>';
        return;
    }

    if (!dashCharts['chart-radar']) {
        dashCharts['chart-radar'] = echarts.init(container);
    }
    const chart = dashCharts['chart-radar'];

    const indicators = compData.dimensions.map(d => ({ name: d, max: 100 }));

    const option = {
        tooltip: {
            trigger: 'item',
            formatter: function (params) {
                let html = '<b>市场竞争力评估</b><br/>';
                params.value.forEach((v, i) => {
                    html += `${compData.dimensions[i]}: <b>${v}</b>/100<br/>`;
                });
                return html;
            }
        },
        radar: {
            indicator: indicators,
            shape: 'polygon',
            splitNumber: 4,
            axisName: { color: '#666', fontSize: 11 },
            splitLine: { lineStyle: { color: ['#e8e8e8'] } },
            splitArea: { show: true, areaStyle: { color: ['rgba(22, 119, 255, 0.02)', 'rgba(22, 119, 255, 0.05)'] } }
        },
        series: [{
            type: 'radar',
            data: [{
                value: compData.values,
                name: '竞争力指数',
                areaStyle: {
                    color: new echarts.graphic.RadialGradient(0.5, 0.5, 0.5, [
                        { offset: 0, color: 'rgba(37, 99, 235, 0.7)' },
                        { offset: 1, color: 'rgba(37, 99, 235, 0.1)' }
                    ])
                },
                lineStyle: { color: '#2563eb', width: 3, shadowColor: 'rgba(37,99,235,0.6)', shadowBlur: 12 },
                itemStyle: { color: '#2563eb', borderColor: '#fff', borderWidth: 2 },
                symbol: 'circle',
                symbolSize: 8
            }]
        }]
    };
    chart.setOption(option);
}

function openAnalysis(i) {
    const d = window.currentAiData[i];
    if (!d) return;
    const jobId = resolveRecommendJobId(d);
    document.getElementById('analysis-modal').style.display = 'flex';
    document.getElementById('modal-title').innerText = d.job_name;
    document.getElementById('modal-company').innerText = '🏢 ' + d.company;
    document.getElementById('modal-salary').innerText = '💰 ' + d.salary_avg;
    document.getElementById('modal-city').innerText = '📍 ' + (d.city || '未知');
    document.getElementById('modal-desc-text').innerText = d.desc || '暂无描述';

    const proc = d.process_analysis || {};
    const missingSkills = Array.isArray(proc.missing_skills) ? proc.missing_skills : [];
    const matchedSkills = Array.isArray(d.matched_skills) ? d.matched_skills : [];

    const skillsDiv = document.getElementById('modal-skills');
    let skillsHtml = '';
    if (matchedSkills.length) matchedSkills.forEach(s => skillsHtml += `<span class="skill-tag matched">✅ ${s}</span>`);
    if (missingSkills.length) missingSkills.forEach(s => skillsHtml += `<span class="skill-tag missing">⚠️ ${s}</span>`);
    skillsDiv.innerHTML = skillsHtml || '<span style="color:#999;font-size:12px;">无技能数据</span>';

    const modalConclusion = d.score > 90 ? '高匹配，建议优先投递'
        : (d.score > 75 ? '匹配度良好，可作为主申岗位' : '存在缺口，建议先补齐后投递');
    const modalReason = `匹配分 ${d.score || 0}，缺失技能 ${missingSkills.slice(0, 3).join('、') || '暂无明显缺口'}。`;
    const modalSuggestion = d.score > 75
        ? `投递时突出已匹配能力，并补充 ${missingSkills.slice(0, 2).join('、') || '项目成果'} 的案例。`
        : `先补齐 ${missingSkills.slice(0, 2).join('、') || '关键技能'}，再作为第二批投递。`;
    document.getElementById('modal-advice').innerHTML = `<b>结论：</b>${modalConclusion}<br><b>原因：</b>${modalReason}<br><b>建议：</b>${modalSuggestion}`;
    const modalActions = document.getElementById('modal-actions');
    if (modalActions) {
        if (jobId > 0) {
            modalActions.innerHTML = `
                <button class="btn btn-default" onclick="gotoDataEvaluateByRec(${i})"><i class="ri-radar-line"></i> 去岗位决策</button>
                <button class="btn btn-default" onclick="addRecToBoard(${i})"><i class="ri-star-line"></i> 收藏到看板</button>
                <button class="btn btn-primary" onclick="markRecApplied(${i})"><i class="ri-send-plane-line"></i> 标记已投递</button>
            `;
        } else {
            modalActions.innerHTML = `<span style="font-size:12px; color:#b45309;">该推荐项缺少岗位ID，暂无法执行投递动作。</span>`;
        }
    }

    const skillRadar = Math.max(0, Math.min(100, Number(proc.skill_match || d.score || 0)));
    const salaryRadar = Math.max(0, Math.min(100, Number(proc.salary_diff || 0) + 50));
    const expGap = Number(((d.gap_analysis || {}).exp_gap_val) || 0);
    const expRadar = Math.max(0, Math.min(100, 100 - Math.max(0, expGap) * 15));
    const matchRadar = Math.max(0, Math.min(100, Number(d.score || 0)));
    const eduRadar = Number(d.edu_score || 70);
    const radar = d.radar || { salary: salaryRadar, match: matchRadar, edu: eduRadar, exp: expRadar, skill: skillRadar };

    if (charts.radar) charts.radar.dispose();
    charts.radar = echarts.init(document.getElementById('radar-chart'));
    charts.radar.setOption({
        radar: {
            indicator: [{ name: '薪资', max: 100 }, { name: '匹配', max: 100 }, { name: '学历', max: 100 }, {
                name: '经验',
                max: 100
            }, { name: '技能', max: 100 }],
            radius: '65%'
        },
        series: [{
            type: 'radar',
            data: [{
                value: [radar.salary, radar.match, radar.edu, radar.exp, radar.skill],
                areaStyle: { color: 'rgba(22,119,255,0.4)' }
            }]
        }]
    });

    if (charts.gaugeScore) charts.gaugeScore.dispose();
    charts.gaugeScore = echarts.init(document.getElementById('gauge-score-chart'));
    charts.gaugeScore.setOption({
        series: [{
            type: 'gauge', radius: '95%', center: ['50%', '65%'],
            detail: { formatter: '{value}%', fontSize: 24 },
            data: [{ value: d.score }]
        }]
    });
}
