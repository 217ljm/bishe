﻿// 6. 智能匹配与深度画像分析双轨交互重构
// =========================================================

let recommendAppMap = {};
const REC_MATCH_SCORE_MAIN = 80;
const REC_MATCH_SCORE_SPRINT = 65;
const REC_SEARCH_HISTORY_KEY = 'recommend_search_history_v1';
const REC_FEEDBACK_KEY = 'recommend_feedback_v1';
let recommendMode = 'quick';
let recommendHistoryTimer = null;

function safeJsonParse(raw, fallback) {
    try {
        const val = JSON.parse(raw || '');
        return val && typeof val === 'object' ? val : fallback;
    } catch (_) {
        return fallback;
    }
}

function escapeHtml(val) {
    return String(val || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function getRecommendFeedbackMap() {
    return safeJsonParse(localStorage.getItem(REC_FEEDBACK_KEY), {});
}

function setRecommendFeedbackMap(mapObj) {
    localStorage.setItem(REC_FEEDBACK_KEY, JSON.stringify(mapObj || {}));
}

function getRecommendHistoryList() {
    const arr = safeJsonParse(localStorage.getItem(REC_SEARCH_HISTORY_KEY), []);
    return Array.isArray(arr) ? arr.filter(Boolean).slice(0, 12) : [];
}

function saveRecommendHistory(keyword) {
    const kw = String(keyword || '').trim();
    if (!kw) return;
    const old = getRecommendHistoryList().filter(x => String(x).trim() !== kw);
    const next = [kw, ...old].slice(0, 12);
    localStorage.setItem(REC_SEARCH_HISTORY_KEY, JSON.stringify(next));
}

function deleteRecommendHistory(keyword) {
    const kw = String(keyword || '').trim();
    if (!kw) return;
    const next = getRecommendHistoryList().filter(x => String(x).trim() !== kw);
    localStorage.setItem(REC_SEARCH_HISTORY_KEY, JSON.stringify(next));
    renderRecommendHistoryDropdown(next);
}

function hideRecommendHistoryDropdown() {
    const panel = document.getElementById('search-history-dropdown');
    if (!panel) return;
    panel.style.display = 'none';
}

function renderRecommendHistoryDropdown(items = null) {
    const panel = document.getElementById('search-history-dropdown');
    if (!panel) return;
    const list = Array.isArray(items) ? items : getRecommendHistoryList();
    if (!list.length) {
        panel.innerHTML = '<div class="history-item" style="color:#94a3b8; cursor:default;"><i class="ri-history-line"></i> 暂无搜索历史</div>';
        panel.style.display = 'block';
        return;
    }
    panel.innerHTML = list.map(kw => `
        <div class="history-item">
            <span class="history-text" onclick="applyRecommendHistoryKeyword('${kw.replace(/'/g, "\\'")}')"><i class="ri-history-line"></i> ${escapeHtml(kw)}</span>
            <button class="history-del-btn" onclick="deleteRecommendHistory('${kw.replace(/'/g, "\\'")}')" title="删除历史"><i class="ri-close-line"></i></button>
        </div>
    `).join('');
    panel.style.display = 'block';
}

function toggleRecommendHistoryDropdown() {
    const panel = document.getElementById('search-history-dropdown');
    if (!panel) return;
    if (panel.style.display === 'block') {
        hideRecommendHistoryDropdown();
        return;
    }
    renderRecommendHistoryDropdown();
}

function applyRecommendHistoryKeyword(keyword) {
    const input = document.getElementById('kw');
    if (!input) return;
    input.value = String(keyword || '').trim();
    hideRecommendHistoryDropdown();
    quickSearch();
}

function scheduleRecommendHistoryHint() {
    const input = document.getElementById('kw');
    if (!input) return;
    clearTimeout(recommendHistoryTimer);
    recommendHistoryTimer = setTimeout(() => {
        const current = String(input.value || '').trim();
        if (!current) renderRecommendHistoryDropdown();
        else hideRecommendHistoryDropdown();
    }, 300);
}

function setRecommendMode(mode) {
    recommendMode = mode === 'deep' ? 'deep' : 'quick';
    const quick = document.getElementById('rec-mode-quick');
    const deep = document.getElementById('rec-mode-deep');
    if (quick) quick.classList.toggle('active', recommendMode === 'quick');
    if (deep) deep.classList.toggle('active', recommendMode === 'deep');
}

function applyFeedbackToRecommendations(list) {
    const rows = Array.isArray(list) ? list : [];
    const fbMap = getRecommendFeedbackMap();
    return rows
        .map(item => {
            const jobId = resolveRecommendJobId(item);
            const fb = fbMap[String(jobId)] || null;
            return { ...item, _feedback: fb };
        })
        .filter(item => !(item._feedback && item._feedback.type === 'not_interested' && item._feedback.hide === true))
        .sort((a, b) => {
            const pa = a._feedback && a._feedback.type === 'not_interested' ? -8 : 0;
            const pb = b._feedback && b._feedback.type === 'not_interested' ? -8 : 0;
            return (Number(b.score || 0) + pb) - (Number(a.score || 0) + pa);
        });
}

function buildRecNaturalReason(item) {
    const proc = (item && item.process_analysis) || {};
    const radar = (item && item.radar) || {};
    const matched = Array.isArray(proc.matched_skills) ? proc.matched_skills.filter(Boolean) : [];
    const missing = Array.isArray(proc.missing_skills) ? proc.missing_skills.filter(Boolean) : [];
    const skillText = matched.length
        ? `与你的技能命中 ${matched.slice(0, 3).join('、')}`
        : `与你的画像标签有较高重合`;
    const salary = Number(item && item.salary_avg || 0);
    const salaryText = salary > 0 ? `薪资约 ¥${salary.toLocaleString()}，处于可投区间` : '薪资信息可作为补充参考';
    const eduScore = Number(radar.edu_match || radar.edu || 0);
    const expScore = Number(radar.exp_match || radar.exp || 0);
    const thresholdText = `学历匹配 ${eduScore}%、经验匹配 ${expScore}%`;
    const gapText = missing.length ? `当前主要缺口：${missing.slice(0, 2).join('、')}` : '硬性门槛缺口较少，可优先评估并投递';
    return `${skillText}；${salaryText}；${thresholdText}；${gapText}。`;
}

function getRecFeedbackReasonPrompt() {
    return '请选择不感兴趣原因：\n1. 薪资不符\n2. 公司不合适\n3. 岗位不匹配\n4. 城市不合适\n\n请输入序号或直接输入原因';
}

function normalizeRecFeedbackReason(raw) {
    const txt = String(raw || '').trim();
    if (!txt) return '';
    if (txt === '1') return '薪资不符';
    if (txt === '2') return '公司不合适';
    if (txt === '3') return '岗位不匹配';
    if (txt === '4') return '城市不合适';
    return txt;
}

function setRecommendFeedback(item, type, reason = '', hide = false) {
    const jobId = resolveRecommendJobId(item);
    if (!jobId) return;
    const map = getRecommendFeedbackMap();
    map[String(jobId)] = {
        type: String(type || '').trim(),
        reason: String(reason || '').trim(),
        hide: !!hide,
        updated_at: new Date().toISOString()
    };
    setRecommendFeedbackMap(map);
}

function removeRecommendFeedback(item) {
    const jobId = resolveRecommendJobId(item);
    if (!jobId) return;
    const map = getRecommendFeedbackMap();
    delete map[String(jobId)];
    setRecommendFeedbackMap(map);
}

async function handleRecommendCandidate(index) {
    const item = (window.currentAiData || [])[index];
    if (!item) return;
    setRecommendFeedback(item, 'candidate', '加入候选', false);
    await addRecToBoard(index);
    window.currentAiData = applyFeedbackToRecommendations(window.currentAiData || []);
    rerenderRecommendCurrentView();
    showToast('已加入候选池，后续将优先推荐相近岗位');
}

function handleRecommendNotInterested(index) {
    const item = (window.currentAiData || [])[index];
    if (!item) return;
    const raw = window.prompt(getRecFeedbackReasonPrompt(), '3');
    if (raw === null) return;
    const reason = normalizeRecFeedbackReason(raw) || '岗位不匹配';
    setRecommendFeedback(item, 'not_interested', reason, true);
    window.currentAiData = applyFeedbackToRecommendations(window.currentAiData || []);
    rerenderRecommendCurrentView();
    showToast(`已记录：不感兴趣（${reason}）`);
}

function toggleRecMatchDetail(detailId, btnEl) {
    const box = document.getElementById(detailId);
    if (!box) return;
    const open = box.style.display !== 'none';
    box.style.display = open ? 'none' : 'block';
    if (btnEl) {
        btnEl.innerHTML = open ? '<i class="ri-arrow-down-s-line"></i> 展开匹配明细' : '<i class="ri-arrow-up-s-line"></i> 收起匹配明细';
    }
}

function renderDeepProgress(container, step = 1, text = '') {
    if (!container) return;
    const labels = ['分析你的画像', '匹配市场样本库', '生成个性化推荐方案'];
    container.innerHTML = `
        <div class="rec-deep-progress-wrap">
            <div class="rec-deep-progress-title">深度分析进行中</div>
            <div class="rec-deep-progress-steps">
                ${labels.map((lb, idx) => {
            const s = idx + 1;
            const cls = s < step ? 'done' : (s === step ? 'active' : '');
            const icon = s < step ? 'ri-check-line' : (s === step ? 'ri-loader-4-line ri-spin' : 'ri-time-line');
            return `<div class="rec-deep-step ${cls}"><i class="${icon}"></i><span>${lb}</span></div>`;
        }).join('')}
            </div>
            <div class="rec-deep-progress-text">${text || '请稍候，正在处理中...'}</div>
        </div>
    `;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function initRecommendUiEnhancements() {
    const kw = document.getElementById('kw');
    const panel = document.getElementById('search-history-dropdown');
    if (kw && !kw.dataset.recHistoryBound) {
        kw.dataset.recHistoryBound = '1';
        kw.addEventListener('input', scheduleRecommendHistoryHint);
        kw.addEventListener('focus', scheduleRecommendHistoryHint);
    }
    if (!window.__recHistoryDocClickBound) {
        window.__recHistoryDocClickBound = true;
        document.addEventListener('click', function (e) {
            const target = e.target;
            const btn = document.querySelector('#tab-ai .rec-history-btn');
            const insidePanel = panel && panel.contains(target);
            const insideInput = kw && kw.contains(target);
            const insideBtn = btn && btn.contains(target);
            if (!insidePanel && !insideInput && !insideBtn) hideRecommendHistoryDropdown();
        });
    }
}

document.addEventListener('DOMContentLoaded', initRecommendUiEnhancements);

function getRecommendItemStatus(item) {
    const jobId = resolveRecommendJobId(item);
    if (!jobId) return { key: 'none', text: '未入看板', tone: '#64748b', bg: '#f8fafc' };
    const app = recommendAppMap[jobId];
    if (!app) return { key: 'none', text: '未入看板', tone: '#64748b', bg: '#f8fafc' };
    const status = String(app.status || '').toLowerCase();
    if (status.includes('offer')) return { key: 'offer', text: 'Offer', tone: '#166534', bg: '#ecfdf5' };
    if (status.includes('interview') || status.includes('面试')) return { key: 'interview', text: '面试邀约', tone: '#1d4ed8', bg: '#eff6ff' };
    if (status.includes('applied') || status.includes('投递') || status.includes('姇')) return { key: 'applied', text: '已投递', tone: '#92400e', bg: '#fffbeb' };
    return { key: 'favorite', text: '已收藏', tone: '#7c3aed', bg: '#f5f3ff' };
}

function rerenderRecommendCurrentView() {
    const resDiv = document.getElementById('ai-res');
    if (!resDiv || resDiv.style.display === 'none') return;
    const list = Array.isArray(window.currentAiData) ? window.currentAiData : [];
    if (!list.length) return;
    if (window.isRecComparison) renderComparisonTable(list, resDiv);
    else renderRecList(list, resDiv, window.currentAiPayload || window.currentAiSummary);
}

async function syncRecommendApplicationMap() {
    try {
        const r = await fetch('/api/applications');
        const d = await r.json();
        if (!d.success) return;
        recommendAppMap = {};
        (d.data || []).forEach(x => {
            if (x && x.job_id) recommendAppMap[Number(x.job_id)] = x;
        });
    } catch (e) {
        console.warn('同步推荐状态失败', e);
    }
}

function renderRecommendBlockedState(payload, container) {
    const gate = (payload || {}).quality_gate || {};
    const blockers = Array.isArray(gate.blockers) ? gate.blockers : [];
    const actions = Array.isArray(gate.actions) ? gate.actions : [];
    container.innerHTML = `
        <div class="empty-state" style="background:#fff7ed; border:1px solid #fed7aa; border-radius:16px; padding:24px;">
            <div style="width:54px; height:54px; border-radius:50%; background:#ffedd5; color:#c2410c; margin:0 auto 14px; display:flex; align-items:center; justify-content:center; font-size:24px;">
                <i class="ri-shield-warning-line"></i>
            </div>
            <div style="font-size:17px; font-weight:700; color:#9a3412;">当前不建议直接生成投递推荐</div>
            <div style="font-size:13px; color:#9a3412; margin-top:8px;">${gate.summary || '数据质量未达到推荐准入门槛。'}</div>
            <div style="margin-top:16px; text-align:left; background:#fff; border-radius:12px; padding:14px;">
                <div style="font-size:13px; font-weight:700; color:#7c2d12; margin-bottom:8px;">主要原因</div>
                ${(blockers.length ? blockers : ['当前数据质量未达标']).map(x => `<div style="font-size:12px; color:#7c2d12; margin-bottom:6px;">• ${x}</div>`).join('')}
            </div>
            <div style="margin-top:12px; text-align:left; background:#fff; border-radius:12px; padding:14px;">
                <div style="font-size:13px; font-weight:700; color:#7c2d12; margin-bottom:8px;">建议先做</div>
                ${(actions.length ? actions : ['先完成数据清洗与补齐，再重新生成推荐']).map(x => `<div style="font-size:12px; color:#7c2d12; margin-bottom:6px;">• ${x}</div>`).join('')}
            </div>
            <div style="display:flex; justify-content:center; gap:10px; margin-top:16px; flex-wrap:wrap;">
                <button class="btn btn-default" onclick="switchTab('data')"><i class="ri-database-2-line"></i> 去数据管理</button>
                <button class="btn btn-default" onclick="switchTab('dashboard')"><i class="ri-line-chart-line"></i> 去市场分析</button>
            </div>
        </div>
    `;
}

// 双轨设计A：快速岗位检索（轻量交互）
async function quickSearch() {
    setRecommendMode('quick');
    const val = document.getElementById('kw').value;
    const resDiv = document.getElementById('ai-res');
    const emptyDiv = document.getElementById('ai-empty-state');
    const ctxBar = document.getElementById('ai-context-bar');

    if (!val) return showToast("请输入职能或技能关键词，例如：Python", "error");
    saveRecommendHistory(val);
    hideRecommendHistoryDropdown();
    const actionBtn = document.querySelector('#tab-ai button[onclick="quickSearch()"]');
    setButtonLoading(actionBtn, '检索中...');

    emptyDiv.style.display = 'none';
    resDiv.style.display = 'block';
    if (ctxBar) ctxBar.style.display = 'none';

    // 展现简易 Loading 状态（无步骤动画）
    resDiv.innerHTML = `<div style="text-align:center; padding: 60px 0;">
        <i class="ri-loader-4-line ri-spin" style="font-size: 32px; color: var(--primary);"></i>
        <p style="color: var(--text-secondary); font-size: 14px; margin-top: 12px;">正在岗位库中检索匹配岗位...</p>
    </div>`;

    try {
        const payload = {
            keyword: val,
            city: (document.getElementById('p-city') || {}).value || '',
            exp: (document.getElementById('p-exp') || {}).value || '',
            skills: (document.getElementById('p-skills') || {}).value || '',
            expected_salary: parseInt((document.getElementById('p-salary-max') || {}).value || '0', 10) || 0
        };
        const r = await fetch('/api/recommend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await r.json();
        if (!data || data.success === false) {
            throw new Error((data && data.msg) || '推荐接口返回失败');
        }
        let list = Array.isArray(data) ? data : (data.recommendations || []);
        list = applyFeedbackToRecommendations(list);

        if (!list || list.length === 0) {
            // 友好的数据兜底展示，取代原本的大段红字报错
            resDiv.innerHTML = `<div class="empty-state">
                <img src="https://api.iconify.design/ri/search-eye-line.svg?color=%2394a3b8" style="width:64px; margin-bottom:16px; opacity:0.6;">
                <div style="color: var(--gray-800); font-weight: 500; font-size: 16px;">未检索到精确匹配的岗位结果</div>
                <div class="empty-hint" style="margin-top: 8px;">系统暂无包含 [${val}] 的招聘数据，请尝试放宽或更换搜录词</div>
                <button class="auth-btn" style="margin-top:16px; background:#f1f5f9; color:#475569; width: 120px; font-size: 14px;" 
                    onclick="document.getElementById('ai-empty-state').style.display='block';document.getElementById('ai-res').style.display='none';">返回</button>
            </div>`;
            return;
        }

        if (ctxBar && data.persona) {
            ctxBar.style.display = 'flex';
            document.getElementById('rec-keywords').innerText = data.persona.keywords || '通用';
            document.getElementById('rec-skills').innerText = (data.persona.skills || []).join(', ') || '未指定';
            document.getElementById('rec-benchmark').innerText = '¥' + (data.market_context?.avg_salary || 0);
        }

        window.currentAiPayload = data || {};
        window.currentAiData = list;
        window.currentAiSummary = data.summary || null;
        window.isRecComparison = false;
        await syncRecommendApplicationMap();
        updateRecommendExplainPanel(data);
        if (data.quality_gate && data.quality_gate.blocking) {
            renderRecommendBlockedState(data, resDiv);
            return;
        }
        renderRecList(list, resDiv, data);

    } catch (e) {
        console.error("检索网络异常: ", e);
        showToast("网络请求异常，请稍后重试", "error");
        // 恢复未搜索状态
        emptyDiv.style.display = 'block';
        resDiv.style.display = 'none';
    } finally {
        clearButtonLoading(actionBtn);
    }
}

// 双轨设计B：启动深度画像分析（极客重度分析，依赖用户 Profile，带引擎动画）
async function deepAnalysis() {
    setRecommendMode('deep');
    const ready = await ensureProfileReadyForAnalysis(40);
    if (!ready) return;
    const job = document.getElementById('p-job')?.value;
    const skills = document.getElementById('p-skills')?.value;
    let keyword = job || skills;

    if (!keyword) {
        showToast("请先在[个人竞争力画像]中完善职位与技能信息以生成画像基准", "error");
        const btn = document.querySelector('.menu-item[onclick*="profile"]');
        if (btn) switchTab('profile', btn);
        return;
    }

    const val = keyword.split(/[,， ]/)[0]; // 提取首要词组作为底层搜索入口标识
    document.getElementById('kw').value = val; // 反填搜索框以呼应UI意图
    saveRecommendHistory(val);
    hideRecommendHistoryDropdown();
    const actionBtn = document.querySelector('#tab-ai button[onclick="deepAnalysis()"]');
    setButtonLoading(actionBtn, '分析中...');

    const resDiv = document.getElementById('ai-res');
    const emptyDiv = document.getElementById('ai-empty-state');
    const ctxBar = document.getElementById('ai-context-bar');

    emptyDiv.style.display = 'none';
    resDiv.style.display = 'block';
    if (ctxBar) ctxBar.style.display = 'none';

    try {
        renderDeepProgress(resDiv, 1, '正在读取你的画像字段与能力特征...');
        await sleep(260);

        const payload = {
            keyword: val,
            deep_analysis: true,
            city: (document.getElementById('p-city') || {}).value || '',
            exp: (document.getElementById('p-exp') || {}).value || '',
            skills: (document.getElementById('p-skills') || {}).value || '',
            expected_salary: parseInt((document.getElementById('p-salary-max') || {}).value || '0', 10) || 0
        };

        renderDeepProgress(resDiv, 2, '正在匹配市场样本库并计算人岗契合度...');
        const r = await fetch('/api/recommend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await r.json();
        if (!data || data.success === false) {
            throw new Error((data && data.msg) || '推荐接口返回失败');
        }
        let list = Array.isArray(data) ? data : (data.recommendations || []);
        list = applyFeedbackToRecommendations(list);

        renderDeepProgress(resDiv, 3, '正在生成个性化推荐与行动建议...');
        await sleep(220);

        if (!list || list.length === 0) {
            resDiv.innerHTML = `<div class="empty-state" style="padding: 40px 0;">
                <div class="ai-avatar" style="width:48px; height:48px; margin: 0 auto 16px; background: #f1f5f9; color: #94a3b8; filter: grayscale(1);">
                    <i class="ri-brain-line" style="font-size: 24px;"></i>
                </div>
                <div style="color: var(--gray-800); font-weight: 500;">未能根据当前画像提炼出高匹配岗位</div>
                <div class="empty-hint" style="margin-top: 8px;">建议补充技能标签或放宽目标城市后再试</div>
                <button class="btn btn-default" style="margin-top: 20px;" 
                    onclick="document.getElementById('ai-empty-state').style.display='block';document.getElementById('ai-res').style.display='none';">结束分析</button>
            </div>`;
            return;
        }

        if (ctxBar && data.persona) {
            ctxBar.style.display = 'flex';
            document.getElementById('rec-keywords').innerText = data.persona.keywords || '通用';
            document.getElementById('rec-skills').innerText = (data.persona.skills || []).join(', ') || '未指定';
            document.getElementById('rec-benchmark').innerText = '¥' + (data.market_context?.avg_salary || 0);
        }

        window.currentAiPayload = data || {};
        window.currentAiData = list;
        window.currentAiSummary = data.summary || null;
        window.isRecComparison = false;
        await syncRecommendApplicationMap();
        updateRecommendExplainPanel(data);
        if (data.quality_gate && data.quality_gate.blocking) {
            renderRecommendBlockedState(data, resDiv);
            return;
        }
        renderRecList(list, resDiv, data);
    } catch (e) {
        console.error("深度分析执行中断: ", e);
        resDiv.innerHTML = `<div class="empty-state" style="background:#fef2f2; border: 1px solid #fee2e2; border-radius: 12px;">
            <i class="ri-error-warning-line" style="font-size: 32px; color: #ef4444; margin-bottom: 12px;"></i>
            <div style="color: #991b1b; font-weight: 500;">引擎调用异常</div>
            <div style="color: #b91c1c; font-size: 13px; margin-top: 4px;">服务计算暂时中断，请检查网络配置或刷新重试</div>
            <button class="btn btn-default" style="margin-top: 16px; border-color:#fca5a5; color:#b91c1c;" 
                onclick="document.getElementById('ai-empty-state').style.display='block';document.getElementById('ai-res').style.display='none';">返回上一页</button>
        </div>`;
    } finally {
        clearButtonLoading(actionBtn);
    }
}

function updateRecommendExplainPanel(payload) {
    const personaEl = document.getElementById('recommend-persona');
    const marketEl = document.getElementById('recommend-market');
    const actionsEl = document.getElementById('recommend-actions');
    const planConclusionEl = document.getElementById('recommend-plan-conclusion');
    const planReasonEl = document.getElementById('recommend-plan-reason');
    const planSuggestionEl = document.getElementById('recommend-plan-suggestion');
    const planTargetsEl = document.getElementById('recommend-plan-targets');
    const planFocusEl = document.getElementById('recommend-plan-focus');
    if (!personaEl || !marketEl || !actionsEl) return;

    const persona = (payload || {}).persona || {};
    const summary = (payload || {}).summary || {};
    const market = (payload || {}).market_context || {};
    const recs = (payload || {}).recommendations || [];
    const gate = (payload || {}).quality_gate || {};
    const plan = (payload || {}).recommendation_plan || {};

    const skills = Array.isArray(persona.skills) ? persona.skills.filter(Boolean) : [];
    const modeText = persona.mode === 'profile_deep' ? '画像深度分析' : '关键词快速检索';
    personaEl.innerHTML = `
        <div><b>模式：</b>${modeText}</div>
        <div><b>关键词：</b>${persona.keywords || '未设置'}</div>
        <div><b>经验：</b>${persona.experience || '不限'}，<b>城市：</b>${persona.city || '不限'}</div>
        <div><b>技能：</b>${skills.length ? skills.slice(0, 4).join(' / ') : '未填写'}</div>
    `;

    const avg = Number(market.avg_salary || summary.avg_salary || 0);
    const median = Number(market.median_salary || 0);
    const jobCount = Number(market.job_count || 0);
    const readiness = Number(gate.readiness_score || 0);
    marketEl.innerHTML = `
        <div><b>市场均薪：</b>${avg > 0 ? ('¥' + avg.toLocaleString()) : '暂无'}</div>
        <div><b>市场中位：</b>${median > 0 ? ('¥' + median.toLocaleString()) : '暂无'}</div>
        <div><b>可参考岗位：</b>${jobCount || recs.length || 0} 条</div>
        <div><b>数据准入：</b>${gate.blocking ? '未通过' : (gate.level === 'warning' ? '谨慎可用' : '已通过')}（${readiness} 分）</div>
    `;

    const targets = plan.execution_targets || {};
    const focusJobs = Array.isArray(plan.focus_jobs) ? plan.focus_jobs : [];
    if (planConclusionEl) planConclusionEl.innerText = plan.conclusion || (gate.blocking ? '当前不建议直接执行推荐投递' : '等待生成推荐计划');
    if (planReasonEl) planReasonEl.innerText = plan.reason || gate.summary || '系统会根据画像、市场基准和数据质量生成本轮推荐结论。';
    if (planSuggestionEl) planSuggestionEl.innerText = plan.suggestion || '先输入关键词或执行深度分析。';
    if (planTargetsEl) {
        planTargetsEl.innerHTML = `
            <div class="mini-panel-p12" style="text-align:center;"><div class="text-hint">主申</div><div style="font-size:20px; font-weight:800; color:#1d4ed8;">${Number(targets['主申'] || 0)}</div></div>
            <div class="mini-panel-p12" style="text-align:center;"><div class="text-hint">冲刺</div><div style="font-size:20px; font-weight:800; color:#92400e;">${Number(targets['冲刺'] || 0)}</div></div>
            <div class="mini-panel-p12" style="text-align:center;"><div class="text-hint">保底</div><div style="font-size:20px; font-weight:800; color:#475569;">${Number(targets['保底'] || 0)}</div></div>
        `;
    }
    if (planFocusEl) {
        planFocusEl.innerText = focusJobs.length
            ? `今日优先：${focusJobs.map(x => `${x.job_name}（${x.bucket}）`).join('、')}`
            : (gate.blocking ? '请先修复数据质量，再重新生成推荐计划。' : '今日优先岗位将在生成推荐后显示。');
    }

    const planActions = Array.isArray(plan.today_actions) ? plan.today_actions : [];
    const blockers = Array.isArray(gate.blockers) ? gate.blockers : [];
    const warnings = Array.isArray(gate.warnings) ? gate.warnings : [];
    const actionLines = [];
    if (plan.conclusion) actionLines.push(`结论：${plan.conclusion}`);
    if (plan.reason) actionLines.push(`依据：${plan.reason}`);
    if (plan.suggestion) actionLines.push(`建议：${plan.suggestion}`);
    planActions.forEach(item => {
        if (item && item.label) actionLines.push(`${item.label}${item.detail ? `：${item.detail}` : ''}`);
    });
    if (focusJobs.length) {
        const names = focusJobs.map(x => `${x.job_name}（${x.bucket}）`).join('、');
        actionLines.push(`今日优先：${names}`);
    }
    if (gate.blocking) {
        blockers.forEach(x => actionLines.push(`阻断原因：${x}`));
    } else {
        warnings.forEach(x => actionLines.push(`质量提醒：${x}`));
    }
    if (!actionLines.length) actionLines.push('下一步：进入“岗位决策”查看结论，再到“投递执行”跟进状态。');
    actionsEl.innerHTML = actionLines.slice(0, 7).map(x => `<div>• ${x}</div>`).join('');
}

function applyRecommendSortMode(mode) {
    const list = Array.isArray(window.currentAiData) ? [...window.currentAiData] : [];
    if (!list.length) return;
    const sortMode = mode || 'comprehensive';
    const scoreOf = (x) => Number(x.score || 0);
    const salaryOf = (x) => Number(x.salary_avg || 0);
    const missCount = (x) => (((x.process_analysis || {}).missing_skills) || []).length;
    const heatOf = (x) => {
        const tags = Array.isArray(x.tags) ? x.tags.join(',') : String(x.tags || '');
        if (tags.includes('热招') || tags.includes('急聘')) return 100;
        return Number(x.heat_index || 0);
    };

    list.sort((a, b) => {
        if (sortMode === 'salary_first') {
            return salaryOf(b) - salaryOf(a) || scoreOf(b) - scoreOf(a);
        }
        if (sortMode === 'threshold_first') {
            return missCount(a) - missCount(b) || scoreOf(b) - scoreOf(a);
        }
        if (sortMode === 'heat_first') {
            return heatOf(b) - heatOf(a) || scoreOf(b) - scoreOf(a);
        }
        return scoreOf(b) - scoreOf(a);
    });

    window.currentAiData = list;
    window.currentAiPayload = { ...(window.currentAiPayload || {}), recommendations: list, summary: window.currentAiSummary || {} };
    const tipMap = {
        comprehensive: '当前按综合匹配排序。',
        salary_first: '当前按薪资优先排序，适合冲刺更高报价岗位。',
        threshold_first: '当前按门槛优先排序，适合先拿面试机会。',
        heat_first: '当前按热度优先排序，适合跟进市场热点岗位。'
    };
    const basisEl = document.getElementById('recommend-sort-basis');
    if (basisEl) basisEl.innerText = tipMap[sortMode] || tipMap.comprehensive;

    const resDiv = document.getElementById('ai-res');
    if (resDiv && resDiv.style.display !== 'none') {
        if (window.isRecComparison) renderComparisonTable(list, resDiv);
        else renderRecList(list, resDiv, window.currentAiPayload || window.currentAiSummary);
    }
}

function applyPersonaTemplate(type) {
    const map = {
        graduate: { job: '数据分析师', exp: '应届', edu: '本科', skills: 'Python,SQL,Excel' },
        junior: { job: 'Python开发工程师', exp: '1-3年', edu: '本科', skills: 'Python,SQL,Django' },
        switcher: { job: 'BI分析师', exp: '1年以内', edu: '本科', skills: 'SQL,PowerBI,Tableau' }
    };
    const tpl = map[type];
    if (!tpl) return;
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val;
    };
    setVal('p-job', tpl.job);
    setVal('p-exp', tpl.exp);
    setVal('p-edu', tpl.edu);
    setVal('p-skills', tpl.skills);
    setVal('kw', tpl.job);
    updateCard();
    showToast(`已应用${type === 'graduate' ? '应届' : (type === 'junior' ? '1-3年' : '转岗')}模板`);
}

function copyDeliveryStrategy() {
    const list = Array.isArray(window.currentAiData) ? window.currentAiData : [];
    const payload = window.currentAiPayload || {};
    const plan = payload.recommendation_plan || {};
    if (!list.length && !plan.conclusion) {
        showToast('请先生成推荐结果', 'error');
        return;
    }
    const targets = plan.execution_targets || {};
    const focusJobs = Array.isArray(plan.focus_jobs) ? plan.focus_jobs : [];
    const todayActions = Array.isArray(plan.today_actions) ? plan.today_actions : [];
    const top = list.slice(0, 5);
    const main = top.filter(x => Number(x.score || 0) >= REC_MATCH_SCORE_MAIN).slice(0, 3);
    const sprint = top.filter(x => Number(x.score || 0) >= REC_MATCH_SCORE_SPRINT && Number(x.score || 0) < REC_MATCH_SCORE_MAIN).slice(0, 2);
    const backup = top.filter(x => Number(x.score || 0) < REC_MATCH_SCORE_SPRINT).slice(0, 2);
    const lines = [
        '投递策略（系统生成）',
        `结论：${plan.conclusion || '当前推荐结果已生成，可进入岗位决策与投递执行。'}`
    ];
    if (plan.reason) lines.push(`依据：${plan.reason}`);
    if (plan.suggestion) lines.push(`建议：${plan.suggestion}`);
    lines.push(`执行目标：主申 ${Number(targets['主申'] || main.length || 0)}，冲刺 ${Number(targets['冲刺'] || sprint.length || 0)}，保底 ${Number(targets['保底'] || backup.length || 0)}`);
    lines.push(`今日优先：${focusJobs.length ? focusJobs.map(x => `${x.job_name}（${x.bucket}）`).join('、') : (main.length ? main.map(x => x.job_name).join('、') : '暂无')}`);
    if (todayActions.length) {
        todayActions.slice(0, 3).forEach((item, idx) => {
            lines.push(`${idx + 1}. ${item.label || '执行动作'}${item.detail ? `：${item.detail}` : ''}`);
        });
    } else {
        lines.push('建议顺序：先投主申岗位，再小规模尝试冲刺岗位，保底岗位只用于补充投递密度，48小时内跟进状态。');
    }
    const text = lines.join('\n');
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => showToast('投递策略已复制'));
    } else {
        showToast('当前环境不支持自动复制，请手动复制', 'error');
        console.log(text);
    }
}

function resolveRecommendJobId(item) {
    if (!item || typeof item !== 'object') return 0;
    return Number(item.id || item.job_id || 0);
}

function gotoDataEvaluateByRec(index) {
    const item = (window.currentAiData || [])[index];
    const jobId = resolveRecommendJobId(item);
    if (!jobId) return showToast('该推荐项缺少岗位ID，暂无法评估', 'error');
    switchTab('data');
    setTimeout(() => evaluateJobFromList(jobId), 120);
}

async function addRecToBoard(index) {
    const item = (window.currentAiData || [])[index];
    const jobId = resolveRecommendJobId(item);
    if (!jobId) return showToast('该推荐项缺少岗位ID，暂无法加入看板', 'error');
    await markJobAsFavorite(jobId, Number(item.score || 0));
    await syncRecommendApplicationMap();
    rerenderRecommendCurrentView();
    updateRecommendExplainPanel({ ...(window.currentAiPayload || {}), recommendations: window.currentAiData || [], summary: window.currentAiSummary || {} });
}

async function markRecApplied(index) {
    const item = (window.currentAiData || [])[index];
    const jobId = resolveRecommendJobId(item);
    if (!jobId) return showToast('该推荐项缺少岗位ID，暂无法标记投递', 'error');
    await markJobAppliedById(jobId, Number(item.score || 0));
    await syncRecommendApplicationMap();
    rerenderRecommendCurrentView();
    updateRecommendExplainPanel({ ...(window.currentAiPayload || {}), recommendations: window.currentAiData || [], summary: window.currentAiSummary || {} });
}

async function addTopRecommendationsToBoard(limit = 3) {
    const list = Array.isArray(window.currentAiData) ? window.currentAiData : [];
    if (!list.length) return showToast('请先生成推荐结果', 'error');
    const targets = list.slice(0, Math.max(1, Number(limit) || 3));
    let ok = 0;
    for (const item of targets) {
        const jobId = resolveRecommendJobId(item);
        if (!jobId) continue;
        try {
            await markJobAsFavorite(jobId, Number(item.score || 0));
            ok += 1;
        } catch (e) { }
    }
    await syncRecommendApplicationMap();
    rerenderRecommendCurrentView();
    updateRecommendExplainPanel({ ...(window.currentAiPayload || {}), recommendations: window.currentAiData || [], summary: window.currentAiSummary || {} });
    showToast(`已加入候选看板：${ok} 条`);
}

function renderRecViewToggleButton(isComparison = false) {
    if (isComparison) {
        return `<button class="btn btn-sm" onclick="toggleRecView()" style="background:#e6f7ff; border:1px solid #1890ff; color:#1890ff; display:flex; align-items:center; gap:4px;">
            <i class="ri-list-check"></i> 返回列表视图
        </button>`;
    }
    return `<button class="btn btn-sm" onclick="toggleRecView()" style="background:#fff; border:1px solid #ddd; color:#555; display:flex; align-items:center; gap:4px;">
        <i class="ri-layout-grid-line"></i> 切换对比视图
    </button>`;
}

function buildRecommendTraceTags(item) {
    const score = Number((item && item.score) || 0);
    const radar = (item && item.radar) || {};
    const proc = (item && item.process_analysis) || {};
    const gap = (item && item.gap_analysis) || {};
    const skill = Number(proc.skill_match || radar.skill_match || radar.skill || 0);
    const expGap = Number(gap.exp_gap_val || 0);
    const salary = Number(item.salary_avg || 0);
    const tags = [];
    if (skill >= 75) tags.push({ text: `技能高匹配 ${skill}%`, tone: 'good' });
    else if (skill > 0) tags.push({ text: `技能待补强 ${skill}%`, tone: 'mid' });
    if (expGap <= 0) tags.push({ text: '经验要求基本匹配', tone: 'good' });
    else tags.push({ text: `经验差距 ${expGap}`, tone: 'risk' });
    if (salary > 0) {
        if (score >= REC_MATCH_SCORE_MAIN) tags.push({ text: '薪资与画像预期相对友好', tone: 'good' });
        else if (score >= REC_MATCH_SCORE_SPRINT) tags.push({ text: '薪资可接受，建议先补短板', tone: 'mid' });
        else tags.push({ text: '薪资/门槛可能偏高', tone: 'risk' });
    }
    if (item && item.city) tags.push({ text: `城市命中：${item.city}`, tone: 'default' });
    return tags.slice(0, 4);
}

function renderRecommendTraceTags(tags) {
    if (!Array.isArray(tags) || !tags.length) return '<span class="rec-trace-item">暂无匹配依据</span>';
    return tags.map(t => {
        let cls = 'rec-trace-item';
        if (t.tone === 'good') cls += ' is-good';
        else if (t.tone === 'mid') cls += ' is-mid';
        else if (t.tone === 'risk') cls += ' is-risk';
        return `<span class="${cls}">${t.text}</span>`;
    }).join('');
}

function buildRecDimensionRows(item) {
    const radar = (item && item.radar) || {};
    const proc = (item && item.process_analysis) || {};
    const gap = (item && item.gap_analysis) || {};
    const skill = Number(proc.skill_match || radar.skill_match || radar.skill || 0);
    const salary = Number(radar.salary_fit || radar.salary || item.score || 0);
    const edu = Number(radar.edu_match || radar.edu || 0);
    const exp = Number(radar.exp_match || radar.exp || 0);
    const missingSkills = Array.isArray(proc.missing_skills) ? proc.missing_skills : [];
    const rows = [
        { label: '技能匹配', val: skill, desc: missingSkills.length ? `缺少 ${missingSkills.slice(0, 2).join('、')}` : '核心技能覆盖较好', color: '#3b82f6' },
        { label: '薪资匹配', val: salary, desc: Number(item.salary_avg || 0) > 0 ? `当前岗位均薪 ¥${Number(item.salary_avg || 0).toLocaleString()}` : '薪资字段不完整，建议人工复核', color: '#10b981' },
        { label: '学历匹配', val: edu, desc: edu >= 80 ? '学历门槛基本匹配' : '学历门槛偏高，建议选同级岗位', color: '#8b5cf6' },
        { label: '经验匹配', val: exp, desc: gap.exp_desc || (exp >= 80 ? '经验区间匹配良好' : '经验要求偏高，建议先补项目'), color: '#f59e0b' }
    ];
    return rows.map(r => {
        const pct = Math.max(0, Math.min(100, Number(r.val || 0)));
        return `
            <div class="rec-dim-row">
                <div class="rec-dim-head"><span>${r.label}</span><b style="color:${r.color};">${pct}%</b></div>
                <div class="rec-dim-track"><span style="width:${pct}%; background:${r.color};"></span></div>
                <div class="rec-dim-desc">${r.desc}</div>
            </div>
        `;
    }).join('');
}

function renderRecActionSuggestions(item) {
    const suggestions = Array.isArray((item || {}).action_suggestions) ? item.action_suggestions.filter(Boolean) : [];
    if (!suggestions.length) return '';
    return `
        <div style="margin-top:12px; padding:12px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0;">
            <div style="font-size:13px; font-weight:700; color:#0f172a; margin-bottom:8px;"><i class="ri-list-check-3"></i> 执行动作</div>
            <div style="display:grid; gap:6px;">
                ${suggestions.slice(0, 3).map((item, idx) => `
                    <div style="font-size:12px; color:#334155; line-height:1.6;">
                        <b>${idx + 1}. ${item.title || '执行建议'}</b>${item.text ? `：${item.text}` : ''}
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// 渲染推荐列表（普通视图）
function renderRecList(list, container, summaryPayload) {
    const payload = (summaryPayload && (summaryPayload.summary || summaryPayload.recommendation_plan || summaryPayload.quality_gate))
        ? summaryPayload
        : { summary: summaryPayload || {} };
    const summary = payload.summary || {};
    const plan = payload.recommendation_plan || {};
    const gate = payload.quality_gate || {};
    let h = '';

    // ===== 匹配结果汇总面板 =====
    if (summary) {
        const missingHtml = (summary.top_missing_skills || []).map(s => {
            const name = (s && (s.name || s.skill)) || '';
            const count = (s && (s.count || s.freq || 0)) || 0;
            return `<span style="display:inline-block; background:#fff1f0; color:#ff4d4f; padding:2px 8px; border-radius:10px; font-size:12px; margin:2px;">${name} <b>(${count})</b></span>`;
        }
        ).join('') || '<span style="color:#10b981; font-size:12px;">✨ 无明显缺口</span>';

        h += `<div style="background:linear-gradient(135deg, #f8faff 0%, #f0f5ff 100%); border:1px solid #d6e4ff; border-radius:12px; padding:20px; margin-bottom:20px;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px;">
                <div style="font-size:15px; font-weight:bold; color:#333;"><i class="ri-dashboard-3-line" style="color:#2563eb; margin-right:6px;"></i>匹配结果速览</div>
                ${renderRecViewToggleButton(false)}
            </div>
            <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:12px; margin-bottom:16px;">
                <div style="background:#fff; border-radius:8px; padding:12px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,0.06);">
                    <div style="font-size:24px; font-weight:bold; color:#2563eb;">${summary.total_matched || 0}</div>
                    <div style="font-size:12px; color:#999; margin-top:2px;">匹配岗位</div>
                </div>
                <div style="background:#fff; border-radius:8px; padding:12px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,0.06);">
                    <div style="font-size:24px; font-weight:bold; color:#10b981;">${summary.avg_score || 0}</div>
                    <div style="font-size:12px; color:#999; margin-top:2px;">平均匹配度</div>
                </div>
                <div style="background:#fff; border-radius:8px; padding:12px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,0.06);">
                    <div style="font-size:24px; font-weight:bold; color:#f59e0b;">¥${(summary.max_salary || 0).toLocaleString()}</div>
                    <div style="font-size:12px; color:#999; margin-top:2px;">最高薪资</div>
                </div>
                <div style="background:#fff; border-radius:8px; padding:12px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,0.06);">
                    <div style="font-size:24px; font-weight:bold; color:#7c3aed;">¥${(summary.avg_salary || 0).toLocaleString()}</div>
                    <div style="font-size:12px; color:#999; margin-top:2px;">平均薪资</div>
                </div>
            </div>
            ${plan && plan.conclusion ? `
            <div style="background:${gate.blocking ? '#fff7ed' : '#f8fafc'}; border:1px solid ${gate.blocking ? '#fed7aa' : '#e2e8f0'}; border-radius:8px; padding:12px; margin-bottom:12px;">
                <div style="font-size:13px; color:#0f172a; font-weight:700; margin-bottom:6px;"><i class="ri-focus-3-line" style="margin-right:4px;"></i>${plan.title || '推荐投递计划'}</div>
                <div style="font-size:12px; color:#334155; margin-bottom:4px;"><b>结论：</b>${plan.conclusion}</div>
                <div style="font-size:12px; color:#475569; margin-bottom:4px;"><b>依据：</b>${plan.reason || '暂无'}</div>
                <div style="font-size:12px; color:#0f172a;"><b>建议：</b>${plan.suggestion || '暂无'}</div>
            </div>` : ''}
            <div style="background:#fff; border-radius:8px; padding:12px; box-shadow:0 1px 3px rgba(0,0,0,0.06);">
                <div style="font-size:13px; color:#666; margin-bottom:8px;"><i class="ri-alarm-warning-line" style="color:#ff4d4f; margin-right:4px;"></i><b>技能缺口热度榜</b>（您尚未掌握的市场高频技能）</div>
                <div>${missingHtml}</div>
            </div>
            <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:12px;">
                <button class="btn btn-sm btn-primary" onclick="addTopRecommendationsToBoard(3)"><i class="ri-star-line"></i> Top3 加入候选看板</button>
                <button class="btn btn-sm btn-default" onclick="typeof autoBuildExecutionPool === 'function' ? autoBuildExecutionPool() : addTopRecommendationsToBoard(5)"><i class="ri-magic-line"></i> 一键生成执行池</button>
                <button class="btn btn-sm btn-default" onclick="copyDeliveryStrategy()"><i class="ri-file-copy-line"></i> 复制投递策略</button>
            </div>
        </div>`;
    } else {
        h += `<div style="display:flex; justify-content:flex-end; margin-bottom:10px;">
            ${renderRecViewToggleButton(false)}
        </div>`;
    }

    const topRec = list[0] || null;
    if (topRec && !plan.conclusion) {
        const highCount = list.filter(x => Number(x.score || 0) >= REC_MATCH_SCORE_MAIN).length;
        const topMissing = ((summary || {}).top_missing_skills || [])
            .slice(0, 2)
            .map(x => x.name || x.skill)
            .filter(Boolean)
            .join('、');
        const topDecision = topRec.decision || {};
        const topConclusion = plan.conclusion || topDecision.conclusion || (Number(topRec.score || 0) >= REC_MATCH_SCORE_MAIN
            ? '当前推荐结果可进入首轮投递'
            : (Number(topRec.score || 0) >= REC_MATCH_SCORE_SPRINT ? '推荐结果可投递，但建议先补短板' : '推荐结果匹配偏弱，建议先优化画像'));
        const topReason = plan.reason || topDecision.reason || `高匹配岗位 ${highCount} 个，最高匹配 ${topRec.score || 0}（${topRec.job_name || '未知岗位'}）。`;
        const topSuggestion = plan.suggestion || (topMissing
            ? `建议先补齐 ${topMissing}，再优先评估并投递 Top3 岗位。`
            : '建议先评估并投递 Top3 岗位，再根据反馈迭代画像。');
        h += `<div style="margin-bottom:12px;">${renderConclusionCard('推荐决策结论', topConclusion, topReason, topSuggestion, Number(topRec.score || 0) >= REC_MATCH_SCORE_MAIN ? 'good' : (Number(topRec.score || 0) >= REC_MATCH_SCORE_SPRINT ? 'mid' : 'risk'))}</div>`;
    }

    list.forEach((i, x) => {
        const rank = x + 1;
        const statusMeta = getRecommendItemStatus(i);
        // 分数颜色逻辑
        let scoreColor = i.score >= REC_MATCH_SCORE_MAIN ? '#10b981' : (i.score >= REC_MATCH_SCORE_SPRINT ? '#f59e0b' : '#2563eb');

        // 薪资与标签
        let tagsHtml = `<span class="salary-tag-hero">💰 ${Number(i.salary_avg || 0).toLocaleString()}</span>`;
        const tagArr = Array.isArray(i.tags) ? i.tags : (String(i.tags || '').split(',').map(x => x.trim()).filter(Boolean));
        if (tagArr.length) tagsHtml += tagArr.map(t => `<span class="tag-pill highlight" style="margin-left:8px;">${t}</span>`).join('');

        // 技能匹配进度
        let skillMatch = i.process_analysis ? i.process_analysis.skill_match : (i.radar ? i.radar.skill : 0);

        // 差距分析: 技能缺失
        let missing = i.process_analysis ? i.process_analysis.missing_skills : [];
        let missingHtml = '';
        if (missing.length > 0) {
            missingHtml = `<div style="margin-bottom:8px;">
                <div class="analysis-block-title" style="color:#ef4444;">⚠️ 技能缺口</div>
                <div style="display:flex; flex-wrap:wrap; gap:6px;">
                    ${missing.slice(0, 3).map(s => `<span style="font-size:12px; color:#ef4444; background:#fef2f2; padding:2px 8px; border-radius:4px;">${s}</span>`).join('')}
                </div>
            </div>`;
        } else {
            missingHtml = `<div style="margin-bottom:8px;">
                <div class="analysis-block-title" style="color:#10b981;">✅ 技能完备</div>
                <div style="font-size:12px; color:#059669;">核心技能均已匹配</div>
            </div>`;
        }

        // 差距分析: 经验
        let expHtml = '';
        if (i.gap_analysis) {
            const isGap = i.gap_analysis.exp_gap_val > 0;
            const color = isGap ? '#f59e0b' : '#10b981';
            expHtml = `<div style="margin-bottom:8px;">
                <div class="analysis-block-title">⏳ 经验匹配</div>
                <div style="font-size:12px; color:${color}; font-weight:500;">${i.gap_analysis.exp_desc}</div>
            </div>`;
        }

        // 建议
        const decision = i.decision || {};
        const recConclusion = decision.conclusion || (i.score >= REC_MATCH_SCORE_MAIN ? '适合投递（主申）' : (i.score >= REC_MATCH_SCORE_SPRINT ? '可投递（补强后优先）' : '建议观望（先补短板）'));
        const recReason = decision.reason || buildRecNaturalReason(i);
        const recSuggestion = decision.suggestion || (missing.length ? `优先补齐 ${missing.slice(0, 2).join('、')} 后再投递。` : '可直接投递，并在简历中强调项目成果。');
        const recToneBg = i.score >= REC_MATCH_SCORE_MAIN ? '#ecfdf5' : (i.score >= REC_MATCH_SCORE_SPRINT ? '#fffbeb' : '#fef2f2');
        const recToneBd = i.score >= REC_MATCH_SCORE_MAIN ? '#86efac' : (i.score >= REC_MATCH_SCORE_SPRINT ? '#fcd34d' : '#fecaca');
        const recToneFg = i.score >= REC_MATCH_SCORE_MAIN ? '#166534' : (i.score >= REC_MATCH_SCORE_SPRINT ? '#92400e' : '#991b1b');
        const recBucket = decision.bucket || (i.score >= REC_MATCH_SCORE_MAIN ? '主申' : (i.score >= REC_MATCH_SCORE_SPRINT ? '冲刺' : '保底'));
        const recConfidence = Number(decision.confidence || 0);
        const jobId = resolveRecommendJobId(i) || rank;
        const detailId = `rec-match-detail-${jobId}-${x}`;
        const dimRows = buildRecDimensionRows(i);
        const userFeedback = i._feedback || null;
        const feedbackTip = userFeedback
            ? `<div class="rec-feedback-tip"><i class="ri-feedback-line"></i> 已记录反馈：${escapeHtml(userFeedback.reason || (userFeedback.type === 'candidate' ? '加入候选' : '不感兴趣'))}</div>`
            : '';
        const structuredBlock = `
            <div style="margin-top:12px; border:1px solid ${recToneBd}; background:${recToneBg}; border-radius:8px; padding:10px;">
                <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px;">
                    <span class="tag" style="background:#eff6ff;color:#1d4ed8;">分层：${recBucket}</span>
                    ${recConfidence ? `<span class="tag" style="background:#f8fafc;color:#475569;">置信度 ${recConfidence}</span>` : ''}
                </div>
                <div style="margin-bottom:6px; color:${recToneFg};"><b>结论：</b>${recConclusion}</div>
                <div style="margin-bottom:6px; color:#334155; font-size:12px;"><b>原因：</b>${recReason}</div>
                <div style="color:#0f172a; font-size:12px;"><b>建议：</b>${recSuggestion}${decision.next_step ? `（下一步：${decision.next_step}）` : ''}</div>
            </div>
        `;
        const traceTags = buildRecommendTraceTags(i);
        const traceHtml = renderRecommendTraceTags(traceTags);

        h += `
        <div class="rec-card-enhanced">
            ${rank <= 3 ? `<div class="rec-rank-badge">🏆 TOP ${rank}</div>` : ''}
            
            <div class="rec-main-info">
                <div class="company-logo-box">
                    ${i.company ? i.company.charAt(0) : '聘'}
                </div>
                <div style="flex:1;">
                    <div class="job-details-hero">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                            <div>
                                <h3>
                                    ${i.job_name}
                                    <span style="font-size:13px; font-weight:normal; color:#64748b; background:#f1f5f9; padding:2px 8px; border-radius:12px; margin-left:8px;">
                                        ${i.city || '未知'}
                                    </span>
                                    <span style="font-size:12px; font-weight:600; color:${statusMeta.tone}; background:${statusMeta.bg}; border-radius:12px; padding:2px 8px; margin-left:8px;">
                                        ${statusMeta.text}
                                    </span>
                                </h3>
                                <div style="font-size:14px; color:#64748b; margin-bottom:8px;">${i.company}</div>
                                <div>${tagsHtml}</div>
                            </div>
                            <!-- 匹配环形图 -->
                            <div style="text-align:center;">
                                <div class="match-score-ring" style="background: conic-gradient(${scoreColor} ${i.score}%, #e5e7eb ${i.score}%);">
                                    <div class="match-score-inner" style="color:${scoreColor}">${i.score}</div>
                                </div>
                                <div style="font-size:11px; color:#94a3b8; margin-top:4px;">匹配指数</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 深度分析网格 -->
            <div class="rec-analysis-grid">
                <div>
                    <div class="analysis-block-title">📊 核心胜任力分析（分项匹配明细）</div>
                    ${(() => {
                let radar = i.radar || { skill_match: skillMatch, exp_match: 80, edu_match: 80, salary_fit: 80 };
                let buildBar = (label, val, color) => `
                            <div style="margin-bottom:8px;">
                                <div style="display:flex; align-items:center; margin-bottom:2px; font-size:11px; color:#475569;">
                                    <span style="flex:1;">${label}</span>
                                    <span style="font-weight:700; color:${color};">${val}%</span>
                                </div>
                                <div class="skill-progress-bar" style="height:4px; background:#e2e8f0; border-radius:2px; overflow:hidden;">
                                    <div class="skill-progress-fill" style="height:100%; background:${color}; width:${val}%;"></div>
                                </div>
                            </div>`;
                return `
                            <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 4px 16px; margin-top:12px;">
                                ${buildBar('技能契合度', radar.skill_match, '#3b82f6')}
                                ${buildBar('经验匹配度', radar.exp_match, '#10b981')}
                                ${buildBar('学历匹配度', radar.edu_match, '#8b5cf6')}
                                ${buildBar('薪水符合度', radar.salary_fit, '#f59e0b')}
                            </div>
                        `;
            })()}
                    <div style="font-size:12px; color:#64748b; margin-top:8px;">
                        <i class="ri-check-double-line" style="color:#10b981; margin-right:4px;"></i>
                        匹配理由: ${i.reason || '综合匹配度较高'}
                    </div>
                </div>

                <div style="border-left:1px dashed #e2e8f0; padding-left:20px;">
                    ${missingHtml}
                    ${expHtml}
                </div>
            </div>

            <div class="rec-trace-box">
                <div class="rec-trace-title"><i class="ri-information-line"></i> 推荐依据</div>
                <div class="rec-trace-list">${traceHtml}</div>
            </div>
            <div class="rec-reason-box"><b>为什么推荐给你：</b>${recReason}</div>
            ${feedbackTip}
            <div class="rec-detail-toggle-row">
                <button class="btn btn-sm btn-default" onclick="toggleRecMatchDetail('${detailId}', this)"><i class="ri-arrow-down-s-line"></i> 展开匹配明细</button>
            </div>
            <div id="${detailId}" class="rec-match-detail" style="display:none;">${dimRows}</div>
            ${structuredBlock}
            ${renderRecActionSuggestions(i)}

            <div style="margin-top:16px; display:flex; justify-content:space-between; align-items:center; gap:8px; flex-wrap:wrap;">
                <div style="display:flex; gap:8px;">
                    <button class="btn btn-default" onclick="toggleFavorite(${i.id}, this, true)" style="padding:6px 10px;">
                        <i class="${i.is_favorite ? 'ri-star-fill' : 'ri-star-line'}" style="color:${i.is_favorite ? '#f59e0b' : '#64748b'}"></i>
                        ${i.is_favorite ? '已收藏' : '收藏'}
                    </button>
                    <button class="btn btn-default" onclick="toggleIgnore(${i.id})" style="padding:6px 10px; color:${i.is_ignored ? '#ef4444' : '#64748b'};">
                        <i class="ri-forbid-2-line"></i> ${i.is_ignored ? '已忽略' : '忽略'}
                    </button>
                    <button class="btn btn-default" onclick="quickNote(${i.id}, '${encodeURIComponent(i.note || '')}')" style="padding:6px 10px;">
                        <i class="ri-edit-2-line"></i> 备注
                    </button>
                </div>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <button class="btn btn-sm btn-default" onclick="handleRecommendNotInterested(${x})">
                        <i class="ri-thumb-down-line"></i> 不感兴趣
                    </button>
                    <button class="btn btn-sm btn-default" onclick="handleRecommendCandidate(${x})">
                        <i class="ri-user-follow-line"></i> 加入候选
                    </button>
                    <button class="btn btn-sm btn-default" onclick="gotoDataEvaluateByRec(${x})" style="color:#1d4ed8; font-weight:600;">
                        <i class="ri-radar-line"></i> 去岗位决策
                    </button>
                    <button class="btn btn-sm btn-primary" onclick="markRecApplied(${x})">
                        <i class="ri-send-plane-line"></i> 标记已投递
                    </button>
                    <button class="btn btn-sm btn-default" onclick="openAnalysis(${x})" style="color:var(--primary); font-weight:600;">
                        查看完整报告 <i class="ri-arrow-right-line"></i>
                    </button>
                </div>
            </div>
        </div>`;
    });
    container.innerHTML = h;
}

// 切换推荐结果视图
function toggleRecView() {
    window.isRecComparison = !window.isRecComparison;
    const resDiv = document.getElementById('ai-res');
    if (window.isRecComparison) {
        renderComparisonTable(window.currentAiData, resDiv);
    } else {
        renderRecList(window.currentAiData, resDiv, window.currentAiPayload || window.currentAiSummary);
    }
}

// 渲染对比视图表格
function renderComparisonTable(list, container) {
    if (!list || list.length === 0) return;

    // 只取前5个进行对比，避免太宽
    const topList = list.slice(0, 5);

    let ths = '';
    let tds_score = '';
    let tds_salary = '';
    let tds_company = '';
    let tds_missing = '';
    let tds_action = '';

    topList.forEach((item, idx) => {
        const scoreColor = item.score >= REC_MATCH_SCORE_MAIN ? '#10b981' : (item.score >= REC_MATCH_SCORE_SPRINT ? '#f59e0b' : '#2563eb');
        const missing = item.process_analysis?.missing_skills || [];

        ths += `<th style="padding:12px; text-align:center; min-width:140px; background:#f8fafc; border-bottom:2px solid #e2e8f0;">
            <div style="font-size:15px; font-weight:bold; color:#333;">${item.job_name}</div>
        </th>`;

        tds_company += `<td style="padding:12px; text-align:center; border-bottom:1px solid #eee;">
            <div style="font-size:13px;">${item.company}</div>
            <div style="font-size:12px; color:#999;">${item.city}</div>
        </td>`;

        tds_salary += `<td style="padding:12px; text-align:center; border-bottom:1px solid #eee; font-weight:bold; color:#f59e0b;">
            ¥${item.salary_avg}
        </td>`;

        tds_score += `<td style="padding:12px; text-align:center; border-bottom:1px solid #eee;">
            <div style="font-size:24px; font-weight:bold; color:${scoreColor};">${item.score}</div>
            <div style="font-size:12px; color:#999;">综合匹配度</div>
        </td>`;

        tds_missing += `<td style="padding:12px; text-align:center; border-bottom:1px solid #eee;">
            ${missing.length > 0 ? missing.map(s => `<span class="tag-pill" style="background:#fff1f0; color:#ff4d4f; border:none; margin:2px;">${s}</span>`).join('<br>') : '<span style="color:#10b981">✨ 技能全覆盖</span>'}
        </td>`;

        tds_action += `<td style="padding:12px; text-align:center; border-bottom:1px solid #eee;">
            <div style="display:flex; flex-direction:column; gap:6px; align-items:center;">
                <button class="auth-btn" style="padding:4px 12px; font-size:12px; background:${scoreColor};" onclick="openAnalysis(${idx})">查看</button>
                <button class="btn btn-default" style="padding:4px 10px; font-size:12px;" onclick="gotoDataEvaluateByRec(${idx})"><i class="ri-radar-line"></i> 评估</button>
                <button class="btn btn-primary" style="padding:4px 10px; font-size:12px;" onclick="markRecApplied(${idx})"><i class="ri-send-plane-line"></i> 投递</button>
            </div>
        </td>`;
    });

    let html = `<div style="display:flex; justify-content:flex-end; margin-bottom:10px;">
        ${renderRecViewToggleButton(true)}
    </div>
    <div style="overflow-x:auto; border:1px solid #e2e8f0; border-radius:8px;">
        <table style="width:100%; border-collapse:collapse;">
            <thead><tr>${ths}</tr></thead>
            <tbody>
                <tr>${tds_company}</tr>
                <tr>${tds_salary}</tr>
                <tr>${tds_score}</tr>
                <tr>${tds_missing}</tr>
                <tr>${tds_action}</tr>
            </tbody>
        </table>
    </div>`;

    container.innerHTML = html;
}

