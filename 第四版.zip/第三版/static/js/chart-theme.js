/**
 * 统一 ECharts 主题层
 * 目标：
 * 1) 兼容旧代码（继续使用 echarts.init + setOption 也可）
 * 2) 提供 ChartTheme.init / ChartTheme.merge 供新代码使用
 */
(function () {
  if (typeof window === 'undefined' || typeof echarts === 'undefined') return;

  const COLORS = [
    '#3b82f6',
    '#10b981',
    '#8b5cf6',
    '#f59e0b',
    '#06b6d4',
    '#f43f5e',
    '#84cc16',
    '#a78bfa'
  ];

  const BASE = {
    color: COLORS,
    backgroundColor: 'transparent',
    textStyle: {
      fontFamily: 'Noto Sans SC, Sora, sans-serif',
      color: '#8b949e',
      fontSize: 11
    },
    tooltip: {
      backgroundColor: '#1c2333',
      borderColor: '#222d3f',
      borderWidth: 1,
      textStyle: { color: '#e2e8f0', fontSize: 12 },
      extraCssText: 'border-radius:10px; box-shadow:0 8px 30px rgba(0,0,0,.45); padding:10px 12px;'
    },
    legend: {
      textStyle: { color: '#8b949e', fontSize: 11 },
      itemWidth: 10,
      itemHeight: 10,
      itemGap: 14
    },
    grid: {
      top: 32,
      right: 16,
      bottom: 30,
      left: 16,
      containLabel: true
    },
    xAxis: {
      axisLine: { lineStyle: { color: '#222d3f' } },
      axisTick: { show: false },
      axisLabel: { color: '#484f58', fontSize: 11 },
      splitLine: { lineStyle: { color: '#1c2333', type: 'solid' } }
    },
    yAxis: {
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: '#484f58', fontSize: 11 },
      splitLine: { lineStyle: { color: '#1c2333', type: 'solid' } }
    }
  };

  function isObj(v) {
    return Object.prototype.toString.call(v) === '[object Object]';
  }

  function deepMerge(target, source) {
    const out = Array.isArray(target) ? target.slice() : { ...(target || {}) };
    if (!source) return out;
    Object.keys(source).forEach((k) => {
      const sv = source[k];
      const tv = out[k];
      if (isObj(tv) && isObj(sv)) out[k] = deepMerge(tv, sv);
      else out[k] = sv;
    });
    return out;
  }

  window.ChartTheme = {
    colors: COLORS,
    base: BASE,
    init(el) {
      if (!el) return null;
      const old = echarts.getInstanceByDom(el);
      if (old) echarts.dispose(el);
      return echarts.init(el);
    },
    merge(option) {
      return deepMerge(BASE, option || {});
    }
  };

  // 兼容旧逻辑：自动给 chart.setOption 合并主题
  if (!echarts.__chartThemePatched) {
    const rawInit = echarts.init;
    echarts.init = function patchedInit() {
      const chart = rawInit.apply(echarts, arguments);
      if (!chart || chart.__chartThemeWrapped) return chart;
      const rawSetOption = chart.setOption.bind(chart);
      chart.setOption = function patchedSetOption(option, notMerge, lazyUpdate) {
        return rawSetOption(window.ChartTheme.merge(option), notMerge, lazyUpdate);
      };
      chart.__chartThemeWrapped = true;
      return chart;
    };
    echarts.__chartThemePatched = true;
  }

  // 兼容历史调用
  window.initChart = function initChart(elementId, option) {
    const el = document.getElementById(elementId);
    if (!el) return null;
    const chart = window.ChartTheme.init(el);
    chart.setOption(window.ChartTheme.merge(option || {}));
    return chart;
  };
})();
