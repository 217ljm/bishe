import os, re

def main():
    routes_dir = r'd:\PyCharmprojects\analysis project\app\routes'
    js_path = r'd:\PyCharmprojects\analysis project\static\js\script.js'
    html_path = r'd:\PyCharmprojects\analysis project\templates\index.html'

    with open(js_path, encoding='utf-8') as f: js_code = f.read()
    with open(html_path, encoding='utf-8') as f: html_code = f.read()
    frontend_code = js_code + html_code

    all_routes = []
    for file in os.listdir(routes_dir):
        if file.endswith('.py'):
            path = os.path.join(routes_dir, file)
            with open(path, encoding='utf-8') as f:
                content = f.read()
                matches = re.findall(r'@\w+\.route\([\'"](.*?)[\'"]', content)
                for m in matches:
                    all_routes.append((file, m))

    unused_routes = []
    for file, route in all_routes:
        base_route = re.sub(r'<[^>]+>', '', route).rstrip('/')
        if not base_route:
            base_route = '/'
        
        # Exceptions or standard routes
        if base_route == '/' or base_route == '/login' or base_route == '/logout':
            continue
            
        # check if route is in frontend code
        if base_route not in frontend_code:
            unused_routes.append((file, route))

    print("Potentially unused routes:")
    for r in unused_routes:
        print(f"{r[0]}: {r[1]}")

if __name__ == '__main__':
    main()
