# Force Reload Triggered
from app import create_app


app = create_app()
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.jinja_env.auto_reload = True

if __name__ == '__main__':
    print("Starting Flask Server on port 5000...")
    try:
        app.run(debug=False, port=5000)
    except Exception as e:
        print(f"Failed to start server: {e}")
