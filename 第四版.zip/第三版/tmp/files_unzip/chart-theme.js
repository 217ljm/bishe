/**
 * chart-theme.js
 * 统一 ECharts 图表主题配置
 * 使用方法：把所有 echarts.init(el) 改为 ChartTheme.init(el)
 *           把所有 chart.setOption({...}) 改为 chart.setOption(ChartTheme.merge({...}))
 */

window.ChartTheme = {

  // 统一配色序列
  colors: [
    '#3b82f6',  // 蓝
    '#10b981',  // 绿
    '#8b5cf6',  // 紫
    '#f59e0b',  // 橙
    '#06b6d4',  // 青
    '#f43f5e',  // 红
    '#84cc16',  // 黄绿
    '#a78bfa',  // 浅紫
  ],

  // 基础配置（所有图表共享）
  base: {
    color: [
      '#3b82f6', '#10b981', '#8b5cf6', '#f59e0b',
      '#06b6d4', '#f43f5e', '#84cc16', '#a78bfa',
    ],
    backgroundColor: 'transparent',
    textStyle: {
      fontFamily: 'Inter, -apple-system, "Segoe UI", sans-serif',
      color: '#64748b',
      fontSize: 12,
    },
    tooltip: {
      backgroundColor: '#1e293b',
      borderColor: '#334155',
      borderWidth: 1,
      textStyle: { color: '#e2e8f0', fontSize: 12 },
      extraCssText: 'border-radius:10px; box-shadow:0 8px 32px rgba(0,0,0,0.3); padding:10px 14px;',
    },
    legend: {
      textStyle: { color: '#64748b', fontSize: 12 },
      itemWidth: 10,
      itemHeight: 10,
      itemGap: 16,
    },
    grid: {
      top: 32,
      right: 16,
      bottom: 28,
      left: 12,
      containLabel: true,
    },
    xAxis: {
      axisLine:  { lineStyle: { color: '#e2e8f0' } },
      axisTick:  { show: false },
      axisLabel: { color: '#94a3b8', fontSize: 11 },
      splitLine: { lineStyle: { color: '#f1f5f9', type: 'dashed' } },
    },
    yAxis: {
      axisLine:  { show: false },
      axisTick:  { show: false },
      axisLabel: { color: '#94a3b8', fontSize: 11 },
      splitLine: { lineStyle: { color: '#f1f5f9', type: 'dashed' } },
    },
  },

  /**
   * 初始化图表（替代 echarts.init）
   * 自动处理已存在实例的销毁
   */
  init(el) {
    if (!el) return null;
    const existing = echarts.getInstanceByDom(el);
    if (existing) echarts.dispose(el);
    return echarts.init(el);
  },

  /**
   * 把用户的 option 与基础配置合并
   * 用法：chart.setOption(ChartTheme.merge({ series: [...] }))
   */
  merge(userOption) {
    const base = JSON.parse(JSON.stringify(this.base)); // 深拷贝避免污染
    return this._deepMerge(base, userOption);
  },

  /**
   * 深度合并两个对象（后者优先）
   */
  _deepMerge(target, source) {
    if (!source) return target;
    const result = Object.assign({}, target);
    for (const key of Object.keys(source)) {
      if (
        source[key] !== null &&
        typeof source[key] === 'object' &&
        !Array.isArray(source[key]) &&
        target[key] !== null &&
        typeof target[key] === 'object' &&
        !Array.isArray(target[key])
      ) {
        result[key] = this._deepMerge(target[key], source[key]);
      } else {
        result[key] = source[key];
      }
    }
    return result;
  },

  // ---- 常用图表快速生成器 ----

  /** 柱状图 option */
  bar(categories, data, opts = {}) {
    return this.merge({
      xAxis: { type: 'category', data: categories },
      yAxis: { type: 'value' },
      series: [{
        type: 'bar',
        data: data,
        barMaxWidth: 40,
        itemStyle: {
          borderRadius: [4, 4, 0, 0],
          color: {
            type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: opts.color || '#3b82f6' },
              { offset: 1, color: opts.colorEnd || '#60a5fa' },
            ],
          },
        },
        ...opts.seriesExtra,
      }],
      ...opts.extra,
    });
  },

  /** 折线图 option */
  line(categories, series, opts = {}) {
    const seriesList = series.map((s, i) => ({
      type: 'line',
      name: s.name,
      data: s.data,
      smooth: true,
      symbol: 'circle',
      symbolSize: 6,
      lineStyle: { width: 2.5 },
      areaStyle: opts.area ? {
        opacity: 0.08,
        color: {
          type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: this.colors[i % this.colors.length] },
            { offset: 1, color: 'rgba(255,255,255,0)' },
          ],
        },
      } : undefined,
      ...s.extra,
    }));
    return this.merge({
      xAxis: { type: 'category', data: categories },
      yAxis: { type: 'value' },
      series: seriesList,
      ...opts.extra,
    });
  },

  /** 饼图 option */
  pie(data, opts = {}) {
    return this.merge({
      tooltip: { trigger: 'item' },
      legend: { bottom: 0, left: 'center' },
      series: [{
        type: 'pie',
        radius: opts.donut ? ['45%', '72%'] : '65%',
        center: ['50%', '45%'],
        data: data,
        label: {
          fontSize: 11,
          formatter: '{b}: {d}%',
        },
        itemStyle: { borderRadius: 4, borderWidth: 2, borderColor: '#fff' },
        ...opts.seriesExtra,
      }],
      ...opts.extra,
    });
  },

  /** 雷达图 option */
  radar(indicators, dataList, opts = {}) {
    return this.merge({
      radar: {
        indicator: indicators,
        axisName: { color: '#64748b', fontSize: 11 },
        splitLine: { lineStyle: { color: '#e2e8f0' } },
        splitArea: { areaStyle: { color: ['#f8fafc', '#fff'] } },
        axisLine: { lineStyle: { color: '#e2e8f0' } },
      },
      series: [{
        type: 'radar',
        data: dataList.map((item, i) => ({
          ...item,
          lineStyle: { width: 2 },
          areaStyle: { opacity: 0.15 },
          symbol: 'circle',
          symbolSize: 5,
        })),
        ...opts.seriesExtra,
      }],
      ...opts.extra,
    });
  },
};
